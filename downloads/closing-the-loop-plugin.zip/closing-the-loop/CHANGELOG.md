# Changelog

Maintainer-facing history for the Closing the Loop bundle. User-facing docs are the
[README](README.md) and [`docs/`](docs/); verified sharp edges live in
[`KNOWN-ISSUES.md`](KNOWN-ISSUES.md).

Two things live here that aren't ordinary release notes:

- **[Divergences from upstream](#divergences-from-upstream)** — every place a bundled skill deliberately
  differs from the library it was imported from. **Re-apply these on the next sync**, or push them
  upstream.
- **[Maintainer TODOs](#maintainer-todos)** — known-wrong plumbing that needs a decision before this goes
  wider than a pilot.

---

## Unreleased

### Telemetry owned by this project, extended to the whole loop

The bundled telemetry (imported with the discovery skills) posted to the upstream Discovery Engine
maintainers' Google Sheet — a maintainer TODO since bundling. Now:

- All four `hooks/track-*.sh` post to the **Closing the Loop maintainers' own webhook/Sheet**
  (owner: Cristina; shared with the maintainer team). The Apps Script side reuses the Discovery
  Engine's script (doPost + weekly summary email + aggregated `doGet` dashboard API), adapted:
  opened by ID, CTL naming, and a full-loop funnel.
- Opt-out renamed to `CLOSING_THE_LOOP_TELEMETRY_DISABLED=1`; the legacy
  `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` is still honored.
- `track-stage.sh` accepts named **loop milestones** besides the discovery stage ids:
  `activation` (logged by `closing-the-loop-start`), `publish` (logged by
  `discovery-create-tracker-issue`), `handover` (logged by `handover-shape-feature` and
  `discovery-handover-package` at completion). The funnel now covers the whole loop —
  activation → discovery → publish → handover — not just stages 0–6. Delivery progress is
  derived from `skill_invoked` (no `v-*` edits, preserving upstream parity).
- Bundle-wide `skill_invoked` is now the deliberate, documented behavior; README → Telemetry
  rewritten accordingly and the maintainer TODO closed.

### Backlog shape is decided per feature

`backlogMode` was a team-wide key read by ~10 skills as *the* shape of every feature, while the plugin's
own rationale was per feature ("worth it if the feature is too big for one PR"). The decision now lives
where the evidence is.

- **The shapers recommend, you confirm.** `handover-shape-feature` (context-first, Step 6) and
  `discovery-handover-package` (governed, Step 3.5) inspect the shaped contract, recommend `single-ticket`
  or `epic`, and ask for one confirmation per feature. Shared heuristic, confirmation shape, recording
  rule, and re-evaluation rules live in the new `references/backlog-shape-decision.md`.
- **`backlogMode` is now the team's default shape — a tie-breaker only.** Same key, same values, absent
  still means `single-ticket`; existing configs work without edits. Setup Step 1.6 is retitled "Choose
  the default backlog shape" and says so; changing it later affects only future features.
- **The artifact is the source of truth downstream.** A `> **Backlog shape:**` header line plus the
  story map (Brief `### 6.3 Story map` / Delivery Context `### Story map`) present iff epic — mirroring
  how the handover path is resolved from the ticket marker, never from config. The legacy
  `Backlog mode:` header is read as equivalent. `create-backlog-from-brief`, `handover-workflow`,
  `handover-project-stories`, `handover-deliver-epic`, `prepare-amigo-session`, `handover-brief-review`,
  and the `closing-the-loop` orchestrator all resolve the shape from the artifact.
- **`backlogTiming` is now asked for every governed team** (default `post-gate`), since any feature can
  end up epic-shaped; it applies only to those that do.
- **`prepare-amigo-session` stops on a single-ticket-shaped feature** (no story set to walk) instead of
  re-running setup mid-feature.
- **Jira reshape rule made explicit.** Single-ticket → epic after sign-offs exist uses the wrapper-Epic
  model, never a conversion (Sub-task sign-offs orphan on conversion) — new `KNOWN-ISSUES.md` entry.
- **Docs.** `docs/setup.md` Question 4 rewritten around the per-feature decision, and its stale
  `backlogMode` "Read by" row fixed (it listed the projectors and the orchestrator as readers; they read
  the artifact). "Epic mode" / "single-ticket mode" wording replaced with "epic-shaped" /
  "single-ticket-shaped" across the README, `docs/*.md`, and KNOWN-ISSUES prose. The HTML decks under
  `docs/` predate this change and still say "epic mode".

### The front door: `closing-the-loop-start`

First finding of the DataGPT end-to-end pilot (2026-09): a new user who installs the plugin has no
activation moment — the knowledge of "what do I do next" lived in the README, not in a dialogue, and
nothing detected where the *user* (as opposed to the feature) was. New skill `closing-the-loop-start`
("Start Closing the Loop"):

- silently detects config, agent context (`AGENTS.md`/`CLAUDE.md`), tracker/Figma connectors, `gh`,
  a component library, product-context docs, and **duplicate plugins** (the standalone
  discovery-engine plugin competing for the same triggers — the pilot's silent-failure cause)
- reports a plain-language readiness checklist (✅/⚠️/❌); doubles as the pilot playbook's **Week 0
  preparedness scan**, writing `closing-the-loop-readiness.md` on request
- shows a ~10-line journey map of the whole loop, then ends with an explicit closed choice —
  A) guided from the beginning · B) jump to a specific point · C) fix what's missing — echoing the
  discovery engine's welcome pattern at plugin level
- carries the engine's anytime-feedback invitation

Also from the same pilot finding: the README's *Before you install* section now warns to uninstall
the standalone discovery-engine plugin (this bundle supersedes it), because two plugins answering the
same phrase means the older one can silently win — which is exactly what happened at pilot Stage 4.

### Prototyping skills refresh (Stage 4–5 replaced)

The old generate-a-lookalike-library pipeline is replaced by the scan → remediate →
prototype → fidelity chain proven on the Dialog pilot (2026-07) and the React prototyping
workshop (2026-08), generalized here to be **stack-agnostic** (Angular, React, Vue,
Svelte, … — detected from the repo) per the project principle that no skill may hardcode
a framework or require Code Connect.

- **New `component-readiness-scan`** (Stage 4) — merges the Dialog `design-system-readiness-audit`
  and the workshop `scan-repo-for-prototyping` into one skill: classifies every component
  (🟢 reusable / 🟡 coupled / 🟠 heavy dependency / 🔴 missing or trapped), checks the repo copy can
  build, optionally cross-checks against Figma, and writes `component-inventory.md` +
  `prototype-rules.md` + two audit reports.
- **New `component-remediation`** (Stage 4, optional) — the five fix patterns (decouple / promote /
  extract / extend / build), reading project conventions from `prototype-rules.md` instead of
  hardcoding them; lab-copy safety rules and mandatory standalone verification kept from the
  Dialog original.
- **New `prototype-from-components`** (Stage 5) — builds from the team's own components;
  substitute-and-flag instead of stop-on-gap; stand-ins must compose from real inventory
  components and tokens; optional Figma-frame input; primary output is a live dev surface, with
  the standalone single-file HTML export kept as the workshop/sharing format.
- **New `prototype-fidelity-report`** (Stage 5, auto-chained) — plain-language real-vs-stand-in
  report + developer fix-list, plus a visual-match check against the Figma frame when one was
  the prototype's source.
- **Retired `discovery-component-library` and `discovery-prototype-generator`** → `retired/`, with
  superseded-by notes. The orchestrator (`discovery-to-prototype-engine`), `docs/skills.md`,
  the README, `code-connect-coverage-audit`, and the Stage 4/5 artifact contracts were rewired in
  the same change (Stage 4 now hands off `component-inventory.md` + `prototype-rules.md` instead of
  `component-library/`).
- **`discovery-component-mapper` enhanced, not retired** — gains Mode 0: resolving directly from
  `component-inventory.md` when the prototype was built by the new chain; Code Connect remains its
  optional Mode A. The README now states explicitly that Code Connect is a recommendation, never
  a requirement.

### Documentation and onboarding

- **README rewritten as a front door.** It was 390 lines serving adopters, evaluators, and maintainers at
  once, with the install and quickstart buried at line 100. It is now roughly a third of that: what this
  is, the three lanes, the 5-minute version, install, four get-started steps, an entry-points table, and
  an index. Reference detail moved out to `docs/`.
- **New `docs/setup.md`** — the canonical setup reference. The four setup questions with what each choice
  *costs* as well as what it buys, the full config schema with the default-when-absent column (previously
  visible only as two JSON blobs inside a skill), Jira auth and the classic-vs-scoped token trap,
  reconfiguring rules, and a troubleshooting table.
- **New `docs/getting-started.md`** — the step-by-step walkthrough the README defers to, absorbing the old
  Quickstart in full plus a which-lane-am-I-in orientation and "where discovery outputs land".
- **New `docs/skills.md`** — the complete catalog. Adds `handover-brief-review`, which was a real,
  config-reading skill with its own `agents/` that the README's skills section never mentioned (69 of 70
  named).
- **New `docs/pilot-guide.md`**, replacing `README-DIALOG-PILOT.md`. The old file was a letter to one named
  person about a ZIP export of `feat/amigo-session-preparer`, a branch that has since merged. Its actual
  advice — staging tracker first, the two Jira behaviours, the amigo configuration, honest token
  expectations — is now reusable by the next pilot team.
- **New `CHANGELOG.md`** (this file). `## What was changed when bundling` was a dated changelog living in
  the user-facing README, and the upstream-divergence list was prose scattered through it. Both now have a
  home.
- **New skill `closing-the-loop-getting-started`.** `discovery-getting-started` owned the broadest
  orientation triggers — "what is this plugin", "help", "what skills do I have", "where do I start" — but
  its body only explains the discovery engine. Someone installing the bundle for the handover seam or the
  delivery lane got a lane-specific answer, and there was no plugin-wide orientation skill at all. The new
  skill covers all three lanes, checks whether setup has run, and routes to the right entry point.
  `discovery-getting-started`'s triggers were narrowed to discovery-lane phrasing — see
  [divergence 7](#7-discovery-getting-started-triggers-narrowed).
- **`closing-the-loop-setup` improved** without restructuring its steps (the numbering is referenced from
  three other files): a "four questions" preview table so the shape of the run is visible before question
  one, a new Step 0 that reads an existing config and offers show / reconfigure / cancel (there was no
  re-run entry point, despite `## Triggers` advertising "check my tracker connection"), trade-off framing
  on the path and backlog choices, and a Step 7 report that prints the resulting config plus the single
  next command.

### Cold-install gaps

A read-through from an installer's perspective — rather than a maintainer's — found things the docs
assumed away. All of these were true before this release too; they were just invisible to anyone who
already knew the system.

- **Prerequisites did not exist anywhere.** The plugin ships no connectors: it drives Jira, Linear,
  Confluence, and Figma through MCP servers the user provides. Nothing said so. `closing-the-loop-setup`
  Step 1 "detects what's connected" and, finding nothing, previously just asked which tracker they intended
  and proceeded — producing a config that looks correct and fails at the first tracker write. There is now
  a **Before you install** table in the README, a per-connector and per-lane section in
  `docs/getting-started.md`, a warning at the top of `docs/setup.md`, and honest handling in the skill
  itself: it names the missing connector, explains how to add one for the user's surface, and offers
  either connect-then-re-run or scaffold-now-with-verification-pending. It no longer implies the
  configuration is complete when the connector is absent. `gh` (needed by 32 of 39 `v-*` skills) and the
  Figma MCP are also stated now. The docs name the **exact vendor plugins and install commands**
  (`/plugin install atlassian@claude-plugins-official`, same for `linear` and `figma`) rather than leaving
  the reader to hunt — see the decision note below on why we point at those instead of bundling.
- **The invocation model was never established.** Docs alternated between skill names (`v-setup-agent-context`)
  and English phrases ("Set up Closing the Loop") without ever saying which to type. The namespaced
  slash form — `/closing-the-loop:<skill>` — appeared exactly once in the repo, in the telemetry table.
  There is now a **How to run a skill** section in the README and `docs/getting-started.md`, a note in
  `docs/skills.md`, and an instruction in the orientation skill to state it early. Narrowing
  `discovery-getting-started`'s triggers had made this worse, since its `/`-menu explanation was the only
  one and is now harder to reach.
- **The "Verify" section could not be run by anyone who installed the plugin.** Both
  `bash scripts/verify-skills.sh` and `claude plugin validate .` require a checkout. It is now split into
  **Confirm the install** (type `/`, or ask the orientation skill) and a clearly-labelled maintainer
  subsection.
- **Notation was unglossed on first use.** `D-n`, `AC-n`, `S-n`, Delivery Context, and Gherkin all landed
  in the README's 5-minute version with no explanation. Those bullets now lead with the idea and follow
  with the notation, and there is a new **`docs/glossary.md`** covering the notation, the seam vocabulary,
  the config keys, and the terms nothing defined anywhere: `<KEY>` (used ~15 times, never explained), the
  `v-` prefix (39 skills, never expanded to Visma), "amigo" / three amigos, brownfield, `~/.netrc`,
  classic-vs-scoped tokens, Rail → Highway, Surface Conventions.
- **"What should I see?" was missing at both checkpoints.** `docs/getting-started.md` now states what a
  finished setup looks like, and what each path actually leaves on the ticket — including that a failed
  write, not a failed run, is the reason a ticket looks unchanged.

### Editorial: `context-first` now leads

`context-first` is the direction the project is heading, and the docs were still framed around `governed`.
Rebalanced so the recommended path leads everywhere it's presented:

- **`docs/pilot-guide.md`** — its suggested first config recommended `governed`-flavoured answers and its
  only worked example was the governed three-amigos setup. Now leads with a **`context-first` + `epic`**
  worked example, including who runs which step; the amigo configuration is kept as a clearly-labelled
  alternative for teams that specifically want the approval record.
- **`docs/setup.md`** — Question 3's comparison table puts `context-first` first, and gained two rows the
  decision actually turns on: what each path *needs* (a repo checkout) and Confluence support.
- **README** and **`closing-the-loop-setup`** — path options reordered, with `context-first` marked as the
  recommendation and the only path supporting Confluence. The skill's stored-config examples now lead with a
  `context-first` config.

**Deliberately unchanged: the technical default.** `handoverPath` still falls back to `governed` when the
key is absent, so configs predating the choice keep working. Every place that states the fallback now also
says it's backward compatibility rather than a recommendation — the editorial lead and the coded fallback are
different things, and conflating them would be a silent behaviour change. Whether the fallback itself should
flip in a future version is a product call, not a docs one.

### The seam needs a repo checkout — now documented

`handover-shape-feature` lists two required inputs, the second being *"the target repository at a known
commit"* — it reads live production code. That requirement appeared nowhere outside the skill file, which
made `context-first` look like a tracker-only workflow a PM could run unaided. It's now in the README
prerequisites table, `docs/getting-started.md`, and the setup skill, together with the work-splitting
options for someone without a checkout.

The same skill states that composing a path into `v-develop-feature` / `v-ticket-to-release` is *"the
engineering lead's call — flag it, don't assume it."* Also now surfaced in the docs, since it's a social
prerequisite for a pilot and was invisible outside the skill.

### Decision: we don't bundle MCP connectors

Recorded because it will be asked again. Plugins **can** bundle MCP servers — `.mcp.json` at the plugin
root or inline `mcpServers` in `plugin.json`, and remote OAuth servers work (`http`/`sse`/`ws` with
`url`/`headers`/`headersHelper`). We deliberately don't, for five reasons:

1. **Atlassian, Linear, and Figma each maintain their own connector plugin** in `claude-plugins-official`
   (`atlassian` → `github.com/atlassian/atlassian-mcp-server`, `figma` → `github.com/figma/mcp-server-guide`).
   Bundling copies means we own vendor endpoints and ship the fix when a vendor changes transport.
2. **Duplicate toolsets break tool selection.** A team that already has an Atlassian connector would get a
   second one, and these skills reference tools by bare name (`createJiraIssue`, `getAccessibleAtlassianResources`).
3. **It wouldn't remove the step worth removing.** Plugin-declared servers go through the same per-server
   approval as a project `.mcp.json`, and remote connectors still run their own OAuth per user. Bundling
   saves "which URL do I paste", not "authorize this".
4. **It changes what installing means** — a discovery-only PM needs no connector at all, and shouldn't be
   asked to connect the company Jira to get a prototype generator.
5. **It wouldn't help Cowork**, which doesn't read `~/.claude/` regardless.

Two implementation notes for whoever revisits this: every official plugin uses the **bare** server map in
`.mcp.json`, not the `mcpServers`-wrapped form the published example shows; and `claude plugin validate`
does not inspect `.mcp.json` at all — a wrong shape passes validation and fails at runtime.

### Corrections

- The README's Layout tree omitted `docs/`, `references/visma-conventions-template.md`, and
  `skills/handover-brief-review/`.
- The local-development install command was referenced ("point a marketplace at this checkout directly")
  but never given — it existed only in the pilot README.
- The Confluence constraint count was stale: the README said four, `KNOWN-ISSUES.md` documents five.
- `scripts/verify-skills.sh` still announced "Verifying N Handover Bridge skill(s)" — pre-bundle naming,
  printed on every run of the command the README tells you to run.
- `.gitignore` now includes `discovery-engine/`, which the README already suggested users would want
  ignored.

---

## 0.2.0

What was changed when bundling three separate skill libraries into one plugin.

- **Full library parity (2026-07-27):** the original bundle pruned 12 engineering skills as out-of-scope
  (the repo-wiki suite and friends). That pruning has been reversed — every skill in the visma-skills
  library is now bundled, so a team installing Closing the Loop gets the complete Visma engineering toolkit
  rather than a subset.
- **Synced to the visma-skills library audit (2026-07-27):** all bundled `v-` skills now track the
  condensed "one home per rule" rewrite. `v-review-security` folded into `v-review-changes` (Security Depth
  pass) and `v-onboard-repo` into `v-setup-agent-context` (First-Time Bootstrap), matching upstream. The
  Closing-the-Loop adaptations were re-applied on top — see
  [divergences](#divergences-from-upstream).
- **Naming reconciled:** the bridge keeps referring to engineering skills, now by their `v-` names
  (`v-write-spec`, `v-develop-feature`, `v-ticket-to-release`).
- **Added** the `closing-the-loop` master orchestrator.
- The verifier was loosened to a prototype bar — see [`KNOWN-ISSUES.md`](KNOWN-ISSUES.md).
- **Discovery lane synced to upstream v1.7.0** (was a pre-1.6.0 snapshot): standalone single-file HTML
  prototypes + Wizard-of-Oz agentic mode (stage 5), participant screener / operationalized success criteria
  / results-analysis guidance (stage 6), five previously-missing `references/` files, environment guards on
  every `present_files` call site, and the telemetry hooks + `discovery-feedback` skill.
- **`plugin.json` manifest fixed** — the non-schema `authors` array became the spec's singular `author`
  object. `claude plugin validate` now passes with **no warnings**; previously Claude Code ignored the field
  at load time and the plugin showed no author attribution. Same bug upstream fixed in their v1.5.1.

---

## Divergences from upstream

Eight places where a bundled skill deliberately differs from the library it came from. **Re-apply each on
the next sync**, or push it upstream behind the stated condition. The numbering continues the count the
README used to carry, so divergence 7 is genuinely the seventh.

### 1–4. Closing-the-Loop delivery adaptations (4 skills)

Marker-based governed retrieval and direct context-first Delivery Context loading in `v-develop-feature`
and `v-ticket-to-release`, plus the BHB-postmortem hardening — behavioral verification, toolchain preflight,
claim calibration, adversarial review, fail-without-fix tests, and no process artifacts on the branch — in
`v-implement-code`, `v-develop-feature`, and `v-prepare-commit`.

*Upstream:* `visma-skills`.

### 5. Feedback routing disambiguated (`v-give-feedback`)

Bundling two lanes meant two feedback skills both answering "give feedback" and reporting to different
maintainer teams. Both are now lane-scoped (`discovery-feedback` → discovery stages 0–6;
`v-give-feedback` → `v-*` delivery + the handover bridge), and both ask which lane is meant when the phrase
is bare.

*Upstream:* `visma-skills`. *Push-upstream condition:* behind a "bundled alongside a discovery lane"
condition.

### 6. Discovery lane made portable (34 sites)

Upstream targets the Cowork / claude.ai sandbox and hardcodes `/home/claude/` and
`/mnt/user-data/outputs/`. Neither exists in a local Claude Code install (on macOS `mkdir /home/claude`
fails with `Operation not supported`), so every discovery stage produced content and then failed to persist
it where the next stage looks. All 34 sites now resolve `$DISCOVERY_DIR` / `$OUTPUTS_DIR` by probing —
sandbox path first, `./discovery-engine/` in the repo as fallback — per
[`references/discovery-working-directory.md`](references/discovery-working-directory.md).
`component-library/` moved under `$DISCOVERY_DIR` so one resolved root covers a whole run, and each stage's
*primary* write is now `$DISCOVERY_DIR` with `$OUTPUTS_DIR` only ever receiving a copy.

*Upstream:* `discovery-engine-plugin`. *Push-upstream condition:* none — the probe still picks the sandbox
path in the environment upstream targets, so this is a strict improvement there.

### 7. `discovery-getting-started` triggers narrowed

Its `description` claimed the broadest orientation phrases — "what is this plugin", "help", "what skills do
I have", "what's installed", "where do I start" — while its body explains only the discovery engine. In a
three-lane bundle those phrases must reach the new plugin-wide
`closing-the-loop-getting-started` instead. Body unchanged; frontmatter only.

*Upstream:* `discovery-engine-plugin`. *Push-upstream condition:* behind a "bundled alongside other lanes"
condition — standalone, upstream's broad triggers are correct.

### 8. Prototyping skills generalized from their stack-shaped originals

The four prototyping skills are adapted, not copied. `component-readiness-scan` merges
`~/Dialog/ds-readiness-engine/design-system-readiness-audit` (Angular 20 / Nx) with
`react-workshop-prototyping/scan-repo-for-prototyping` (React) and adds runtime stack detection;
`component-remediation` reads project conventions from `prototype-rules.md` instead of hardcoding
Dialog's; `prototype-from-components` adds the compose-stand-ins-from-real-components rule, the
optional Figma-frame input, and the live-surface-primary / HTML-export-secondary delivery order;
`prototype-fidelity-report` adds the visual-match check. The originals carried an explicit
"generalise when a second product commits" note — this bundle is that commitment.

*Upstream:* the Dialog `ds-readiness-engine` and `react-workshop-prototyping` skill sets (local,
not yet published as repos). *Push-upstream condition:* none yet — this repo is now the canonical
home of the generalized versions; the Dialog/workshop copies remain stack-tuned instances.

### Smaller local adaptations (not numbered)

Also carried on top of upstream `discovery-engine-plugin`, and also needing re-application:

- `hooks/track-usage.sh` matches the `closing-the-loop:*` skill namespace rather than the upstream
  plugin's.
- `discovery-handover-package` looks for `stage-5-prototype.html` in `/home/claude/discovery-engine/`
  alongside the older paths.
- `discovery-create-tracker-issue` stamps the configured `handoverPath` marker (`discovery-handover` or
  `context-first-handover`) on the published issue or Confluence page body, which is what routes delivery
  later. Upstream has no handover-path concept, so this has no upstream counterpart to reconcile with.

---

## Maintainer TODOs

Known-wrong plumbing to settle before this goes wider than a pilot.

- ~~**Telemetry points at the upstream maintainers' sheet.**~~ Resolved 2026-09: all four
  `hooks/track-*.sh` now post to the Closing the Loop maintainers' own webhook/Sheet, and
  bundle-wide `skill_invoked` is the deliberate, documented behavior (see README → Telemetry).
- **`plugin_version` is read from this repo's `.claude-plugin/plugin.json`**, so events land tagged with the
  Closing the Loop version rather than an upstream Discovery engine version. Harmless but worth stating
  when the two sheets are compared.
- **The version is duplicated** in `.claude-plugin/plugin.json` and `.claude-plugin/marketplace.json` —
  two places to bump, with nothing asserting they match.
- **Nine unlinked HTML explainers in `docs/`**, two of which share a `<title>` and are near-duplicates
  (`closing-the-loop-paths-explained.html` and `context-first-handover-explained.html`, 2530 vs 2525
  lines). Not indexed from anywhere. Decide which survive.
- **Replace the `~/.netrc` token dance with plugin `userConfig`.** Plugins can declare config options that
  are prompted when the plugin is enabled, with sensitive values stored in the macOS Keychain (or
  `~/.claude/.credentials.json` where no keychain exists) and substituted as `${user_config.KEY}` in MCP
  configs and hook commands. That could replace the whole scaffold-a-placeholder → open-your-editor →
  paste-a-classic-token sequence, which is the clunkiest part of setup and the source of the misleading
  `401`. Blast radius: `closing-the-loop-setup` Steps 3–6, both
  `discovery-handover-package/references/jira-attachment-*.md`, and anything shelling out to
  `curl --netrc`. Needs scoping before anyone starts — note the ~2 KB total Keychain limit shared with
  OAuth tokens.
- **`track-stage.sh` and `track-feedback.sh` are not registered in `hooks/hooks.json`** — they're invoked
  from inside 10 discovery `SKILL.md` files instead. Intentional, but the asymmetry with the two registered
  hooks is easy to trip over.
