# Changelog

Maintainer-facing history for the Closing the Loop bundle. User-facing docs are the
[README](README.md) and [`docs/`](docs/); verified sharp edges live in
[`KNOWN-ISSUES.md`](KNOWN-ISSUES.md).

Two things live here that aren't ordinary release notes:

- **[Divergences from upstream](#divergences-from-upstream)** — every place a bundled skill deliberately
  differs from the library it was imported from. **Re-apply these on the next sync**, or push them
  upstream.
- **[Maintainer TODOs](#maintainer-todos)** — known-wrong plumbing that needs a decision before this goes
  wider than a pilot.

---

## 0.3.1 — 2026-11-19

Both pilots' feedback shipped as one wave — Compello's 18 Nov epic review (#52–#56, everything
live-tested against a real Azure DevOps org) and Dialog's 3 Nov session (#58):

- **Human-first ticket output (#52):** projected children open with a plain-language summary; the
  stamp (now labelled, lenient matching keeps legacy children reconciling) and the technical slice
  sit below a "not required reading" divider; on ADO the Gherkin goes to the native Acceptance
  Criteria field; outcome-only child titles; functional feature names; reconcile refreshes
  presentation-only drift on reused children.
- **Multi-repo awareness (#53):** shared `references/multi-repo.md` — repo-shape detection, the
  repo-landscape file, the working-view declaration, the escalation rule for requirements the
  visible code can't explain; per-repo base commits in the delivery contract; a Week-0
  repo-landscape check in the start scan.
- **Backend delta sketch + PM-safe counts (#54):** the fidelity report reads the prototype's mocks
  out as backend needs (exists / extend / new), and counts components reuse-first with the
  lifecycle sentence — no more alarming "N new components" tallies.
- **Azure Repos reference hardening (#55):** six behaviors verified on a live org folded into
  `v-ship/references/azure-repos.md`.
- **Team ticket format guides (#56):** opt-in `ticketFormatGuide` config key — the ticket-writing
  skills follow a team's own house format above the divider, mapped from the Delivery Context,
  with the machine block unchanged below; generalized example guide included; landscape-file
  naming flexibility (`repoLandscape`, `*landscape*.md`, nested checkouts, branch in the working
  view); terminal-state items are never silently rewritten; the ADO multiline field format
  switches only together with content in one update.
- **The Dialog wave (#58):** slices default to the smallest demonstrable piece of customer value
  (oversized stories split); the whole acceptance set is swept for cross-story contradictions at
  shaping and projection; prototype drift is flagged against the pinned commit at projection and
  delivery; story bodies gain "Not in this story" and a "Who is who" persona legend; claude.ai
  artifacts are named always-throwaway with a rebuild offer at the shaping gate, and the prototype
  is read-only evidence; prototype packs recommend URL-reachable states (`/error`, `/empty`,
  `/loading`).

### The download uploads to Claude again, and a check keeps it that way

Uploading the served zip to the Claude app failed twice in a row: first "Zip cannot contain nested
zip files" (a tracked `skills.zip`, removed in #48), then "Plugin description must be at most 500
characters". Neither is caught by `claude plugin validate` or by Claude Code.

- **Plugin description shortened** from 603 to 488 characters in `plugin.json` and `marketplace.json`.
  It had grown past the limit in 0.2.10 when the telemetry disclosure was added; the disclosure and
  the opt-out are kept in full.
- **New `scripts/validate-plugin-upload.py`** checks a `git archive` of a ref, the same archive the
  guide repo serves, against the upload rules Anthropic documents (Plugins API guide, skills docs,
  Agent Skills spec): no zip inside the zip, one manifest under a single top-level folder, no top-level
  `bin/`, no symlinks or encrypted entries, file count, size, path depth, length and characters, plugin
  name, description and display name limits, and in every skill valid YAML frontmatter with a matching
  name and a description of at most 1024 characters without XML tags.
- **Warning, not failure, for non-spec frontmatter keys** (`trigger`, `output_contract_schema`,
  `author`, `source`, `disable-model-invocation`). The docs say claude.ai skill uploads reject them;
  plugin uploads have accepted them so far. If an upload ever refuses them, that is the next fix.
- **No dry run exists** for the real upload validation, so the script can fall behind it. A rule the
  app enforces and the script misses gets added to the script.
- **New workflow `.github/workflows/validate-plugin-upload.yml`** runs it on every pull request and
  on push to `main`.

## 0.3.0 — 16 November 2026

### Delivery moves to the five core skills of visma-skills v2

**Breaking.** The 39 bundled `v-*` skills, a copy of `visma-skills` 1.x, are replaced by the five core
skills of v2 (`6575cde`): `v-scope`, `v-investigate`, `v-build`, `v-challenge`, `v-ship`, plus the
standalone `v-agent-readiness-report`. 74 skills become 41. A prompt that names a removed skill no longer resolves.

| Before | Now |
|---|---|
| `v-develop-feature`, `v-ticket-to-release`, `v-write-spec`, `v-plan-work`, `v-fix-bug`, `v-ship-feature` | `v-scope` (spec, plan and recipe references) |
| `v-debug-issue`, `v-analyze-repo` | `v-investigate` |
| `v-implement-code`, `v-run-tdd`, `v-design-frontend`, `v-test-e2e`, `v-upgrade-dependencies`, `v-update-docs` | `v-build` |
| `v-review-changes`, `v-scored-code-review`, `v-audit-readiness` | `v-challenge` |
| `v-prepare-commit`, `v-address-review`, `v-manage-ci`, `v-prepare-release`, `v-capture-learning`, `v-setup-agent-context`, `v-find-missing-documentation` | `v-ship` |
| `v-generate-wiki`, the nine `v-wiki-layer-*`, `v-give-feedback`, `v-guidance`, `v-skill-author`, `v-run-lean` | Not bundled. Wiki generation was removed upstream; the rest install with the `visma-skills` installer |

- **Handover routing is now a `v-scope` recipe.** `skills/v-scope/references/recipe-handover.md` loads a
  handover by its marker before any scoping, takes a governed Brief as the settled scope, and adds the
  pilot hardening as extra gates on the feature recipe. It replaces the edits this repo carried in four
  v1 skills. See [divergences 1–4](#divergences-from-upstream).
- **The Azure Repos PR rung moved** to `skills/v-ship/references/azure-repos.md`, unchanged.
- **Every caller renamed:** `closing-the-loop`, `handover-workflow`, `handover-deliver-epic`,
  `handover-retrieval`, `handover-shape-feature`, `discovery-handover-package` and its two templates,
  and the three front-door skills. `discovery-handover-package` now calls `v-scope` for the spec step
  only when it authors §6.
- **The agent readiness report is one step from the front door.** `v-agent-readiness-report` is bundled
  at its v2 version (report contract 2.0: it answers AIEA's capability questions, and adds the report to
  the team's AIEA assessment when AIEA's MCP server is connected and the user agrees). It is copied
  unchanged. `closing-the-loop-start` looks for an earlier run, shows it as a checklist line, offers the
  report as option D, and writes its summary into the Week 0 file `closing-the-loop-readiness.md`, so
  the two readiness reports have one entry point and one file to share. "Readiness report" now triggers
  the front door.
- **One feedback route.** `discovery-feedback` covers discovery, the handover and the delivery skills.
- **Docs and counts** in the README, `docs/` and `KNOWN-ISSUES.md` follow.

Not verified: no live run of `closing-the-loop`, `handover-workflow` or `handover-deliver-epic` was done
against the new skills. The running pilots get this as soon as the pilot zip is refreshed from `main`.

## 0.2.11 — 10 November 2026

### Agent patterns add-on, and upstream's stage-file names

The two upstream 1.8–1.9 items held back in 0.2.10. With them the discovery lane is level with
upstream 1.9.0.

- **New optional skill `discovery-agent-patterns`** (upstream 1.9.0, by Cristina Iftode and Lucia
  Wang), applying Visma's guide for Great Agentic Experiences — Amanda Lundius, Nicolae Socaciu and
  Diana Almeida's Agent Design Guidelines. Agent path only, opt-in at two points: after the agent PRD,
  a **Pattern Card** (the 5–7 patterns this agent needs, a level per task — Off, Suggest, Ask first,
  Auto — beside the Stage 3 autonomy level, and 4–5 design moments to prototype); after the prototype,
  a **pattern audit** (pass / described-not-shown / partial / gap per pattern, no score — the guide's
  own Assess page gives that). Both run standalone on any agent PRD or prototype. Adapted here:
  - **Live patterns through `gh`.** The guidelines repo is internal, so upstream's anonymous
    `raw.githubusercontent.com` fetch returns 404 and every upstream install silently uses its bundled
    copy. This version reads `patterns.json` with `gh api` when it is signed in, then tries the raw URL,
    then the bundled copy — and says which it used.
  - **Bundled copy + refresh script.** `references/patterns.md` is built from the guidelines repo by
    `scripts/sync_patterns.py` (upstream's, unchanged), which runs the guidelines' own generator. Synced
    10 Nov to build `c61e185` (guidelines updated 20 Oct; links on `agenticexperiences.visma.org`) —
    newer than upstream's bundled copy, still build `2039a8e` from 13 Oct with the old Cloud Run links.
    All 14 pattern ids are unchanged; their wording and examples changed. Run the script again before
    each release. Upstream's daily `sync-patterns.yml` is not ported: its token cannot read the internal
    repo — upstream's own runs fail on that 404 every morning while reporting success, because the error
    goes through `tee`.
  - **Stage 4 and 5 are this bundle's skills.** The Pattern Card hands off to the component scan;
    `prototype-from-components` builds the card's design moments in and offers the audit after an
    agentic prototype is approved; audit fixes go through a `prototype-from-components` refine (live
    surface, decision log, `prototype-pack.md`, re-export) instead of editing the HTML export.
  - **Agent simulation is back in Stage 5.** Upstream's Wizard-of-Oz mode (scripted agent states, an
    activity panel, real approval moments, one scripted failure) was lost when the old prototype
    generator was retired in the 2026-08 prototyping refresh; `prototype-from-components` now carries a
    stack-neutral version (step 3a), which the design moments need.
  - Wired through `discovery-agent-prd` (offers the check before Stage 4), the orchestrator (stage
    table, path announcement, file table), `discovery-experiment-plan` (turns audit gaps into test
    questions), `discovery-handover-package` (reads the card and audit as inputs) and the progress hook
    (stages `3.5` and `5.5`).
- **Stage 3 and 6 files renamed to upstream's names:** `stage-3-prd-[feature].md`,
  `stage-3-prd-agent-[feature].md`, `stage-6-experiment-plan.md`, `stage-6-usability-test-script.md`.
  Every reader also accepts the older `prd-*`, `agent-prd-*`, `experiment-plan.md` and
  `usability-test-script.md`, so runs from before this release still resolve: the orchestrator,
  `discovery-handover-package`, the progress hook, and the ctl-loop mod (`mods/ctl-loop/hooks/model.ts`,
  not yet on `main`; its tests now cover the new PRD name).
- **One file table in the orchestrator.** Its File Convention, Passing Context and "files to present"
  lists repeated each other; they are now one table of what each stage writes and who reads it,
  including the optional steps — which also keeps the skill under the 600-line cap.
- **Fixed: the PRD skills pointed at the retired Stage 4.** `discovery-prd-foundation`'s Stage 3
  handoff still asked for 5–10 product screenshots and offered "default Tailwind styles", and both PRD
  skills said "Build component library". They now describe the component scan and say "Scan our
  component library".

**Verified:** skill verifier and `claude plugin validate` (plugin and mod), the ctl-loop mod's 3 engine
tests, and the progress hook for every old and new stage name. **Not verified:** a live agent-path run
through the pattern check and audit.

## 0.2.10 — 10 November 2026

### Discovery lane synced to upstream 1.9.0 — agent patterns and stage-file renames held back

Upstream `discovery-engine-plugin` shipped 1.8.0, 1.8.1 and 1.9.0 (7–22 Oct) while this bundle was still
on 1.7.0. The stage skills were 1.7.0 plus small local edits, so the shared changes ported cleanly.

- **Stage telemetry is sent by hooks, not by the model.** Upstream found that telling the model to run
  `bash "${CLAUDE_PLUGIN_ROOT}/hooks/track-stage.sh"` failed in the field: the variable is not set for
  model-run Bash in Cowork, and in default permission mode the "silent" call asked the user for approval.
  This bundle had the same instruction at 14 places in 13 skills (including its own `activation`,
  `publish` and `handover` milestones), plus `discovery-feedback` calling `track-feedback.sh`. All are
  gone. New `hooks/track-progress.sh` — this project's own port of upstream's idea, kept dependency-light
  (no `jq`/`shasum` needed, Windows Git Bash) — runs on:
  - **file saves:** canonical stage files under `discovery-engine/` → stages `0`–`6` (current names,
    plus upstream's newer `stage-3-prd*` / `stage-6-experiment-plan*` ahead of any rename);
    `handover/<feature>-manifest.json` or `-delivery-context.md` → `handover`;
    `discovery-feedback-*.md` → the feedback event;
  - **tracker writes:** a create carrying the path marker (`discovery-handover` /
    `context-first-handover`, or the Confluence marker block) → `publish`; a write carrying a Delivery
    Context → `handover`. Reads never count, and child stories carry other markers.

  `activation` now comes from the existing Skill hook when `closing-the-loop-start` runs. Every stage
  event is sent at most once per session and now carries the session id (upstream 1.8.1).
- **Feedback is a file, not a command.** `discovery-feedback` writes
  `$DISCOVERY_DIR/feedback/discovery-feedback-<timestamp>.md` (`Rating` / `About` / `Comment`); the hook
  sends it. The 0.2.7 `about` field is kept.
- **Formula-injection guard.** Free text bound for the Sheet (feedback comment and `about`, identity
  name and team) gets a leading apostrophe when it starts with `= + - @` (upstream 1.8.1).
- **Fixed: multi-line text produced invalid JSON on macOS.** `json_escape` joined lines with sed's
  `:a;N;$!ba` loop, which BSD sed reads as a label name, so newlines went out raw and the event was
  dropped. It now joins with `awk`, also strips CR and turns tabs into spaces. Found while testing the
  feedback file; it predates this release but rarely bit while comments arrived as one-line arguments.
- **No double welcome.** Arriving from `closing-the-loop-start` or the `closing-the-loop` orchestrator,
  `discovery-to-prototype-engine` now skips its own welcome and journey map (upstream 1.8.1, adapted to
  this bundle's front door).
- **Stage skills run through the Skill tool.** The discovery orchestrator invokes each stage's skill
  instead of doing the work from memory — which matters more here than upstream, since Stages 4 and 5
  are this bundle's own skills. Only the Stage 1.3 merge stays inline.
- **Choices and next steps.** Nine stage skills (the seven upstream ones that have it, plus
  `component-readiness-scan` and `prototype-from-components`) end with upstream's block: clickable
  buttons that mirror the lettered options exactly (the 0.2.8 rule), the lettered list as fallback, and a
  progress line such as `Stage 4 of 6 · Standard path`.
- **`discovery-experiment-plan` runs standalone** — when invoked cold it asks for what is being tested,
  the riskiest assumption, and the target users (upstream 1.8.0).
- **`discovery-getting-started` retired** to `retired/`, as upstream did in 1.8.1. Its stage overview,
  inputs table and single-stage phrases moved into `closing-the-loop-getting-started`, which now also
  answers "getting started with discovery". Divergence 7 is resolved with it.
- **Telemetry disclosed in the plugin description** (`plugin.json` and `marketplace.json`), as upstream
  did in 1.9.0 — including that personalized downloads send name, email and team.

**Held back, to decide separately:** the agent patterns add-on (`discovery-agent-patterns`; its live
fetch from the internal `agent-design-guidelines` repo returns 404 without auth, so upstream installs
always use the bundled copy) and upstream's stage-file renames. **Not taken:** the Stage 0 company
question (personalized downloads already attribute usage), the Opportunity Radar (pulled upstream in
1.8.1), the `route_chosen` event, upstream's release tooling, and upstream's once-a-day cap on
`session_ended` (upstream measured it at ~97% of rows — worth a look on this sheet too).

**Verified:** the hooks against synthetic hook payloads — every stage file, duplicate and out-of-folder
saves, Windows paths, the feedback file (valid JSON, guard applied), and 12 tracker-write cases (creates
with and without the marker, child stories, a Linear update, a JQL search, an edit whose response echoes
a Delivery Context). **Not verified:** a live Claude Code or Cowork session against the Sheet. Tracker
tools named outside the Linear, Jira, Confluence, Azure DevOps and Atlassian `executeWrite` patterns
send no `publish` event rather than a wrong one.

## 0.2.9 — 9 November 2026

### Epic projection reaches Azure DevOps

`handover-project-stories` projected S-n/C-n story maps into Linear or Jira only — and Compello's
config switched to `backlogMode: epic` in today's session, so their first epic handover would have
stopped at the story map. The Azure DevOps rung now exists, written against the official
`@azure-devops/mcp` source:

- **Parent prep:** the source work item is the parent; when it sits at the requirement level
  (PBI / User Story), the dry run offers raising it to `Feature` and creating children at the
  requirement level — mirroring the Jira Epic-conversion rule. Process rejects the type change →
  `Task` children under the unchanged parent, said out loud; never a silent wrapper item.
- **Mechanics** (new *Azure DevOps specifics* subsection): children via `wit_work_item_write`
  `add_child` (native Markdown descriptions, ≤50 per call, chores before stories for safe resume),
  inspection via `wit_query` WIQL on `System.Parent` + stamp lines, dependencies via
  `wit_work_item_link_write` `predecessor`/`successor`, refresh via `update`. Markers ride
  `System.Tags` (append-only — ADO tags trigger team agents at Compello), since ADO has no labels.
- **`v-ticket-to-release`** — the ticket fetch & transition ladder now names the Azure DevOps MCP
  (`wit_work_item*`) between Jira and GitHub Issues.
- Also fixed: `marketplace.json` had been left at 0.2.5 by the last three releases; both manifests
  now carry 0.2.9.

Same honesty as the 0.2.5 PR rung: not yet exercised against a live Azure DevOps project —
Compello's epic handover this week is the dry run, reviewed 18 Nov.

### A component prototype reaches delivery as source, not as a hosted bundle

Dialog reported (27 Oct) that building from the prototype got the behavior right and the design
wrong. The shared prototype link served the delivery agent a 1.8 MB minified bundle. Tokens and
spacing were compiled to raw values, and the context-first Delivery Context had no place for design.
The skills also told teams the hosted link was preferred because it "carries the design context and
tokens", which is false for a built app.

- **New shared rule:** [`references/prototype-handover.md`](references/prototype-handover.md). The
  prototype's *kind* decides what crosses into implementation. A **throwaway** prototype stays intent
  documentation only. A **component** prototype's source is the UI reference implementation,
  ported under a port rule: markup, components, and token usage, but never mock data, stand-ins, kit
  import paths, or hard-coded copy. The old "intent documentation only" rule came from the first
  pilot, whose frontend was not component-based. It now applies only to that kind.
- **`prototype-from-components`** writes `prototype-pack.md` at the source root on approval: the
  source location with a pinned commit, the design-system origin, how to run it, and the files per
  screen and state.
- **`discovery-create-tracker-issue`** keeps the hosted link for people and adds a `Prototype
  source:` line (or the attached source zip) for agents.
- **`handover-shape-feature` and its delivery contract** gain a `Prototype:` header line and a
  `UI reference` section: files, components with key props, and tokens per screen and state, mapped
  to `D-n`. Delivery step 8 opens those files at the pinned commit. `v-ticket-to-release` and
  `v-develop-feature` already read the contract, so no `v-*` skill changed.
- **Governed path** (`discovery-handover-package`, its Brief and bootstrap templates,
  `handover-codebase-discovery`): the unconditional "intent only" wording is now kind-aware, which
  removes the contradiction with its own "Prototype source" input row.

## 0.2.8 — 9 November 2026

The start skill's choice buttons now mirror the lettered options exactly. Sessions were
improvising buttons that drifted from the A/B/C text (a missing B, a repair action shown as
its own button). The skill now instructs: one button per letter, same labels, nothing else;
repair actions belong inside C.

## 0.2.7 — 5 November 2026

Feedback events now say what they are about. `track-feedback.sh` takes an optional third
argument — a short label for the part of the loop the feedback concerns ("discovery", a stage, a
skill name) — sent as the event's `extra` field, which the telemetry sheet already stores in
column H, so no server change is needed. `discovery-feedback` derives the label from the
conversation and passes it. Feedback stays fully anonymous: the label is routing, not identity.

## 0.2.6 — 3 November 2026

### Identified downloads: telemetry can now say who, not just how many

productos.visma.org serves each signed-in download with a `telemetry-identity.json` baked into the
zip (download token, name, work email, team — loop-os #80/#81). The hooks now read it:

- **`telemetry-lib.sh`** — new `identity_fields()` helper: reads the identity file once per event,
  escapes the values, and returns a JSON fragment; missing file → empty string, so zips from the
  public guide page send byte-identical events to 0.2.5.
- **`track-usage.sh` / `track-stage.sh` / `track-session-end.sh`** — payloads append
  `identity_token`, `user_email`, `user_name`, `user_team` when present.
- **`track-feedback.sh`** — deliberately unchanged: the skills promise feedback is completely
  anonymous, so it never carries identity, even on identified copies.
- **README → Telemetry** — documents identified downloads, the per-copy anonymity escape hatch
  (delete the file), and that the opt-out env var covers everything.

Server side: the Apps Script webhook gains columns K–N (Identity Token, User Email, User Name,
User Team) — additive, so old rows, the dashboard doGet and the Dashboard tab formulas are
untouched. Remember the rule: after editing the script, bump BOTH deployments.

## 0.2.5 — 2 November 2026

### The Azure Repos PR rung is now real

The delivery lane's PR ladder named "Bitbucket / Azure Repos / GitLab equivalents" with no mechanism
behind them (KNOWN-ISSUES, residual defect of the epic-walker entry), so an Azure Repos team degraded
straight to user-provided actions — PR creation, merge, post-merge CI and the ticket transition all
manual. The Azure Repos rung now exists, written against the official `@azure-devops/mcp` source:

- **`v-ticket-to-release`** — PR and CI ladders point at the new
  `skills/v-ticket-to-release/references/azure-repos.md`: the operation→tool mapping
  (`repo_pull_request_write` create / update / update_reviewers, `repo_pull_request_thread*` for
  review comments, `pipelines_build` / `pipelines_build_log` for CI) plus the behavioral traps —
  merge is autocomplete-only (report "merge submitted", confirm via `get`; policy-blocked PRs are the
  walker's `awaiting-merge` state), PR descriptions cap at 4,000 characters, `transitionWorkItems`
  moves linked work items on merge so the post-merge ticket transition is native, and never
  `bypassPolicy` or vote on your own PR.
- **`v-prepare-commit`** — the PR-creation tooling note teaches the create call (full refs,
  `isDraft`, `workItems` linking the ticket, description budget).
- **`v-address-review`** — comment fetch / reply / resolve and CI reads on Azure DevOps.
- **`v-manage-ci`** — Azure Pipelines status, failing-step logs, and re-trigger tools named.

The rung verifies the tools exist before relying on them (older server generations expose per-action
names like `repo_create_pull_request` — match by `repo_` prefix) and degrades to user-provided
actions exactly as before when the server is absent. Bitbucket and GitLab stay nominal. Not yet
exercised against a live Azure Repos repo — Compello's first build session is the dry run.

## 0.2.4 — 27 October 2026

### Skill frontmatter passes claude.ai / Cowork upload checks

Pilot users who uploaded the zip under **Customize → Plugins** hit validation errors. Claude Code
accepts the frontmatter as it was, so the problems never showed up locally; `claude plugin validate`
passes either way. Fixed:

- **Two descriptions were invalid YAML.** `handover-project-stories` and `v-give-feedback` had an
  unquoted `: ` inside the description, which a strict YAML parser rejects. The upload requires
  parseable frontmatter in every `SKILL.md`. Both are now quoted; wording unchanged.
- **Three descriptions exceeded the 1,024-character limit** from the Agent Skills spec, which the
  Claude app has refused since v2.26454.0 (6 Oct 2026): `code-connect-coverage-audit` (1,254),
  `code-connect-setup` (1,202), `figma-readiness-check` (1,112). Each is now under 500 characters,
  this repo's verifier threshold. The trims also drop references to `library-freshness-check` and
  `components-from-figma`, which are not in this bundle.

Not changed here: the non-spec frontmatter keys (`trigger`, `output_contract_schema`, `author`,
`source`). Standalone claude.ai skill uploads reject them; whether plugin uploads do is undocumented.

## 0.2.3 — 5 October 2026

### Front door tells you when you're outdated

`closing-the-loop-start`'s preparedness scan now checks the installed version against the
guide page's public `downloads/version.json` (3-second timeout; skipped silently when
offline — no false warnings behind a firewall). When outdated, the readiness checklist
shows the update path that matches the install: GitHub-marketplace installs get the two
`claude plugin … update` commands, zip installs (the pilot teams — no repo access, so
those commands are no-ops for them) get the re-download link. Detection is the presence
of a `.git` directory in the installed plugin/marketplace folder; when unsure, both
paths are shown, labeled.

Why now: pilot machines only learn about releases via Slack messages. The plugin can
say it itself, at the moment the user is already at the front door.

## 0.2.2 — 5 October 2026

### Telemetry hardening — Windows support and three silent leaks fixed

The dashboard showed zero plugin events despite three pilot readiness scans. Diagnosis found three
independent silent failures; all fixed:

- **Windows (Git Bash) now works.** `hooks.json` invokes the scripts via `bash` (a `.sh` executed
  directly fails silently on Windows), and all four `track-*.sh` scripts plus a new shared
  `telemetry-lib.sh` drop the hard `jq`/`shasum` dependencies — field extraction and hashing fall back
  through jq → node → python3 → sed, and shasum → sha256sum → openssl → node. Machine hashes stay
  byte-identical to the old `echo | shasum` scheme.
- **Bare skill names are no longer dropped.** The usage filter accepted only `closing-the-loop:*`;
  a hook payload carrying the un-namespaced skill name was silently skipped. Bare names that exist in
  the plugin's own `skills/` folder are now accepted and normalized.
- Reminder: installs from before v0.2.1 still post to the upstream Discovery Engine sheet — update
  with `claude plugin marketplace update closing-the-loop` + `claude plugin update closing-the-loop`.

### Docs

- Removed the nine unlinked HTML explainers from `docs/` (the July handover-flow diagrams, the two unbuilt handover alternatives and their decision deck, and the three path explainers). The markdown guides remain the documentation index.

### Multi-repo products + Azure DevOps PAT self-service (Compello pilot findings)

Compello's product spans ~20 repos opened together as a VS Code workspace; they scanned one
(the right one for the pilot feature). Two findings turned into fixes:

- **`component-readiness-scan`** treats multi-repo products as first-class: it accepts several
  repo paths or a `.code-workspace`, asks which repos hold frontend components instead of
  guessing, records scanned-vs-skipped scope in the report header, and states the honest cost
  of skipping ("components in unscanned repos are invisible — a prototype needing one gets a
  stand-in"). A merged multi-repo inventory carries a Repo column; components outside the
  prototyping surface's repo are 🟡 at best.
- **`closing-the-loop-start`** detects multi-repo folders/workspaces and plans the
  "which repo is the frontend?" question — and never treats a folder name as an app to launch
  (a workspace named `CTL` once triggered the app-launcher instead of the front door).
- **`AZURE_DEVOPS_PAT` is now self-service**: the setup skill carries the exact create-and-set
  steps (dev.azure.com PAT with Work Items Read & Write; `setx` on Windows / `export` on
  macOS+Linux; restart Claude Code) after a pilot engineer reasonably asked "where do I put
  this?" and the one-liner had no answer.

## 0.2.1 — 25 September 2026

From this release on, **every release bumps the version number** (plugin.json + marketplace.json
together). Everything below shipped in the v0.2.0-labeled zips since September; 0.2.1 is the first
honest label.

### Prototype decision log (Dialog pilot request)

`prototype-from-components` now appends a four-line entry to `prototype-decision-log.md` on the
initial build and every refine round — requested by, change, why, touched. Dialog's designers review
prototypes with their developers; the log lets a reviewer see what changed and why without replaying
the session. The handover skills may cite it as decision evidence.

### Azure DevOps as a third tracker (context-first path)

First Compello pilot requirement: their tracker is Azure DevOps. `tracker: "azure-devops"` is now a
first-class option on the context-first path, using Microsoft's official MCP server (`@azure-devops/mcp`,
preview) — `closing-the-loop-setup` detects it and records an `azureDevops` config block (organization,
project, work item type); `discovery-create-tracker-issue` publishes the PRD as a work item (Markdown →
HTML description, marker as a `System.Tags` tag, prototype attached via REST when `AZURE_DEVOPS_PAT` is
set, else linked; the work item ID is the handle); `handover-shape-feature` reads and writes the Delivery
Context on the work item in HTML and never disturbs existing tags (Compello's own agents trigger on ADO
tags — the integration point, not a conflict). Governed-path ADO support (sign-off sub-issues, package
attachments) is deliberately not included yet; governed teams stay on Jira/Linear.

### Telemetry owned by this project, extended to the whole loop

The bundled telemetry (imported with the discovery skills) posted to the upstream Discovery Engine
maintainers' Google Sheet — a maintainer TODO since bundling. Now:

- All four `hooks/track-*.sh` post to the **Closing the Loop maintainers' own webhook/Sheet**
  (owner: Cristina; shared with the maintainer team). The Apps Script side reuses the Discovery
  Engine's script (doPost + weekly summary email + aggregated `doGet` dashboard API), adapted:
  opened by ID, CTL naming, and a full-loop funnel.
- Opt-out renamed to `CLOSING_THE_LOOP_TELEMETRY_DISABLED=1`; the legacy
  `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` is still honored.
- `track-stage.sh` accepts named **loop milestones** besides the discovery stage ids:
  `activation` (logged by `closing-the-loop-start`), `publish` (logged by
  `discovery-create-tracker-issue`), `handover` (logged by `handover-shape-feature` and
  `discovery-handover-package` at completion). The funnel now covers the whole loop —
  activation → discovery → publish → handover — not just stages 0–6. Delivery progress is
  derived from `skill_invoked` (no `v-*` edits, preserving upstream parity).
- Bundle-wide `skill_invoked` is now the deliberate, documented behavior; README → Telemetry
  rewritten accordingly and the maintainer TODO closed.

### Backlog shape is decided per feature

`backlogMode` was a team-wide key read by ~10 skills as *the* shape of every feature, while the plugin's
own rationale was per feature ("worth it if the feature is too big for one PR"). The decision now lives
where the evidence is.

- **The shapers recommend, you confirm.** `handover-shape-feature` (context-first, Step 6) and
  `discovery-handover-package` (governed, Step 3.5) inspect the shaped contract, recommend `single-ticket`
  or `epic`, and ask for one confirmation per feature. Shared heuristic, confirmation shape, recording
  rule, and re-evaluation rules live in the new `references/backlog-shape-decision.md`.
- **`backlogMode` is now the team's default shape — a tie-breaker only.** Same key, same values, absent
  still means `single-ticket`; existing configs work without edits. Setup Step 1.6 is retitled "Choose
  the default backlog shape" and says so; changing it later affects only future features.
- **The artifact is the source of truth downstream.** A `> **Backlog shape:**` header line plus the
  story map (Brief `### 6.3 Story map` / Delivery Context `### Story map`) present iff epic — mirroring
  how the handover path is resolved from the ticket marker, never from config. The legacy
  `Backlog mode:` header is read as equivalent. `create-backlog-from-brief`, `handover-workflow`,
  `handover-project-stories`, `handover-deliver-epic`, `prepare-amigo-session`, `handover-brief-review`,
  and the `closing-the-loop` orchestrator all resolve the shape from the artifact.
- **`backlogTiming` is now asked for every governed team** (default `post-gate`), since any feature can
  end up epic-shaped; it applies only to those that do.
- **`prepare-amigo-session` stops on a single-ticket-shaped feature** (no story set to walk) instead of
  re-running setup mid-feature.
- **Jira reshape rule made explicit.** Single-ticket → epic after sign-offs exist uses the wrapper-Epic
  model, never a conversion (Sub-task sign-offs orphan on conversion) — new `KNOWN-ISSUES.md` entry.
- **Docs.** `docs/setup.md` Question 4 rewritten around the per-feature decision, and its stale
  `backlogMode` "Read by" row fixed (it listed the projectors and the orchestrator as readers; they read
  the artifact). "Epic mode" / "single-ticket mode" wording replaced with "epic-shaped" /
  "single-ticket-shaped" across the README, `docs/*.md`, and KNOWN-ISSUES prose. The HTML decks under
  `docs/` predated this change and still said "epic mode"; they were removed later.

### The front door: `closing-the-loop-start`

First finding of the DataGPT end-to-end pilot (2026-09): a new user who installs the plugin has no
activation moment — the knowledge of "what do I do next" lived in the README, not in a dialogue, and
nothing detected where the *user* (as opposed to the feature) was. New skill `closing-the-loop-start`
("Start Closing the Loop"):

- silently detects config, agent context (`AGENTS.md`/`CLAUDE.md`), tracker/Figma connectors, `gh`,
  a component library, product-context docs, and **duplicate plugins** (the standalone
  discovery-engine plugin competing for the same triggers — the pilot's silent-failure cause)
- reports a plain-language readiness checklist (✅/⚠️/❌); doubles as the pilot playbook's **Week 0
  preparedness scan**, writing `closing-the-loop-readiness.md` on request
- shows a ~10-line journey map of the whole loop, then ends with an explicit closed choice —
  A) guided from the beginning · B) jump to a specific point · C) fix what's missing — echoing the
  discovery engine's welcome pattern at plugin level
- carries the engine's anytime-feedback invitation

Also from the same pilot finding: the README's *Before you install* section now warns to uninstall
the standalone discovery-engine plugin (this bundle supersedes it), because two plugins answering the
same phrase means the older one can silently win — which is exactly what happened at pilot Stage 4.

### Prototyping skills refresh (Stage 4–5 replaced)

The old generate-a-lookalike-library pipeline is replaced by the scan → remediate →
prototype → fidelity chain proven on the Dialog pilot (2026-07) and the React prototyping
workshop (2026-08), generalized here to be **stack-agnostic** (Angular, React, Vue,
Svelte, … — detected from the repo) per the project principle that no skill may hardcode
a framework or require Code Connect.

- **New `component-readiness-scan`** (Stage 4) — merges the Dialog `design-system-readiness-audit`
  and the workshop `scan-repo-for-prototyping` into one skill: classifies every component
  (🟢 reusable / 🟡 coupled / 🟠 heavy dependency / 🔴 missing or trapped), checks the repo copy can
  build, optionally cross-checks against Figma, and writes `component-inventory.md` +
  `prototype-rules.md` + two audit reports.
- **New `component-remediation`** (Stage 4, optional) — the five fix patterns (decouple / promote /
  extract / extend / build), reading project conventions from `prototype-rules.md` instead of
  hardcoding them; lab-copy safety rules and mandatory standalone verification kept from the
  Dialog original.
- **New `prototype-from-components`** (Stage 5) — builds from the team's own components;
  substitute-and-flag instead of stop-on-gap; stand-ins must compose from real inventory
  components and tokens; optional Figma-frame input; primary output is a live dev surface, with
  the standalone single-file HTML export kept as the workshop/sharing format.
- **New `prototype-fidelity-report`** (Stage 5, auto-chained) — plain-language real-vs-stand-in
  report + developer fix-list, plus a visual-match check against the Figma frame when one was
  the prototype's source.
- **Retired `discovery-component-library` and `discovery-prototype-generator`** → `retired/`, with
  superseded-by notes. The orchestrator (`discovery-to-prototype-engine`), `docs/skills.md`,
  the README, `code-connect-coverage-audit`, and the Stage 4/5 artifact contracts were rewired in
  the same change (Stage 4 now hands off `component-inventory.md` + `prototype-rules.md` instead of
  `component-library/`).
- **`discovery-component-mapper` enhanced, not retired** — gains Mode 0: resolving directly from
  `component-inventory.md` when the prototype was built by the new chain; Code Connect remains its
  optional Mode A. The README now states explicitly that Code Connect is a recommendation, never
  a requirement.

### Documentation and onboarding

- **README rewritten as a front door.** It was 390 lines serving adopters, evaluators, and maintainers at
  once, with the install and quickstart buried at line 100. It is now roughly a third of that: what this
  is, the three lanes, the 5-minute version, install, four get-started steps, an entry-points table, and
  an index. Reference detail moved out to `docs/`.
- **New `docs/setup.md`** — the canonical setup reference. The four setup questions with what each choice
  *costs* as well as what it buys, the full config schema with the default-when-absent column (previously
  visible only as two JSON blobs inside a skill), Jira auth and the classic-vs-scoped token trap,
  reconfiguring rules, and a troubleshooting table.
- **New `docs/getting-started.md`** — the step-by-step walkthrough the README defers to, absorbing the old
  Quickstart in full plus a which-lane-am-I-in orientation and "where discovery outputs land".
- **New `docs/skills.md`** — the complete catalog. Adds `handover-brief-review`, which was a real,
  config-reading skill with its own `agents/` that the README's skills section never mentioned (69 of 70
  named).
- **New `docs/pilot-guide.md`**, replacing `README-DIALOG-PILOT.md`. The old file was a letter to one named
  person about a ZIP export of `feat/amigo-session-preparer`, a branch that has since merged. Its actual
  advice — staging tracker first, the two Jira behaviours, the amigo configuration, honest token
  expectations — is now reusable by the next pilot team.
- **New `CHANGELOG.md`** (this file). `## What was changed when bundling` was a dated changelog living in
  the user-facing README, and the upstream-divergence list was prose scattered through it. Both now have a
  home.
- **New skill `closing-the-loop-getting-started`.** `discovery-getting-started` owned the broadest
  orientation triggers — "what is this plugin", "help", "what skills do I have", "where do I start" — but
  its body only explains the discovery engine. Someone installing the bundle for the handover seam or the
  delivery lane got a lane-specific answer, and there was no plugin-wide orientation skill at all. The new
  skill covers all three lanes, checks whether setup has run, and routes to the right entry point.
  `discovery-getting-started`'s triggers were narrowed to discovery-lane phrasing — see
  [divergence 7](#7-discovery-getting-started-triggers-narrowed).
- **`closing-the-loop-setup` improved** without restructuring its steps (the numbering is referenced from
  three other files): a "four questions" preview table so the shape of the run is visible before question
  one, a new Step 0 that reads an existing config and offers show / reconfigure / cancel (there was no
  re-run entry point, despite `## Triggers` advertising "check my tracker connection"), trade-off framing
  on the path and backlog choices, and a Step 7 report that prints the resulting config plus the single
  next command.

### Cold-install gaps

A read-through from an installer's perspective — rather than a maintainer's — found things the docs
assumed away. All of these were true before this release too; they were just invisible to anyone who
already knew the system.

- **Prerequisites did not exist anywhere.** The plugin ships no connectors: it drives Jira, Linear,
  Confluence, and Figma through MCP servers the user provides. Nothing said so. `closing-the-loop-setup`
  Step 1 "detects what's connected" and, finding nothing, previously just asked which tracker they intended
  and proceeded — producing a config that looks correct and fails at the first tracker write. There is now
  a **Before you install** table in the README, a per-connector and per-lane section in
  `docs/getting-started.md`, a warning at the top of `docs/setup.md`, and honest handling in the skill
  itself: it names the missing connector, explains how to add one for the user's surface, and offers
  either connect-then-re-run or scaffold-now-with-verification-pending. It no longer implies the
  configuration is complete when the connector is absent. `gh` (needed by 32 of 39 `v-*` skills) and the
  Figma MCP are also stated now. The docs name the **exact vendor plugins and install commands**
  (`/plugin install atlassian@claude-plugins-official`, same for `linear` and `figma`) rather than leaving
  the reader to hunt — see the decision note below on why we point at those instead of bundling.
- **The invocation model was never established.** Docs alternated between skill names (`v-setup-agent-context`)
  and English phrases ("Set up Closing the Loop") without ever saying which to type. The namespaced
  slash form — `/closing-the-loop:<skill>` — appeared exactly once in the repo, in the telemetry table.
  There is now a **How to run a skill** section in the README and `docs/getting-started.md`, a note in
  `docs/skills.md`, and an instruction in the orientation skill to state it early. Narrowing
  `discovery-getting-started`'s triggers had made this worse, since its `/`-menu explanation was the only
  one and is now harder to reach.
- **The "Verify" section could not be run by anyone who installed the plugin.** Both
  `bash scripts/verify-skills.sh` and `claude plugin validate .` require a checkout. It is now split into
  **Confirm the install** (type `/`, or ask the orientation skill) and a clearly-labelled maintainer
  subsection.
- **Notation was unglossed on first use.** `D-n`, `AC-n`, `S-n`, Delivery Context, and Gherkin all landed
  in the README's 5-minute version with no explanation. Those bullets now lead with the idea and follow
  with the notation, and there is a new **`docs/glossary.md`** covering the notation, the seam vocabulary,
  the config keys, and the terms nothing defined anywhere: `<KEY>` (used ~15 times, never explained), the
  `v-` prefix (39 skills, never expanded to Visma), "amigo" / three amigos, brownfield, `~/.netrc`,
  classic-vs-scoped tokens, Rail → Highway, Surface Conventions.
- **"What should I see?" was missing at both checkpoints.** `docs/getting-started.md` now states what a
  finished setup looks like, and what each path actually leaves on the ticket — including that a failed
  write, not a failed run, is the reason a ticket looks unchanged.

### Editorial: `context-first` now leads

`context-first` is the direction the project is heading, and the docs were still framed around `governed`.
Rebalanced so the recommended path leads everywhere it's presented:

- **`docs/pilot-guide.md`** — its suggested first config recommended `governed`-flavoured answers and its
  only worked example was the governed three-amigos setup. Now leads with a **`context-first` + `epic`**
  worked example, including who runs which step; the amigo configuration is kept as a clearly-labelled
  alternative for teams that specifically want the approval record.
- **`docs/setup.md`** — Question 3's comparison table puts `context-first` first, and gained two rows the
  decision actually turns on: what each path *needs* (a repo checkout) and Confluence support.
- **README** and **`closing-the-loop-setup`** — path options reordered, with `context-first` marked as the
  recommendation and the only path supporting Confluence. The skill's stored-config examples now lead with a
  `context-first` config.

**Deliberately unchanged: the technical default.** `handoverPath` still falls back to `governed` when the
key is absent, so configs predating the choice keep working. Every place that states the fallback now also
says it's backward compatibility rather than a recommendation — the editorial lead and the coded fallback are
different things, and conflating them would be a silent behaviour change. Whether the fallback itself should
flip in a future version is a product call, not a docs one.

### The seam needs a repo checkout — now documented

`handover-shape-feature` lists two required inputs, the second being *"the target repository at a known
commit"* — it reads live production code. That requirement appeared nowhere outside the skill file, which
made `context-first` look like a tracker-only workflow a PM could run unaided. It's now in the README
prerequisites table, `docs/getting-started.md`, and the setup skill, together with the work-splitting
options for someone without a checkout.

The same skill states that composing a path into `v-develop-feature` / `v-ticket-to-release` is *"the
engineering lead's call — flag it, don't assume it."* Also now surfaced in the docs, since it's a social
prerequisite for a pilot and was invisible outside the skill.

### Decision: we don't bundle MCP connectors

Recorded because it will be asked again. Plugins **can** bundle MCP servers — `.mcp.json` at the plugin
root or inline `mcpServers` in `plugin.json`, and remote OAuth servers work (`http`/`sse`/`ws` with
`url`/`headers`/`headersHelper`). We deliberately don't, for five reasons:

1. **Atlassian, Linear, and Figma each maintain their own connector plugin** in `claude-plugins-official`
   (`atlassian` → `github.com/atlassian/atlassian-mcp-server`, `figma` → `github.com/figma/mcp-server-guide`).
   Bundling copies means we own vendor endpoints and ship the fix when a vendor changes transport.
2. **Duplicate toolsets break tool selection.** A team that already has an Atlassian connector would get a
   second one, and these skills reference tools by bare name (`createJiraIssue`, `getAccessibleAtlassianResources`).
3. **It wouldn't remove the step worth removing.** Plugin-declared servers go through the same per-server
   approval as a project `.mcp.json`, and remote connectors still run their own OAuth per user. Bundling
   saves "which URL do I paste", not "authorize this".
4. **It changes what installing means** — a discovery-only PM needs no connector at all, and shouldn't be
   asked to connect the company Jira to get a prototype generator.
5. **It wouldn't help Cowork**, which doesn't read `~/.claude/` regardless.

Two implementation notes for whoever revisits this: every official plugin uses the **bare** server map in
`.mcp.json`, not the `mcpServers`-wrapped form the published example shows; and `claude plugin validate`
does not inspect `.mcp.json` at all — a wrong shape passes validation and fails at runtime.

### Corrections

- The README's Layout tree omitted `docs/`, `references/visma-conventions-template.md`, and
  `skills/handover-brief-review/`.
- The local-development install command was referenced ("point a marketplace at this checkout directly")
  but never given — it existed only in the pilot README.
- The Confluence constraint count was stale: the README said four, `KNOWN-ISSUES.md` documents five.
- `scripts/verify-skills.sh` still announced "Verifying N Handover Bridge skill(s)" — pre-bundle naming,
  printed on every run of the command the README tells you to run.
- `.gitignore` now includes `discovery-engine/`, which the README already suggested users would want
  ignored.

---

## 0.2.0

What was changed when bundling three separate skill libraries into one plugin.

- **Full library parity (2026-07-27):** the original bundle pruned 12 engineering skills as out-of-scope
  (the repo-wiki suite and friends). That pruning has been reversed — every skill in the visma-skills
  library is now bundled, so a team installing Closing the Loop gets the complete Visma engineering toolkit
  rather than a subset.
- **Synced to the visma-skills library audit (2026-07-27):** all bundled `v-` skills now track the
  condensed "one home per rule" rewrite. `v-review-security` folded into `v-review-changes` (Security Depth
  pass) and `v-onboard-repo` into `v-setup-agent-context` (First-Time Bootstrap), matching upstream. The
  Closing-the-Loop adaptations were re-applied on top — see
  [divergences](#divergences-from-upstream).
- **Naming reconciled:** the bridge keeps referring to engineering skills, now by their `v-` names
  (`v-write-spec`, `v-develop-feature`, `v-ticket-to-release`).
- **Added** the `closing-the-loop` master orchestrator.
- The verifier was loosened to a prototype bar — see [`KNOWN-ISSUES.md`](KNOWN-ISSUES.md).
- **Discovery lane synced to upstream v1.7.0** (was a pre-1.6.0 snapshot): standalone single-file HTML
  prototypes + Wizard-of-Oz agentic mode (stage 5), participant screener / operationalized success criteria
  / results-analysis guidance (stage 6), five previously-missing `references/` files, environment guards on
  every `present_files` call site, and the telemetry hooks + `discovery-feedback` skill.
- **`plugin.json` manifest fixed** — the non-schema `authors` array became the spec's singular `author`
  object. `claude plugin validate` now passes with **no warnings**; previously Claude Code ignored the field
  at load time and the plugin showed no author attribution. Same bug upstream fixed in their v1.5.1.

---

## Divergences from upstream

Nine places where a bundled skill deliberately differs from the library it came from. **Re-apply each on
the next sync**, or push it upstream behind the stated condition. The numbering continues the count the
README used to carry, so divergence 7 is genuinely the seventh.

### 1–4. Closing-the-Loop delivery adaptations (2 skills, since 0.3.0)

The bundled `v-*` skills are the five core skills of `visma-skills` v2 at `6575cde`, copied unchanged
except for these additions. On the next sync, copy upstream over them and re-add:

- **`v-scope`:** the file `references/recipe-handover.md`, its row in the References table, and the
  paragraph in step 1 that sends a handover ticket to it. The recipe carries what used to be edits in
  `v-develop-feature`, `v-ticket-to-release`, `v-implement-code` and `v-prepare-commit`: routing by
  handover marker, the governed Brief as settled scope, direct context-first Delivery Context loading,
  the in-flight ticket transition, and the BHB-postmortem hardening (toolchain preflight, behavioural
  verification, claim calibration, adversarial review, fail-without-fix tests, no process artifacts on
  the branch). The two additions put `SKILL.md` at 8,294 bytes, over upstream's 8,000-byte cap; this
  repo's verifier caps lines, not bytes.
- **`v-ship`:** the file `references/azure-repos.md` (the Azure Repos PR rung, unchanged from 0.2.5) and
  its row in the References table. Upstream names Azure Repos but gives no mechanism.

*Upstream:* `visma-skills`. *Push-upstream condition:* the Azure Repos reference is general and could go
upstream as it is; the handover recipe only makes sense beside this bundle's handover skills.

### 5. ~~Feedback routing disambiguated (`v-give-feedback`)~~ — resolved in 0.3.0

`v-give-feedback` is no longer bundled. `discovery-feedback` is the one feedback route and covers
discovery, the handover bridge and the delivery skills.

### 6. Discovery lane made portable (34 sites)

Upstream targets the Cowork / claude.ai sandbox and hardcodes `/home/claude/` and
`/mnt/user-data/outputs/`. Neither exists in a local Claude Code install (on macOS `mkdir /home/claude`
fails with `Operation not supported`), so every discovery stage produced content and then failed to persist
it where the next stage looks. All 34 sites now resolve `$DISCOVERY_DIR` / `$OUTPUTS_DIR` by probing —
sandbox path first, `./discovery-engine/` in the repo as fallback — per
[`references/discovery-working-directory.md`](references/discovery-working-directory.md).
`component-library/` moved under `$DISCOVERY_DIR` so one resolved root covers a whole run, and each stage's
*primary* write is now `$DISCOVERY_DIR` with `$OUTPUTS_DIR` only ever receiving a copy.

*Upstream:* `discovery-engine-plugin`. *Push-upstream condition:* none — the probe still picks the sandbox
path in the environment upstream targets, so this is a strict improvement there.

### 7. ~~`discovery-getting-started` triggers narrowed~~ — resolved in 0.2.10

Resolved by retiring the skill, as upstream did in 1.8.1; `closing-the-loop-getting-started` now carries
the discovery-stage orientation. Kept below for the history.

Its `description` claimed the broadest orientation phrases — "what is this plugin", "help", "what skills do
I have", "what's installed", "where do I start" — while its body explains only the discovery engine. In a
three-lane bundle those phrases must reach the new plugin-wide
`closing-the-loop-getting-started` instead. Body unchanged; frontmatter only.

*Upstream:* `discovery-engine-plugin`. *Push-upstream condition:* behind a "bundled alongside other lanes"
condition — standalone, upstream's broad triggers are correct.

### 8. Prototyping skills generalized from their stack-shaped originals

The four prototyping skills are adapted, not copied. `component-readiness-scan` merges
`~/Dialog/ds-readiness-engine/design-system-readiness-audit` (Angular 20 / Nx) with
`react-workshop-prototyping/scan-repo-for-prototyping` (React) and adds runtime stack detection;
`component-remediation` reads project conventions from `prototype-rules.md` instead of hardcoding
Dialog's; `prototype-from-components` adds the compose-stand-ins-from-real-components rule, the
optional Figma-frame input, and the live-surface-primary / HTML-export-secondary delivery order;
`prototype-fidelity-report` adds the visual-match check. The originals carried an explicit
"generalise when a second product commits" note — this bundle is that commitment.

*Upstream:* the Dialog `ds-readiness-engine` and `react-workshop-prototyping` skill sets (local,
not yet published as repos). *Push-upstream condition:* none yet — this repo is now the canonical
home of the generalized versions; the Dialog/workshop copies remain stack-tuned instances.

### 9. Agent patterns add-on adapted to this bundle

`discovery-agent-patterns` reads live patterns through `gh` (the guidelines repo is internal), writes to
`$DISCOVERY_DIR`, hands off to this bundle's Stage 4 and 5 skills, and routes audit fixes through
`prototype-from-components`, whose step 3a carries the agent simulation upstream keeps in its
generator. `scripts/sync_patterns.py` is upstream's, unchanged; the bundled `references/patterns.md` it
produces is newer here than upstream's (build `c61e185` vs `2039a8e`) — on a sync, keep whichever build is
newer. No daily sync workflow.

*Upstream:* `discovery-engine-plugin`. *Push-upstream condition:* the `gh`-first fetch, none — it is a
strict improvement there (upstream's anonymous fetch and daily sync both 404 on the internal repo).

### Smaller local adaptations (not numbered)

Also carried on top of upstream `discovery-engine-plugin`, and also needing re-application:

- `hooks/track-usage.sh` matches the `closing-the-loop:*` skill namespace rather than the upstream
  plugin's.
- `discovery-handover-package` looks for `stage-5-prototype.html` in `/home/claude/discovery-engine/`
  alongside the older paths.
- **Telemetry hooks (0.2.10).** Upstream's `track-progress.sh` is not copied: this bundle's own version
  keeps `telemetry-lib.sh`'s dependency-light style, maps this bundle's stage filenames
  (`component-inventory.md` for Stage 4; the pre-0.2.11 `prd-*` / `agent-prd-*` / `experiment-plan.md`
  alongside upstream's `stage-3-prd*` / `stage-6-experiment-plan*`),
  adds the loop milestones (including a tracker-write route for `publish` / `handover`), and drops
  upstream's company and route events. On the next sync, take upstream's skill text without its
  hook-specific lines and keep these hooks.
- **"Choices and next steps" (0.2.10)** uses this bundle's wording: `AskUserQuestion` in Claude Code and
  Cowork, buttons mirror the options exactly (0.2.8), `$DISCOVERY_DIR`, no pattern-check example.
- **No-double-welcome exception (0.2.10)** names `closing-the-loop-start` and `closing-the-loop` where
  upstream names `discovery-engine-start`.
- `discovery-create-tracker-issue` stamps the configured `handoverPath` marker (`discovery-handover` or
  `context-first-handover`) on the published issue or Confluence page body, which is what routes delivery
  later. Upstream has no handover-path concept, so this has no upstream counterpart to reconcile with.

---

## Maintainer TODOs

Known-wrong plumbing to settle before this goes wider than a pilot.

- ~~**Telemetry points at the upstream maintainers' sheet.**~~ Resolved 2026-09: all four
  `hooks/track-*.sh` now post to the Closing the Loop maintainers' own webhook/Sheet, and
  bundle-wide `skill_invoked` is the deliberate, documented behavior (see README → Telemetry).
- **`plugin_version` is read from this repo's `.claude-plugin/plugin.json`**, so events land tagged with the
  Closing the Loop version rather than an upstream Discovery engine version. Harmless but worth stating
  when the two sheets are compared.
- **The version is duplicated** in `.claude-plugin/plugin.json` and `.claude-plugin/marketplace.json` —
  two places to bump, with nothing asserting they match.
- ~~**Nine unlinked HTML explainers in `docs/`**, two of which share a `<title>` and are near-duplicates
  (`closing-the-loop-paths-explained.html` and `context-first-handover-explained.html`, 2530 vs 2525
  lines). Not indexed from anywhere. Decide which survive.~~ Resolved 2026-09: removed. The markdown
  guides are the documentation index.
- **Replace the `~/.netrc` token dance with plugin `userConfig`.** Plugins can declare config options that
  are prompted when the plugin is enabled, with sensitive values stored in the macOS Keychain (or
  `~/.claude/.credentials.json` where no keychain exists) and substituted as `${user_config.KEY}` in MCP
  configs and hook commands. That could replace the whole scaffold-a-placeholder → open-your-editor →
  paste-a-classic-token sequence, which is the clunkiest part of setup and the source of the misleading
  `401`. Blast radius: `closing-the-loop-setup` Steps 3–6, both
  `discovery-handover-package/references/jira-attachment-*.md`, and anything shelling out to
  `curl --netrc`. Needs scoping before anyone starts — note the ~2 KB total Keychain limit shared with
  OAuth tokens.
- ~~**`track-stage.sh` and `track-feedback.sh` are not registered in `hooks/hooks.json`**~~ Resolved
  0.2.10: no skill calls them any more; `track-progress.sh` and `track-usage.sh` (both registered) do.
