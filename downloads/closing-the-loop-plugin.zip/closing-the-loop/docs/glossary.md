# Glossary

Every term the docs and skills use as if you already knew it.

## The notation

| Term | Means |
|---|---|
| **`<KEY>`** | A tracker issue key — `KAN-12` in Jira, `ENG-451` in Linear. Wherever docs say `<KEY>`, substitute yours. It's the handle for a feature across every lane |
| **`D-n`** | A **delta**: one specific change to make, numbered `D-1`, `D-2`, … Lives in a Delivery Context. Each carries the code path it affects and why |
| **`AC-n`** | An **acceptance criterion**, written as a concrete scenario rather than a wish. Numbered `AC-1`, `AC-2`, … Expressed in Gherkin |
| **`S-n`** | A **vertical slice**: one deliverable story cutting through the stack, numbered `S-1`, `S-2`, … Becomes a tracker child when the feature is epic-shaped. Ids are stable, so a re-run reconciles rather than duplicates |
| **`C-n`** | A **chore**: prerequisite work with no user-visible behaviour (a migration, a config change). Delivered before the slices that depend on it |
| **Gherkin** | The Given/When/Then way of writing a scenario — *Given* a starting state, *When* something happens, *Then* this is true. Used because it's testable and unambiguous, not because anyone runs Cucumber |
| **`✋ PM` / `✋ Dev`** | The two blocking sign-off issues the governed path creates. Each side ticks its checklist and moves its issue to Done. That's the gate |

## The seam

| Term | Means |
|---|---|
| **The seam** | The handover between product and engineering — stage 7. Where intent meets the actual codebase. The thing this plugin exists to fix |
| **`handoverPath`** | Which seam contract your team uses: `governed` or `context-first`. Recorded once by setup. See [setup reference](setup.md#the-four-questions) |
| **`context-first`** | The seam contract where the ticket stays the live requirements surface and gains a Delivery Context. No Brief, no freeze, no sign-off gate |
| **`governed`** | The seam contract that produces a ratified payload — Engineering Brief, frozen PRD, agent context — reviewed and then approved through the `✋` gate |
| **Delivery Context** | The block context-first appends to a ticket: the deltas, the code evidence, reuse/preserve constraints, the `AC-n` scenarios, open decisions, and — for an epic-shaped feature — the slices. Not a document you maintain separately — it lives on the ticket |
| **Engineering Brief** | The governed path's single evolving document, promoted to the ticket description. The PRD freezes; the Brief is what changes as review and sign-off comments land |
| **Frozen PRD** | The PRD as it stood when the handover ran, attached to the ticket so the Brief's divergences from it stay auditable |
| **Marker** | The label (`discovery-handover` or `context-first-handover`) that handover leaves on a ticket. Delivery reads it to know which path to follow — which is why you never have to remember |
| **The gate** | Governed only: both `✋` sign-off issues moved to Done. Delivery refuses to start before that |
| **Projection** | Mechanically rendering an already-decided story map into tracker children. Projectors never invent a breakdown — if it isn't in the Brief or Delivery Context, it doesn't get created |
| **Read-only stories** | Projected children are regenerated on reconcile, so edits to them are lost. Feedback goes on the parent ticket |
| **Amigo session / three amigos** | A refinement conversation between the three perspectives — **Product** (is this the right thing?), **Dev** (can we build it?), **Test** (how would we know it works?). `prepare-amigo-session` assembles the pack for one and stops before sign-off |

## Configuration

| Term | Means |
|---|---|
| **`tracker`** | Where *delivery items* live: `jira` or `linear` |
| **`requirementsSurface`** | Where the *PRD* lives: `jira`, `linear`, or `confluence`. Usually the same as `tracker` |
| **`backlogMode`** | The team's **default** backlog shape: `single-ticket` or `epic`. The shaper recommends a shape per feature from the contract, uses this only to break ties, and you confirm. Never the decision itself |
| **Backlog shape** | The per-feature outcome: **single-ticket** (one ticket, one PR) or **epic** (`S-n` stories as tracker children). Recorded on the artifact — a `Backlog shape:` header line plus the story map (Brief §6.3 / Delivery Context `### Story map`), present only when epic. Every downstream skill reads it there, never from config |
| **`handoverMode`** | Governed only. `standard` (gaps become gate questions) or `strict` (gaps block the handover) |
| **`backlogTiming`** | Governed only; applies when a feature is epic-shaped. Whether stories are projected `post-gate` or `pre-gate` |

Full schema, with what happens when a key is absent: [setup reference](setup.md#config-schema).

## Lanes and skills

| Term | Means |
|---|---|
| **The three lanes** | Discovery (stages 0–6), the seam (stage 7), engineering delivery. See the [README](../README.md#the-three-lanes-and-the-seam-between-them) |
| **`discovery-*`** | Discovery-engine skills — customer signal through to a validated prototype |
| **`handover-*`** | Seam skills, both paths |
| **`v-*`** | The **V**isma engineering delivery library — 39 skills, spec through release. Bundled at full parity with the standalone `visma-skills` collection |
| **Orchestrator** | A skill that sequences other skills. `closing-the-loop` is the master one; each lane has its own |
| **PRD** | Product Requirements Document — the problem, the solution concept, user flows, success metrics. Discovery's stage-3 output |
| **Stage 0–6 / stage 7 / stage 8** | Discovery is stages 0–6, the seam is stage 7, and "into production" is stage 8 — a [known gap](../KNOWN-ISSUES.md), not yet built |

## Codebase and design

| Term | Means |
|---|---|
| **Brownfield** | An existing codebase with history, conventions, and constraints — as opposed to greenfield. Most real work. It's why the seam reads code instead of trusting intent |
| **Agent context** | `AGENTS.md` / `CLAUDE.md` in the target repo: build, test, and review conventions an agent needs. Created by `v-setup-agent-context`. Repo-level, distinct from the per-feature context a handover emits |
| **Evidence / evidence index** | The specific code paths a shaping run actually read, recorded so a later refresh can check just those instead of re-reading the feature |
| **Code Connect** | Figma's mechanism for mapping a design component to the real code component. Lets the mapper resolve prototype UI to canonical imports |
| **Surface Conventions** | The fallback when there's no Code Connect: class names and markup patterns discovered from the codebase itself |
| **Rail → Highway** | The maturity step from a team hand-mapping design to code, to one where Code Connect makes it automatic |
| **`~/.netrc`** | A long-standing Unix file holding credentials per host, which `curl --netrc` reads. Used here so your Atlassian token stays in one `chmod 600` file instead of a config or the chat |
| **Classic vs scoped token** | Atlassian's two API token kinds. Classic (unscoped) works with basic auth, which is what these skills use. A scoped token is Bearer-only and fails with a misleading `401` |

## Surfaces

| Term | Means |
|---|---|
| **Claude Code** | The CLI, desktop, web, and IDE surfaces this plugin installs into |
| **Cowork** | The claude.ai knowledge-work surface. Runs the discovery lane well; the delivery lane assumes a checkout and a PR, so it doesn't belong there. Distribution is separate — it doesn't read `~/.claude/` |
| **MCP connector** | The integration that gives Claude access to Jira, Linear, Confluence, or Figma. This plugin ships none of them — see [prerequisites](../README.md#before-you-install) |
| **`$DISCOVERY_DIR` / `$OUTPUTS_DIR`** | Where discovery writes. Resolved per environment at stage 0 — see [`references/discovery-working-directory.md`](../references/discovery-working-directory.md) |
