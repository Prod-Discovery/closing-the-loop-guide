# Setup reference

The canonical reference for configuring Closing the Loop. The [`closing-the-loop-setup`](../skills/closing-the-loop-setup/SKILL.md)
skill walks you through all of this interactively — read this when you want to decide *before* the run,
look a key up afterwards, or work out why a connection check failed.

- [The four questions](#the-four-questions)
- [Config schema](#config-schema)
- [Jira auth](#jira-auth)
- [Confluence as the requirements surface](#confluence-as-the-requirements-surface)
- [Linear](#linear)
- [Reconfiguring](#reconfiguring)
- [Troubleshooting](#troubleshooting)
- [Cost expectations](#cost-expectations)

> **Connect your tracker first.** This plugin ships no connectors — it drives Jira or Linear through an MCP
> server you provide, and setup can only record what it can see. Recording a choice against an absent
> connector produces a config that looks right and fails at the first tracker write.
> `/plugin install atlassian@claude-plugins-official` or `linear@claude-plugins-official`, then authorize
> it. Full prerequisites, including other surfaces:
> [getting started → before you start](getting-started.md#before-you-start).

Run setup once per machine:

```
Set up Closing the Loop
```

It writes a non-secret config file at `~/.config/closing-the-loop/config.json` and, for Jira, scaffolds
`~/.netrc` with a placeholder you fill in yourself. **No API token ever passes through the chat.**

---

## The four questions

Setup asks at most five things. Two of them only apply to some teams, so most runs are four questions
long. Decide these ahead of time and the run takes a minute.

| # | Question | Key | Options | Asked when |
|---|---|---|---|---|
| 1 | Which tracker do you work in? | `tracker` | `jira` · `linear` | always (usually auto-detected) |
| 2 | Where does the PRD live? | `requirementsSurface` | `jira` · `confluence` | Jira teams only — Linear records `linear` |
| 3 | How does context cross into delivery? | `handoverPath` | `context-first` · `governed` | always |
| 4 | What should **most features** default to? | `backlogMode` | `single-ticket` · `epic` | always — the shaper recommends per feature and asks you to confirm; this is only the tie-breaker |
| 5a | Who implements the features? | `handoverMode` | `standard` · `strict` | `governed` only |
| 5b | When are stories projected? | `backlogTiming` | `post-gate` · `pre-gate` | `governed` only |

### Question 3 — the one that matters most

`handoverPath` decides what the seam between product and engineering actually *is*. Both paths are
complete; neither is the degraded one.

|  | `context-first` | `governed` |
|---|---|---|
| **What you get** | One live ticket that stays the requirements surface, plus a compact `## Delivery Context` grounding the change in real code — `D-n` deltas, evidence, reuse/preserve rules, behavioral `AC-n` Gherkin | An Engineering Brief, a frozen PRD, an agent-context block, automated review pressure-testing the Brief, and two blocking sign-off issues (`✋ PM`, `✋ Dev`) |
| **What you give up** | The ratified artifact and the asynchronous approval record. Unresolved choices become ordinary planning decisions, not gate questions | Speed and a single source of truth — the PRD freezes, so the Brief becomes the document that evolves |
| **What it costs** | The shaping pass only — no Brief, no freeze, no sign-off, no retrieval pass | A review pass per change, plus the gate wait |
| **It needs** | A checkout of the target repo — shaping reads live code, so tracker access alone isn't enough | The same, for governed brownfield discovery |
| **Confluence** | Supported | Not yet — the push refuses the combination rather than half-supporting it |
| **Choose it when** | Product, design, and engineering already work together and want a code-grounded conversation rather than another decision artifact | Ambiguity is high, disciplines work asynchronously, or risk warrants an explicit ratification point |

**`context-first` is where the project is heading**, and it's what we'd point most teams at. Note the one
thing that could mislead you: `governed` remains the value every skill assumes when `handoverPath` is
*absent* from the config, purely so pre-existing configs keep working. That backward-compatible fallback is
not a recommendation — setup always records an explicit choice.

### Question 4 — default backlog shape

Independent of question 3, and **a default, not a decision.** Each feature's shape —
**single-ticket** (one ticket, one Delivery Context or Brief, one PR) or **epic** (vertical `S-n`
stories projected as tracker children) — is decided per feature at handover. The shaper for your path
(`handover-shape-feature` on context-first, `discovery-handover-package` on governed) reads the shaped
contract and recommends:

- **epic** when two or more slices would each own a coherent, disjoint subset of the `AC-n` *and* need
  a distinct owner/discipline or have a hard sequencing dependency between them;
- **epic** when the contract clearly exceeds one reviewable PR — many `D-n` across independent
  surfaces, or a chore that has to merge first;
- **single-ticket** otherwise. `backlogMode` breaks the tie only when the evidence is balanced.

You confirm once per feature, and the outcome is recorded on the artifact: a `Backlog shape:` header
line, plus the story map (Brief §6.3 / Delivery Context `### Story map`) present only when epic. Every
downstream skill resolves the shape from the artifact, never from this key — just like the path is
resolved from the ticket marker. Full heuristic:
[`references/backlog-shape-decision.md`](../references/backlog-shape-decision.md).

**What epic costs:** a projection pass, and the generated children are **read-only** — feedback goes on
the parent, not on a story. Governed projects the reviewed Brief's §6.3 map via
`create-backlog-from-brief`; context-first projects the Delivery Context's slices via
`handover-project-stories` after showing a dry run.

For an epic-shaped feature on either path, hand the parent key to `handover-deliver-epic` — it walks the
children one at a time, chores first.

### Question 5a — governed handover mode

`standard` versus `strict` changes what happens to **gaps in the payload**. It does not select the
handover path, and it is not a token lever.

- **`standard`** (default, start here) — *a developer working with an AI copilot.* Anything unresolved
  becomes an explicit question on the sign-off gate, and the dev can always just ask.
- **`strict`** — *an autonomous coding agent with no human conversation.* The payload must stand alone
  before the ticket is promoted; gaps block the handover instead of becoming questions.

### Question 5b — governed backlog timing

- **`post-gate`** (default) — stories are created only after both sign-offs are Done. Defers the
  projector's token spend past the gate.
- **`pre-gate`** — stories are projected right after the mandatory Brief review, *before* sign-off, so a
  refinement session (a three-amigos walkthrough, say) reviews real tracker stories and the sign-off
  then ratifies the Brief *and* the visible breakdown. Delivery stays blocked until both sign-offs are
  Done either way. See [`prepare-amigo-session`](../skills/prepare-amigo-session/SKILL.md) and the
  [pilot guide](pilot-guide.md).

---

## Config schema

`~/.config/closing-the-loop/config.json`. **Non-secret by construction** — it holds a *pointer* to the
auth file, never a credential.

```json
{
  "version": 1,
  "tracker": "jira",
  "requirementsSurface": "jira",
  "handoverPath": "governed",
  "handoverMode": "standard",
  "backlogMode": "single-ticket",
  "backlogTiming": "post-gate",
  "jira": {
    "site": "<site>.atlassian.net",
    "email": "<your-atlassian-email>",
    "authMethod": "netrc",
    "authFile": "~/.netrc"
  },
  "linear": { "authMethod": "mcp" }
}
```

Every key, and what happens when it is absent:

| Key | Values | Default when absent | Read by |
|---|---|---|---|
| `version` | `1` | — | schema marker |
| `tracker` | `jira` · `linear` | *no default — setup always records it* | every tracker-touching skill |
| `requirementsSurface` | `jira` · `linear` · `confluence` | **equal to `tracker`** | `discovery-create-tracker-issue`, `handover-shape-feature` |
| `handoverPath` | `context-first` · `governed` | **`governed`** (backward compatibility only) | `closing-the-loop`, `discovery-create-tracker-issue`, and the whole bridge |
| `handoverMode` | `standard` · `strict` | **`standard`** | `discovery-handover-package`, `handover-brief-review`, `handover-retrieval` |
| `backlogMode` | `single-ticket` · `epic` | **`single-ticket`** | `closing-the-loop-setup` (writes); `handover-shape-feature` and `discovery-handover-package`, as tie-breaker only. Every other skill resolves the shape from the artifact |
| `backlogTiming` | `post-gate` · `pre-gate` | **`post-gate`** | governed only; applies to epic-shaped features. `create-backlog-from-brief`, `handover-workflow`, `prepare-amigo-session` |
| `jira.site` | `<site>.atlassian.net` | — | Jira REST calls |
| `jira.email` | Atlassian account email | — | `~/.netrc` login |
| `jira.authMethod` | `netrc` | — | attachment byte transfer |
| `jira.authFile` | `~/.netrc` | — | pointer only |
| `confluence.spaceKey` | space **key**, e.g. `PROD` | — | page create |
| `confluence.parentPageId` | page id | pages parent to the space homepage | page create |
| `confluence.authMethod` | `netrc` · `mcp` | — | decides attachment vs link fallback |
| `linear.authMethod` | `mcp` · `env` | — | Linear auth route |

**The defaults are the important column.** An older config that predates `requirementsSurface`,
`handoverPath`, or `backlogMode` keeps working untouched — every skill falls back to the values above.

**Two keys, two questions.** `tracker` says where *delivery items* live. `requirementsSurface` says where
the *PRD* lives. They are usually the same.

**Governed-only keys.** `handoverMode` and `backlogTiming` describe the governed Brief/sign-off path.
A `context-first` config should not carry them at all — see [Reconfiguring](#reconfiguring).

---

## Jira auth

Jira needs one thing the connected Atlassian tooling cannot provide: **attachment bytes**. The MCP
exposes attachment *metadata* only, so the governed bridge moves the actual bytes through the Jira REST
API using a classic API token read from `~/.netrc`. Without it, spec files on tickets are silently
ignored.

(Context-first reads and updates the ticket description directly, so its core context does not depend on
attachments — the token still buys prototype attachment and the setup verify.)

### The token trap

**Create a classic (unscoped) token.** Go to **id.atlassian.com → Security → API tokens**. A *scoped*
token is Bearer-only and fails basic auth with a confusing `401` that looks exactly like a wrong
password.

### How the file gets written

Setup appends this block to `~/.netrc`, creating the file if needed and **never overwriting** an existing
entry for the same site:

```
machine <site>.atlassian.net
  login <your-atlassian-email>
  password REPLACE_WITH_CLASSIC_API_TOKEN
```

Then `chmod 600 ~/.netrc`. You open the file in your own editor and replace the placeholder. The token
never enters the conversation, and the skill never reads it back.

### Verify

Status code only — nothing is ever echoed:

```bash
curl -s -o /dev/null -w "%{http_code}" --netrc "https://<site>.atlassian.net/rest/api/3/myself"
```

`200` means working. See [Troubleshooting](#troubleshooting) for the rest.

---

## Confluence as the requirements surface

Choose `requirementsSurface: confluence` when requirements need to stay a living document, or when
Briefs are long enough to bump the Jira description cap (32,000 characters — a Confluence page has no
comparable limit).

**Currently supported on the `context-first` path only.** If you pick `confluence` and `governed`, setup
records both honestly and `discovery-create-tracker-issue` will ask you to publish to Jira until governed
Confluence support lands. It refuses that combination rather than half-supporting it.

How the three surfaces divide the work — one concern each, nothing duplicated:

| Surface | Owns |
|---|---|
| Confluence page | *what and why* — the PRD the PM keeps editing, prototype attached |
| Confluence sub-page | *how the code changes* — the `## Delivery Context` |
| Jira issues | *work tracking* — an optional lean delivery issue, plus story children for an epic-shaped feature |

The lean delivery issue is a pointer plus short framing, never a copy of the PRD. Setup asks per run
whether to create one.

**No second credential.** Confluence uses the same Atlassian site and the same `~/.netrc` entry as Jira.
Setup resolves the destination up front: it lists spaces with `getConfluenceSpaces` and records
`confluence.spaceKey`, plus an optional `parentPageId` if discovery pages should nest under a specific
page.

Verify, same discipline:

```bash
curl -s -o /dev/null -w "%{http_code}" --netrc "https://<site>.atlassian.net/wiki/rest/api/user/current"
```

**A missing token is not a failure here.** On the Confluence surface the token buys only prototype
*attachment* and a convenience page label. Everything load-bearing — page create, read, update, and the
path marker (a page *body block*, not a label) — is pure MCP. When there is no classic token, setup
verifies through the connector instead and records `confluence.authMethod: "mcp"`. You then get:

- **works** — publishing the page, editing it, the marker block, and the whole handover chain;
- **falls back** — the prototype is linked or handed to you to upload manually, and no page label is
  applied.

See [`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md) for the five verified Confluence constraints.

---

## Linear

No auth file. The connector or `LINEAR_API_KEY` carries auth.

- Setup records `tracker: "linear"` and `linear.authMethod`: `"mcp"` when the MCP is connected, else
  `"env"`.
- For `"env"`, set `LINEAR_API_KEY` in your own shell profile — never in chat.
- `requirementsSurface` is recorded as `"linear"`; there is nothing to choose, since Confluence pairs
  with Jira on the same Atlassian site.

---

## Reconfiguring

Run `Set up Closing the Loop` again at any time. It reads the existing config first and offers to show
it, reconfigure, or cancel.

**Safe to change any time:** `backlogMode`, `handoverMode`, `backlogTiming`, `requirementsSurface`.
Skills read the config per run, so the next run picks the new value up. Changing `backlogMode` only
changes the tie-breaker for future features; already-shaped features keep the shape recorded on their
ticket.

**Changing `handoverPath` mid-feature is the one to think about.** The path is also stamped as a marker
on the ticket, which is what routes delivery. A feature already carrying a governed package does not
become context-first because the config changed — re-run the handover for that ticket if you want it to
switch.

**Governed → context-first must remove keys, not just change them.** `handoverMode` and `backlogTiming`
describe machinery that no longer exists on the context-first path; leaving them behind is misleading.
Setup removes them for you.

**`~/.netrc` is never clobbered.** If an entry for the site already exists, setup leaves it alone and
skips straight to verification.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Verify returns `401` | The placeholder is still in `~/.netrc`, **or** a scoped token was used | Replace `REPLACE_WITH_CLASSIC_API_TOKEN` with a **classic (unscoped)** token from id.atlassian.com → Security → API tokens |
| Verify returns `403` | The account lacks access to the site | Check the Atlassian account has a Jira licence on that site |
| Verify returns `404` | Wrong site in `jira.site` | Re-run setup, or fix the `site` value and the `machine` line in `~/.netrc` |
| Confluence verify returns `404` | Confluence is not provisioned on this site | Fall back to `requirementsSurface: "jira"` |
| Confluence works but the prototype is only linked | No classic token on this surface | Expected. Attachment needs the token; everything else is MCP. See [above](#confluence-as-the-requirements-surface) |
| A skill says there is no config | `~/.config/closing-the-loop/config.json` is missing | Run `Set up Closing the Loop` |
| A governed-only key seems ignored | The config records `handoverPath: "context-first"` | Correct — those keys apply to the governed path only |
| Sub-tasks vanished after Epic conversion | Jira orphans sub-tasks when a ticket is converted late | Known and handled: the bridge converts to Epic *early*, and a later single-ticket → epic reshape uses a wrapper Epic instead of converting. See [`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md) |
| A long Brief was tightened | Jira caps descriptions; the skills budget to 32,000 characters | Expected, and reported in the output. Confluence has no comparable cap |

### Cowork / claude.ai

Cowork deliberately does not read `~/.claude/`, so a local `claude plugin install` does not carry over —
add the plugin under **Cowork → Customize → Plugins**, or provision it org-wide under **Organization
settings → Skills**.

There is also **no classic API token in Cowork**: connector OAuth tokens never enter the sandbox and
`~/.netrc` is not part of that environment. Every REST-token route degrades rather than fails, and the
fallback is always a manual upload by you. The Confluence surface degrades best, because page
create/read/update is pure MCP and the path marker is a page body block. Full detail in
[`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md).

---

## Cost expectations

Honesty first: reading enough real code to reconcile a meaningful feature is substantive work in either
path. Context-first removes the separate Brief, review, freeze, sign-offs, wrapper orchestrator, and
retrieval pass. A single-ticket-shaped feature also skips story projection; an epic-shaped one pays for
projection only after the same shaping pass has produced a story map.

What keeps repeat cost down:

- **Feature-driven evidence.** `handover-shape-feature` reads only the complete live paths needed for its
  `D-n` changes; a current brownfield reference can accelerate this but is not a mandatory intermediate
  document.
- **Targeted refresh.** Delivery compares only evidence-index paths and reshapes affected rows, not the
  whole feature.
- **Optional stories.** A single-ticket-shaped feature never invokes a projector. An epic-shaped one
  projects mechanically instead of rerunning discovery or planning.
- **Governed prototype analysis is carried forward** after the package first reads it.
- **Governed Brief reviews are priced per change**, and `backlogTiming: post-gate` defers projector spend
  until approval.

What is **not** a token lever: governed `standard` versus `strict`. That changes what happens to payload
gaps, not what the review costs.

A full governed handover on a brownfield repo is genuinely heavy — codebase discovery and Brief review
are both multi-agent.
