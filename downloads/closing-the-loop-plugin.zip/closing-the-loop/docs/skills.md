# Skills catalog

All **74** skills in the bundle. The [README](../README.md#entry-points) lists the ones you actually start
from; this is the complete inventory. Unfamiliar terms are in the [glossary](glossary.md).

**To run any of them:** type `/` and pick from the menu (they're namespaced, e.g.
`/closing-the-loop:handover-shape-feature`), or just describe what you want in plain English.

Counts: 4 orchestration and setup · 16 discovery · 3 Figma input · 3 Code Connect · 9 handover bridge ·
39 engineering delivery = **74**. Two skills are cross-listed rather than double-counted
(`discovery-handover-package` and `discovery-component-mapper` are counted under discovery and described
again under the bridge). If the total stops matching `ls -d skills/*/ | wc -l`, this page has drifted.

- [Orchestration and setup](#orchestration-and-setup)
- [Discovery lane (Sense → Shape)](#discovery-lane-sense--shape)
- [Figma-input utilities](#figma-input-utilities)
- [Handover bridge (the seam — stage 7)](#handover-bridge-the-seam--stage-7)
- [Code Connect (Figma ↔ codebase mapping)](#code-connect-figma--codebase-mapping)
- [Engineering delivery lane](#engineering-delivery-lane)

---

## Orchestration and setup

| Skill | What it does |
|---|---|
| `closing-the-loop-start` | The front door: silently detects what's present (config, agent context, connectors, design system, duplicate plugins), shows a readiness checklist + the whole journey map, and ends with an explicit choice — guided from the beginning, jump to a specific point, or fix what's missing. Doubles as the Week 0 preparedness scan (writes `closing-the-loop-readiness.md`) |
| `closing-the-loop` | End-to-end spine: detect entry point → discovery → configured handover path → delivery → release |
| `closing-the-loop-getting-started` | Plugin-wide orientation: which lane you're in, whether setup has run, and the phrase that starts your lane |
| `closing-the-loop-setup` | One-time, credential-safe setup: records tracker, `requirementsSurface` (`jira`/`linear`/`confluence`), `handoverPath` (`governed`/`context-first`), and the team's default backlog shape (`backlogMode`); governed teams additionally choose handover mode and backlog timing. Scaffolds Jira auth without putting a token in config or chat. See [setup reference](setup.md) |

## Discovery lane (Sense → Shape)

| Skill | Stage | What it does |
|---|---|---|
| `discovery-to-prototype-engine` | 0 + orchestrator | Ingests product context, determines the workflow path, sequences stages 1–6 with a checkpoint at each |
| `discovery-getting-started` | — | Discovery-lane quick start: the six stages, what each needs, the phrase to begin |
| `discovery-customer-insights` | 1.1 | Ingests multi-source customer data (pNPS, CES, tickets, usage) and synthesizes pain points with severity scoring |
| `discovery-competitive-landscape` | 1.2 | Researches competitors from public sources into a Kano-style gap analysis |
| `discovery-solution-prioritization` | 2 | Scores opportunities on pain, market, feasibility, and strategy; then explores and commits to a solution concept with an agentic/non-agentic flag |
| `discovery-prd-foundation` | 3.1 | Non-agentic PRD: problem, solution concept, user flows, success metrics |
| `discovery-agent-prd` | 3.2 + 3.3 | Agentic path: designs agent behavior (triggers, actions, boundaries, failure modes), pauses for review, then writes the PRD around the confirmed behavior script |
| `component-readiness-scan` | 4 | Scans the team's component library — any stack — and classifies every component (reusable / coupled / heavy dependency / missing or trapped). Writes the `component-inventory.md` + `prototype-rules.md` Stage 5 builds from, plus a reusability audit and code-gap audit |
| `component-remediation` | 4 (optional) | Fixes a flagged component so it works standalone — decouple, promote, extract, extend, or build from the Figma spec — in an editable lab copy, verified in the browser before handing back |
| `prototype-from-components` | 5 | Builds a clickable prototype from a brief and/or a Figma frame using the team's own components on a live dev surface; substitutes and flags stand-ins (composed from real components + tokens) instead of stopping on gaps; standalone single-file HTML export available for workshops and sharing |
| `prototype-fidelity-report` | 5 (auto-chained) | Plain-language report with every prototype: which pieces are real components vs. stand-ins, why, and a developer fix-list — plus a visual-match check against the Figma frame when one was the source |
| `discovery-experiment-plan` | 6 | Assumptions, hypothesis, test method, success criteria, and a usability interview script |
| `discovery-create-tracker-issue` | pre-handover | Publishes the validated run as one feature issue (or Confluence page + optional lean delivery issue), stamped with the configured path marker. The returned key is engineering's handle |
| `discovery-component-mapper` | feeds 7 | Maps prototype UI elements to production equivalents — see [handover bridge](#handover-bridge-the-seam--stage-7) |
| `discovery-handover-package` | 7 | Governed producer — see [handover bridge](#handover-bridge-the-seam--stage-7) |
| `discovery-feedback` | any | Anonymous 1–5 rating + optional comment on the discovery lane itself. Say "feedback on discovery"; see [Sending feedback](../README.md#sending-feedback) |

## Figma-input utilities

| Skill | What it does |
|---|---|
| `figma-readiness-check` | Audits a Figma file for AI-handoff hygiene (Variables, layer naming, variant structure, designer-annotation description fields) **before** any generation runs. Produces a punch list of fixes plus an "annotations to honor" section |
| `figma-tokens-extract` | Pulls every Figma Variable into `tokens/colors.css` / `tokens/spacing.css` / `tokens/typography.css`. The canonical token extractor; the prototyping skills and the handover package both depend on having tokens in this shape |
| `figma-batch-probe` | Fans out `get_design_context` + `get_screenshot` + `get_variable_defs` + `get_metadata` across N Figma nodes in parallel. Used by any skill that needs to survey multiple nodes — turns a 30+ sequential-call multi-node request into one round trip |

These three are *Figma-input* utilities, not stage-aligned discovery skills. They prepare the inputs the
rest of the discovery lane (`component-readiness-scan`, `prototype-from-components`,
`discovery-component-mapper`) then builds on. Pulled in from
[`cristinaiftode/ai-design-system-skills`](https://github.com/cristinaiftode/ai-design-system-skills) —
see [provenance](../README.md#provenance).

## Handover bridge (the seam — stage 7)

### Context-first path

| Skill | What it does |
|---|---|
| `handover-shape-feature` | **The shaper.** Reads intent plus the smallest complete live code path, then writes one compact Delivery Context with `D-n` deltas, evidence, reuse/preserve rules, behavioral `AC-n` Gherkin; recommends and confirms the backlog shape per feature, and—when epic-shaped—authors vertical `S-n` slices. Appended to the ticket, or published as a Confluence sub-page |
| `handover-project-stories` | **Optional projector.** Only when the Delivery Context carries a Story map, validates the `S-n`/`D-n`/`AC-n` map, shows a dry run, then creates or reconciles self-contained tracker children by stable ids and context hash. On the Confluence surface it offers to create the delivery issue first when the run was page-only |

### Governed path

| Skill | What it does |
|---|---|
| `discovery-handover-package` | **The producer.** Builds the Engineering Brief + frozen PRD + AGENTS context + manifest, runs review, and opens the PM + Dev sign-off gate |
| `handover-brief-review` | **Mandatory pre-gate review.** One consolidated read-only Brief Reviewer (feasibility, design/UX, customer evidence, risk, legal/privacy) plus two verifiers — a Source-Fidelity Auditor and a Fresh-Eyes Probe. Applies mechanical fixes into the versioned Brief and routes judgment calls onto the sign-off checklists. Also runs in a cheap targeted form whenever a new comment lands |
| `create-backlog-from-brief` | **The projector.** Renders an epic-shaped Brief's ratified §6.3 story map into stories and blocking chores, before or after the gate. It never invents a breakdown |
| `prepare-amigo-session` | **Pre-gate entry point.** Reviews the package, projects the provisional backlog, emits a Product/Dev/Test session pack, and stops before approval or delivery |
| `handover-workflow` | Runs the governed bridge end to end, holds at PM + Dev approval, then hands approved work to delivery |
| `handover-retrieval` | **The consumer.** Detects the `discovery-handover` marker, checks live sign-off state, and loads the approved Brief + AGENTS context; generated children walk up to the parent Epic |

### Both paths

| Skill | What it does |
|---|---|
| `handover-deliver-epic` | **Epic slice walker.** The iterator the projectors hand to: enumerates the projected children, derives the order from live blocking relations (chores first), drives one delivery run per child, pauses between them, and closes the parent out. Resume state is the tracker, never a manifest |
| `handover-codebase-discovery` | Produces a sourced, self-verified component reference for governed brownfield handover and standalone module discovery. Context-first may reuse a current reference as evidence, but does not invoke it as a mandatory runtime step |
| `discovery-component-mapper` | Maps prototype UI elements to production equivalents via Figma/Code Connect or `handover-codebase-discovery` Surface Conventions. Its component map feeds the governed Brief and can serve as evidence when context-first UI shaping needs it |

## Code Connect (Figma ↔ codebase mapping)

| Skill | What it does |
|---|---|
| `code-connect-setup` | One-time team bootstrap — verifies prerequisites (Org/Enterprise plan, components published, componentised codebase), installs `@figma/code-connect`, scaffolds `figma.config.json`, sets up auth credential-safely (token via env var or `~/.netrc`, never written to repo), maps a first batch of 3–5 foundational components (delegating to `figma-code-connect`), publishes, and verifies the mappings appear in Figma Dev Mode. Designed for the Rail → Highway transition |
| `figma-code-connect` | Per-component mapping. Given a Figma URL, fetches component properties via the Figma MCP, identifies the corresponding code component, and writes a `.figma.ts` template file with the correct `getString`/`getBoolean`/`getEnum`/`getInstanceSwap`/`getSlot` mapping. Used both incrementally by humans and chained from `code-connect-setup` for batch initial mapping |
| `code-connect-coverage-audit` | Maintenance audit. Walks `*.figma.ts` files + queries Figma for published components; computes three drift directions (unmapped in code, orphan mappings, stale/drifted mappings) and produces a percentage + punch list. Pairs with the `schedule` skill for weekly automated runs. Read-only — never modifies mappings |

These three unlock `discovery-component-mapper`'s Mode A path — once a team has Code Connect set up, the
mapper resolves prototype UI to canonical code imports directly, instead of falling back to Surface
Conventions from `handover-codebase-discovery`. Highway-tier teams should aim for ≥ 70% coverage before
treating Mode A as reliable.

## Engineering delivery lane

The full Visma engineering skills library is bundled — all 39 skills, in parity with
[visma-skills](https://github.com/Visma-AI-Engineering-Technology/visma-skills).

**Orchestrators (6).** `v-develop-feature`, `v-fix-bug`, `v-ticket-to-release`, `v-prepare-release`,
`v-ship-feature`, `v-run-lean`.

**Stage skills (19).** `v-write-spec`, `v-plan-work`, `v-implement-code`, `v-design-frontend`,
`v-run-tdd`, `v-test-e2e`, `v-debug-issue`, `v-review-changes` (includes the Security Depth pass),
`v-scored-code-review`, `v-address-review`, `v-prepare-commit`, `v-update-docs`, `v-manage-ci`,
`v-upgrade-dependencies`, `v-setup-agent-context` (includes First-Time Bootstrap), `v-skill-author`,
`v-capture-learning`, `v-give-feedback`, `v-guidance`.

**Repo analysis and documentation (12).** `v-analyze-repo`, `v-find-missing-documentation`,
`v-generate-wiki`, and the nine `v-wiki-layer-*` skills (architecture, devops, engineering, executive,
marketing, overview, product, security, support).

**Readiness and assurance (2).** `v-agent-readiness-report`, `v-audit-readiness`.

Four of these carry Closing-the-Loop adaptations on top of upstream — see
[`CHANGELOG.md`](../CHANGELOG.md#divergences-from-upstream).

---

Retired skills are kept for provenance under [`retired/`](../retired/) —
`document-feature` was superseded by `handover-codebase-discovery`.
