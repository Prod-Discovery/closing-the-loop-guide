# Getting started

The full walkthrough. The [README](../README.md#get-started) has the four-step version; this page covers
what each step actually does, what it asks you for, and where its output lands.

- [How to run a skill](#how-to-run-a-skill)
- [Which lane are you in?](#which-lane-are-you-in)
- [Before you start](#before-you-start)
- [Your first handover, step by step](#your-first-handover-step-by-step)
- [Starting from discovery instead](#starting-from-discovery-instead)
- [Where discovery outputs land](#where-discovery-outputs-land)
- [What to read next](#what-to-read-next)

Unfamiliar terms — `D-n`, `AC-n`, `<KEY>`, Gherkin, amigo, brownfield — are all in the
[glossary](glossary.md).

---

## How to run a skill

Nothing here is a command you have to memorise. Two equivalent ways in:

**Type `/`** and pick from the menu. Plugin skills are namespaced, so they group together:

```
/closing-the-loop:closing-the-loop-setup
```

This is also the fastest way to see everything installed, and to re-run one stage without restarting a
workflow.

**Or describe what you want** in plain English — "set up closing the loop", "create a handover from
KAN-12", "take KAN-12 to a PR". Every skill declares the phrases it answers to, so you don't need names.

Throughout these docs, a name in `code` is a skill and a phrase in quotes is something you type. Either
form works, and the quoted phrases are the ones the skills are actually tuned for.

When you're not sure what to say at all:

```
What is this plugin and where do I start?
```

That reaches `closing-the-loop-getting-started`, which reports which connectors it can see, whether setup
has run, and the one phrase that starts your lane.

---

## Which lane are you in?

Three lanes, one seam between them. Find yourself here:

| You are | Your lane | You start by saying |
|---|---|---|
| A PM or designer with customer signal and no feature defined yet | **Discovery** (stages 0–6) | "Run the full discovery to prototype workflow" |
| A PM, BA, or tech lead with a ticket that needs to become implementable | **The seam** (stage 7) | "Create a handover from `<KEY>`" |
| A developer with a ticket that's ready to build | **Delivery** | "Take `<KEY>` to a PR" |
| Not sure — you want the whole arc driven for you | All three | "Close the loop on `<KEY>`" |

The last one is `closing-the-loop`, the master orchestrator. It detects where the feature already is and
sequences from there, so it's a safe default when you don't know which lane applies.

**You do not have to start at the beginning.** The bridge runs without a prototype — declared feature work
is a first-class path, not a degraded one.

## Before you start

Four one-time things. The first two are the ones people skip and then lose a run to.

### 1. Connect the tools the plugin drives

**The plugin ships no connectors, deliberately.** It drives your tracker through an MCP connector you
provide, and `closing-the-loop-setup` can only record what it can see. Connect first, configure second.

Atlassian, Linear, and Figma each publish and maintain their own connector plugin, which is why we don't
bundle copies — a vendor endpoint that changes gets fixed by the vendor, not by us on your release
schedule.

| Connector | Needed for | Install |
|---|---|---|
| **Atlassian** (Jira, plus Confluence if you use it) | the seam and delivery lanes, Jira teams | `/plugin install atlassian@claude-plugins-official` |
| **Linear** | the seam and delivery lanes, Linear teams | `/plugin install linear@claude-plugins-official` — or just a `LINEAR_API_KEY` in your shell |
| **Figma** | the three `figma-*` skills and all three Code Connect skills. Nothing else | `/plugin install figma@claude-plugins-official` |

`claude-plugins-official` ships with Claude Code, so those commands work as-is; you can also browse
`/plugin` → Discover and search by name.

**Installing declares the server; you still authorize it once.** Claude Code asks you to approve each new
server, and remote connectors then run their own OAuth flow. Until that's done the tools exist but report
that they need authentication — which is a connected-but-unauthorized state, not a broken install.

**Don't add a second connector for a service you already have.** Two Atlassian servers means two copies of
every Jira tool in the toolkit, and these skills reference tools by name.

**Other surfaces:** claude.ai connector settings on Claude Code desktop/web; **Customize → Connectors** in
Cowork. Cowork doesn't read `~/.claude/`, so nothing installed locally carries over.

**To check it worked**, just run setup — its first step reports what it found by name. If it reports
nothing, the connector isn't attached to *this* surface, which is the usual cause.

### 2. Tooling for the lane you're using

| Lane | Needs |
|---|---|
| **Discovery** (stages 0–6) | Claude Code and nothing else. Outputs are files, not tracker writes. This is the lane that runs fine in Cowork |
| **The seam** (stage 7) | A tracker connector, **a checkout of the target repo**, and for Jira a classic API token if you want prototype/spec attachments |
| **Delivery** | All of the above plus **`gh`, authenticated** — 32 of the 39 `v-*` skills invoke it, and the PR steps fail without it. Assumes a checkout, a runnable test suite, and a PR workflow |
| **Code Connect** | A Figma MCP connector, Node, a Figma Org/Enterprise plan, and components published to a team library |

So: a PM piloting discovery alone needs almost nothing. A developer taking a ticket to a PR needs all of it.

**Two things about the seam that catch people out:**

- **It reads production code**, so whoever runs it needs the repo open in Claude Code. A plain clone is
  enough — shaping never builds or runs anything — but tracker access alone won't do. On a
  `context-first` run this is `handover-shape-feature`'s second required input, stated as *"the target
  repository at a known commit"*. If the PM doesn't have a checkout, split the work: they own discovery,
  publishing, and confirming the story projection; someone with the repo runs the shaping step.
- **Routing into the engineering skills is the engineering lead's call.** `handover-shape-feature` says so
  itself — the delivery contract is read by `v-develop-feature` and `v-ticket-to-release`, which engineering
  owns, and *"composing a path into those entry points is the engineering lead's call — flag it, don't
  assume it."* Agree the routing before a pilot, not after.

### 3. Agent context in the target repo

Open Claude Code **inside the repository you want to work on**. If it has no `AGENTS.md` or `CLAUDE.md`
yet, run:

```
Run v-setup-agent-context
```

Take its First-Time Bootstrap path. This is what the bridge reads when it captures codebase constraints,
and what the delivery skills read to know your build, test, and review conventions. There's a starter
template at [`references/visma-conventions-template.md`](../references/visma-conventions-template.md) if
you'd rather write it by hand.

The governed bridge also emits a feature-specific AGENTS block per handover; context-first keeps feature
context on the ticket instead. Neither replaces repo-level context.

### 4. Setup

```
Set up Closing the Loop
```

One credential-safe run that records your tracker, where requirements live, your handover path, and your
default backlog shape at `~/.config/closing-the-loop/config.json`. For Jira it also scaffolds `~/.netrc` with a
placeholder you fill in yourself — **no API token ever passes through the chat**.

Decide the four answers ahead of time if you like: [setup reference → The four questions](setup.md#the-four-questions).
Every tracker-touching skill reads this config automatically, so you never pass these choices again.

**What you should see when it's done:** the settings echoed back, a `~/.config/closing-the-loop/config.json`
you can open and read, a `200` from the connection check, and one suggested next command. If the check
returned `401`, the token placeholder is still in `~/.netrc` or you created a *scoped* token instead of a
classic one — [troubleshooting](setup.md#troubleshooting) covers each code.

---

## Your first handover, step by step

This is the path from an existing ticket to a merged PR. It assumes both prerequisites above are done.

### 1. Pick a real ticket

One scoped feature whose description is a decent PRD. **Use a staging tracker project for the first run**
— see the [pilot guide](pilot-guide.md) for why and what else to expect on a first outing.

### 2. Create the handover

```
Create a handover from <KEY>
```

What happens depends on your configured `handoverPath`.

**`context-first`** preserves the requirements as they are and appends one compact `## Delivery Context`
to the same ticket: `D-n` deltas, code evidence, reuse and preserve constraints, behavioral `AC-n`
Gherkin, and any unresolved decisions. It recommends a backlog shape for the feature and asks you to
confirm; when epic-shaped it also authors vertical `S-n` slices — review the dry-run tree and confirm
before it writes anything to the tracker.

There is no Engineering Brief, no PRD freeze, and no handover sign-off gate. Unresolved product or
engineering choices stay ordinary planning decisions.

**`governed`** produces the ratified payload: an Engineering Brief promoted to the ticket description, the
PRD frozen as an attachment, and an AGENTS context block. Mandatory automated review pressure-tests the
Brief (`handover-brief-review`), then it opens two blocking sign-off issues, `✋ PM` and `✋ Dev`.

**Jira note, precisely.** The connected Atlassian tooling exposes attachment *metadata* only. The governed
bridge fetches and uploads attachment *bytes* through the Jira REST API using the classic (unscoped) API
token setup scaffolds into `~/.netrc`. Without that token, spec files on tickets are silently ignored.
Context-first reads and updates the ticket description directly, so its core context doesn't depend on
attachments. Full detail: [setup reference → Jira auth](setup.md#jira-auth).

**Confluence requirements surface** (context-first only, for now). Choosing `confluence` publishes the PRD
as a page the PM keeps editing, with the prototype attached, and asks per run whether to also create a
lean Jira delivery issue — a pointer plus short framing, never a copy of the PRD. Handover then writes the
`## Delivery Context` as a **sub-page** of that page, and — for an epic-shaped feature — stories are projected as Jira children
of the delivery issue. Each surface owns one concern, so nothing is duplicated: page = *what and why*,
sub-page = *how the code changes*, issues = *work tracking*. Same site, same `~/.netrc` token as Jira — no
second credential. Governed Confluence support is a follow-up; the push refuses that combination rather
than half-supporting it. See [`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md) for the five verified constraints.

**What you should see when it's done** — go look at the ticket, because this is the whole point:

| Path | On the ticket |
|---|---|
| `context-first` | The original description intact, with a `## Delivery Context` section appended below it, and a `context-first-handover` label |
| `governed` | The description **replaced** by the Engineering Brief, the PRD attached as a file, a `discovery-handover` label, and two new linked issues named `✋ PM` and `✋ Dev`, each with a checklist |
| either, epic-shaped | Child issues, one per slice, plus any chores — created only after you confirmed the dry run |

If the ticket looks unchanged, the write failed rather than the run — check the connector and the token.

### 3. Governed, pre-gate amigo mode only

If you configured `backlogTiming: pre-gate` and the feature was shaped epic, walk the projected story
breakdown together before anyone signs off:

```
Run prepare-amigo-session for <KEY>
```

It builds the package if the ticket doesn't have one, runs the review, projects the story map, and ends
with an in-chat session pack — walkthrough order, AC coverage, Product/Dev/Test challenge prompts, open
decisions, agenda. Then it **stops**. Nothing is approved and nothing is built.

During the session: generated stories are **read-only**. Feedback and decisions go as comments on the
parent ticket or the sign-off issues, and the review machinery folds them into the Brief and refreshes
affected stories. Sign-off means each side ticks its checklist and moves its `✋` issue to **Done**.

### 4. Deliver

```
Take <KEY> to a PR
```

This routes by the marker on the ticket, not by anything you have to remember.

- **Context-first** loads the live requirements plus the fresh Delivery Context straight into normal
  engineering planning.
- **Governed** checks the sign-off gate first and refuses to proceed until both `✋` issues are Done, then
  loads the ratified package.

Both continue through implementation, behavioral verification, review, and release.

**For an epic-shaped feature on either path**, hand the *parent* key to `handover-deliver-epic` instead — it walks the children
one at a time, chores first, deriving the order from live blocking relations and pausing between slices.

### 5. If the code moved underneath you

Re-run the shaping step. Context-first compares only evidence-index paths and reshapes the affected rows
rather than the whole feature, so a refresh is cheap. Governed re-runs the Brief review, which is priced
per change.

---

## Starting from discovery instead

If the feature doesn't exist yet:

```
Run the full discovery to prototype workflow
```

Six stages with a checkpoint at each one — you review the output and decide whether to continue, adjust,
or stop:

```
SENSE — Understand the landscape
  Stage 0    Set up product context
  Stage 1.1  Analyze customer data
  Stage 1.2  Research competitors
  Stage 1.3  Merge into Top 5 Opportunities (automatic)
  Stage 2    Score, pick an opportunity, commit to a solution direction

SHAPE — Build the response
  Stage 3    Write the PRD
  Stage 4    Scan your component library for prototype-readiness (any stack)
  Stage 5    Build an interactive prototype from your own components
  Stage 6    Create an experiment plan and usability test script
```

You don't need everything upfront — each stage asks for what it needs. Uploading a strategy doc or pitch
deck at Stage 0 is the fastest way to give it product context. Corrections in Stage 1 save hours of rework
in Stages 4–6, so take the early checkpoints seriously.

When the prototype validates, publish it:

```
Create a ticket
```

That's `discovery-create-tracker-issue`. The PRD becomes the issue description (or a Confluence page), the
prototype is linked or attached, and the configured path marker is stamped on. The returned key is the
handle you hand to step 2 above.

Stage-by-stage detail and the single-stage entry phrases live in `discovery-getting-started` — say
"getting started with discovery".

## Where discovery outputs land

The discovery lane resolves its working directory at Stage 0 and tells you which one it picked:

- **Cowork / claude.ai** — `/home/claude/discovery-engine/`, with shareable copies in
  `/mnt/user-data/outputs/` and a downloadable card per stage.
- **Local Claude Code** — `./discovery-engine/` in whatever repo you opened, because `/home/claude/`
  cannot be created there. No second copy and no download card (`present_files` doesn't exist locally
  either) — the skill states the full path instead.

`discovery-engine/` is in this repo's `.gitignore`; add it to your own target repo's if you don't want run
artifacts committed. The skills will ask rather than edit it for you.

Full rules: [`references/discovery-working-directory.md`](../references/discovery-working-directory.md).

## What to read next

| If you want | Read |
|---|---|
| A term defined — `D-n`, `AC-n`, Gherkin, amigo, brownfield | [Glossary](glossary.md) |
| To decide your config before running setup | [Setup reference](setup.md) |
| To know what a first pilot run really costs and where it's sharp | [Pilot guide](pilot-guide.md) |
| The complete list of skills | [Skills catalog](skills.md) |
| Known sharp edges, verified | [`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md) |
| What changed and what diverges from upstream | [`CHANGELOG.md`](../CHANGELOG.md) |
