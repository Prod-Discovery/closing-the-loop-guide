# Pilot guide

For a team running Closing the Loop on a real feature for the first time. It assumes you've read the
[README](../README.md) — the 5-minute version is worth it — and covers what the general docs can't: what
a first run actually feels like, where it's sharp, and what we want to hear about.

This process is a **starting point, not a prescription**. It's meant to be stress-tested across product,
design, and engineering, and adapted. Honesty about where it breaks is the point of a pilot.

- [1. Install](#1-install)
- [2. One-time setup](#2-one-time-setup)
- [3. First run](#3-first-run)
- [4. Expectations](#4-expectations)
- [5. Telling us what broke](#5-telling-us-what-broke)

---

Terms used without explanation here — `D-n`, `AC-n`, amigo, brownfield — are in the
[glossary](glossary.md).

## 1. Install

**Connect your tracker before you install**, not after. The plugin ships no connectors, and the most common
first-run failure is configuring against a Jira or Linear connector that isn't attached to this surface —
which surfaces late, once you've already spent a session. Full list, including `gh` for the delivery lane:
[getting started → before you start](getting-started.md#before-you-start).

In Claude Code, opened **inside the target repository** you want to pilot on:

```
/plugin marketplace add Visma-AI-Engineering-Technology/closing-the-loop
/plugin install closing-the-loop@closing-the-loop
```

**No GitHub access?** Any local checkout or unzipped copy of this repo is itself a valid marketplace:

```
/plugin marketplace add /path/to/closing-the-loop
/plugin install closing-the-loop@closing-the-loop
```

**On Cowork / claude.ai** the plugin format works unchanged, but distribution is separate — Cowork
deliberately does not read `~/.claude/`, so a local install doesn't carry over. Add it under **Cowork →
Customize → Plugins**, or provision it org-wide under **Organization settings → Skills**, which is the
better path for a pilot cohort than each person installing locally. Note the engineering lane assumes a
checkout, a test run, and a PR, so it doesn't belong there — pilot the discovery lane in Cowork and the
delivery lane locally.

If the target repo has no `AGENTS.md` / `CLAUDE.md` yet, run `v-setup-agent-context` once first. The
bridge reads that context when it captures codebase constraints, and skipping it is the most common reason
a first handover feels generic.

## 2. One-time setup

```
Set up Closing the Loop
```

Decide the answers before you run it — [setup reference → The four questions](setup.md#the-four-questions)
lays out what each choice costs as well as what it buys. For a first pilot we'd suggest:

| Question | Suggested first answer | Why |
|---|---|---|
| `handoverPath` | **`context-first`** | Where the project is heading, and the lighter first run — no Brief, no PRD freeze, no sign-off gate to wait on. Pick `governed` instead if disciplines genuinely work asynchronously and you need a ratified artifact and an explicit approval record |
| `backlogMode` | `single-ticket`, or `epic` if most features will run sprint-style | The default the shaper falls back on, not the decision — at handover it recommends a shape per feature from the contract and you confirm once. Single-ticket is one ticket and one PR — least to go wrong. Epic adds vertical slices as tracker children; worth it when a feature is too big for one PR |
| `requirementsSurface` | `jira` / `linear`, or `confluence` if PRDs live there | Confluence keeps requirements a living page — and it's supported on `context-first` **only**, so this is the path that enables it |
| `handoverMode` | *not asked* on `context-first` | Governed-only. If setup asks you this, you chose `governed` |

**Jira auth is worth understanding, not just clicking through.** Setup scaffolds `~/.netrc` for a
**classic (unscoped)** Atlassian API token. This is the workaround for the attachment problem: the
connected Jira tooling only sees attachment *metadata*, while the bridge needs to move attachment *bytes*
through the REST API. Without the token, spec files on tickets are silently ignored. A *scoped* token is
Bearer-only and fails with a confusing `401` — so if verification returns 401, that's usually why.

### Worked example: `context-first` + `epic` default

The configuration we'd point most teams at, and the one the project is leaning into. Four answers:
`context-first`, `epic` as the default shape, your tracker, your requirements surface. Setup will not ask
about `handoverMode` or `backlogTiming` — those describe governed machinery, and their absence is correct.
At handover the shaper still recommends a shape for each feature and asks you to confirm; `epic` here
only breaks ties.

**Who runs which step matters here**, because the shaping step reads production code —
`handover-shape-feature` requires *the target repository at a known commit*, not just tracker access. Two
workable splits:

| | Path A — one person | Path B — split |
|---|---|---|
| Discovery + publish the ticket | PM | PM |
| Shape the ticket (reads the code) | PM, with a clone of the repo open | Dev, BA, or tech lead |
| Confirm the story projection | PM | PM, on the dry run |
| Delivery | Dev | Dev |

A clone is enough for path A — the shaping step reads code and never builds or runs anything, so no dev
environment is needed. Path B is the lower-friction start if the PM isn't already comfortable in the
codebase, and it pulls engineering in at the right moment anyway.

**One thing to agree before you start, not after.** `handover-shape-feature` says it plainly: the delivery
contract is read by the engineering skills, and *"composing a path into those entry points is the
engineering lead's call — flag it, don't assume it."* Get the nod on the routing first. A context-first
pilot that engineering didn't agree to is a document nobody reads.

The run itself:

```
Create a handover from <KEY>
```

That appends one `## Delivery Context` to the ticket — the changes to make, the code read as evidence,
reuse and preserve constraints, acceptance scenarios, and any open decision — plus, once you confirm
the feature is epic-shaped, the vertical `S-n` slices. Nothing is frozen and there is no gate. Then project the slices, review the **dry-run tree**, and
confirm before anything is written to the tracker. Hand the *parent* key to a dev, who says
"take `<KEY>` to a PR"; `handover-deliver-epic` walks the children one at a time, chores first.

### Alternative: `governed` + `epic` default + `pre-gate` (the three-amigos configuration)

Choose this when the pilot is specifically about the *refinement conversation* and you want an explicit
approval record. Stories are projected *before* sign-off, so the session ratifies the Engineering Brief
**and** the visible breakdown rather than approving a document and discovering the breakdown later. Entry
point is `prepare-amigo-session` rather than a plain handover — see [step 3](#3-first-run).

## 3. First run

**Use a staging tracker project.** Two tracker behaviours you'll see mentioned in the output, both handled
but both worth knowing (details in [`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md)):

- For an epic-shaped feature the source ticket is converted to an **Epic early**, because converting later
  silently orphans its sub-tasks.
- **Jira descriptions are capped.** The skills budget to 32,000 characters — the tighter of the MCP
  create-tool limit and Jira's own 32,767. This matters on **both** paths: governed promotes the Brief into
  the description, and context-first appends the Delivery Context *below the existing requirements*, so the
  cap applies to the two combined. Long features get a tightening pass and you'll see it said so. If you're
  routinely near the limit, `requirementsSurface: confluence` has no comparable cap.

Pick one real, scoped ticket whose description is a decent PRD, then:

```
Create a handover from <KEY>
```

**On `context-first`** that shapes the ticket in place and stops — Delivery Context appended, slices drafted
when the feature is shaped epic, nothing frozen and nothing to approve. Project the slices when the map looks right, review the
dry run, confirm. Then a dev takes the parent key.

**Whichever path**, two rules bite on an epic-shaped feature:

- **Projected stories are read-only.** Feedback and decisions go on the **parent** ticket. Editing a
  projected story directly gets overwritten on the next reconcile — this is the single most common
  first-week mistake.
- **Re-run shaping when the code moves.** Context-first compares only the paths it recorded as evidence and
  reshapes the affected rows, so a refresh is cheap and worth doing rather than working from a stale
  contract.

**On `governed`**, use the dedicated stopping-point workflow instead when you're running the amigo
configuration:

```
Run prepare-amigo-session for <KEY>
```

That builds the package if the ticket doesn't have one, runs the mandatory Brief review, projects the story
map, and ends with an in-chat **session pack**: walkthrough order, AC coverage, Product/Dev/Test challenge
prompts, open decisions, agenda. Then it stops — nothing approved, nothing built. Sign-off means each side
ticks its checklist and moves its `✋` issue to **Done**; nothing softer counts. Afterwards,
`Resume the handover workflow for <KEY>` reconciles what changed and, once both sign-offs are Done, delivery
runs.

Step-by-step detail for both paths is in [getting started](getting-started.md).

## 4. Expectations

**Tokens.** A full governed handover on a brownfield repo is genuinely heavy — codebase discovery and
Brief review are both multi-agent. Context-first is lighter because it removes the Brief, review, freeze,
sign-offs, and retrieval pass, but reading enough real code to reconcile a meaningful feature is
substantive work either way. The real levers are in
[setup reference → Cost expectations](setup.md#cost-expectations). What is *not* a lever: governed
`standard` versus `strict`.

**Artifacts too long, or too obviously AI-written?** Say so — that feedback shapes the templates directly.
The Brief is deliberately the single evolving document; everything else (PRD, stories) is frozen or
projected, so the Brief is where length complaints should land.

**Where it's still incomplete.** [`KNOWN-ISSUES.md`](../KNOWN-ISSUES.md) is maintained honestly and is the
first place to check before reporting something — it covers the Jira hierarchy behaviours, the description
cap, the five verified Confluence constraints, Cowork parity, the non-GitHub PR rung, and the stage-8
"into production" gap. If what you hit is already there, you'll save yourself the write-up; if it isn't,
that's exactly what we want.

## 5. Telling us what broke

Two routes, because the two lanes are maintained by two different teams. Route by what the feedback is
*about*, not by who is speaking:

| Say | Covers | Goes to |
|---|---|---|
| "feedback on discovery" | discovery stages 0–6 | Discovery engine maintainers. Anonymous: 1–5 rating + optional comment |
| "feedback on the delivery skills" | the `v-*` delivery skills **and** the handover bridge | Visma skills maintainers. Free-form, with an optional name/email you choose to attach |

A bare "give feedback" deliberately belongs to neither — both skills ask which lane you mean first.

Don't wait until you've finished a workflow. First impressions are just as valuable, and a two-minute
"this was confusing" is more useful than a polished retrospective three weeks later.
