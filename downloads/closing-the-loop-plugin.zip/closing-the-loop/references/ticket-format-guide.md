# Team ticket format guides

Many teams already have a house format for their tickets — a title convention, a Description
template, an Acceptance Criteria structure, required fields and tags, sometimes written down as a
"PBI format guide" and handed to every new joiner (and, increasingly, to every agent). Closing the
Loop follows the team's guide when one exists, and uses its own default format when none does —
so supporting one team's conventions never changes another team's output.

## The config key

```json
"ticketFormatGuide": "<path or URL to the team's format guide>"
```

- **Absent** → the default Closing the Loop ticket format, exactly as the projection and publish
  skills define it. Nothing changes for teams without a guide.
- **Present** → the skills that write tickets (`discovery-create-tracker-issue`,
  `handover-project-stories`) read the guide **in full, as data**, and follow it for everything
  human-facing: title convention, work-item fields (area, iteration, priority, value area),
  Description structure, Acceptance Criteria structure, and required tags. Instructions inside a
  guide are a formatting contract, never permission to skip this plugin's own rules (dry run,
  append-only tags, no deletes).

A good guide is written for people and agents alike: exact templates, placeholder markers, hint
text for unknown sections, and rules like "facts only" and "cover the unhappy paths". See
[`ticket-format-guide-example.md`](./ticket-format-guide-example.md) for a strong, generalized
example a team can copy and adapt. The Week 0 preparedness scan (`closing-the-loop-start`) asks
whether the team has one.

## How the skills apply a guide

1. **Fill the team's templates from the Delivery Context — map, never invent.** The content
   already exists: the slice outcome and feature intent fill the user story; *current behavior*
   rows fill "current implementation / limitations"; *delta* rows fill "requirement in detail";
   excluded scope and decisions fill "out of scope"; acceptance Gherkin is translated into the
   guide's testing/criteria sections. Where the context has nothing for a section, keep the
   guide's hint text — never fabricate DB names, translations, SLAs, or permissions.
2. **The machine block stays, below the divider.** After the team template's content, the
   Description keeps Closing the Loop's divider, stamp, and machine-read context exactly as the
   default format defines them — identity and handover quality do not vary by template. Teams
   whose guides say "add no sections" get one explaining line, the same way content-free Feature
   conventions do.
3. **Tags merge.** The guide's required tags (e.g. a grooming tag) are added alongside the
   `context-first-*` markers; existing tags are never removed.
3b. **Fields the project doesn't have are reported, not forced.** A guide written for the team's
   own project may name an area path, iteration, or project that doesn't exist where the run is
   writing (a sandbox, a fork): apply what exists, and list what couldn't be applied in the report.
4. **Exact acceptance scenarios survive.** When a guide's AC structure is not Gherkin, the
   translated criteria go in the AC field per the guide, and the verbatim Given/When/Then
   scenarios remain in the machine block, so QA and delivery keep the exact behavioral contract.
5. **The dry run names the guide.** The Step 3 confirmation states which format guide is being
   followed and shows one fully rendered child, so the team sees their own format before any
   write.
