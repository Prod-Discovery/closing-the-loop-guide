# Multi-repo products

Real products rarely live in one repository — a 113-repo landscape split by layer is normal, not
exotic. Any skill that reads code must therefore know, and say, which part of the product it can
actually see. These rules are shared by the code-reading skills (`handover-shape-feature`,
`handover-codebase-discovery`, `component-readiness-scan`, prototyping) and the preparedness scan.

## Repo shape — detect before reading

At the start of any code-grounded run, establish the shape of the working directory:

- **One git repository** → single-repo view. Nothing more to declare unless the landscape file
  (below) lists repositories that are not this one.
- **A parent folder holding several git repositories** (or a `.code-workspace` file) → multi-repo
  view. Enumerate the checkouts; resolve git context **per repository, from inside that
  repository's folder** — the parent folder itself is usually not a git repo, so a bare `git
  rev-parse` at the top level fails and that is normal.
- **Inside one repository of a larger product** — the shape you cannot detect from the inside.
  The landscape file and the escalation rule below are the safety net.

Starting the session from the parent folder is the supported way to work on a multi-repo product:
everything under it is readable, and each repo keeps its own git context. Starting inside one repo
limits the view to that repo — nothing outside it exists for the session.

## The repo landscape file

`repo-landscape.md`, at the root of the parent folder (or of the single checkout), is the team's
own map of the product: one row per repository with its layer and what it holds — including the
repositories **not** checked out locally. Database schemas and pipelines may ride along.

- When present, read it before reading code, and treat it as the authority on what exists beyond
  the working view.
- When absent in a multi-repo folder, say so and offer to draft one from the checkouts found —
  filling in what each repo holds is the team's 10 minutes, not a blocker.
- The preparedness scan (`closing-the-loop-start`) checks for it at Week 0, which is where a team
  first learns they need it.

## Declare the working view

Every code-grounded output opens with one plain statement of scope, for example:

> Working view: `shop-web` @ `8402cf7`, `shop-admin` @ `933dbe9`. Not checked out (per
> repo-landscape.md): `shop-api` — backend claims are unverified.

Never present conclusions from a partial view as conclusions about the product. A reader must be
able to tell "the code does not do this" apart from "the code I could see does not do this."

## When the visible code cannot explain a requirement

If a requirement, setting, or behavior has no plausible home in the visible code — a feature flag
no checkout defines, an API nothing implements, an admin capability with no admin surface — do not
answer from the partial view and do not invent an owner. Name what is missing, point at the
landscape row (or say the landscape has no candidate), and ask whether another repository holds it.
In a Delivery Context this becomes an unresolved decision naming the probable repository; in a
reference document it is a `Not covered — lives outside the working view` note.

## Base commits are per repository

Freshness is checked repo by repo. Record one base commit **per repository in the working view**
(a single-repo product keeps a single entry), and compare evidence paths against the commit of the
repository that owns them. A legacy single `Base commit:` line reads as a working view of one
repository.
