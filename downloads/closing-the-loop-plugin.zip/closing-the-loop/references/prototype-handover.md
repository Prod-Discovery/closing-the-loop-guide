# The prototype in the handover — source, not bundle

The kind of prototype decides what may cross into implementation. Both handover paths apply this rule.
The older "prototype code is intent documentation only" rule came from the first pilot, whose frontend
was not component-based, so every prototype was throwaway code. It still holds for that kind. It does
not hold for a prototype built from the team's own components.

| Kind | How to recognize it | What delivery does with it |
|---|---|---|
| **Component prototype** | Built by `prototype-from-components` from `component-inventory.md`. It imports the team's components — at their production paths or through a kit copy of the library — and has a `prototype-pack.md` at its source root. | The source is the **UI reference implementation**. Delivery opens it and may port from it under the port rule below. |
| **Throwaway prototype** | A single HTML / JSX file, or code that does not import the team's component library (a stack with no component library, or a run older than the prototyping refresh). | **Intent documentation only.** Read it in full and capture its exact values (layout, defaults, column order, every state) into the handover. Copy no code. |

When the kind is unclear, look for `prototype-pack.md` first: its design-system line names what the
prototype imports, including a kit copy of the library kept under a different alias. With no pack, read
the imports. Any import of the team's library — at a production path, or through an alias or copy of it
(the team's component prefix in the markup, e.g. `dds-`, is corroborating evidence) — makes it a
component prototype. Without any such import it is throwaway.

## What to share, and with whom

- **People** (PM, stakeholders, test participants) get the hosted link or the HTML export.
- **Agents** (shaping and delivery) get the **source**. Never hand an agent a deployed build as the
  thing to build from. A built single-page app serves a minified bundle, where tokens are compiled to raw
  values and component boundaries are gone. A pilot team's delivery agent was given a hosted link,
  received a 1.8 MB minified bundle, and got the behavior right but the design wrong. A comparable
  prototype's source in the same kit is about 72 KB, with every spacing and type value named as a token.

A source location takes one of these forms:

- a git repository, branch, **commit**, and folder (pin the commit so the reference cannot drift);
- a zip of the source folder attached to the ticket (`discovery-create-tracker-issue`'s
  `package_prototype.sh` strips `node_modules`, `.git`, `dist`, and other build output);
- a local path, only when the reader is on the same machine.

If a component prototype is reachable only as a hosted link, ask for the source. If the user proceeds
without it, mark the UI reference `[Prototype source not available — design detail unverified]` so the
gap stays visible.

## The prototype pack

`prototype-from-components` writes `prototype-pack.md` at the root of the prototype source, next to
`prototype-decision-log.md`, when the prototype is approved. It refreshes the pack after every refine.
Because it sits in the source folder, it travels with the branch or the zip. Keep it to this shape:

````markdown
# Prototype pack — <feature>

- **Source:** <repo URL> · branch `<branch>` · commit `<sha>` · folder `<path>`
- **Design system:** imported from `<prototype import root>`, a copy of `<production path>` at
  `<commit or version>` (or: the production package `<name>@<version>` itself)
- **Run it:** `<command>`, then open `<route>`
- **Stand-ins:** flagged inline as `<the convention this source uses, e.g. SUBSTITUTE or NEW COMPONENT>`;
  fixes listed in `fidelity-fixes.md` when present, otherwise in the inline flag comments

| Screen / state | How to reach it | Files |
|---|---|---|
| <screen> — <state> | <route, or the mock flag to set> | `<path>.html`, `<path>.scss` |
````

One row per state a test participant saw, including the empty, loading, and error states. Name the
files. Do not paste their code.

## The port rule — component prototypes only

Delivery **may** port:

- the markup structure and component usage, with their props;
- the styles and token usage (spacing, type, color, radius). Keep tokens as tokens; never resolve
  them to raw values.

Delivery **must not** port:

- mock data, fake services, or stubbed wiring. Replace them with the production data path from the
  change map.
- stand-ins as they are. Build the real component, or apply the fix pattern named in
  `fidelity-fixes.md` (when there is no fixes file, the fix named in the stand-in's inline flag
  comment). Keeping a stand-in needs an explicit decision.
- kit import paths. Translate them to production paths using the pack's design-system line.
- hard-coded copy. Move it into the product's translation mechanism.

Ported code goes through the normal plan, tests, and review. The prototype is a reference, not
pre-approved code. Where production conventions differ (state management, accessibility, i18n),
production wins, and the pull request says where it deviates from the prototype.
