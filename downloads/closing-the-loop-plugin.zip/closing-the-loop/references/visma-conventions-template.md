# Visma Conventions Template — AGENTS.md Starter

Copy this template into your repository root as `AGENTS.md` and fill in the
sections that apply. Delete sections that don't apply. The goal is under 80
lines of project-specific, non-obvious information.

---

```markdown
# AGENTS.md

## Build & Test
- Build: `[exact build command]`
- Test: `[exact test command]`
- Test (single file): `[exact command with placeholder]`
- Lint: `[exact lint command]`
- Type check: `[exact type-check command, if applicable]`
- Format: `[exact format command]`

## Environment Setup
- Package manager: `[pnpm/npm/yarn/maven/gradle/etc]` — do not use alternatives
- Local setup: `[exact steps to go from clone to running]`
- Required services: `[databases, queues, etc. and how to start them]`
- Environment variables: copy `[.env.example]` to `[.env.local]`

## Conventions
- [Your most important naming or structural convention]
- [Your commit message format, if non-standard]
- [Your branch naming convention, if non-standard]
- [Any architectural boundaries — e.g., "do not import from X in Y"]

## Do Not
- [Critical thing agents should never do in this repo]
- [Another prohibited action — e.g., "never modify generated files"]

## Common Pitfalls
- [Thing that breaks and how to fix it]
- [Non-obvious dependency or ordering requirement]

## Skills
This repository uses skills from the Visma Skills collection.
For development workflows, load the appropriate skill:
- Feature development: `develop-feature`
- Bug fixes: `fix-bug`
- Releases: `prepare-release`
- Repo setup: `onboard-repo`
Skills are available at: https://github.com/Visma-AI-Engineering-Technology/visma-skills
```
