# Example — a strong team ticket format guide

A generalized example of a team's ticket format guide, modeled on a pilot team's well-groomed
backlog format. Copy it, replace the bracketed parts with your product's own conventions, and point
`ticketFormatGuide` in the Closing the Loop config at your copy. Everything here is a template for
**your** guide — none of it is required by the plugin.

---

## Rules for anyone (or any agent) creating tickets

1. **Use the templates exactly** — same headings, same order. Hint text stays where information
   is genuinely unknown; never invent facts to fill a section.
2. **Facts only.** Every statement comes from the request, the source material, or confirmed
   knowledge. Mark assumptions *(to be confirmed)*. Do not invent data-model names, translations,
   SLAs, permissions, or message texts.
3. **Be testable.** One checkable statement per rule: exact message texts, defaults, permissions,
   ON/OFF behavior of settings and toggles. No "seamlessly", "reasonable", or "e.g." lists.
4. **Cover the unhappy paths**: invalid input, not found, failure half-way, cancel, double
   submit, missing permission.
5. **No sensitive data** in any field: no credentials, customer names, tenant identifiers, or
   personal data.
6. New tickets get the tag `[your grooming tag]`; the team removes it after grooming.

## Title

```text
[Product] - [Module] : [Feature] - [one short, user-facing line, ~90 characters]
```

## Work item fields

| Field | Value |
|---|---|
| Work item type | [your requirement-level type] |
| Area / Iteration path | [your defaults; the team moves items into sprints] |
| Priority / Value area | [your defaults] |
| Parent | the Feature the ticket belongs to |
| Tags | [grooming tag]; add [toggle tag] when the change is behind a feature toggle |

## Description template — the why and who

```text
As a [user role] I would like to [action], So I can [benefit]

[Optional background: original request, example, link to the design]

Impacted Screens:
  • [one bullet per screen, as a navigation path — or "None – background process"]

Privacy / Security Concerns:
  • [personal data shown/stored/sent; access control involved — or N/A]

Performance Concerns:
  • [expected volumes, file sizes, SLAs, bulk cases — or N/A]

Out of scope
  • [what this ticket deliberately does not cover, and why]
```

## Acceptance Criteria template — the what, in detail

```text
Functional Summary:
  • Requirement in brief: [1–3 sentences: what and where]
  • Current implementation and limitations: [how it works today, why that is a problem]
  • Value proposition: [concrete gains — less manual work, fewer errors]

Functionality in Detail:
  • Impacted modules / functionalities: [exact names]
  • Impacted user roles: [exact role/permission names]
  • Requirement in detail: [numbered, testable rules: fields, defaults, exact message
    texts, permissions, toggle ON/OFF behavior, error/cancel cases, mock-ups per UI state]
  • Non-functional requirements: [measurable performance, security, privacy expectations]

Other Area:
  • Testing scope: [positive, negative and regression scenarios beyond the rules above]
  • Out of scope: [explicit exclusions with reasons; related ticket ids if planned later]

Common Validations: [your team's standing QA checklist — locales, themes, browsers,
  audit/history capture, telemetry, field validations; remove items that do not apply]
```

## A completeness checklist

- [ ] Title follows the convention; the parent Feature is set.
- [ ] The user story has all three parts (role, action, benefit).
- [ ] Every Description section is filled, or N/A on purpose; open points marked *(to be confirmed)*.
- [ ] Requirement in detail states exact messages, permissions, defaults, and toggle ON/OFF behavior.
- [ ] Failure, cancel and repeated-submit behavior is described.
- [ ] UI changes have mock-ups; data-model changes name their objects (when known); new texts are listed for translation.
- [ ] Testing scope has positive, negative and regression scenarios.
- [ ] Irrelevant standing-checklist items are removed; the grooming tag is set.
