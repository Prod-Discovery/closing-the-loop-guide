# Discovery working directory — path resolution

The discovery lane came from a plugin written for the Cowork / claude.ai sandbox, where
`/home/claude/` and `/mnt/user-data/outputs/` always exist. **Neither exists in a local Claude Code
install.** On macOS `/home` is an autofs symlink and `mkdir /home/claude` fails outright with
`Operation not supported`; `/mnt` is simply absent. Hardcoding those paths means every stage
produces content and then fails to persist it where the next stage looks.

Two logical locations, resolved once at the start of a run and reused by every stage.

## `$DISCOVERY_DIR` — stage output files

Where the run's own state lives: `product-context.md`, every `stage-*.md`, the prototype export, and
Stage 4's `component-inventory.md` + `prototype-rules.md` (older runs: `component-library/`). Stages
read each other through this directory, never through conversation history.

Resolve in this order, first writable wins:

1. **`/home/claude/discovery-engine/`** — Cowork / claude.ai. Use when `/home/claude/` exists and is
   writable.
2. **`./discovery-engine/`** — local Claude Code, relative to the current working directory (usually
   the repo root). Create it if missing.

Probe rather than assume — attempt to create option 1 and fall through on any failure. Do not test
for "am I in Claude Code" by any other signal; writability is the only thing that matters.

**State the resolved path once**, at Stage 0, in the confirmation message — the user needs to know
where their outputs are. Do not re-announce it at every stage.

**When resolution lands on option 2**, the directory sits inside the user's repo. Mention that
`discovery-engine/` may want a `.gitignore` entry — a discovery run is working state, not source.
Ask before adding one; never edit `.gitignore` unprompted.

## `$OUTPUTS_DIR` — the shareable copy

Where a copy goes so the user can download it, paste it into a deck, or re-upload it to resume a
later session.

1. **`/mnt/user-data/outputs/`** — Cowork / claude.ai, when it exists.
2. **Otherwise `$OUTPUTS_DIR` is `$DISCOVERY_DIR`** — locally the working directory *is* the user's
   workspace. Skip the copy step entirely rather than duplicating every file; state the full path
   instead. This is the same environment where `present_files` is unavailable, so the two fallbacks
   travel together: no downloadable card, no second copy — just tell the user the path.

## What this means per stage

| Was hardcoded | Now |
|---|---|
| `/home/claude/discovery-engine/…` | `$DISCOVERY_DIR/…` |
| `/home/claude/component-library/` | `$DISCOVERY_DIR/component-library/` |
| `/mnt/user-data/outputs/…` | `$OUTPUTS_DIR/…` (may equal `$DISCOVERY_DIR`) |

`component-library/` moved under `$DISCOVERY_DIR` rather than staying a sibling, so one resolved root
covers a whole run and Stage 4 → Stage 5 handoff needs no second probe. (Since the 2026-08 prototyping
refresh, Stage 4 writes `component-inventory.md` + `prototype-rules.md` instead of generating
`component-library/` — the mapping above still applies when reading older runs.)

## Standalone stage runs

Any stage can be invoked on its own, without Stage 0 having run. In that case resolve
`$DISCOVERY_DIR` with the same order above and read whatever prior stage files are already there. If
the expected input file is missing, say which stage produces it and offer to run that stage — do not
invent the content.

## Upstream divergence

This convention is **local to Closing the Loop**. Upstream
[`Prod-Discovery/discovery-engine-plugin`](https://github.com/Prod-Discovery/discovery-engine-plugin)
hardcodes the sandbox paths because it only ever runs in Cowork. Re-apply this on the next upstream
sync, or push the resolution upstream — it is a strict improvement there too, since option 1 still
wins in the environment upstream targets.
