# Backlog shape — the per-feature decision

`backlogMode` in `~/.config/closing-the-loop/config.json` is the team's **default** backlog shape, not
the decision. The shape of any one feature — **single-ticket** (one ticket, one PR) or **epic**
(vertical `S-n` stories projected as tracker children) — is decided per feature by the shaper for its
path: `handover-shape-feature` (context-first, Step 6) or `discovery-handover-package` (governed,
Step 3.5). Both apply this reference. Every downstream skill reads the outcome from the artifact,
never from config — the same way the handover path is resolved from the ticket marker.

## Inputs the shaper already holds

- `D-n` count and the surfaces each touches (from the change map).
- `AC-n` count (from the acceptance examples).
- Candidate slice groupings — which `AC-n` would travel together — with the owner or discipline each
  group would need.
- Sequencing dependencies between groups, and any chore that must merge before the rest can start.
- The team default: `backlogMode`, `single-ticket` when absent.
- Whether this is a fresh shaping or a re-evaluation of an existing artifact (see below).

## Heuristic

Recommend **epic** when either holds:

- **(a) Real slices.** Two or more groups would each own a coherent, disjoint subset of `AC-n` **and**
  either need a distinct owner/discipline or have a hard sequencing dependency between them.
- **(b) More than one PR.** The contract clearly exceeds one reviewable pull request — many `D-n`
  across independent surfaces or layers, or a chore that has to land and merge first.

Otherwise recommend **single-ticket**. Use the team default **only as the tie-breaker** when the
evidence is balanced, and say so in the recommendation. A team default of `epic` never turns a
one-PR feature into an epic on its own; a default of `single-ticket` never suppresses a real slice set.

## Output and confirmation

Produce: the recommended shape; one evidence line per criterion (a) and (b); whether the team default
was needed to break the tie; and the confirmation question. Ask **exactly one** question per run —
recommendation, team default, the two options — and do not re-ask later in the same run.

This is a per-feature confirmation, not a re-ask of setup. **Never write the outcome back to the
config.** The shaper's summary states the chosen shape and whether it matched the team default.

## Recording the outcome in the artifact

1. **The story-map section is present iff the feature is epic-shaped** — `### 6.3 Story map` in the
   Engineering Brief (governed), `### Story map` in the Delivery Context (context-first, on the ticket
   section or the Confluence sub-page). Its presence is the source of truth.
2. **A header line states it in words:**
   `> **Backlog shape:** epic | single-ticket (team default: <X>; chosen per feature)`.
   The header is the human-readable statement; when the two disagree, section presence wins.
   Header says single-ticket but a story map is present → the header is wrong (mechanical fix).
   Header says epic but no story map → ambiguous (judgment; ask before projecting anything).

## How each consumer resolves the shape

| Consumer | Reads |
|---|---|
| `handover-project-stories`, `handover-deliver-epic` (context-first) | Delivery Context `### Story map`; projected children (`context-first` story / backlog-item labels) corroborate |
| `create-backlog-from-brief`, `handover-workflow`, `prepare-amigo-session`, `handover-brief-review`, `handover-deliver-epic` (governed) | Brief `### 6.3 Story map`; manifest `backlogShape`, Jira Epic type, and `discovery-handover-backlog-item` children corroborate |
| `closing-the-loop` orchestrator | whichever of the above matches the ticket's path marker |
| `handover-retrieval` | nothing new — its walk-up stays label- and stamp-driven |

Children corroborate the shape for **delivery-side** skills only. Shapers never infer shape from
existing children; children are downstream of the decision.

## Backwards compatibility

- Older artifacts carry `> **Backlog mode:** …`. Read that label as equivalent to `Backlog shape:`;
  relabel it only on the next refresh or revision. Renaming changes the Delivery Context hash once,
  so projected children are flagged stale one time — expected, not a defect.
- Older artifacts already carry or omit the story-map section, so every consumer resolves them with no
  migration. An older config with `backlogMode: epic` simply makes epic the tie-breaker.

## Re-evaluating an existing feature

"Should this ticket be an epic?" / "re-evaluate the backlog shape for <KEY>" routes to the shaper for
the ticket's path (the marker decides), run against the existing artifact with the same heuristic and
the same single confirmation.

- **single-ticket → epic:** add the story map, fix the header, bump the version. Governed: this is a
  Brief revision that **re-opens both sign-offs**. **Jira:** the sign-offs are Sub-tasks under a
  non-Epic source — **never convert the ticket**; converting orphans them (see `KNOWN-ISSUES.md`).
  Use the wrapper-Epic model in `create-backlog-from-brief` Step 5 when stories are later projected.
- **epic → single-ticket:** only while no children have been projected. Once children exist, stop and
  report — removing a projected backlog is a tracker decision for the team, not a shaper action.
