# Known Issues

This is a prototype-stage bundle. `bash scripts/verify-skills.sh` passes (0 failures); a handful
of informational **warnings** remain. Nothing here blocks use.

## Verifier warnings (informational)

The shared verifier was deliberately loosened to fit a prototype bar and to respect the
discovery lane's authoring style (it's a separately owned package — see provenance in the README):

- It accepts `## Step` / `## Phase` / `## How to Start` as workflow-equivalent sections, not just `## Workflow`.
- 500 lines is a guideline (warn); 600 is the hard cap.

Skills currently warning (worth a light upstream cleanup eventually, not now):

- `discovery-to-prototype-engine` — 544 lines (over the 500 guideline).
- A few skills reference tool-specific commands rather than tool-neutral phrasing.

## Jira hierarchy: Epic conversion orphans Sub-task sign-offs (verified on staging)

Converting a source ticket to **Epic** while its `✋ PM` / `✋ Dev` sign-off **Sub-tasks** are attached
succeeds silently (HTTP 204) and **detaches both sub-tasks** (`parent: null`, no error) — verified
2026-07-14 on the team-managed staging project (KAN-24…26). Mitigation shipped: for an epic-shaped
feature on Jira, `discovery-handover-package` runs a **hierarchy preflight** — the source is converted to
Epic *before* the sign-off children are created, and the sign-offs are standard **Task-type
children**, not Sub-tasks (Task-type children parent cleanly to an Epic; also verified). Caveats:

- Verified on a **team-managed** project only; company-managed schemes may behave differently — the
  preflight stops and asks on anything unexpected rather than pressing on.
- Type conversion can change workflow, required fields, and board behaviour — the preflight previews
  and asks for confirmation before converting.

## Jira reshape single-ticket → epic after sign-offs exist: wrapper Epic, never conversion

Backlog shape is decided per feature at handover, so a feature shaped single-ticket — whose `✋ PM` /
`✋ Dev` were created as **Sub-tasks** of a non-Epic ticket — can later be re-evaluated and shaped epic
("should KAN-63 be an epic?"). The early conversion above is no longer available at that point:
converting now would orphan both sign-offs exactly as verified. The reshape is therefore a Brief
revision (adds §6.3, bumps the version, re-opens both sign-offs), and when stories are later projected
`create-backlog-from-brief` uses its **wrapper-Epic model** (Step 5) — a new Epic linked to the source
ticket, with the stories as its children — rather than converting the source. The rule: on Jira, convert
to Epic only in the `discovery-handover-package` preflight, before any sign-off child exists; any later
reshape is a wrapper. Heuristic and switching rules: `references/backlog-shape-decision.md`.

## Sign-off checklist scan: the MCP always flattens descriptions to markdown

**`responseContentFormat: "adf"` does not work on `getJiraIssue`.** The parameter is accepted without
error and **silently ignored** — the description comes back as markdown regardless. Verified
2026-08-04 against three live issues (KAN-63, KAN-59, KAN-16); independently reported upstream
[2026-06-16](https://community.developer.atlassian.com/t/rovo-mcp-server-no-attachment-upload-tool-and-description-drops-adf-media-nodes-on-edit/101278)
and still open. **Do not write gate logic that expects ADF `taskList`/`taskItem` nodes from the MCP —
they never arrive.** (This also means an agent editing a description through the MCP can silently
destroy embedded ADF `media` nodes, which is the other half of that upstream report.)

Because everything arrives as markdown, the scan is a text scan — and live sign-offs contain **two
different renderings**, so matching only one is unsafe:

| Form | Example | Where seen |
|------|---------|------------|
| Real markdown checkbox | `- [ ] Problem statement reflects…` | KAN-59 (Task-type, current template) |
| Escaped literal text | `* \[ \] **Problem statement** reflects…` | KAN-16 (Subtask, wiki-markup path) |

The second form is the "dead text" case `signoff-subissue-template.md` warns about — `\[ \]` was never
a tickable box in the Jira UI at all. **A scan matching only `- [ ]` misses those items and reports a
clean scan on a sign-off where nothing was ticked** — a false pass on the approval gate. KAN-16 is
exactly that: Done, with all ten boxes unticked in the fetched text.

**The rule:** match both forms (optional `-`/`*` bullet, optional backslashes around the brackets),
and treat Done-with-any-unticked-form as a dirty gate. And keep the honest limit in the report: since
the MCP flattens to markdown, an unticked box cannot be distinguished from literal text that was never
tickable. Tracker checkboxes are never workflow validators — Done state plus the template's
instruction to reviewers is the backstop, and the scan is a check on top of it, not a substitute.

## Jira attachments: no MCP tool on GA; a preview endpoint has them

**GA (what the skills target today):** the Atlassian MCP exposes **no attachment tool** — no upload,
no byte download. `fetch` resolves issues/pages by ARI only. Jira's create-field metadata lists an
`Attachment` field that cannot carry bytes; ignore it. Verified 2026-08-04; upstream requests
[#15](https://github.com/atlassian/atlassian-mcp-server/issues/15) (download),
[#47](https://github.com/atlassian/atlassian-mcp-server/issues/47) (upload),
[#63](https://github.com/atlassian/atlassian-mcp-server/issues/63),
[#110](https://github.com/atlassian/atlassian-mcp-server/issues/110) (Confluence) and
[#125](https://github.com/atlassian/atlassian-mcp-server/issues/125) are all still open. **This is why
the REST + classic-token path exists** (`references/jira-attachment-upload.md` /
`-download.md`) — it is not legacy cruft, and it must not be removed.

**Preview endpoint — `https://mcp.atlassian.com/v1/mcp/preview`** (vs GA `…/v1/mcp`). Same auth,
products and clients; no admin opt-in or feature flag — connecting to the URL is the whole opt-in.
It carries `uploadAttachmentToJiraIssue`, `downloadJiraIssueAttachment`, and four Confluence
attachment operations. Two structural caveats:

1. They are **discovery operations, not pre-declared tools** — reachable only via the `discover` /
   `execute` meta-tools, which the GA surface does not expose. So they are unreachable from a GA
   connection.
2. **Bytes still do not move through MCP.** Each returns a short-lived URL plus *a local command to
   run* ("return a local curl command"). The curl mechanics in our reference files stay; only the
   URL's provenance changes.

**The open question that decides whether this is worth adopting:** is the brokered short-lived URL
pre-authorized, or does the client still need its own credential? Atlassian's docs do not say. If
pre-authorized, this removes the classic-token setup step from `closing-the-loop-setup` — the single
biggest friction point in Jira onboarding. If not, it is a cosmetic change over the REST path and not
worth taking on preview-grade risk. **To settle it:** add a second server on the preview URL,
authorize it, and try `uploadAttachmentToJiraIssue` with no `~/.netrc` and no `JIRA_API_TOKEN` in the
environment. Sandboxed clients must also allowlist `api.media.atlassian.com` and
`*.frontend.public.atl-paas.net`.

## Jira description cap: budget to 32,000 characters

The effective cap **depends on the write path**, so budget to the tighter of the two:

| Path | Cap | Enforced by |
|------|-----|-------------|
| Atlassian MCP `createJiraIssue` | **32,000** | the tool schema (`description.maxLength`) — rejected before the request is sent |
| Jira REST API directly, and `editJiraIssue` (description passed through `fields`, uncapped in-schema) | **32,767** | Jira, as HTTP 400 |

"The ticket description IS the full Engineering Brief" can collide with this on a thorough brownfield
Brief — observed on the KAN-30 pilot, where the wiki-converted Brief exceeded the cap and needed a
tightening pass. **Measure against 32,000**, not 32,767: a Brief sized to the Jira limit still fails
through the MCP's create tool, and the same text may be written through either path.

The rule (`discovery-handover-package` Step 7.0): convert first, measure, and if over, run a
**logged, content-preserving tightening pass** (reword, never drop content; own version bump naming
the §s reworded). Abridging the description ("see attached §X") remains a defect. Related: Jira
renders descriptions as wiki markup, not markdown — the description is
content-verbatim/markup-translated, and the markdown attachment stays canonical.

## Confluence: five constraints, all verified

Verified against a live Cloud site on **2026-08-05** while adding the Confluence requirements surface.
The first two are traps that fail *after* a page already exists, so they decide step ordering; the third
is the reason the marker is not a label; the fourth is a silent data-loss risk; the fifth will waste your
debugging time. Full mechanics live in
`skills/discovery-create-tracker-issue/references/confluence-page-publishing.md`.

**1. Create with `status: "current"` — the MCP cannot publish a draft.** `updateConfluencePage` always
sends the next version number, but Confluence requires version 1 on a first publish, so a draft→published
transition fails with `Version number must be 1 when publishing a page for the first time. Provided
version: [2]` (400). There is no MCP path out of a draft.

**2. Attachments require a published page.** `POST /wiki/rest/api/content/{id}/child/attachment` against a
draft returns `404` with `No content found with id : ContentId{id=…} and status [current], there is a
content object with status : draft`. Combined with (1): publish first, attach second, and never create a
draft you intend to attach to. As with Jira, there is **no MCP attachment tool** — the classic-token REST
path is mandatory, not legacy.

**3. No Confluence label tool on the MCP, but the REST label endpoint works.** `POST
/wiki/rest/api/content/{id}/label` with `[{"prefix":"global","name":"…"}]` returns `200` — and unlike
attachments it works on drafts. Because the tool is missing, the handover path marker on a page is a
**body block**, not a label; the label is applied as a convenience mirror when a token exists. Never route
on the label alone.

**4. Reading a page as `markdown` is lossy — silently, and it eats exactly the content we care about.**
On a requirements page carrying a `panel-warning` ("Legal reviewed the reminder wording — do not change
the template copy") and a `decision-list` item marked `DECIDED` ("Cap a batch at 50 invoices"),
`getConfluencePage` with `contentFormat: "markdown"` returned **both as ordinary paragraphs** — a
constraint and a decision reduced to background prose. A `task-list` likewise flattened to `- [ ]`.
Reading the same page as `html` preserved all three, with their `data-state` and `data-local-id`
attributes. Two consequences: **any update to a human-editable page must fetch and write `html`**, or a
PM's constraint is destroyed by the round trip; and the flattened `- [ ]` is the *same* dead-text
ambiguity documented above for Jira's ADF flattening, so never build a gate check on checkboxes read out
of a page as markdown. Reading as markdown is fine when you only want the prose — never as the read half
of a write.

**5. `body.storage` is a third representation — do not verify against it.** Storage is not what you
wrote: a `data-type="panel-warning"` div is stored as `<ac:structured-macro ac:name="note">` (severity
normalised away) and an absolute page URL is stored as `<ac:link><ri:page ri:content-title="…"/></ac:link>`
(a *title* reference, not an id). Both render correctly and both read back correctly as `html`. Assert on
a `contentFormat: "html"` read; inspecting `body.storage` with curl makes a healthy round trip look
broken — a trap worth an hour if you hit it cold.

Two smaller notes: `createConfluencePage` accepts a space **key** and resolves it to the numeric id (no
lookup step), and pages default to parenting under the space homepage. Deleting needs the status the
content is in — a plain `DELETE` targets `current` and returns `404` for a draft, which needs
`?status=draft`.

**What this surface buys:** it removes the 32,000-character pressure documented directly above — a
Confluence page has no comparable cap, so a thorough Brief needs no tightening pass — and it gives
requirements native page versioning plus an editing surface a PM will actually use.

## Cowork parity: what carries over, what does not

The plugin format itself is not the problem — plugins are fully supported in Cowork, same
`.claude-plugin/plugin.json`, no repackaging. Three other things diverge. Documented 2026-08-05 from
Anthropic's Cowork docs plus an audit of this repo; the items marked **unverified** need one session in
an actual Cowork instance to settle, the same way the Confluence endpoints above were settled.

**Distribution is separate.** Cowork loads skills and plugins from claude.ai account settings, synced at
session start, and deliberately **does not read `~/.claude/`**. A local `claude plugin install` does not
carry over — add it under **Cowork → Customize → Plugins**. For a team, Team/Enterprise can provision
org-wide under **Organization settings → Skills**, which is the better path for a pilot cohort than each
person installing locally.

**No classic API token exists in Cowork.** Connector OAuth tokens never enter the sandbox and `~/.netrc`
is not part of that environment, so every REST-token route is unavailable: Jira attachments, Confluence
attachments, the Confluence page label, and the setup verify. All four degrade rather than fail
(`discovery-create-tracker-issue` Step 2, `closing-the-loop-setup` Step 6); the single attachment
fallback everywhere is a **manual upload by the user** — deliberately not a third storage service, since
another connector would just move the credential problem rather than remove it. **Confluence degrades
best** — page create/read/update is pure MCP and the path marker is a page *body block*, so the routing
layer every downstream skill depends on needs no credential at all. That was forced by the missing MCP
label tool; it happens to be what makes the surface Cowork-portable.

**The engineering lane does not belong there.** 32 of 39 `v-*` skills invoke `gh`, and the lane assumes a
checkout, a test run, and a PR. Cowork is a knowledge-work surface with no repo workflow. By contrast
only 3 discovery skills reference a repo at all, and that lane *originated* in Cowork — which is why
`references/discovery-working-directory.md` probes writability instead of detecting the environment. The
honest scope is **discovery + handover in Cowork, `v-*` delivery in Claude Code**. Anyone proposing full
parity should cost the `gh` dependency first.

Two things to check rather than assume:

- **`${CLAUDE_PLUGIN_ROOT}` — 27 sites** across skills and hooks. It should resolve for a plugin-packaged
  install, but Cowork parity is not documented. If it does not, bundled `references/` links and the four
  telemetry hooks break together. **Unverified.**
- **Writable paths.** `/home/claude/` and `/mnt/user-data/outputs/` are the claude.ai sandbox convention
  and are not documented as Cowork paths. The probe handles absence correctly, but its fallback lands in
  whatever folder the session has been granted — which may not be a repo. **Unverified.**

Hooks are confirmed supported for plugin-bundled components in Cowork (and greyed out in plain chat), so
telemetry should work there; that too is worth confirming rather than trusting.

## Epic mode had no slice-walking step — FIXED, except the non-GitHub PR rung

**Resolved by `handover-deliver-epic`** (both handover paths), plus a best-effort in-flight
transition in `v-ticket-to-release` Phase 0. Defect (2) below — the nominal non-GitHub PR rung —
**remains open**; the walker now converts that degradation into an explicit `awaiting-merge` stop
instead of a silent no-op, but nothing yet opens or merges a change on a non-GitHub host. The
original analysis is kept below because it is the evidence for why the walk works the way it does.

---

In `backlogMode: epic`, `handover-project-stories` projects one tracker issue per `S-n` slice plus
`C-n` chores. **Nothing then walked them.** The rule existed but had no mechanism behind it:

- `closing-the-loop` Step 4 states it in one passive sentence — *"In epic mode, deliver chores first
  and then one `S-n` story per PR in dependency order"* — with no loop, no dependency-order
  derivation, no per-story completion criteria, and no instruction to return after each story.
- `v-ticket-to-release` takes **exactly one** ticket and has no notion of a sibling set or a parent
  epic. It ends at "merged + transitioned" for its single ticket and never hands back to pick up the
  next one.

So the pipeline reliably produces N tickets and then delivers them as one undifferentiated unit.

**Verified on the BHB pilot** (KAN-63 Anlagenverzeichnis-Export, 2026-07-31 → 2026-08-03):

| | |
|---|---|
| Children projected | 10 (KAN-64 chore + KAN-65…KAN-73 stories) |
| Entered a delivery skill | **1** — `v-ticket-to-release` on KAN-64 only |
| Branches created | 2: `kan-64-assetregister-fixture`, then `kan-63-anlagenverzeichnis-export` (15 commits, everything else) |
| Tracker status at the end | **all 10 still `To Do`**, epic included |

Note what this is *not*: the ordering rule was read and obeyed — the chore genuinely went first. The
run then fell out of the sequence after one iteration, because there is no iteration construct to
stay inside. A single epic-wide branch replaced per-story PRs, and the nine remaining stories were
built without ever being fetched, planned, or closed as tickets.

**Two compounding defects:**

1. ~~**No `In Progress` transition anywhere in the pipeline.**~~ **Fixed.** `v-ticket-to-release`
   transitioned only in its post-merge phase, so for the entire multi-day build every ticket was
   indistinguishable from unstarted work — the BHB run had to compensate in prose, writing stories
   that "state plainly that they were written after the fact and name the implementing commits, so
   nobody mistakes them for unstarted work." Phase 0 now moves the ticket into the project's first
   in-flight state once the branch exists, read from the available transitions rather than assuming a
   name. Deliberately **best-effort and not a gate condition**: environments with no tracker write
   path skip it and say so, because hard-failing Phase 0 there would be worse than the original bug.
2. **The non-GitHub rung of the PR ladder is nominal — still open.** `v-ticket-to-release`'s Tooling Note lists
   "Bitbucket / Azure Repos / GitLab equivalents" but no mechanism exists, so a Bitbucket repo
   degrades straight to "user-provided actions" — taking PR creation, merge, post-merge CI *and* the
   ticket transition down with it. BHB, the pilot repo, is on Bitbucket. Per the Tooling Note this
   degradation is correct and was surfaced rather than hidden, but it means the whole tail of the
   workflow is unreachable there.

Consequence: a ten-story epic could be fully implemented, tested and pushed while the board showed
nothing started. Fixing (1) alone would not have helped the nine stories — they never entered a
workflow that transitions anything. **The slice-walking step was the load-bearing fix.**

**What the walker changes for the residual defect.** On a host with no automated merge path, a
delivery run returns a *complete* report with no merge reference — previously indistinguishable from
success, which is how ten tickets stayed in `To Do`. The walker classifies that as `awaiting-merge`,
stops, and surfaces the outstanding merge and transition, keeping it distinct from `blocked` (a merge
that was attempted and refused). So the walk is honest on Bitbucket today; it is just not unattended.
A ten-child epic there costs ten human round-trips, which the walker states up front at its
confirmation step so the team can choose to build the PR rung first.

## Phase 2 gap: into production ("stage 8")

The brief's Phase 2 — taking an AI-assisted implementation into production (feature toggle, pilot
group, observability, optimise before full launch) — is **not** yet covered by a dedicated skill.
The `closing-the-loop` orchestrator stops at release and names this as an out-of-scope follow-up
rather than treating a generic release as production-ready. That's Phase 2 work, scoped by Phase 1.
