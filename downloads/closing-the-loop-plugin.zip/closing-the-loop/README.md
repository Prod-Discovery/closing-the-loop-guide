# Closing the Loop

A single Claude Code plugin that bundles **product discovery**, the **handover seam**, and
**engineering delivery** into one skill set — taking a feature from raw customer signal, through a
validated prototype, across the PM→engineering handover, into implemented and reviewed code.

It is the "default skills and workflows template" deliverable for the *Closing the Loop: Discovery
to Delivery* project — a concrete, adaptable starting point, **not a prescription**. The process it
encodes is meant to be run on a real feature, stress-tested across product, design, and
engineering, and adapted. Honesty about where it breaks is the point.

**New here?** [Install](#install) → [Get started](#get-started), or just ask Claude Code
"what is this plugin and where do I start?"

## The three lanes (and the seam between them)

```
   [DISCOVERY ENGINE]            [HANDOVER BRIDGE]              [ENGINEERING DELIVERY]
 PM / Designer · no code   →   PM/Dev hybrid · the seam   →   Developer · full code access
 Sense & Shape (stages 0–6)    Intent ↔ reality (stage 7)    Build & deliver (plan→release)
        discovery-*                configured path                     v-*
                         \              |              /
                          └──  closing-the-loop  ──┘   (master orchestrator)
```

The master `closing-the-loop` skill is the spine: it detects where a feature already is, then
sequences the discovery engine → the configured handover path → the engineering delivery skills,
threading one source of truth end to end.

## How the loop works (the 5-minute version)

**The PM's side.** Run discovery ("run the full discovery to prototype workflow"): customer signal →
scored opportunity → PRD → validated prototype. Then "create a ticket" — the PRD becomes one feature
issue in Linear/Jira, prototype linked. That issue key is the handoff. (Teams that keep product docs in
Confluence can publish the PRD as an editable page instead. The bridge also runs **without a prototype** —
declared feature work is a first-class path, not a degraded one.)

**The seam has two complete paths.** `closing-the-loop-setup` records one as `handoverPath`:

- **`context-first`** — merge new intent and requirements with the codebase status quo in one
  feature-driven pass. `handover-shape-feature` reads only the live code needed for the proposed change,
  then appends one compact block to the same ticket — the **Delivery Context**. It holds the specific
  changes to make (numbered `D-1`, `D-2`, …), the code it read as evidence, what must be reused or left
  alone, and acceptance criteria written as concrete scenarios (`AC-1`, `AC-2`, … in Gherkin's
  Given/When/Then form), plus any decision still open. When the feature is shaped epic it also carries vertical slices
  (`S-1`, `S-2`, …) ready to become tracker stories. There is no Engineering Brief, PRD freeze, or
  handover sign-off.
- **`governed`** (backward-compatible default) — produce a ratified payload instead: an **Engineering
  Brief** (the one document that evolves), the PRD frozen as an attachment, and a context block for coding
  agents. Automated review pressure-tests the Brief, then PM and lead Dev approve it by closing two
  blocking sign-off issues.

**The dev's side.** "Take `KAN-12` to a PR" — where `KAN-12` is just a tracker issue key, yours will look
different — routes by a label the handover left on the ticket. Context-first reads the live requirements
and fresh Delivery Context directly into normal engineering planning. Governed checks the sign-off gate
and loads the ratified package. Both continue through implementation, behavioral verification, review,
and release.

**Backlog shape is independent of the seam choice, and decided per feature:** the shaper recommends a
shape from the contract, your config default (`backlogMode`) breaks ties, and you confirm once. A
single-ticket-shaped feature goes straight to delivery: one ticket, one PR. An epic-shaped one adds
stories as tracker children — governed projects the story map its Brief already ratified; context-first
projects the Delivery Context's vertical slices after showing you a dry run and getting confirmation
before it writes. Context-first projection is not a sign-off gate.

Every term above is defined in the [glossary](docs/glossary.md).

## The operating-model choice

Choose the seam contract first:

- **`context-first`** — for high-trust, collaborative teams that want a code-grounded conversation rather
  than another decision artifact. **This is where the project is heading, and what we'd point most teams
  at.** It is also the only path that supports Confluence as the requirements surface.
- **`governed`** — for asynchronous or higher-risk work that benefits from a ratified payload and an
  explicit cross-functional gate. It then has two modes: **`standard`** (a developer with an AI copilot;
  gaps become explicit sign-off questions) and **`strict`** (an autonomous delivery pilot; the payload must
  stand alone before promotion).

One thing not to misread: `governed` is what every skill assumes when `handoverPath` is *absent*, so that
configs written before the choice existed keep working. That backward-compatible fallback isn't a
recommendation — setup always records an explicit answer.

`standard` versus `strict` changes governed-package completeness — it does not select the handover path.
`single-ticket` versus `epic` is a per-feature shape on both paths; the config value is only the default. Full trade-offs, including what each choice *costs*:
[**docs/setup.md → The four questions**](docs/setup.md#the-four-questions).

## Before you install

The plugin drives your tracker and your codebase through tools it does not ship. Sort these out first —
otherwise setup detects nothing and the tracker skills fail later, at the point where you've already
invested a run.

| You need | For | If it's missing |
|---|---|---|
| **Claude Code** | everything | — |
| **A checkout of the target repo** | the seam and delivery lanes | The seam reads live production code — tracker access alone isn't enough. A clone suffices for shaping; no build or test run needed |
| **A Jira, Linear, or Azure DevOps MCP connector** | the seam and delivery lanes | `closing-the-loop-setup` detects nothing and every tracker skill fails |
| **A classic Atlassian API token** (Jira teams) | attachments, and the setup connection check | Spec files on tickets are silently ignored. Setup scaffolds the file; you paste the token |
| **`gh`, authenticated** | the delivery lane | the delivery skills open and read PRs with it; PR steps fail |
| **A Figma MCP connector** | the `figma-*` and Code Connect skills, plus the Figma cross-check/visual-match options in the prototyping skills | Those skills (and options) can't run. The rest are unaffected |

> **Code Connect is a recommendation, never a requirement.** It needs a Figma Organization/Enterprise
> plan with a full seat, and works most smoothly with React libraries — most teams don't have that, and
> every workflow here has a full path without it (`component-readiness-scan` → `prototype-from-components`
> → `discovery-component-mapper` all resolve components from the codebase directly). Teams that do have
> it get extra precision via `code-connect-setup` / `code-connect-coverage-audit`.

**This plugin ships no connectors on purpose** — Atlassian, Linear, and Figma each maintain their own, and
a vendor-maintained endpoint beats a copy of it in here. Install whichever you need:

```
/plugin install atlassian@claude-plugins-official
/plugin install linear@claude-plugins-official
/plugin install figma@claude-plugins-official
```

**Azure DevOps teams:** Microsoft ships the official MCP server (preview) — added directly, no plugin:

```
claude mcp add azure-devops -- npx -y @azure-devops/mcp <organization-name>
```

(Authenticates via Microsoft sign-in / `az login`; needs Node 20+. Attachment upload additionally
needs an `AZURE_DEVOPS_PAT` — see `closing-the-loop-setup`.)

`claude-plugins-official` ships with Claude Code; you can also browse `/plugin` → Discover and search by
name. Each still needs you to authorize it once — installing declares the server, OAuth connects it.

**Already have a connector?** Skip this — don't add a second one for the same service. Two Atlassian
servers means two copies of every Jira tool, and the skills reference them by name.

**Already have the standalone discovery-engine plugin (or personal copies of these skills)?** Uninstall
or disable them before using this bundle — it supersedes the discovery plugin entirely. Two plugins
answering the same phrases means Claude silently picks one, and it may be the older one: a pilot run has
already hit this (the retired screenshot-based Stage 4 fired instead of the current component scan). One
phrase, one skill. `closing-the-loop-start` warns when it detects the duplicate.

**On other surfaces:** claude.ai connector settings on Claude Code desktop/web, **Customize → Connectors**
in Cowork (which doesn't read `~/.claude/`, so a local install doesn't carry over).

**Only doing discovery?** Stages 0–6 write to the filesystem, not a tracker, so you need none of the above
— just Claude Code. Connectors matter from the moment you publish a ticket.

Step-by-step, per connector and per lane: [docs/getting-started.md](docs/getting-started.md#before-you-start).

## Install

```
/plugin marketplace add Visma-AI-Engineering-Technology/closing-the-loop
/plugin install closing-the-loop@closing-the-loop
```

Open Claude Code **inside the target repository** first. No GitHub access, or developing locally? Any
checkout or unzipped copy of this repo is itself a valid marketplace:

```
/plugin marketplace add /path/to/closing-the-loop
/plugin install closing-the-loop@closing-the-loop
```

On Cowork / claude.ai, add it under **Cowork → Customize → Plugins** instead — Cowork deliberately does not
read `~/.claude/`, so a local install does not carry over.

## How to run a skill

Two ways, and they do the same thing:

- **Type `/`** and pick from the menu. Plugin skills are namespaced —
  `/closing-the-loop:closing-the-loop-setup`. This is also how you see everything installed.
- **Just describe what you want** in plain English. "Set up Closing the Loop", "create a handover from
  KAN-12", "take KAN-12 to a PR". Each skill lists the phrases it answers to, so you don't have to
  remember names.

Below, a name in `code` is a skill and a phrase in quotes is something you type. Either works.

## Get started

1. **Establish agent context** if the target repo has none: ask to "set up AGENTS.md" (`v-ship` handles it,
   including the first-time bootstrap). The bridge and the delivery skills both read `AGENTS.md` / `CLAUDE.md`.
2. **Run setup once:** "Set up Closing the Loop". It records your tracker, requirements surface, handover
   path, and default backlog shape at `~/.config/closing-the-loop/config.json`, and for Jira scaffolds `~/.netrc`
   with a placeholder you fill in yourself — **no API token ever passes through the chat**.
3. **Create the handover:** "create a handover from `<KEY>`", where `<KEY>` is your tracker's issue key —
   `KAN-12`, `ENG-451`. Context-first appends a Delivery Context to the ticket; governed produces the
   Brief + frozen PRD + agent-context block and opens the `✋ PM` / `✋ Dev` sign-off gate.
4. **Deliver:** "take `<KEY>` to a PR". For an epic-shaped feature, hand it the *parent* key and it walks the
   children one at a time, chores first.

Each step in full, plus which lane you're in and what discovery needs from you:
[**docs/getting-started.md**](docs/getting-started.md). Running this on a real feature for the first time:
[**docs/pilot-guide.md**](docs/pilot-guide.md).

## Entry points

The skills you actually start from. All **41** are catalogued in
[docs/skills.md](docs/skills.md).

Prefixes tell you the lane: `discovery-*` is the discovery engine, `handover-*` is the seam, and `v-*` is
the Visma engineering library (hence the `v`): its five core skills and the agent readiness report.

| Skill | Start here when |
|---|---|
| `closing-the-loop-start` | **First contact, or a team pilot's Week 0** — "Start Closing the Loop" scans what you have, shows the journey map, and routes you: guided from the beginning, jump to a specific point, fix what's missing, or score the repo with the agent readiness report |
| `closing-the-loop` | You want the whole arc driven — it detects where the feature already is |
| `closing-the-loop-getting-started` | You want orienting: which lane, has setup run, what to say |
| `closing-the-loop-setup` | First run on this machine, or you're changing tracker, path, or default backlog shape |
| `discovery-to-prototype-engine` | You have customer signal and no feature defined yet |
| `discovery-create-tracker-issue` | Discovery validated; publish it as the handoff ticket |
| `handover-shape-feature` | Context-first: make a live ticket implementable |
| `handover-workflow` | Governed: run the bridge end to end and hold at the gate |
| `prepare-amigo-session` | Governed pre-gate: walk the breakdown together before sign-off |
| `handover-deliver-epic` | Epic-shaped feature, either path: walk the projected children one at a time |
| `v-scope` | A ticket is ready and you want it built: it scopes, then chains into `v-build`, `v-challenge` and `v-ship` |
| `v-investigate` | Something fails, or the code is unfamiliar |
| `v-ship` | Commit, PR, review loop, release; also "set up AGENTS.md" when the repo has none |
| `v-agent-readiness-report` | You want this repo scored for coding agents: an HTML scorecard with evidence and paste-ready fixes. Also option D of "Start Closing the Loop" |
| `code-connect-setup` | Bootstrapping Figma ↔ codebase mapping (the Rail → Highway step) |

## Layout

```
closing-the-loop/
  .claude-plugin/
    plugin.json          # plugin manifest
    marketplace.json     # single-plugin marketplace
  skills/                # 41 skills, each a self-contained SKILL.md (+ references/agents/scripts)
    closing-the-loop/    # master orchestrator (the spine)
    closing-the-loop-setup/ closing-the-loop-getting-started/   # onboarding
    discovery-*/         # Sense → Shape, plus discovery-create-tracker-issue (publishes the handoff
                         #   ticket) and discovery-component-mapper/discovery-handover-package (stage 7)
    component-readiness-scan/ component-remediation/            # stage 4: scan + fix (any stack)
    prototype-from-components/ prototype-fidelity-report/       # stage 5: build + honesty report
    handover-shape-feature/ handover-project-stories/           # context-first seam
    handover-workflow/ handover-retrieval/ handover-brief-review/ create-backlog-from-brief/
                         #   governed seam
    handover-codebase-discovery/                                # reusable component reference
    handover-deliver-epic/                                      # epic slice walker (both paths)
    v-*/                 # the 5 visma-skills v2 core skills + v-agent-readiness-report
  hooks/
    hooks.json           # registers PostToolUse (Skill) + SessionEnd telemetry hooks
    track-*.sh           # anonymous usage / stage-funnel / feedback events — see Telemetry
  docs/                  # getting-started, setup, skills catalog, pilot guide, glossary
  references/
    backlog-shape-decision.md        # per-feature backlog shape: heuristic, confirmation, recording rule
    discovery-working-directory.md   # $DISCOVERY_DIR / $OUTPUTS_DIR resolution (Cowork vs local)
    visma-conventions-template.md    # AGENTS.md starter template
  scripts/verify-skills.sh
  scripts/validate-plugin-upload.py   # the served zip against Claude's upload rules (also in CI)
  retired/               # superseded skills, kept for provenance (document-feature →
                         #   handover-codebase-discovery, discovery-getting-started →
                         #   closing-the-loop-getting-started)
  CHANGELOG.md           # release notes, upstream divergences, maintainer TODOs
  KNOWN-ISSUES.md        # verified sharp edges
  README.md
```

## Documentation

| Document | What's in it |
|---|---|
| [docs/getting-started.md](docs/getting-started.md) | The full walkthrough: which lane you're in, first handover step by step, where discovery outputs land |
| [docs/setup.md](docs/setup.md) | Canonical setup reference: the four questions, config schema and defaults, Jira auth, troubleshooting, cost expectations |
| [docs/glossary.md](docs/glossary.md) | Every term these docs use as if you knew it — `D-n`, `AC-n`, `<KEY>`, Gherkin, amigo, brownfield, the config keys |
| [docs/skills.md](docs/skills.md) | All 41 skills by lane |
| [docs/pilot-guide.md](docs/pilot-guide.md) | Running this on a real feature for the first time — what to configure, what's sharp, what to report |
| [KNOWN-ISSUES.md](KNOWN-ISSUES.md) | Verified constraints and gaps, maintained honestly |
| [CHANGELOG.md](CHANGELOG.md) | What changed, the seven upstream divergences, maintainer TODOs |

## Confirm the install

Type `/` — you should see the skills namespaced under `closing-the-loop:`. Or just ask:

```
What is this plugin and where do I start?
```

That reaches `closing-the-loop-getting-started`, which reports which connectors it can see, whether setup
has run, and the one phrase that starts your lane. If nothing appears under `/`, the plugin didn't load —
re-run the two install commands and check the marketplace was added.

### For maintainers (from a checkout)

These need a clone of this repo, not an install:

```
bash scripts/verify-skills.sh
```

Manifest and component schemas:

```
claude plugin validate .
```

Upload rules. The zip people download is uploaded to the Claude app, which is stricter than Claude
Code and than `claude plugin validate` (no zip inside the zip, plugin description at most 500
characters, skill descriptions at most 1024, valid YAML frontmatter, and more). This checks the archive
exactly as it is served against the rules Anthropic documents, and CI runs it on every pull request and
push to `main`. There is no dry run of the real upload, so when the app refuses something this passes,
add the rule to the script (its header links the source docs):

```
python3 scripts/validate-plugin-upload.py
```

## Sending feedback

One route for the whole bundle. Say **"give feedback"**: `discovery-feedback` collects an anonymous
1–5 rating plus an optional comment, with a line saying which part it is about — discovery stages 0–6,
the handover bridge, or the delivery skills. It goes to the Closing the Loop maintainers.

## Telemetry

The plugin ships anonymous usage telemetry so the maintainers can see adoption and where users stop.
Events go to a Google Apps Script webhook that appends to a private Google Sheet owned by the
**Closing the Loop maintainers**:

| Event | When | Payload |
|---|---|---|
| `skill_invoked` | any `closing-the-loop:*` skill starts — the whole bundle, deliberately | skill name, session id, plugin version, machine hash |
| `stage_completed` | a discovery stage's output file is saved (`0`–`6`, plus `3.5` / `5.5` for the optional agent pattern check and audit), or a loop milestone is reached (`activation` = the front door ran, `publish` = the feature issue/page was created with its path marker, `handover` = a Delivery Context or governed package was written) — at most once per stage per session | stage/milestone id only, session id, plugin version, machine hash |
| `feedback` | user runs `discovery-feedback` (the discovery lane route above), which saves a `discovery-feedback-*.md` file | 1–5 rating, optional comment (≤500 chars), what it's about (a stage or skill name), plugin version, machine hash |
| `session_ended` | a session closes | session id, plugin version, machine hash |

No prompts, file contents, ticket keys, IPs, or conversation context are ever sent.
The machine hash is `sha256("$USER-$HOSTNAME")` truncated to 12 chars. Every send is backgrounded
with a 3-second timeout and cannot block or fail a workflow. Free text that lands in the Sheet (feedback
comments, names) is made sheet-safe, so nothing typed can run as a spreadsheet formula.

**How events are triggered.** Only by plugin hooks — no skill ever asks the model to run a telemetry
command (that prompted for permission in default mode and could not find the scripts in Cowork).
`skill_invoked` and `activation` come from a hook on the Skill tool; stages, `handover` and `feedback`
from a hook on file saves (`hooks/track-progress.sh` maps canonical output filenames to stage ids);
`publish` and the tracker-side `handover` from a hook on tracker writes, recognized by Closing the Loop's
own markers. The hooks read file names and markers locally; only the stage id leaves the machine.

**Identified downloads.** A zip downloaded signed-in from [productos.visma.org](https://productos.visma.org)
contains a `telemetry-identity.json` (download token, name, work email, team — written at download,
stated next to the download button). When that file is present, `skill_invoked`, `stage_completed`
and `session_ended` events carry those fields too, so the maintainers can see who uses which skills —
still never any content. `feedback` stays fully anonymous on purpose, even on identified copies.
Zips from the public guide page have no identity file and behave exactly as before. Deleting
`telemetry-identity.json` from the plugin folder makes an identified copy anonymous again, and the
opt-out below silences everything either way.

**Opt out** of all event types:

```bash
export CLOSING_THE_LOOP_TELEMETRY_DISABLED=1
```

(The legacy `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` is still honored.)

## Provenance

- `discovery-*` skills — [`Prod-Discovery/discovery-engine-plugin`](https://github.com/Prod-Discovery/discovery-engine-plugin).
  The agent patterns add-on applies Visma's guide for Great Agentic Experiences (formerly the Agent
  Design Guidelines) by Amanda Lundius, Nicolae Socaciu and Diana Almeida; its bundled copy comes from
  `Prod-Discovery/agent-design-guidelines` via `scripts/sync_patterns.py`.
- Governed bridge skills (`discovery-handover-package`, `create-backlog-from-brief`—formerly
  `create-tracker-tickets`—and `handover-workflow`) —
  [`danielbarfuss-visma/handover-bridge-plugin`](https://github.com/danielbarfuss-visma/handover-bridge-plugin).
- `handover-codebase-discovery` is a local, ground-up successor to the retired `document-feature`
  and remains the governed/standalone component-reference skill. The context-first path
  (`handover-shape-feature` plus optional `handover-project-stories`) is newly authored here; it
  internalizes feature-scoped code reading so it can merge intent with status quo without a
  mandatory intermediate dossier.
- Figma-input utilities (`figma-readiness-check`, `figma-tokens-extract`, `figma-batch-probe`) — [`cristinaiftode/ai-design-system-skills`](https://github.com/cristinaiftode/ai-design-system-skills) (validated on Tripletex Atlas and Visionplanner libraries).
- Prototyping skills (`component-readiness-scan`, `component-remediation`, `prototype-from-components`, `prototype-fidelity-report`) — generalized here (2026-08) from the Dialog pilot's `ds-readiness-engine` (Angular 20 / Nx, validated on the Dialog design system, 2026-07) and the `react-workshop-prototyping` skills (React, 2026-08). They supersede the retired `discovery-component-library` and `discovery-prototype-generator`, and are stack-agnostic by design.
- `v-*` skills — the Visma Skills collection ([`visma-skills-installer`](https://github.com/Visma-AI-Engineering-Technology/visma-skills-installer)).
- Code Connect skills (`code-connect-setup`, `code-connect-coverage-audit`) — newly authored in this repo for the Closing the Loop project, scoped to support the Rail → Highway transition (Dialogue pilot and beyond). `figma-code-connect` is adapted from the BHB Code Connect setup work.
