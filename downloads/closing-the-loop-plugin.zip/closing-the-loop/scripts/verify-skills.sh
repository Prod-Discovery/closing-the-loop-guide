#!/usr/bin/env bash
# verify-skills.sh — Validate all skills in skills/*/SKILL.md
#
# Custom verifier for Closing the Loop plugin skills.
# Enforces YAML frontmatter, name-matching, Workflow presence, and line-caps.

set -euo pipefail
shopt -s nullglob

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

PASS=0
FAIL=0
WARN=0

pass() {
  echo -e "  ${GREEN}✓${NC} $1"
  PASS=$((PASS + 1))
}

fail() {
  echo -e "  ${RED}✗${NC} $1"
  FAIL=$((FAIL + 1))
}

warn() {
  echo -e "  ${YELLOW}⚠${NC} $1"
  WARN=$((WARN + 1))
}

# Resolve directory of this script to run correctly from any CWD
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_ROOT"

SKILL_DIRS=(skills/*/SKILL.md)

if [ ${#SKILL_DIRS[@]} -eq 0 ]; then
  echo -e "${RED}No skills found in skills/*/SKILL.md${NC}"
  exit 1
fi

echo "Verifying ${#SKILL_DIRS[@]} Closing the Loop skill(s)..."
echo ""

for SKILL_FILE in "${SKILL_DIRS[@]}"; do
  SKILL_DIR=$(dirname "$SKILL_FILE")
  DIR_NAME=$(basename "$SKILL_DIR")

  echo "━━━ ${DIR_NAME} ━━━"

  # --- File existence ---
  if [ -f "$SKILL_FILE" ]; then
    pass "SKILL.md exists"
  else
    fail "SKILL.md not found at $SKILL_FILE"
    echo ""
    continue
  fi

  # --- YAML frontmatter presence ---
  FIRST_LINE=$(head -n 1 "$SKILL_FILE")
  if [ "$FIRST_LINE" != "---" ]; then
    fail "Missing YAML frontmatter (file must start with ---)"
    echo ""
    continue
  fi

  # Find closing --- (line 2+)
  CLOSING_LINE=$(awk 'NR > 1 && /^---$/ { print NR; exit }' "$SKILL_FILE")
  if [ -z "$CLOSING_LINE" ]; then
    fail "YAML frontmatter never closed (no closing ---)"
    echo ""
    continue
  fi

  pass "YAML frontmatter present (lines 1-${CLOSING_LINE})"

  # Extract frontmatter content (between the ---'s)
  FRONTMATTER=$(sed -n "2,$((CLOSING_LINE - 1))p" "$SKILL_FILE")

  # --- name field ---
  NAME_LINE=$(echo "$FRONTMATTER" | grep -E '^name:\s*' | head -1)
  if [ -z "$NAME_LINE" ]; then
    fail "Missing 'name' field in frontmatter"
  else
    NAME_VALUE=$(echo "$NAME_LINE" | cut -d':' -f2- | tr -d '"' | tr -d "'" | xargs)
    pass "name field present: ${NAME_VALUE}"

    # Check name matches directory name
    if [ "$NAME_VALUE" = "$DIR_NAME" ]; then
      pass "name matches directory name"
    else
      fail "name '${NAME_VALUE}' does not match directory '${DIR_NAME}'"
    fi
  fi

  # --- description field ---
  DESC_LINE=$(echo "$FRONTMATTER" | grep -E '^description:\s*' | head -1)
  if [ -z "$DESC_LINE" ]; then
    fail "Missing 'description' field in frontmatter"
  else
    DESC_VALUE=$(echo "$DESC_LINE" | cut -d':' -f2- | tr -d '"' | tr -d "'" | xargs)
    DESC_LEN=${#DESC_VALUE}
    if [ "$DESC_LEN" -gt 500 ]; then
      warn "description exceeds 500 characters (${DESC_LEN} chars)"
    else
      pass "description is of valid length (${DESC_LEN} chars)"
    fi
  fi

  # --- Line count check ---
  # 500 lines is a guideline (warn); 600 is the hard cap (fail).
  LINE_COUNT=$(wc -l < "$SKILL_FILE")
  if [ "$LINE_COUNT" -gt 600 ]; then
    fail "Line count (${LINE_COUNT}) exceeds the 600-line hard cap"
  elif [ "$LINE_COUNT" -gt 500 ]; then
    warn "Line count (${LINE_COUNT}) exceeds the 500-line guideline"
  else
    pass "Line count is within limits (${LINE_COUNT} lines)"
  fi

  # --- Required Sections ---
  # Accept ## Workflow OR a recognised step/phase equivalent. The discovery
  # lane authors workflows as ## Step / ## Phase / ## How to Start.
  if grep -qE "^## (Workflow|Step |Phase |How to Start)" "$SKILL_FILE"; then
    pass "Workflow (or step/phase equivalent) section exists"
  else
    warn "No ## Workflow section or recognised step/phase equivalent"
  fi

  # --- Tool Agnostic Terminology check ---
  # Check for common non-neutral terms
  if grep -qiE "npm install|pip install|pytest |cargo run|maven compile" "$SKILL_FILE"; then
    warn "Skill body contains tool-specific commands. Ensure terms are tool-neutral where possible."
  else
    pass "Terminology is tool-neutral"
  fi

  echo ""
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ "$FAIL" -gt 0 ]; then
  echo -e "${RED}Verification FAILED! (Pass: $PASS, Fail: $FAIL, Warn: $WARN)${NC}"
  exit 1
else
  echo -e "${GREEN}Verification PASSED! (Pass: $PASS, Fail: $FAIL, Warn: $WARN)${NC}"
fi
