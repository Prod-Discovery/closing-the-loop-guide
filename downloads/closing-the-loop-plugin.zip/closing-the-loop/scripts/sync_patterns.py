#!/usr/bin/env python3
"""Bundle the Agent Design Guidelines into the plugin.

The patterns and principles have one source: patterns.json in
Prod-Discovery/agent-design-guidelines. This script reads it straight from that
repo, at the latest commit on main, and turns it into patterns.md with the
repo's own scripts/build_patterns.py. So the bundled copy is exactly what the
guidelines site publishes, stamped with the commit it came from, and it
doesn't depend on where the site is hosted.

The repo is read with the GitHub CLI when it is signed in (this keeps working
if the repo becomes internal), otherwise anonymously while the repo is public.

Never edit the bundled copy by hand. Change patterns.json in the guidelines
repo, then sync here.

Usage:
  python3 scripts/sync_patterns.py           # update the bundled copy, show what changed
  python3 scripts/sync_patterns.py --check   # only report whether the bundled copy is behind
  python3 scripts/sync_patterns.py --target some/path.md   # write somewhere else (testing)

Exit codes: 0 = done or up to date, 1 = error, 2 = --check found the bundled copy behind.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

REPO = "Prod-Discovery/agent-design-guidelines"
BRANCH = "main"
ROOT = Path(__file__).resolve().parent.parent
# Where the add-on skill reads the patterns from.
TARGET = ROOT / "skills/discovery-agent-patterns/references/patterns.md"
STAMP_PREFIX = "<!-- Bundled copy of the Agent Design Guidelines."


def http_get(url):
    try:
        with urllib.request.urlopen(url, timeout=20) as r:
            return r.read().decode("utf-8")
    except Exception:
        # Some Python installs on macOS lack root certificates; curl doesn't.
        out = subprocess.run(["curl", "-fsSL", "--max-time", "20", url],
                             capture_output=True, text=True)
        if out.returncode != 0:
            raise RuntimeError(f"could not download {url}: {out.stderr.strip()}")
        return out.stdout


def gh(*args):
    """Runs the GitHub CLI; returns its output, or None if it isn't usable."""
    if not shutil.which("gh"):
        return None
    out = subprocess.run(["gh", *args], capture_output=True, text=True)
    return out.stdout if out.returncode == 0 else None


def latest_commit():
    sha = gh("api", f"repos/{REPO}/commits/{BRANCH}", "--jq", ".sha")
    if sha and sha.strip():
        return sha.strip()
    data = json.loads(http_get(f"https://api.github.com/repos/{REPO}/commits/{BRANCH}"))
    return data["sha"]


def repo_file(path, sha):
    text = gh("api", "-H", "Accept: application/vnd.github.raw+json",
              f"repos/{REPO}/contents/{path}?ref={sha}")
    if text is not None:
        return text
    return http_get(f"https://raw.githubusercontent.com/{REPO}/{sha}/{path}")


def fetch_live():
    """Builds patterns.md from the guidelines repo's latest commit, the way the site does."""
    sha = latest_commit()
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        (tmp / "scripts").mkdir()
        (tmp / "patterns.json").write_text(repo_file("patterns.json", sha), encoding="utf-8")
        (tmp / "scripts/build_patterns.py").write_text(
            repo_file("scripts/build_patterns.py", sha), encoding="utf-8")
        # Optional: the list of ids that must never disappear. When the repo has
        # it, the generator also checks that no id was removed.
        try:
            (tmp / "scripts/ids.json").write_text(
                repo_file("scripts/ids.json", sha), encoding="utf-8")
        except RuntimeError:
            pass
        out = subprocess.run([sys.executable, str(tmp / "scripts/build_patterns.py")],
                             capture_output=True, text=True,
                             env={**os.environ, "GITHUB_SHA": sha})
        if out.returncode != 0:
            raise RuntimeError("the guidelines' patterns.json did not pass its own check at "
                               f"{sha[:7]}:\n{out.stderr.strip()}")
        return (tmp / "patterns.md").read_text(encoding="utf-8")


def body(text):
    """The file without our stamp line, for comparing versions."""
    lines = text.split("\n")
    if lines and lines[0].startswith(STAMP_PREFIX):
        lines = lines[1:]
    return "\n".join(lines)


def content(text):
    """The file without our stamp line and the guidelines' build id: what readers see."""
    return re.sub(r" \(build [0-9a-f]{7}\)", "", body(text))


def build_of(text):
    m = re.search(r"\(build ([0-9a-f]{7})\)", text)
    return m.group(1) if m else "unknown"


def sections(text):
    """Map each pattern or principle id to its section text."""
    out = {}
    for block in re.split(r"\n(?=#{3,4} )", body(text)):
        m = re.search(r"^id: `([a-z0-9-]+)`", block, re.M)
        if m:
            out[m.group(1)] = block.strip()
    return out


def check_shape(text):
    if not text.startswith("# Agent Design Guidelines"):
        raise RuntimeError("downloaded file does not look like patterns.md (wrong title)")
    if "Generated from patterns.json" not in text:
        raise RuntimeError("downloaded file does not look like patterns.md (no generator note)")
    count = len(re.findall(r"^#### ", text, re.M))
    if count == 0:
        raise RuntimeError("downloaded file has no patterns in it")
    return count


def describe_changes(old, new):
    a, b = sections(old), sections(new)
    added = [i for i in b if i not in a]
    removed = [i for i in a if i not in b]
    changed = [i for i in b if i in a and a[i] != b[i]]
    lines = []
    if added:
        lines.append("  added:   " + ", ".join(added))
    if removed:
        lines.append("  removed: " + ", ".join(removed) + "  <- an id disappeared, check the add-on still works")
    if changed:
        lines.append("  changed: " + ", ".join(changed))
    if not lines:
        lines.append("  only the header changed (date or build)")
    return "\n".join(lines)


def main():
    args = sys.argv[1:]
    check = "--check" in args
    target = TARGET
    if "--target" in args:
        target = Path(args[args.index("--target") + 1]).resolve()

    try:
        live = fetch_live()
        count = check_shape(live)
    except (RuntimeError, OSError, ValueError, KeyError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    current = target.read_text(encoding="utf-8") if target.exists() else None
    rel = target.relative_to(ROOT) if target.is_relative_to(ROOT) else target

    if current is not None and body(current) == live:
        print(f"Up to date: {rel} matches the live patterns (build {build_of(live)}).")
        return 0
    if current is not None and content(current) == content(live):
        # The guidelines repo had a commit that didn't change any pattern text
        # (code, docs). Not worth a new copy, a review or a release.
        print(f"Up to date: {rel} has the same patterns as build {build_of(live)} "
              f"(only the build id differs, kept {build_of(current)}).")
        return 0

    if check:
        if current is None:
            print(f"No bundled copy at {rel} yet. Run scripts/sync_patterns.py to create it.")
        else:
            print(f"Behind: {rel} is build {build_of(current)}, live is build {build_of(live)}.")
            print(describe_changes(current, live))
        return 2

    skill_md = TARGET.parent.parent / "SKILL.md"
    if target == TARGET and not skill_md.exists():
        print(f"ERROR: {skill_md.relative_to(ROOT)} does not exist. "
              "The add-on skill has to be in the plugin before its patterns can be synced.",
              file=sys.stderr)
        return 1
    target.parent.mkdir(parents=True, exist_ok=True)

    synced = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    stamp = (f"{STAMP_PREFIX} Synced {synced} from github.com/{REPO}, patterns.json at {BRANCH} (build {build_of(live)}). "
             "Do not edit: change patterns.json in Prod-Discovery/agent-design-guidelines, "
             "then run scripts/sync_patterns.py -->")
    target.write_text(stamp + "\n" + live, encoding="utf-8")

    if current is None:
        print(f"Created {rel}: {count} patterns, build {build_of(live)}.")
    else:
        print(f"Updated {rel}: build {build_of(current)} -> {build_of(live)}.")
        print(describe_changes(current, live))
    print("Review the diff, then commit it with your other changes.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
