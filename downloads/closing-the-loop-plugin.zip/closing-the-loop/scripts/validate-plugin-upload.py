#!/usr/bin/env python3
"""Check that the plugin zip people download will be accepted by Claude's plugin upload.

`claude plugin validate` and Claude Code itself are more lenient than the upload in the
Claude app, so a release can install fine from the marketplace and still be refused when
someone uploads the zip. This script checks the rules Anthropic documents for uploads.

It validates the same archive the guide repo publishes: `git archive` of a ref (default
HEAD) with the `closing-the-loop/` prefix. Only tracked files count, exactly as in the
served zip. Pass a path to an existing zip to check that file instead.

    scripts/validate-plugin-upload.py              # HEAD
    scripts/validate-plugin-upload.py origin/main  # another ref
    scripts/validate-plugin-upload.py some.zip     # a zip on disk

Exits 1 on any error; warnings do not fail. Needs PyYAML (`pip install pyyaml`).

Where the rules come from (re-read these when the upload refuses something this passes,
then add the rule here):
  - Plugins API guide, upload limits:
    https://platform.claude.com/docs/en/manage-claude/plugins-api
  - Skill frontmatter allowed outside Claude Code:
    https://code.claude.com/docs/en/skills
  - Agent Skills spec: skill description at most 1024 characters (the Claude app has
    refused longer ones since October 2026).

There is no dry run of the real upload validation, so this list can fall behind it.
"""
import io
import json
import os
import re
import stat
import subprocess
import sys
import zipfile

PLUGIN_NAME = re.compile(r"^[a-z0-9-]{1,64}$")
PLUGIN_DESCRIPTION_MAX = 500
DISPLAY_NAME_MAX = 64
SKILL_DESCRIPTION_MAX = 1024
COMPATIBILITY_MAX = 500
MAX_FILES = 5000
MAX_UNCOMPRESSED = 200 * 1024 * 1024
MAX_DEPTH = 12
MAX_PATH = 472
MAX_COMPONENT = 255
PATH_OK = re.compile(r"^[A-Za-z0-9 _.\-/(),]+$")
XML_TAG = re.compile(r"</?[A-Za-z][^<>]*>")
# Frontmatter keys the Agent Skills spec allows. The docs say claude.ai skill uploads reject
# any other key; plugin uploads have accepted them so far, so extra keys are only a warning.
SPEC_KEYS = {"name", "description", "license", "compatibility", "metadata", "allowed-tools"}
ZIP_METHODS = {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}


def load_zip(target):
    if os.path.isfile(target):
        with open(target, "rb") as fh:
            return fh.read(), target
    data = subprocess.run(
        ["git", "archive", "--format=zip", "--prefix=closing-the-loop/", target],
        check=True,
        capture_output=True,
    ).stdout
    return data, f"git archive of {target}"


def check_archive(archive, infos, root, errors):
    """Zip-level rules: size, counts, entry kinds, paths."""
    if len(infos) > MAX_FILES:
        errors.append(f"zip has {len(infos)} files, max {MAX_FILES}")
    total = sum(i.file_size for i in infos)
    if total > MAX_UNCOMPRESSED:
        errors.append(f"zip is {total // (1024 * 1024)} MB uncompressed, max 200 MB")

    for info in infos:
        name = info.filename
        rel = name[len(root):]
        parts = name.split("/")
        if name.lower().endswith(".zip"):
            errors.append(f"{rel}: a zip inside the plugin zip is not allowed")
        if info.flag_bits & 0x1:
            errors.append(f"{rel}: encrypted entries are not allowed")
        if info.compress_type not in ZIP_METHODS:
            errors.append(f"{rel}: compression must be DEFLATE or STORE")
        if stat.S_ISLNK(info.external_attr >> 16):
            errors.append(f"{rel}: symlinks are not allowed")
        if name.startswith("/") or ".." in parts:
            errors.append(f"{rel}: paths must be relative and must not contain '..'")
        if not PATH_OK.match(name):
            errors.append(f"{rel}: path has characters the upload does not allow")
        if len(parts) > MAX_DEPTH:
            errors.append(f"{rel}: path is {len(parts)} levels deep, max {MAX_DEPTH}")
        if len(name) > MAX_PATH:
            errors.append(f"{rel}: path is {len(name)} characters, max {MAX_PATH}")
        if any(len(p) > MAX_COMPONENT for p in parts):
            errors.append(f"{rel}: a file or folder name is longer than {MAX_COMPONENT} characters")

    if any(i.filename.startswith(f"{root}bin/") for i in infos):
        errors.append("bin/: a top-level bin/ folder is not allowed")


def check_manifest(archive, manifest_path, errors):
    try:
        manifest = json.loads(archive.read(manifest_path).decode("utf-8"))
    except ValueError as exc:
        errors.append(f".claude-plugin/plugin.json: not valid JSON ({exc})")
        return
    name = manifest.get("name")
    if not isinstance(name, str) or not PLUGIN_NAME.match(name):
        errors.append(
            f".claude-plugin/plugin.json: name {name!r} must be 1-64 lowercase letters, digits or hyphens"
        )
    length = len(manifest.get("description") or "")
    if length > PLUGIN_DESCRIPTION_MAX:
        errors.append(
            f".claude-plugin/plugin.json: description is {length} characters, max {PLUGIN_DESCRIPTION_MAX}"
        )
    length = len(manifest.get("displayName") or "")
    if length > DISPLAY_NAME_MAX:
        errors.append(f".claude-plugin/plugin.json: displayName is {length} characters, max {DISPLAY_NAME_MAX}")


def check_skill(yaml, archive, path, rel, errors, extra_keys):
    folder = rel.split("/")[1]
    try:
        text = archive.read(path).decode("utf-8")
    except UnicodeDecodeError:
        errors.append(f"{rel}: not valid UTF-8")
        return
    match = re.match(r"^---\r?\n(.*?)\r?\n---", text, re.S)
    if not match:
        errors.append(f"{rel}: no YAML frontmatter")
        return
    try:
        front = yaml.safe_load(match.group(1))
    except yaml.YAMLError as exc:
        errors.append(f"{rel}: frontmatter is not valid YAML ({str(exc).splitlines()[0]})")
        return
    if not isinstance(front, dict):
        errors.append(f"{rel}: frontmatter is not a mapping")
        return

    name = front.get("name")
    if name != folder:
        errors.append(f"{rel}: name is {name!r}, expected the folder name {folder!r}")
    description = front.get("description")
    if not isinstance(description, str) or not description.strip():
        errors.append(f"{rel}: missing description")
    else:
        if len(description) > SKILL_DESCRIPTION_MAX:
            errors.append(f"{rel}: description is {len(description)} characters, max {SKILL_DESCRIPTION_MAX}")
        if XML_TAG.search(description):
            errors.append(f"{rel}: description must not contain XML tags")
    if isinstance(name, str) and XML_TAG.search(name):
        errors.append(f"{rel}: name must not contain XML tags")
    compatibility = front.get("compatibility")
    if isinstance(compatibility, str) and len(compatibility) > COMPATIBILITY_MAX:
        errors.append(f"{rel}: compatibility is {len(compatibility)} characters, max {COMPATIBILITY_MAX}")
    for key in set(front) - SPEC_KEYS:
        extra_keys[key] = extra_keys.get(key, 0) + 1


def main():
    try:
        import yaml
    except ImportError:
        print("PyYAML is required: pip install pyyaml", file=sys.stderr)
        return 2

    target = sys.argv[1] if len(sys.argv) > 1 else "HEAD"
    data, label = load_zip(target)
    archive = zipfile.ZipFile(io.BytesIO(data))
    infos = [i for i in archive.infolist() if not i.is_dir()]
    names = [i.filename for i in infos]
    errors, warnings = [], []

    # Layout: everything under one top-level folder, manifest directly inside it.
    tops = sorted({n.split("/", 1)[0] for n in names})
    if len(tops) != 1:
        errors.append(f"zip must have a single top-level folder, found: {', '.join(tops)}")
    root = tops[0] + "/" if tops else ""
    manifests = [n for n in names if n.endswith(".claude-plugin/plugin.json")]
    manifest_path = f"{root}.claude-plugin/plugin.json"
    if manifests != [manifest_path]:
        errors.append(f"expected exactly one manifest at {manifest_path}, found: {manifests or 'none'}")

    check_archive(archive, infos, root, errors)
    if manifest_path in names:
        check_manifest(archive, manifest_path, errors)

    skills = [n for n in names if re.match(re.escape(root) + r"skills/[^/]+/SKILL\.md$", n)]
    if not skills:
        errors.append("no skills/<name>/SKILL.md found")
    extra_keys = {}
    for path in skills:
        check_skill(yaml, archive, path, path[len(root):], errors, extra_keys)
    if extra_keys:
        listed = ", ".join(f"{k} ({v})" for k, v in sorted(extra_keys.items()))
        warnings.append(
            "skill frontmatter keys outside the Agent Skills spec, which the docs say claude.ai "
            f"skill uploads reject (plugin uploads have accepted them so far): {listed}"
        )

    print(f"Checked {label}: {len(names)} files, {len(skills)} skills, {len(data) // 1024} KB")
    if warnings:
        print(f"\n{len(warnings)} warning(s), not failing:")
        for warning in warnings:
            print(f"  - {warning}")
    if errors:
        print(f"\n{len(errors)} problem(s) that would fail the upload to Claude:")
        for error in errors:
            print(f"  - {error}")
        return 1
    print("\nOK: nothing here breaks a documented upload rule.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
