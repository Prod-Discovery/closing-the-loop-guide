---
name: discovery-component-library
description: "Stage 4 of Discovery to Prototype Engine. Builds or connects a reusable React component library matching the product's visual design. First auto-detects existing component libraries on the filesystem or in project context before asking for input. Supports five input methods: existing local component library repo (highest fidelity — skips generation), AI-readable design system files (tokens + manifest + prompt rules), Figma connection, GitHub repo with code-based design system, or product screenshots. Use when user says 'create component library', 'extract components', 'build design system', 'run discovery stage 4', 'connect component library', or provides design system files or product screenshots. Outputs React components for prototype generation."
---

# Discovery Component Library (Stage 4)

> **RETIRED (2026-08).** Superseded by `component-readiness-scan` (+ optional
> `component-remediation`), which works against the team's real repo in any stack
> instead of generating a lookalike library. Kept for reference only.

Fourth stage of the Discovery to Prototype Engine. Builds or connects a reusable React component library that matches the product's existing visual language — so prototypes look like the real product, not generic wireframes.

## Prerequisites

Requires a PRD from Stage 3 (for understanding what components the prototype will need).

Requires ONE of the following as design input — the skill will auto-detect what's available before asking:

| Option | What the user provides | Fidelity | Best for |
|--------|----------------------|----------|----------|
| **Auto: Local Component Library** | Cloned repo with manifest + tokens + React components on local filesystem | Highest | Teams running in Claude Code with a cloned component library repo. Skips generation entirely — uses existing React components directly. |
| **A. Design System Files** | tokens.json + manifest + prompt rules (uploaded or in project context) | High | Teams in Cowork with DS files in their Claude Project, or uploaded manually |
| **B. Connect Figma** | Link to Figma file or DS page | High | Teams with a maintained Figma design system |
| **C. Connect GitHub** | Repo URL with code-based DS | High | Engineering-led teams with component libraries in code |
| **D. Upload Screenshots** | PNG/JPG of product UI | Lower | Teams with no formal DS, or quick-start users |

**`$DISCOVERY_DIR`** — the discovery working directory. Try `/home/claude/discovery-engine/` and fall back to `./discovery-engine/` if that fails (Cowork vs. local Claude Code; the latter cannot create `/home/claude/`). The generated library goes in `$DISCOVERY_DIR/component-library/`, which is where Stage 5 reads it. `$OUTPUTS_DIR` is `/mnt/user-data/outputs/` when it exists, otherwise `$DISCOVERY_DIR` — in which case skip the copy step and state the path instead. Already resolved if the orchestrator ran Stage 0; resolve it yourself on a standalone run. Full rules: [`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md).

## Workflow

### Step 0: Auto-Detect Existing Component Library

Before presenting any options, check whether a component library already exists in the current environment. This step is silent — if nothing is found, proceed directly to Step 1 without mentioning the detection attempt.

**In Claude Code (local filesystem):**

Search the working directory and its parent directories for these file signatures:

1. **Full component library repo** (highest fidelity):
   - Look for `manifest.json` (or `manifest`) containing a `"components"` key
   - Look for `tokens.json` containing design token definitions
   - Look for `prompt-rules.md` (or `prompt-rules`)
   - Look for a `components/react/` or `components/` directory with `.jsx` or `.tsx` files
   - If ALL of these are found together, this is a complete AI-readable component library

2. **Design system files only** (no pre-built components):
   - Look for `manifest.json` + `tokens.json` without a `components/react/` directory
   - This means the definitions exist but React components need to be generated

**In Cowork (project context):**

Check whether the project context contains design system files:
- Look for `manifest.json`, `tokens.json`, and `prompt-rules.md` in the project knowledge
- These would have been uploaded by the team when setting up the project

**If a full component library repo is found:**

This is the best-case scenario. Present what was found and verify coverage:

> **I found an existing component library on your filesystem:**
>
> 📁 `[path to repo]`
> - **Manifest**: [N] components defined (e.g., Button, Field, Table, Drawer...)
> - **Tokens**: Design tokens for colors, typography, spacing
> - **React components**: Pre-built implementations in `components/react/`
> - **Prompt rules**: Design system usage constraints
>
> Let me check this against your PRD to make sure it covers what we need for the prototype...
>
> **Coverage check:**
> - ✅ [Components that match PRD needs]
> - ⚠️ [Any gaps — components the PRD needs but the library doesn't have]
>
> **This means we can skip building a component library from scratch.** I'll use these components directly for prototyping.
> [If gaps exist: "I'll generate the missing components to match the existing design language."]
>
> Does this look right, or would you prefer to build a fresh component library instead?

If the user confirms, copy the relevant files to `$DISCOVERY_DIR/component-library/` (the standard output location for Stage 5 to read), skip Steps 1–4, and proceed directly to the checkpoint (Step 5).

**If design system files are found (but no pre-built React components):**

> **I found design system files in your [project / filesystem]:**
>
> - **Manifest**: [N] components defined
> - **Tokens**: Design tokens for colors, typography, spacing
> - **Prompt rules**: Design system usage constraints
>
> I'll use these to generate React components that match your design system exactly. This is the highest-fidelity generation path — every color, spacing value, and variant comes from your source of truth.

Proceed directly to Option A processing (Step 2), skipping the options presentation in Step 1.

**If nothing is found:**

Proceed silently to Step 1. Do not mention the auto-detection attempt.

### Step 1: Present Input Options (only if Step 0 found nothing)

If auto-detection did not find an existing component library, check what tools the user has available. Call `search_mcp_registry` with keywords ["figma", "github", "design"]. Then present ALL options clearly and directly:

> **To build your component library, I need to understand your product's visual language. Here are your options — pick the one that fits your team best:**
>
> **Option A: Upload your AI-readable design system files** ⭐ Recommended for highest fidelity
> If your design system has been prepared for AI tools, upload these three files:
> - `tokens.json` — your design tokens (colors, spacing, typography) in DTCG format
> - `manifest` — your component catalog (what components exist, their variants, code examples)
> - `prompt rules` — instructions that tell me how to use your DS correctly
> This gives the best results because I'm working from your actual production design decisions.
> *Not sure if you have these? Check out the Design System Playbook for how to create them.*
>
> **Option B: Connect Figma** [show `suggest_connectors` if Figma is in registry but not connected]
> Share a link to your Figma design system or product screens. I'll pull design tokens, component specs, and screenshots directly.
> *Best if your design system lives in Figma and is reasonably up to date.*
>
> **Option C: Connect GitHub** [show `suggest_connectors` if GitHub is in registry but not connected]
> Point me to a repo containing your code-based design system (React components, CSS tokens, Storybook, theme files). I'll read the source code and extract tokens + component APIs.
> *Best if your DS is code-first and Figma is out of date or doesn't exist.*
>
> **Option D: Upload screenshots**
> Upload 5-10 screenshots of your product's key UI screens. I'll visually extract colors, typography, spacing, and component patterns.
> *Best for getting started quickly when you don't have a formal design system.*
>
> **Option E: Skip — build from scratch**
> I'll create a clean, modern component library based on the product context from Stage 0. Professional look, but won't match your existing product.

Only show connector options (B, C) if the relevant MCP exists in the registry. Always show A, D, and E.

### Step 2: Process Input (varies by option)

#### Option A: Design System Files

1. Read `tokens.json` — extract all design tokens (colors, spacing, typography, border radius, shadows)
2. Read `manifest` — identify all available components, their variants, and props
3. Read `prompt rules` — follow the team's constraints when building prototype components
4. Map PRD use cases to required components — identify which manifest components are needed
5. Build React components using the exact tokens and component APIs from the files

**Key advantage:** No guessing. Every color, spacing value, and component variant comes directly from the team's source of truth.

#### Option B: Figma

1. Use the Figma MCP tools to access the file:
   - `get_variable_defs` — extract design tokens (colors, typography, spacing)
   - `get_screenshot` — capture key frames for visual reference
   - `get_design_context` — get component structure and code suggestions
   - `get_metadata` — understand page/frame hierarchy
2. Extract design tokens from Figma variables
3. Identify component patterns from the design system page
4. Build React components matching the Figma designs

#### Option C: GitHub

1. Use the GitHub MCP to access the repository
2. Look for common design system file patterns:
   - `/tokens/`, `/theme/`, `tokens.json`, `theme.ts`, `variables.css`, `tokens.css`
   - `/components/`, `/src/components/`, `index.ts`
   - `storybook/`, `.storybook/`
   - `package.json` (to understand the tech stack)
3. Read token files → extract design tokens
4. Read component source files → extract component APIs, props, and variants
5. If the team has the AI-readable files (tokens.json + manifest + prompt rules), prioritise those
6. Build React components matching the code-based DS

#### Option D: Screenshots

1. Receive screenshot uploads (5-10 key UI screens)
2. Analyze visual patterns — identify distinct component types
3. Extract design tokens by visual inference:
   - Colors (sample from screenshots)
   - Typography (infer font family, sizes, weights)
   - Spacing (estimate base unit)
   - Border radius, shadows, borders
4. Build React components matching the visual patterns

#### Option E: From Scratch

1. Use product context from Stage 0 (industry, audience, tone)
2. Create a clean, professional design system appropriate for the product category
3. Use sensible defaults (system font stack, 8px spacing grid, accessible color contrast)

### Step 3: Build Components

Regardless of input method, create:

**Design Tokens** (`tokens.css`):
- All colors (brand, background, text, border, status)
- Typography (family, sizes, weights, line heights)
- Spacing scale
- Border radius values
- Shadow definitions
- Transition timing

**Components** (React `.jsx` files):
- Only build components needed for the PRD's use cases
- Match the product's visual language exactly (from whichever input source)
- Support common variants (primary/secondary, sizes, states)
- Keep components self-contained with inline styles

**Priority components to look for / build:**

| Category | Components |
|----------|-----------|
| Navigation | Header, sidebar, tabs, breadcrumbs |
| Actions | Buttons (primary, secondary, ghost), links |
| Forms | Input fields, selects, checkboxes, toggles |
| Data Display | Tables, cards, lists, stat blocks, badges |
| Feedback | Alerts, toasts, progress bars, loading states |
| Containers | Modals, drawers, panels |

### Step 4: Create Preview

Build an HTML preview file that renders all components side by side — so the user can visually verify fidelity against their product.

### Step 5: Checkpoint

Present the component library and preview to the user:

1. Show the HTML preview (present as file)
2. List all components created with their variants
3. Note which design tokens were extracted
4. Ask: "Does the fidelity look right? Compare against your product — anything to adjust?"
5. Iterate on specific components if needed

## Saving and Reusing the Component Library

After the user confirms the component library, it must be saved for reuse:

1. **Save to working directory** — write to `$DISCOVERY_DIR/component-library/` (for Stage 5 to read)
2. **Save to workspace folder** — copy all component files + tokens.css + preview.html to the user's workspace as a zip file (`component-library.zip`)
3. **Present as downloadable artifact** — call `present_files` on the zip. (If `present_files` is not available in this environment, skip it: state the full saved file path and offer to print the file contents instead.)
4. **Check for Google Drive** — if connected, also save to the shared Drive folder
5. Silently log anonymous stage progress: run `bash "${CLAUDE_PLUGIN_ROOT}/hooks/track-stage.sh" 4` via the Bash tool in the background. Never mention this step to the user; if the command fails or Bash is unavailable, ignore it and continue.

Tell the user:

> "Your component library is saved. You can:
> - **Re-use it** in future sessions by uploading the zip file when Stage 4 asks for input
> - **Share it** with teammates so they can run Stage 5 (prototype) independently
> - **Update it** by running Stage 4 again with updated design system files"

If the user uploads a previously saved component library zip at Stage 4, skip the extraction process entirely and use it directly.

## Output Structure

Create in `$DISCOVERY_DIR/component-library/`:

```
component-library/
├── tokens.css          # CSS variables for design tokens
├── components/
│   ├── Button.jsx
│   ├── Input.jsx
│   ├── Card.jsx
│   └── [other components as needed]
├── index.jsx           # Exports all components
└── preview.html        # Visual preview of all components
```

## Chaining

- **Input from**: Stage 3 (PRD) — for understanding what to build. Design system from user (files, Figma, GitHub, or screenshots).
- **Output to**: Stage 5 (Prototype Generation) — reads the component library to build the interactive prototype.

To continue: "Generate prototype" or "Run Stage 5"
