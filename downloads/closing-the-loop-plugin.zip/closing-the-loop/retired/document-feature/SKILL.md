---
name: document-feature
description: Generate a comprehensive reference document for a service, module, feature, or component in any codebase. Detects the project's language, framework, and conventions, then produces a markdown reference aimed at product managers, business analysts, and technical leads. Use when you need to capture an existing module's behavior and conventions before building on it — especially as the brownfield input to a Stage 7 handover.
trigger: [document this feature, reference doc for a module, capture existing behavior, brownfield reference, surface conventions]
license: Apache-2.0
---

# Document Feature Skill

Produces a multi-section reference doc for a single component (service, module, feature, package, etc.). Works across languages and frameworks — detects the ecosystem before reading code, then adapts terminology, file conventions, and code-sample syntax accordingly.

## Usage

Invoke with one of:
- A component or feature name (e.g., `"PostingService"`, `"Cash Discount Handling"`, `"AuthMiddleware"`)
- A file path pointing to the main implementation
- A directory path containing the component

## Workflow

Use TODO tracking to show progress through the steps below.

### Step 0: Detect the ecosystem

Before locating any files, identify the project's stack so the later steps use the right conventions. Read what's actually in the repo — do **not** assume a particular layout.

Signals to look for:

- **Language / ecosystem** — from manifest files:
  `package.json` (JS/TS) · `composer.json` (PHP) · `pyproject.toml` / `requirements.txt` (Python) · `go.mod` (Go) · `Cargo.toml` (Rust) · `pom.xml` / `build.gradle` (Java/Kotlin) · `*.csproj` (C#) · `Gemfile` (Ruby) · `mix.exs` (Elixir) · etc.
- **Framework markers** — from manifest deps or config files (Laravel, Symfony, Laminas, Rails, Django, FastAPI, Spring, Next.js, NestJS, Phoenix, ASP.NET, …).
- **Source roots** — `src/`, `lib/`, `app/`, `module/`, `internal/`, `pkg/`, `cmd/`, or framework-specific (e.g., Rails' `app/models`, `app/controllers`).
- **Test conventions** — `test/`, `tests/`, `__tests__/`, colocated `*_test.go`, `*.spec.ts`, `*_test.py`, etc.
- **Config conventions** — `.env`, `config/`, `application.yml`, `appsettings.json`, `settings.py`, `config/*.exs`, framework-specific dirs.
- **Existing docs location** — `docs/`, `documentation/`, `wiki/`, README-adjacent, or none.
- **Primary documentation language** — scan the README and existing docs. Match that language in the output, not a hardcoded "English only."

Record the detected profile (language, framework, source roots, test dir, config dir, docs dir, doc language) and use it in every later step.

### Step 1: Locate related files

Use Glob/Grep within the detected source roots — don't pattern-match against hardcoded paths.

Find and read whichever of these exist in this project (skip categories that don't apply):

- **Main implementation** — the file(s) implementing the component. Note approximate size using the most meaningful metric for the language (LOC, function count, public-export count).
- **Dependencies** — imported modules, injected services, base classes/interfaces, traits/mixins.
- **Composition / wiring** — DI container config, factory, `main`/bootstrap, module registration, framework providers — whatever the project uses to assemble this component.
- **Data layer** *(if data-backed)* — domain objects, schemas, ORM models, repositories/DAOs, migrations.
- **Entry points** *(if applicable)* — HTTP handlers, route definitions, RPC methods, CLI commands, queue consumers, scheduled jobs.
- **Frontend** *(only if there's coupled UI)* — components that consume the feature.
- **Tests** — unit and integration tests using the detected test convention.
- **Configuration** — feature flags, env vars, config entries relevant to the component.

### Step 2: Analyze

Extract:

- **Purpose & responsibility** — what business problem it solves; what's in scope and what isn't.
- **Public surface** — exported functions/methods/types with signatures and contracts. Use the language's actual documentation style (docstrings, JSDoc, godoc, rustdoc, XML doc comments, PHPDoc) — don't translate it into a different idiom.
- **Dependencies** — other components, data stores, external services.
- **Business rules** — validation, calculations, invariants.
- **State** — does the component maintain state between interactions (user settings, workflow progress, session data, resource status, lifecycle stages)? If so, identify the possible states, what triggers each transition, and what the caller needs to know. *(Skip entirely if stateless — most pure functions and stateless services are.)*
- **Data flow** — entry → transformation → persistence → output.
- **Error handling** — describe the error model the project *actually uses*: exceptions, `Result`/`Option`, error returns (Go), tagged tuples (Erlang/Elixir), HTTP problem-details, etc. Do **not** force an "error codes table" if the project doesn't define stable codes.
- **Integration directions** — for each integration, note whether this component *calls* it (outbound) or *is called by* it (inbound). This split matters for reasoning about blast radius later.
- **Hard constraints** — synthesize from what you read: are there things that *cannot be changed without coordinated effort* across the codebase? Examples: a table shared with another module, an endpoint versioned by an external consumer, a regulatory requirement baked into the data model. These are not just descriptions of what exists — they are load-bearing facts a developer must not work around unilaterally. Only include a constraint if you can point at the code or config that proves it.
- **Known risks** — what should a developer touching this module watch out for? Derive from error handling patterns, test coverage gaps, integration complexity, stateful edge cases, or anything flagged in comments or TODOs in the code. Do not invent risks — only surface what the code actually signals.
- **Surfaces the next feature will touch** *(conditional)* — the user- or consumer-facing shapes this module already exposes that an upcoming change is likely to add to or extend. Examples: modal dialog, full-page view, REST endpoint, gRPC handler, PDF report, CSV / Excel export, email template, push notification, CLI command, cron / scheduled job, queue consumer. Identify these from the PRD or feature shape the caller passed in, **plus** what neighbouring code in the same module already exposes. If the next feature adds no new surface (pure-logic change, internal refactor), skip entirely — this stays out of the document.

### Step 3: Generate the reference document

Use the template below. Three rules:

1. **Sections marked *(conditional)* are included only when relevant.** Omit them entirely rather than filling with "N/A."
2. **Code samples and terminology must match the detected ecosystem.** If the codebase calls them "modules," don't rename them to "services" in the doc. Render call-site examples in the project's primary language using its idioms.
3. **No invented content.** Every claim — file paths, line numbers, behaviors, error codes, constraints — must be sourced from code or config you actually read. If you can't source it, leave the section blank and flag the gap explicitly ("Not covered — no evidence in code"). Better an honest hole than a confident fabrication.

**Reference examples.** Before writing, check the `examples/` directory next to this skill for a finished reference doc in the detected ecosystem — it shows tone, depth, and table conventions the user has approved.

- PHP (Laminas / DDD-style): [`examples/php/cash-discount-handling.md`](examples/php/cash-discount-handling.md) — a complete, vetted output covering AI integration, dual-column data patterns, form traits, error codes, and known limitations. Use it as the gold standard for shape and depth, not as a literal template.

If no example matches the detected ecosystem, follow the template below and match the ecosystem's idioms.

#### Template

```markdown
# [Component Name] — Reference

> **Audience:** Product Managers, Business Analysts, Technical Leads
> **Last Updated:** [Current Date]
> **Main File / Entry Point:** `[path]`
> **Size:** ~[LOC, or function / public-export count]

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Core Concept](#2-core-concept)
3. [Data Model](#3-data-model)                          <!-- conditional -->
4. [Main Operations](#4-main-operations)
5. [Business Logic](#5-business-logic)
6. [State & Transitions](#6-state--transitions)         <!-- conditional -->
7. [Dependencies](#7-dependencies)
8. [Configuration](#8-configuration)
9. [Error Handling](#9-error-handling)
10. [Integration Points](#10-integration-points)
11. [Surface Conventions](#11-surface-conventions)      <!-- conditional -->
12. [Hard Constraints](#12-hard-constraints)
13. [Known Risks](#13-known-risks)                      <!-- conditional -->
14. [Code Structure](#14-code-structure)
15. [Glossary](#15-glossary)

---

## 1. Executive Summary

[2–4 sentences: what the component does, why it exists, who it serves.]

### Key Metrics

| Metric | Value |
|--------|-------|
| Size | ~[LOC / functions / exports] |
| Public API surface | [count] |
| External dependencies | [count] |

### Business Impact

- [Impact 1]
- [Impact 2]
- [Impact 3]

---

## 2. Core Concept

[Explain the underlying concept and the approach taken. ASCII diagram if it clarifies flow or structure.]

---

## 3. Data Model *(conditional — include only if the component owns or operates on persistent data)*

### Entities / Schemas

| Field | Type | Description |
|-------|------|-------------|
| ...   | ...  | ...         |

### Storage

- `[table / collection / file / topic]` — purpose and relationships.

### Key Relationships

[How entities relate to each other.]

---

## 4. Main Operations

For each significant public operation:

#### [Operation Name]

**Purpose:** ...
**Inputs:** ...
**Output:** ...
**Workflow:**
1. ...
2. ...

**Example** (use the project's primary language):

```[language]
[idiomatic call-site example]
```

---

## 5. Business Logic

### [Rule / behavior 1]

[What the rule is, why it exists, how it's enforced.]

### Calculation / transformation examples

[Concrete worked examples.]

---

## 6. State & Transitions *(conditional — include only if the component maintains state between interactions)*

**What state means here:** [Plain-language explanation of what gets remembered, and why the caller cares.]

**State machine:**

```
[ASCII or Mermaid state diagram showing states and transitions]
```

**Transition triggers:**

| From → To | Trigger | Notes |
|-----------|---------|-------|
| ...       | ...     | ...   |

**What callers need to know:** [Which transitions are observable from the outside, which are internal, and what guarantees hold across calls.]

> **Why this section matters:** Agents and feature developers that only see the first interaction will handle step 1 correctly but produce incorrect behavior on step 2 or 3 if state isn't documented. If the component is stateful, this is the highest-leverage section in the doc.

---

## 7. Dependencies

### Internal

- **[Name]** (`[path]`) — purpose / how it's used.

### Wiring / Composition

How this component is constructed and made available — DI container, factory, module registration, `main` setup, framework provider, etc. (Use whatever mechanism the project actually uses.)

### External integrations *(conditional)*

- **[Service / API]** — what's exchanged, auth, transport.

---

## 8. Configuration

- **Files:** `[path]` — purpose.
- **Environment variables:** `VAR_NAME` — description, default value.
- **Feature flags:** `flag.name` — effect when enabled.

---

## 9. Error Handling

Describe the error model the project actually uses (exceptions, `Result`, error returns, etc.).

### Failure modes

| Trigger | Result | How it surfaces to the caller |
|---------|--------|-------------------------------|
| ...     | ...    | ...                           |

*(Include a code/constant table only if the project defines stable error codes.)*

---

## 10. Integration Points

Split by direction. Direction is the question "who calls whom?" — outbound = this component calls them; inbound = they call this component.

### Outbound — services and APIs this component calls

| Dependency | Interface | What it's used for |
|------------|-----------|--------------------|
| [Name]     | [HTTP / SDK / DB / queue / library] | [Why this component needs it] |

### Inbound — services and entry points that call this component

| Caller / entry point | What it calls | Why |
|----------------------|---------------|-----|
| [Caller] (`file:line`) | [Method / endpoint] | [Use case] |

Inbound includes: HTTP routes, RPC methods, CLI commands, queue consumers, scheduled jobs, and any other internal service that depends on this one.

### Frontend *(conditional — only if there's coupled UI)*

- **[Component]** (`[path]`) — how it consumes this feature.

---

## 11. Surface Conventions *(conditional — one subsection per surface the next feature will touch; omit the section entirely if no surfaces are added or extended)*

For each surface, capture the conventions the codebase already follows so the next feature lands consistently. Source from 1–2 reference implementations of the same surface type elsewhere in the codebase — do not invent conventions, do not list framework defaults, only describe what this codebase actually does.

### [Surface — e.g. "Modal dialog" / "PDF report" / "REST endpoint" / "Email template" / "CSV export" / "CLI command" / "Cron job"]

- **Reference implementations:** `[path1]`, `[path2]` *(1–2 close analogues — the implementer can read these directly)*
- **Structural conventions:** [markup / file layout / function signature / response envelope — whatever is structural for this surface type in this codebase]
- **Styling / formatting conventions:** [CSS class system, number/date format helpers, header pattern, content-type — only the choices this codebase makes that differ from framework defaults]
- **Required initialisation / wiring:** [JS components to register, factories to bind, routes to add, plugins to enable, asset bundle to rebuild]
- **What goes wrong if you skip a convention:** [observable failure mode — "radios render browser-default", "JSON missing the envelope", "the cron won't pick up", "the dialog crashes on open because dynPosition is missing"]

### [next surface, same shape]

> **For Stage 7 handovers:** this section feeds into the Engineering Brief's `Component decisions` field. When the next feature touches one of the surfaces listed here, the implementer reads the convention here before writing code.

---

## 12. Hard Constraints

Things that **cannot be changed without coordinated effort** across the codebase. Each constraint must be sourced — if you can't point at the code or config that proves it, omit it.

For each constraint, include **what breaks if you deviate** whenever you can observe it in the code (error message, wrong behaviour, silent failure). A constraint without a failure signature is a rule; a constraint with one is a warning that activates at the right moment during implementation.

Format each entry as:

> **[Constraint]** *(source: `file:line` or config key)*
> *What breaks if you skip this:* [specific error / incorrect output / silent failure — e.g. "SQL error: Unknown column 'IF(…)' in order clause", "dialog opens but content never renders (HTTP 200, empty)", "CSV corrupted in Excel because encoding is ISO-8859-1 not UTF-8 with BOM"]
> *Unsafe alternative (avoid):* [specific method, pattern, or shortcut that looks reasonable but violates the constraint — only if one exists]

Examples:
- **Must use the ORM's expression wrapper for raw SQL fragments in `order()` calls** *(source: `TableGateway::selectWith()` passes strings directly to `ORDER BY`)*
  *What breaks if you skip this:* ORM backtick-quotes the string as a column name — SQL error at runtime.
  *Unsafe alternative:* Passing the constant as a plain string to `$select->order($string)`.

- **Must use existing `user_preferences` table — no new backend service** *(source: data-platform team agreement, tracked in ADR-12)*
  *What breaks if you skip this:* Deploy blocked by data-platform review gate.

- **Endpoint `/api/v1/dashboard/preferences` is consumed by ServiceX — versioning changes require coordinated release** *(source: `config/consumers.yml`)*
  *What breaks if you skip this:* ServiceX breaks silently on the old contract.

> **For Stage 7 handovers:** this section feeds directly into the Engineering Brief's `Hard constraints` field. A developer receiving the brief should be able to read this list and know what they must not change unilaterally — and what error they will see if they try.

---

## 13. Known Risks *(conditional — include only if the code signals genuine risks)*

Things a developer touching this module should watch out for. Sourced from error handling patterns, test coverage gaps, integration complexity, stateful edge cases, or explicit TODOs/comments in the code.

- [Risk + why it matters + suggested mitigation if any]

> **For Stage 7 handovers:** this section feeds into the Engineering Brief's `Risks` field.

---

## 14. Code Structure

[How the implementation is organized — modules, files, classes, functions, layers. Tree diagram if useful.]

### Design patterns

- **[Pattern]** — why and how.

### Testing

- **Unit tests:** `[path]` — scenarios covered.
- **Integration tests:** `[path]` — scenarios covered.

---

## 15. Glossary

- **[Term]:** [Definition].

---

## References

- Main file: `[path]`
- Related docs: `[paths if any]`
```

### Step 4: Save

- **Default location:** prefer the existing docs directory detected in Step 0 (`docs/`, `documentation/`, `wiki/`, …). Fall back to `docs/` only if none exists.
- **Stage 7 context:** if this skill is being run as a brownfield prerequisite for a discovery handover, save to `handover/[component-name]-reference.md` instead, so it lands alongside the other Stage 7 outputs.
- **Filename:** kebab-case, descriptive — e.g., `cash-discount-reference.md`, `auth-middleware-reference.md`.
- **Language:** match the project's existing documentation language. Don't force English if the rest of the project's docs are in another language.

After saving, report:
- The file path
- Document size
- Which Stage 7 Engineering Brief sections this document informs (if applicable): `Hard constraints` ← Section 12, `Risks` ← Section 13, `Component decisions` ← Sections 7, 10, and 11 (when Surface Conventions is present)
- Any sections left blank due to insufficient evidence

### Step 5: Quality check

Before completing, verify:

- **Sourced** — every factual claim ties back to a file you read. No invented behaviors, no assumed constraints, no plausible-sounding line numbers. If a section had insufficient evidence, it's blank with a "Not covered — no evidence in code" note, not filled with guesses.
- **Completeness** — executive summary is scannable in under 2 minutes; no placeholder text left behind.
- **Accuracy** — file paths include line numbers; metrics match the actual code; dependencies verified.
- **State documented** — if the component is stateful, the State & Transitions section exists and lists transitions, triggers, and what callers must know. Skipping this is the most common high-impact failure.
- **Hard constraints sourced** — every entry in Section 12 can be traced back to a specific file, config, or codebase constraint. If it can't be sourced, it's not in the list.
- **Surfaces match the next-feature shape** — if Surface Conventions (Section 11) is present, it lists exactly the surfaces the next feature will touch — no more, no less. Each subsection cites at least one reference implementation path. If the next feature adds no surface, the section is absent (not empty).
- **Integration direction is explicit** — every integration is filed as outbound or inbound, never ambiguous.
- **Clarity** — concrete examples where the concept is abstract; glossary covers every domain term.
- **Fit** — conditional sections that don't apply are omitted, not left empty. Code samples and terminology match the detected language and ecosystem. Doc language matches the project.

## Best Practices

1. **Detect before you assume.** Step 0 is mandatory — terminology, file locations, and code samples flow from it.
2. **Read the actual code.** Don't infer behavior from filenames or naming conventions.
3. **Use the project's vocabulary.** If the codebase says "module," don't rebrand it as "service" in the doc. If it says "handler," don't call it "controller."
4. **Use tables** for structured information (metrics, error modes, dependencies).
5. **Think like a PM.** Lead with business value; technical depth follows.
6. **Be thorough but scannable.** Headers, tables, short prose — not walls of text.
7. **Omit, don't pad.** A missing section is better than a section full of "N/A."
8. **Surface conventions are scoped to the next feature.** Section 11 lists only the surfaces the upcoming change will touch — detected from the PRD or feature shape, not enumerated as a system-wide audit. Each entry points at 1–2 reference files the implementer can read directly.

## Anti-patterns

Common failure modes to avoid. If the draft looks like any of these, rewrite it.

- **The architecture overview.** Describing the whole system when only one component was requested. Stay scoped to the target.
- **The code dump.** Pasting method signatures without explaining what they mean in business terms. The audience is a PM, not just an engineer — every signature needs a "why."
- **The missing state section.** Skipping State & Transitions because "it's obvious from the code." It is not obvious to the agent that will implement the next feature, nor to the PM writing the brief. If the component is stateful and this section is missing, the doc is incomplete.
- **The assumed constraint.** Writing "no new endpoints allowed" or "must use existing table X" under Hard Constraints without verifying it in the codebase. If you can't point at a file proving the constraint, omit it.
- **The fabricated line number.** Inventing `file.ts:42` because it sounds plausible. Either you read line 42 and it says what you claim, or you don't cite a line.
- **The confident hole-filler.** Filling a section with reasonable-sounding prose when the code didn't tell you anything. Leave the section blank with a "no evidence" note instead.
- **The language mismatch.** Writing PHP-style examples for a Go project, or English-only output when the rest of the project's docs are in another language.
- **The "everything is integration."** Treating every internal helper call as an integration point. Reserve Section 10 for cross-component / cross-system boundaries that a feature dev would actually need to coordinate across.
- **The framework-defaults dump.** Listing the framework's default conventions under Surface Conventions instead of what this codebase actually does. If your "PDF conventions" entry would apply to any mpdf project, it doesn't belong here — describe this codebase's deviations and choices, not the library's defaults.
- **The exhaustive surface enumeration.** Documenting every possible surface in the codebase "for completeness" instead of only the ones the next feature will touch. Surface Conventions is scoped to one feature, not a system-wide audit.

## Example Usage

By component name:

```
/document-feature PostingService
```

By feature name:

```
/document-feature "Cash Discount Handling"
```

By file path:

```
/document-feature src/auth/middleware.ts
```
