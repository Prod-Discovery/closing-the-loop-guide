#!/bin/bash
# Closing the Loop — progress telemetry driven by hooks, not by the model.
#
# PostToolUse on Write: a canonical output file was saved.
#   - a discovery stage file under discovery-engine/   → stage_completed 0–6
#     (plus 3.5 / 5.5 for the optional agent pattern check and audit)
#   - handover/<feature>-manifest.json (governed) or
#     handover/<feature>-delivery-context.md (local)   → handover milestone
#   - discovery-feedback-*.md                          → feedback event
# PostToolUse on tracker MCP writes:
#   - a create carrying the CTL path marker            → publish milestone
#   - a write carrying a Delivery Context              → handover milestone
#
# WHY A HOOK (found in the field by the upstream Discovery Engine, 1.8.0):
# skills used to tell the model to run track-stage.sh via the Bash tool.
# Where ${CLAUDE_PLUGIN_ROOT} is not set for model-run Bash (Cowork) the path
# broke, and in default permission mode the call asked the user to approve
# "silent" telemetry. A hook has neither problem — it runs with the plugin
# root set and needs no tool permission — and it rides on a save or tracker
# write the user already approved, so it adds no prompts.
#
# Dedupe: one event per (session, stage) — see send_once in telemetry-lib.sh.
# Content never leaves the machine: only the stage id is sent (feedback is
# the exception the user explicitly chose to send). Always exits 0.
# Opt out: CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 still honored).
# Debug: CLOSING_THE_LOOP_TELEMETRY_DEBUG=1 prints what would be sent instead.

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/telemetry-lib.sh" || exit 0

telemetry_disabled && exit 0

INPUT=$(cat)
TOOL=$(json_field "$INPUT" "tool_name")
SESSION_ID=$(json_field "$INPUT" "session_id" | tr -cd 'A-Za-z0-9-' | cut -c1-64)
DEBUG="${CLOSING_THE_LOOP_TELEMETRY_DEBUG:-0}"

stage_event() {  # stage_event <stage-id>
  send_once "${SESSION_ID:-nosession}-stage-$1" || return 0
  if [ "$DEBUG" = "1" ]; then echo "WOULD SEND stage_completed $1"; return 0; fi
  bash "$SCRIPT_DIR/track-stage.sh" "$1" "$SESSION_ID" </dev/null >/dev/null 2>&1
}

# The tool's input object as compact JSON, so content checks never look at
# tool_response (an edit's response can echo a whole ticket). Same tool ladder
# as json_field; the last resort cuts the raw payload between the two keys.
tool_input_json() {
  if command -v jq >/dev/null 2>&1; then
    printf '%s' "$INPUT" | jq -c '.tool_input // {}' 2>/dev/null
  elif command -v node >/dev/null 2>&1; then
    printf '%s' "$INPUT" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{try{process.stdout.write(JSON.stringify(JSON.parse(d).tool_input||{}))}catch(e){}})' 2>/dev/null
  elif command -v python3 >/dev/null 2>&1; then
    printf '%s' "$INPUT" | python3 -c 'import sys,json
try: print(json.dumps(json.load(sys.stdin).get("tool_input") or {}),end="")
except Exception: pass' 2>/dev/null
  else
    printf '%s' "$INPUT" | tr -d '\n' | sed -n 's/.*"tool_input"[[:space:]]*:\(.*\),[[:space:]]*"tool_response".*/\1/p'
  fi
}

# Does the tool input have a top-level "id"? (Linear's save_issue creates
# without one and updates with one.) Unknown → treat as an update.
tool_input_has_id() {
  if command -v jq >/dev/null 2>&1; then
    printf '%s' "$1" | jq -e 'has("id")' >/dev/null 2>&1
  elif command -v python3 >/dev/null 2>&1; then
    printf '%s' "$1" | python3 -c 'import sys,json
sys.exit(0 if "id" in json.load(sys.stdin) else 1)' 2>/dev/null
  else
    printf '%s' "$1" | grep -q '"id"[[:space:]]*:'
  fi
}

send_feedback() {  # send_feedback <file>  — Rating / About / Comment lines
  local raw rating about comment
  raw=$(cat "$1" 2>/dev/null) || return 0
  rating=$(printf '%s\n' "$raw" | sed -n 's/^Rating:[[:space:]]*\([1-5]\).*/\1/p' | head -1)
  [ -n "$rating" ] || return 0
  about=$(printf '%s\n' "$raw" | sed -n 's/^About:[[:space:]]*//p' | head -1)
  comment=$(printf '%s\n' "$raw" | sed -n '/^Comment:/,$p' | sed '1s/^Comment:[[:space:]]*//')
  if [ "$DEBUG" = "1" ]; then echo "WOULD SEND feedback $rating [$about]"; return 0; fi
  bash "$SCRIPT_DIR/track-feedback.sh" "$rating" "$comment" "$about" </dev/null >/dev/null 2>&1
}

case "$TOOL" in
  Write)
    FILE_PATH=$(json_field "$INPUT" "file_path" | tr '\\' '/')
    [ -n "$FILE_PATH" ] && [ "$FILE_PATH" != "unknown" ] || exit 0
    BASE=${FILE_PATH##*/}
    DIR=${FILE_PATH%/*}
    PARENT=${DIR##*/}

    STAGE=""
    if [ "$PARENT" = "discovery-engine" ]; then
      # $DISCOVERY_DIR always ends in discovery-engine/ (references/discovery-working-directory.md),
      # so generic names only count there. Since 0.2.11 Stages 3 and 6 write stage-3-prd* and
      # stage-6-experiment-plan*; the older prd-* / agent-prd-* / experiment-plan.md still count.
      case "$BASE" in
        product-context.md)                    STAGE="0" ;;
        stage-1-1-customer-insights.md)        STAGE="1.1" ;;
        stage-1-2-competitive-landscape.md)    STAGE="1.2" ;;
        stage-1-3-top-5-opportunities.md)      STAGE="1.3" ;;
        stage-2-selected-opportunity.md)       STAGE="2" ;;
        stage-3-prd*.md|prd-*.md|agent-prd-*.md) STAGE="3" ;;
        stage-3-pattern-card*.md)              STAGE="3.5" ;;
        component-inventory.md)                STAGE="4" ;;
        stage-5-prototype*.html)               STAGE="5" ;;
        stage-5-pattern-audit*.md)             STAGE="5.5" ;;
        stage-6-experiment-plan*.md|experiment-plan.md) STAGE="6" ;;
      esac
    elif [ "$PARENT" = "handover" ]; then
      case "$BASE" in
        *-manifest.json|*-delivery-context.md) STAGE="handover" ;;
      esac
    fi
    [ -n "$STAGE" ] && stage_event "$STAGE"

    case "$BASE" in
      discovery-feedback-*.md)
        send_once "${SESSION_ID:-nosession}-feedback-$BASE" && send_feedback "$FILE_PATH" ;;
    esac
    ;;

  mcp__*)
    OP=${TOOL##*__}
    # Reads never count — a search on the marker label would look like a publish.
    case "$OP" in
      *[Gg]et*|*[Ss]earch*|*[Ll]ist*|*[Ff]etch*|*[Rr]ead*|*[Qq]uery*|*[Ff]ind*|*[Ll]ookup*) exit 0 ;;
    esac
    TI=$(tool_input_json)
    [ -n "$TI" ] || exit 0

    # Handover: a tracker write carrying a Delivery Context (its heading + hash line).
    if printf '%s' "$TI" | grep -q 'Delivery Context' && printf '%s' "$TI" | grep -q 'Context hash'; then
      stage_event handover
      exit 0
    fi

    # Publish: creating the feature issue/page with the path marker
    # (discovery-create-tracker-issue). Children carry other markers
    # (-story, -backlog-item, handover-signoff) and never match.
    IS_CREATE=0
    case "$OP" in *[Cc]reate*) IS_CREATE=1 ;; esac
    if [ "$OP" = "save_issue" ] && ! tool_input_has_id "$TI"; then IS_CREATE=1; fi
    if [ "$OP" = "executeWrite" ]; then
      case "$(json_field "$TI" "name")" in *[Cc]reate*) IS_CREATE=1 ;; esac
    fi
    [ "$IS_CREATE" = "1" ] || exit 0
    if printf '%s' "$TI" | grep -Eq '(^|[^A-Za-z0-9-])(discovery|context-first)-handover([^A-Za-z0-9-]|$)|path: `context-first`'; then
      stage_event publish
    fi
    ;;
esac

exit 0
