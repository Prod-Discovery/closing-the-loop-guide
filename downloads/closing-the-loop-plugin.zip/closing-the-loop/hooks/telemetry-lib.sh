#!/bin/bash
# Shared helpers for the telemetry scripts — dependency-light on purpose.
# Works on macOS, Linux, and Windows Git Bash with NO jq/shasum required:
# every helper tries the common tools in order and degrades gracefully.
# Telemetry must never block or break a workflow, and never leak content.

TELEMETRY_WEBHOOK_URL="https://script.google.com/macros/s/AKfycbzeW0PJzGRCy6LIsFHyxIGCPQnVqxBHOa7Mh9gy4W6tgjc7QH3-ujQ56cfcCpIM6vdmqg/exec"

# Opt-out (new name, legacy name still honored). Returns 0 when disabled.
telemetry_disabled() {
  [ "${CLOSING_THE_LOOP_TELEMETRY_DISABLED:-}" = "1" ] || [ "${DISCOVERY_ENGINE_TELEMETRY_DISABLED:-}" = "1" ]
}

# Extract a string field from JSON on stdin: json_field <input> <key>
# Tries jq, then node, then python3, then a sed fallback good enough for
# flat string values (the only thing we read).
json_field() {
  local input="$1" key="$2" val=""
  if command -v jq >/dev/null 2>&1; then
    val=$(printf '%s' "$input" | jq -r "..|.${key}? // empty" 2>/dev/null | head -1)
  elif command -v node >/dev/null 2>&1; then
    val=$(printf '%s' "$input" | node -e '
      let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
        try{const o=JSON.parse(d);const f=(x)=>{if(x&&typeof x==="object"){if(typeof x[process.argv[1]]==="string")return x[process.argv[1]];for(const k in x){const r=f(x[k]);if(r)return r}}return ""};
        process.stdout.write(f(o))}catch(e){}})' "$key" 2>/dev/null)
  elif command -v python3 >/dev/null 2>&1; then
    val=$(printf '%s' "$input" | python3 -c '
import sys,json
key=sys.argv[1]
def find(o):
    if isinstance(o,dict):
        if isinstance(o.get(key),str): return o[key]
        for v in o.values():
            r=find(v)
            if r: return r
    return ""
try: print(find(json.load(sys.stdin)),end="")
except Exception: pass' "$key" 2>/dev/null)
  else
    val=$(printf '%s' "$input" | tr -d '\n' | sed -n 's/.*"'"$key"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)
  fi
  printf '%s' "${val:-unknown}"
}

# Stable anonymized machine id: sha256("$USER-$HOSTNAME") first 12 chars.
# (echo semantics kept identical to the original scripts so existing
# machine hashes don't change.) Tries shasum, sha256sum, openssl, node.
machine_hash() {
  # NOTE: trailing newline is part of the hashed input (the original scripts
  # used `echo`), so existing machine hashes stay identical.
  local h=""
  _src() { printf '%s\n' "${USER:-anon}-${HOSTNAME:-unknown}"; }
  if command -v shasum >/dev/null 2>&1; then
    h=$(_src | shasum -a 256 2>/dev/null | cut -c1-12)
  elif command -v sha256sum >/dev/null 2>&1; then
    h=$(_src | sha256sum 2>/dev/null | cut -c1-12)
  elif command -v openssl >/dev/null 2>&1; then
    h=$(_src | openssl dgst -sha256 2>/dev/null | sed 's/.*= *//' | cut -c1-12)
  elif command -v node >/dev/null 2>&1; then
    h=$(_src | node -e 'const c=require("crypto");let d="";process.stdin.on("data",x=>d+=x).on("end",()=>process.stdout.write(c.createHash("sha256").update(d).digest("hex").slice(0,12)))' 2>/dev/null)
  fi
  printf '%s' "${h:-anonmachine0}"
}

# Plugin version from the manifest, without jq.
plugin_version() {
  sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' \
    "${CLAUDE_PLUGIN_ROOT:-.}/.claude-plugin/plugin.json" 2>/dev/null | head -1 \
    || printf 'unknown'
}

# Escape a string for embedding in a JSON value (backslash, quote, newlines,
# control chars stripped).
json_escape() {
  printf '%s' "$1" | tr -d '\000-\010\013\014\016-\037' \
    | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e ':a;N;$!ba;s/\n/\\n/g' 2>/dev/null \
    || printf '%s' "$1" | tr -d '\n"\\'
}

# Fire-and-forget send. Never blocks; max 3s; backgrounded.
send_event() {
  curl -s -X POST "$TELEMETRY_WEBHOOK_URL" \
    -H "Content-Type: application/json" \
    -d "$1" \
    --max-time 3 \
    > /dev/null 2>&1 &
}

telemetry_timestamp() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
