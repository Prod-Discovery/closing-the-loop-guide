#!/bin/bash
# Shared helpers for the telemetry scripts — dependency-light on purpose.
# Works on macOS, Linux, and Windows Git Bash with NO jq/shasum required:
# every helper tries the common tools in order and degrades gracefully.
# Telemetry must never block or break a workflow, and never leak content.

TELEMETRY_WEBHOOK_URL="https://script.google.com/macros/s/AKfycbzeW0PJzGRCy6LIsFHyxIGCPQnVqxBHOa7Mh9gy4W6tgjc7QH3-ujQ56cfcCpIM6vdmqg/exec"

# Opt-out (new name, legacy name still honored). Returns 0 when disabled.
telemetry_disabled() {
  [ "${CLOSING_THE_LOOP_TELEMETRY_DISABLED:-}" = "1" ] || [ "${DISCOVERY_ENGINE_TELEMETRY_DISABLED:-}" = "1" ]
}

# Extract a string field from JSON on stdin: json_field <input> <key>
# Tries jq, then node, then python3, then a sed fallback good enough for
# flat string values (the only thing we read).
json_field() {
  local input="$1" key="$2" val=""
  if command -v jq >/dev/null 2>&1; then
    val=$(printf '%s' "$input" | jq -r "..|.${key}? // empty" 2>/dev/null | head -1)
  elif command -v node >/dev/null 2>&1; then
    val=$(printf '%s' "$input" | node -e '
      let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
        try{const o=JSON.parse(d);const f=(x)=>{if(x&&typeof x==="object"){if(typeof x[process.argv[1]]==="string")return x[process.argv[1]];for(const k in x){const r=f(x[k]);if(r)return r}}return ""};
        process.stdout.write(f(o))}catch(e){}})' "$key" 2>/dev/null)
  elif command -v python3 >/dev/null 2>&1; then
    val=$(printf '%s' "$input" | python3 -c '
import sys,json
key=sys.argv[1]
def find(o):
    if isinstance(o,dict):
        if isinstance(o.get(key),str): return o[key]
        for v in o.values():
            r=find(v)
            if r: return r
    return ""
try: print(find(json.load(sys.stdin)),end="")
except Exception: pass' "$key" 2>/dev/null)
  else
    val=$(printf '%s' "$input" | tr -d '\n' | sed -n 's/.*"'"$key"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)
  fi
  printf '%s' "${val:-unknown}"
}

# Stable anonymized machine id: sha256("$USER-$HOSTNAME") first 12 chars.
# (echo semantics kept identical to the original scripts so existing
# machine hashes don't change.) Tries shasum, sha256sum, openssl, node.
machine_hash() {
  # NOTE: trailing newline is part of the hashed input (the original scripts
  # used `echo`), so existing machine hashes stay identical.
  local h=""
  _src() { printf '%s\n' "${USER:-anon}-${HOSTNAME:-unknown}"; }
  if command -v shasum >/dev/null 2>&1; then
    h=$(_src | shasum -a 256 2>/dev/null | cut -c1-12)
  elif command -v sha256sum >/dev/null 2>&1; then
    h=$(_src | sha256sum 2>/dev/null | cut -c1-12)
  elif command -v openssl >/dev/null 2>&1; then
    h=$(_src | openssl dgst -sha256 2>/dev/null | sed 's/.*= *//' | cut -c1-12)
  elif command -v node >/dev/null 2>&1; then
    h=$(_src | node -e 'const c=require("crypto");let d="";process.stdin.on("data",x=>d+=x).on("end",()=>process.stdout.write(c.createHash("sha256").update(d).digest("hex").slice(0,12)))' 2>/dev/null)
  fi
  printf '%s' "${h:-anonmachine0}"
}

# Plugin version from the manifest, without jq.
plugin_version() {
  sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' \
    "${CLAUDE_PLUGIN_ROOT:-.}/.claude-plugin/plugin.json" 2>/dev/null | head -1 \
    || printf 'unknown'
}

# Escape a string for embedding in a JSON value: control chars stripped (CR
# included), tabs → spaces, backslash and quote escaped, newlines → \n. The
# line join uses awk, not sed's `:a;N;$!ba` loop — BSD sed (macOS) reads that
# whole script as a label name and leaves raw newlines, i.e. invalid JSON.
json_escape() {
  printf '%s' "$1" | tr -d '\000-\010\013\014\015\016-\037' | tr '\011' ' ' \
    | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' \
    | awk 'BEGIN { ORS = "" } NR > 1 { print "\\n" } { print }' 2>/dev/null \
    || printf '%s' "$1" | tr -d '\n"\\'
}

# Identity fields from a personalized download, as a JSON fragment to splice
# into an event payload (leading comma included), or "" when absent.
#
# productos.visma.org bakes telemetry-identity.json into each signed-in
# download (token, email, name, team) so usage can be attributed to the
# downloader — skill names and counts only; event content never changes.
# Zips from the public guide page have no identity file, and these events
# stay exactly as before. Opt-out (telemetry_disabled) covers this too.
identity_fields() {
  if [ -z "${_IDENTITY_CACHE+x}" ]; then
    _IDENTITY_CACHE=""
    local f="${CLAUDE_PLUGIN_ROOT:-.}/telemetry-identity.json" raw="" v="" out=""
    if [ -r "$f" ]; then
      raw=$(cat "$f" 2>/dev/null)
      for key in token email name team; do
        v=$(json_field "$raw" "$key")
        [ "$v" = "unknown" ] && v=""
        case "$key" in
          token) [ -n "$v" ] && out="$out,\"identity_token\":\"$(json_escape "$v")\"" ;;
          email) [ -n "$v" ] && out="$out,\"user_email\":\"$(json_escape "$v")\"" ;;
          name)  [ -n "$v" ] && out="$out,\"user_name\":\"$(json_escape "$(sheet_safe "$v")")\"" ;;
          team)  [ -n "$v" ] && out="$out,\"user_team\":\"$(json_escape "$(sheet_safe "$v")")\"" ;;
        esac
      done
      _IDENTITY_CACHE="$out"
    fi
  fi
  printf '%s' "$_IDENTITY_CACHE"
}

# Fire-and-forget send. Never blocks; max 3s; backgrounded.
send_event() {
  curl -s -X POST "$TELEMETRY_WEBHOOK_URL" \
    -H "Content-Type: application/json" \
    -d "$1" \
    --max-time 3 \
    > /dev/null 2>&1 &
}

telemetry_timestamp() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }

# Make free text safe to land in a spreadsheet cell: a value starting with
# = + - @ would run as a formula when the Apps Script appends the row, so it
# gets a leading apostrophe (Sheets' "treat as text"). Apply before json_escape
# to anything a person typed (feedback comment, "about", identity name/team).
sheet_safe() {
  case "$1" in
    [=+@-]*) printf "'%s" "$1" ;;
    *) printf '%s' "$1" ;;
  esac
}

# Session-scoped dedupe for hook-driven events: send_once <key> returns 0 the
# first time a key is seen (and records it), 1 after that. Markers live under
# the user's cache dir and are pruned after 7 days. Re-saving a stage file
# after corrections, or a second Write of the same output, never double-counts.
send_once() {
  local dir="${HOME:-/tmp}/.cache/closing-the-loop/sent" key
  key=$(printf '%s' "$1" | tr -cd 'A-Za-z0-9._-' | cut -c1-120)
  [ -n "$key" ] || return 1
  mkdir -p "$dir" 2>/dev/null || return 0   # can't dedupe → still send once now
  find "$dir" -type f -mtime +7 -delete 2>/dev/null
  [ -e "$dir/$key" ] && return 1
  : > "$dir/$key" 2>/dev/null
  return 0
}
