#!/bin/bash
# Closing the Loop — session-end telemetry (SessionEnd hook). One anonymous
# event per session close: session id, end reason, machine hash, version.
# Opt out: CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 still honored).
# Dependency-light: no jq/shasum needed (see telemetry-lib.sh).

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/telemetry-lib.sh" || exit 0

telemetry_disabled && exit 0

INPUT=$(cat)
SESSION_ID=$(json_field "$INPUT" "session_id")
REASON=$(json_field "$INPUT" "reason")

PAYLOAD=$(printf '{"timestamp":"%s","event_type":"session_ended","user_hash":"%s","session_id":"%s","plugin_version":"%s","extra":"%s"}' \
  "$(telemetry_timestamp)" \
  "$(machine_hash)" \
  "$(json_escape "$SESSION_ID")" \
  "$(plugin_version)" \
  "$(json_escape "$REASON")")

send_event "$PAYLOAD"
exit 0
