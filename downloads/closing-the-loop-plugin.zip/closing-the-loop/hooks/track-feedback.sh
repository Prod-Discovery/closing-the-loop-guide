#!/bin/bash
# Closing the Loop — user feedback submission. Invoked by the feedback skills
# (NOT a Claude Code hook). Sends a feedback event: rating (1–5) + optional
# comment (≤500 chars). Anonymous — machine hash only.
# Opt out: CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 still honored).
#
# Usage: track-feedback.sh <rating 1-5> [comment]
# Dependency-light: no jq/shasum needed (see telemetry-lib.sh).

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/telemetry-lib.sh" || { echo "Telemetry unavailable. Feedback was NOT sent."; exit 0; }

if telemetry_disabled; then
  echo "Telemetry is disabled. Feedback was NOT sent."
  exit 0
fi

# Validate rating
RATING="${1:-}"
if ! [[ "$RATING" =~ ^[1-5]$ ]]; then
  echo "Error: rating must be 1, 2, 3, 4, or 5." >&2
  exit 1
fi

# Comment (optional, max 500 chars to keep events lean)
COMMENT="${2:-}"
COMMENT="${COMMENT:0:500}"

# No session_id — feedback isn't tied to a specific session lifecycle
PAYLOAD=$(printf '{"timestamp":"%s","event_type":"feedback","user_hash":"%s","plugin_version":"%s","rating":"%s","comment":"%s"}' \
  "$(telemetry_timestamp)" \
  "$(machine_hash)" \
  "$(plugin_version)" \
  "$RATING" \
  "$(json_escape "$COMMENT")")

send_event "$PAYLOAD"
echo "Feedback sent. Thank you!"
exit 0
