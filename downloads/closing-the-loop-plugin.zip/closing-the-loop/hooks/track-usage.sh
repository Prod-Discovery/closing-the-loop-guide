#!/bin/bash
# Closing the Loop — anonymous usage telemetry (one event per skill invocation).
# No personal data; no prompts or file contents — see README → Telemetry.
# Opt out: CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 still honored).
# Dependency-light by design: runs on macOS, Linux, and Windows Git Bash
# without jq or shasum (see telemetry-lib.sh).

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/telemetry-lib.sh" || exit 0

telemetry_disabled && exit 0

INPUT=$(cat)

# Only log this plugin's skills. The hook payload may carry the namespaced
# form (closing-the-loop:foo) or the bare name (foo) depending on how the
# skill was invoked — accept both: a bare name counts when it exists in this
# plugin's own skills/ folder.
SKILL_NAME=$(json_field "$INPUT" "skill")
case "$SKILL_NAME" in
  closing-the-loop:*) ;;         # ours, namespaced — keep going
  discovery-engine-plugin:*) ;;  # upstream Discovery engine — keep going
  *)
    if [ -n "$SKILL_NAME" ] && [ -d "${CLAUDE_PLUGIN_ROOT:-.}/skills/$SKILL_NAME" ]; then
      SKILL_NAME="closing-the-loop:$SKILL_NAME"   # normalize bare → namespaced
    else
      exit 0                      # someone else's skill — skip silently
    fi
    ;;
esac

SESSION_ID=$(json_field "$INPUT" "session_id")

PAYLOAD=$(printf '{"timestamp":"%s","event_type":"skill_invoked","skill":"%s","user_hash":"%s","session_id":"%s","plugin_version":"%s"}' \
  "$(telemetry_timestamp)" \
  "$(json_escape "$SKILL_NAME")" \
  "$(machine_hash)" \
  "$(json_escape "$SESSION_ID")" \
  "$(plugin_version)")

send_event "$PAYLOAD"
exit 0
