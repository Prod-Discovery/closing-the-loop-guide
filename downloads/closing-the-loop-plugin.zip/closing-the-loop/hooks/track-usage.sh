#!/bin/bash
# Closing the Loop — anonymous usage telemetry (one event per skill invocation).
# No personal data; no prompts or file contents — see README → Telemetry.
# Opt out: CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 still honored).
# Dependency-light by design: runs on macOS, Linux, and Windows Git Bash
# without jq or shasum (see telemetry-lib.sh).

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/telemetry-lib.sh" || exit 0

telemetry_disabled && exit 0

INPUT=$(cat)

# Only log this plugin's skills. The hook payload may carry the namespaced
# form (closing-the-loop:foo) or the bare name (foo) depending on how the
# skill was invoked — accept both: a bare name counts when it exists in this
# plugin's own skills/ folder.
SKILL_NAME=$(json_field "$INPUT" "skill")
case "$SKILL_NAME" in
  closing-the-loop:*) ;;         # ours, namespaced — keep going
  discovery-engine-plugin:*) ;;  # upstream Discovery engine — keep going
  *)
    if [ -n "$SKILL_NAME" ] && [ -d "${CLAUDE_PLUGIN_ROOT:-.}/skills/$SKILL_NAME" ]; then
      SKILL_NAME="closing-the-loop:$SKILL_NAME"   # normalize bare → namespaced
    else
      exit 0                      # someone else's skill — skip silently
    fi
    ;;
esac

SESSION_ID=$(json_field "$INPUT" "session_id")

PAYLOAD=$(printf '{"timestamp":"%s","event_type":"skill_invoked","skill":"%s","user_hash":"%s","session_id":"%s","plugin_version":"%s"%s}' \
  "$(telemetry_timestamp)" \
  "$(json_escape "$SKILL_NAME")" \
  "$(machine_hash)" \
  "$(json_escape "$SESSION_ID")" \
  "$(plugin_version)" \
  "$(identity_fields)")

send_event "$PAYLOAD"

# Loop milestone: the front door ran. Logged here rather than by the skill
# itself, for the same reason as track-progress.sh — a model-run Bash call
# prompts in default permission mode and can't find the script in Cowork.
if [ "$SKILL_NAME" = "closing-the-loop:closing-the-loop-start" ]; then
  SID=$(printf '%s' "$SESSION_ID" | tr -cd 'A-Za-z0-9-' | cut -c1-64)
  if send_once "${SID:-nosession}-stage-activation"; then
    bash "$SCRIPT_DIR/track-stage.sh" activation "$SID" </dev/null >/dev/null 2>&1
  fi
fi
exit 0
