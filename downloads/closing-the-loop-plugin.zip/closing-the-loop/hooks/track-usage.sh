#!/bin/bash
# Discovery to Prototype Engine — anonymous usage telemetry
# Sends one event per skill invocation. No personal data.
# Users can opt out by setting CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (the legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 is still honored).

# 1. Respect opt-out
if [ "${CLOSING_THE_LOOP_TELEMETRY_DISABLED:-}" = "1" ] || [ "${DISCOVERY_ENGINE_TELEMETRY_DISABLED:-}" = "1" ]; then
  exit 0
fi

# 2. Webhook URL — Google Apps Script that appends events to a private Google Sheet
WEBHOOK_URL="https://script.google.com/macros/s/AKfycbzeW0PJzGRCy6LIsFHyxIGCPQnVqxBHOa7Mh9gy4W6tgjc7QH3-ujQ56cfcCpIM6vdmqg/exec"

# 3. Read hook payload from stdin
INPUT=$(cat)

# 4. Extract skill name (only log this plugin's skills)
# Skills bundled here are namespaced `closing-the-loop:*`. The upstream
# `discovery-engine-plugin:*` prefix is still accepted so the same script keeps
# working for anyone who has the standalone Discovery engine installed too.
SKILL_NAME=$(echo "$INPUT" | jq -r '.tool_input.skill // "unknown"' 2>/dev/null)
case "$SKILL_NAME" in
  closing-the-loop:*) ;;         # ours — keep going
  discovery-engine-plugin:*) ;;  # upstream Discovery engine — keep going
  *) exit 0 ;;                    # someone else's skill — skip silently
esac

# 5. Extract session ID (groups events from the same Claude Code session)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // "unknown"' 2>/dev/null)

# 6. Read plugin version from manifest
PLUGIN_VERSION=$(jq -r '.version // "unknown"' "${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json" 2>/dev/null || echo "unknown")

# 7. Build anonymized user ID (stable per machine, not personally identifying)
USER_HASH=$(echo "${USER:-anon}-${HOSTNAME:-unknown}" | shasum -a 256 | cut -c1-12)

# 8. Build event payload
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
PAYLOAD=$(jq -n \
  --arg timestamp "$TIMESTAMP" \
  --arg event_type "skill_invoked" \
  --arg skill "$SKILL_NAME" \
  --arg user_hash "$USER_HASH" \
  --arg session_id "$SESSION_ID" \
  --arg plugin_version "$PLUGIN_VERSION" \
  '{timestamp:$timestamp, event_type:$event_type, skill:$skill, user_hash:$user_hash, session_id:$session_id, plugin_version:$plugin_version}')

# 9. Send in background — never block the user
curl -s -X POST "$WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  --max-time 3 \
  > /dev/null 2>&1 &

exit 0
