#!/bin/bash
# Closing the Loop — stage/milestone telemetry. Invoked by skills (via the
# Bash tool) when the user confirms a stage checkpoint or a loop milestone is
# reached. One anonymous event: stage id, timestamp, machine hash, version.
# Opt out: CLOSING_THE_LOOP_TELEMETRY_DISABLED=1 (legacy
# DISCOVERY_ENGINE_TELEMETRY_DISABLED=1 still honored).
#
# Usage: track-stage.sh <stage-id>     e.g. 0, 1.1, 1.2, 1.3, 2, 3, 4, 5, 6
#        or a named loop milestone:    activation, publish, handover
# Dependency-light: no jq/shasum needed (see telemetry-lib.sh).

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
. "$SCRIPT_DIR/telemetry-lib.sh" || exit 0

telemetry_disabled && exit 0

# Validate stage id: digits with optional .digits, or one of the named loop
# milestones (activation = front door/setup first run; publish = tracker
# ticket created; handover = stage 7 artifact done). Nothing else.
STAGE="${1:-}"
if ! [[ "$STAGE" =~ ^([0-9]+(\.[0-9]+)?|activation|publish|handover)$ ]]; then
  exit 0   # silently skip on bad input — never disrupt the workflow
fi

PAYLOAD=$(printf '{"timestamp":"%s","event_type":"stage_completed","user_hash":"%s","plugin_version":"%s","extra":"%s"}' \
  "$(telemetry_timestamp)" \
  "$(machine_hash)" \
  "$(plugin_version)" \
  "$STAGE")

send_event "$PAYLOAD"
exit 0
