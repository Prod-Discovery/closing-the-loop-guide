---
name: v-design-frontend
description: Design and build clear, production-ready frontend interfaces with strong visual direction, complete component states, responsive behavior, and accessible interaction. Use when creating a page, screen, view, or component, when redesigning an existing interface, when implementing responsive layouts, when translating wireframes or design specs into working UI, or whenever a request touches user-facing visual or interaction work — even if framed as just "make this look better".
trigger: [build a page, design this ui, create a component, responsive design, redesign this screen]
license: Apache-2.0
---

# Design Frontend

## Objective

Produce frontend interfaces that are visually intentional, functionally
complete, and accessible by default. Every component handles its full range
of states, layouts respond to real viewport conditions, interactions are
keyboard-navigable and screen-reader-compatible, and the visual language is
consistent with the project's existing design conventions.

## When to Use

This skill applies across web, native, and hybrid stacks regardless of the
framework or build chain in use.

- Creating new pages, screens, views, or major layout sections
- Building reusable components with full state coverage
- Redesigning existing interfaces or implementing responsive layouts
- Translating design specs, wireframes, or product requirements into working
  interfaces
- Improving interaction quality or fixing accessibility issues

Do not use it for backend API design, business logic that happens to touch a
UI file, reviewing someone else's frontend code, or performance profiling —
this skill produces interfaces; those are separate concerns.

## Workflow

### 1. Audit Existing Patterns

Read the project's style files, theme configuration, and existing components.
Extract the implicit design tokens — colors, spacing values, font sizes,
border radii, shadows — and the layout patterns already in use. Note any
inconsistencies that should be resolved rather than perpetuated.

### 2. Define Visual Direction

Before writing implementation code, confirm the type scale, the color palette
(backgrounds, text, borders, interactive elements, status indicators), the
spacing rhythm, and the visual hierarchy — what draws the eye first, what's
secondary, what's ambient. Document key visual decisions briefly.

### 3. Build Structure and Layout

Use semantic elements that reflect the content's meaning — navigation, main
content, sections, headings, lists. Build the layout for real content, not
placeholder text: long names, empty lists, missing images. Wrapper elements
exist for layout reasons, not because the styling approach demands them.

### 4. Implement Component States

Every interactive component must handle its full state range:

- **Default:** The resting state when the component first renders
- **Hover:** Visual feedback when the cursor is over the element (for pointer
  devices)
- **Focus:** A visible focus indicator for keyboard navigation — this must be
  distinct and meet contrast requirements
- **Active/Pressed:** Feedback during interaction (click, tap, key press)
- **Disabled:** Visually distinct and non-interactive, with appropriate
  attributes to prevent interaction
- **Loading:** If the component triggers async work, show progress or a
  loading indicator
- **Error:** If the component accepts input or displays data that can fail,
  show the error state with a clear message
- **Empty:** If the component displays a collection, handle the zero-item
  case with a meaningful empty state

Not every component needs every state, but every interactive component needs
at least default, hover, focus, and disabled considered.

### 5. Implement Responsive Behavior

- Test at the project's defined breakpoints, plus at least one intermediate
  size between each
- Text remains readable at all sizes — no truncation without access to the
  full content, no overflow; images, media, and embeds scale appropriately
- Interactive elements remain usable at touch-target sizes on small viewports
  (minimum 44×44 point area)
- Test with real content lengths — long titles, long descriptions, many items
  in a list

### 6. Verify Accessibility

- **Semantic structure:** Headings follow a logical hierarchy; landmarks
  (navigation, main, complementary) are present and correct
- **Color contrast:** Text and interactive elements meet minimum contrast
  ratios — 4.5:1 for normal text, 3:1 for large text and UI components
- **Keyboard navigation:** Every interactive element is reachable via Tab,
  focus order follows visual order, and custom components implement expected
  keyboard patterns (arrow keys for menus, Escape to close overlays)
- **Screen reader compatibility:** Descriptive alt text, labeled form inputs,
  dynamic changes announced via live regions, appropriate roles on custom
  widgets
- **Motion sensitivity:** Animations respect the user's reduced-motion
  preference

### 7. Run Verification

Run the project's build, test command, and any style linting or formatting
checks. Visually inspect the interface at each breakpoint. If the project has
visual regression testing, update baselines after confirming the new
appearance is correct.

## Output Contract

Every frontend design task produces these sections under `## Output Contract`:

### Summary

One sentence stating what was designed or changed and the headline visual or
interaction objective (e.g. "Rebuilt the settings panel with a 3-column
responsive layout, full keyboard navigation, and dark-mode support").

### Detail

- Files created or modified, and what visual or interaction objective each
  change serves
- New design tokens or patterns introduced, and why they were needed rather
  than reusing existing ones
- Deviations from existing conventions, with rationale

### Verification

**Responsive:**

- Viewports tested and the results at each
- Layout changes that occur across breakpoints
- Any viewport sizes where the implementation is compromised and why

**Accessibility:**

- Heading structure and landmark usage
- Contrast ratios checked for key text and interactive elements
- Keyboard navigation path tested and confirmed
- Screen reader considerations addressed (labels, roles, live regions)
- Any known accessibility gaps with rationale for deferral

**Build:**

- Commands run and their outcomes (build, tests, linting)
- Any warnings or issues that remain and why they're acceptable

### Follow-ups

- Visual or interaction refinements deferred to a later change
- Accessibility gaps acknowledged but not fixed in this pass
- "None" if the design is fully complete

## Quality Bar

A frontend implementation meets the quality bar when:

- Colors, spacing, and typography follow a consistent system, not ad-hoc
  values
- Every interactive component handles at minimum: default, hover, focus, and
  disabled states
- The layout works across all supported viewports without horizontal scroll,
  content overflow, or unusable element sizes
- Text contrast meets minimum ratios, color is not the sole indicator of
  meaning, and all interactive elements are keyboard-reachable with visible
  focus indicators
- The implementation uses semantic markup and reuses existing design tokens
- The build passes and existing tests are not broken

## Anti-Patterns

**The pixel-perfect trap.** Matching a mockup at one exact viewport width
while ignoring how the layout behaves at every other size. Real interfaces
live on a continuum of viewport sizes — build for the range, not the
screenshot.

**The div soup.** Meaningless container elements for everything. A `<nav>`
tells users and tools what the content is; a `<div class="nav-wrapper">`
tells them nothing.

## Critical Rules

1. **Reuse before inventing.** If design tokens exist, use them. If they
   don't, extract implicit tokens from the existing code before inventing new
   values. New values must justify their existence — "the existing scale
   doesn't have a value that works here" is valid; "I didn't check what
   exists" is not.

2. **Every interactive element must have a visible focus indicator.** If the
   default focus ring is removed for aesthetic reasons, a custom focus
   indicator must replace it. No focus indicator means keyboard users cannot
   navigate.

3. **Never rely on color alone.** Status, errors, required fields, and
   interactive states must be distinguishable by more than color — use icons,
   text labels, patterns, or weight changes.

4. **Handle the unhappy path.** Loading states, error states, empty states,
   and boundary conditions are not optional. An interface that looks perfect
   with ideal data and breaks with real data is not done.

5. **Build from the smallest viewport up.** Start narrow and expand — it's
   easier to add space than to remove it, and it forces deliberate decisions
   about what appears at each size.
