# Security Depth

Run this pass when a change touches a trust boundary — authentication,
authorization, input handling, secrets or sensitive data, dependencies, or
security-relevant configuration — and before any production release.

Think adversarially: for every input point, "what happens if I send
something unexpected?"; for every access check, "what happens if I skip
this?"; for every data flow, "where could this leak?". Cover all six areas:

- **Injection:** queries parameterized, template output escaped, no
  unsanitized user input in shell commands, file paths, fetched URLs, or
  deserialization.
- **Authentication and authorization:** checks on every protected endpoint,
  enforced server-side (not UI-level hiding), tokens fully validated
  (signature, expiration, audience, issuer), secure session flags, no
  privilege-escalation paths, least privilege.
- **Secrets and sensitive-data handling:** no hardcoded credentials in
  source, configuration, fixtures, or comments; secrets loaded from
  environment or secret management; logs and errors sanitized of PII.
- **Dependency risk:** known CVEs in new or updated dependencies (consult
  vulnerability databases), maintenance status, lock files committed,
  dependency-confusion exposure.
- **Configuration:** CORS not wildcard, CSP and security headers present,
  TLS enforced, file-upload restrictions, no default credentials, CI secrets
  scoped and not leaked into logs.
- **Data exposure:** API responses filtered of sensitive fields, error
  messages free of internals (stack traces, queries, file paths), encryption
  at rest and in transit, debug endpoints disabled in production.

## Rules for this pass

- Every security finding includes an attack scenario — how it could actually
  be exploited — not just "this is bad".
- Severity reflects exploitability: access required, complexity of
  exploitation, and impact. Exploitable now or trivially is **Critical**;
  exploitable with effort, or a missing required control, is **Important**;
  defense-in-depth hardening is a **Suggestion**. Hardcoded secrets are
  always Critical.
- Report what was checked in each of the six areas, not just what was not
  found. A pass that cannot say what it checked has not run.

**The checkbox audit** is the failure mode: marking each area "OK" without
reading the code paths, tracing the data flows, and thinking like an
attacker.
