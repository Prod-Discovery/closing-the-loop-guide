---
name: v-challenge
description: Use whenever work needs a second look before it moves on — 'review this', 'code review', 'security review', 'does this look right?', 'what could go wrong?', 'pre-mortem', a PR or local diff before merge, a spec, plan, or decision to stress-test, or audit readiness. Runs a risk-first review from a fresh context with depth set by what the change touches; high risk gets parallel angles, an adversarial pass, and a human reviewer. Reports only; fixes go to v-build.
license: Apache-2.0
metadata:
  author: "Adversarial review contributed by Kent Karlsson (@vogonistic); audit readiness contributed by Ron Koldeweid (@ron1326312356)"
---

# Challenge

**What breaks this?**

## When to Use

- A diff, PR, or commit range before merge
- A spec, plan, or one-way-door decision before anyone builds on it
- A security, compliance, or release-risk assessment

Challenge reports; it never fixes. Fixes go back to **v-build**.

## Workflow

### 1. Review from a fresh context

The reviewer is never the session that wrote the work: use a subagent or a
new session, and hand it the change, its intent, its criteria, and steps
2–5 of this skill — not the authoring session's history. It returns the
report; this session runs steps 6–7. High risk: this session dispatches
each angle, the adversary, and the judge as separate fresh subagents, not
one reviewer. If the harness offers neither, run deliberately separate
passes and say so in the report.

### 2. Establish scope and intent

State exactly what is under review: staged changes, a branch diff, a PR, a
document. Read its intent — ticket, spec, acceptance criteria, PR body — before
judging; code that looks wrong in isolation may be right under constraints
the diff does not show.

### 3. Set depth from what the change touches

Judge risk from the content, never from the author's description of it.

| Risk | The change touches | Review |
|---|---|---|
| Low | Docs, copy, comments, logging, formatting, new tests | One pass |
| Normal | Business logic, state, error handling, integrations, runtime config | One pass, then a human reviewer |
| High | Auth, permissions, input handling, money, personal data, migrations, public API contracts, dependencies, security config | Parallel angles — correctness, security, domain — then an adversary tries to disprove each finding and a judge ranks what survives (`references/adversarial-review.md`). A human reviewer is required — a teammate where the project has required reviewers, otherwise the user |

### 4. Review risk first

Read in order of risk, not file order:

1. **Correctness** — does it do what the intent says: logic, unhandled
   states, boundaries (null, empty, encoding, conversions), error paths,
   concurrency.
2. **Security and data** — input validated, authorization enforced
   server-side, nothing sensitive logged or exposed. Trust boundaries and
   every production release get the full pass in `references/security.md`.
3. **Proof** — every acceptance criterion has a test or check, tests assert
   behavior, and no test was weakened.
4. **Docs** — a behavior change with no doc change is a finding.
5. **Simplicity** — consistent with the codebase, complexity proportional to
   the problem, and nothing added that could have been deleted instead.

Then cross-cutting: changed signatures match every caller, a pattern
changed in one place is changed everywhere, and nothing contradicts a
recorded decision (`.visma-skills/decisions/`).

For a spec, plan, or decision, run a pre-mortem — "six months on, this
failed; why?" — and check each answer against the document.

### 5. Report

First try to disprove each finding against the code; drop what does not
survive. Order the rest by severity; each names its location, what goes
wrong, and when. **Blocking** means Critical or Important; the adversarial
scoreboard maps Critical→Critical, Major and Moderate→Important,
Minor→Suggestion. Give a verdict: *ship* — nothing
blocking; *fix* — blocking findings with clear fixes; *block* — a finding
needs a redesign or a decision from the user. A sound
change can have zero findings — never invent one to look thorough — so
state what was checked, and silence is never mistaken for safety.

### 6. Close the process loop

When a finding repeats a kind already seen in this repo, propose the rule
that stops it recurring — an `AGENTS.md` line, a linter rule, a reference
file — as a follow-up.

### 7. Hand off

- **Your own change** — *fix*: invoke **v-build**, then challenge again;
  still blocking after a second round: stop and give the user both reports.
  *Block*: invoke **v-scope**. *Ship*: invoke **v-ship**.
- **A spec, plan, or decision** — return the findings to **v-scope**.
- **Someone else's change** — stop at the report. Post it on their PR only
  when the user says yes.

Called by a recipe or another skill's reference for one step: do that
step, return the result to the caller, and let it continue.

## References

| When | Read |
|---|---|
| Auth, input, secrets, dependencies, security config, data exposure — or any production release | `references/security.md` |
| High risk: the scored Finder → Adversary → Judge review | `references/adversarial-review.md` (contributed by Kent Karlsson) |
| Assurance audits (ISAE 3000, SOC 2, ISO 27001), security questionnaires and RFPs, or proving a change did not weaken a control | `references/audit-readiness.md` (contributed by Ron Koldeweid) |

## Make it yours

Before step 1, read the team's `.visma-skills/project.md` if it exists.
Precedence: the user's instruction for this task, then that file and
`AGENTS.md` (or `CLAUDE.md`), then your own
`.visma-skills/local/preferences.md` — which never relaxes an approval gate
— then this skill. The layout is in **v-ship** (`references/project-settings.md`). This skill reads: what
counts as high risk in your domain, required reviewers (`CODEOWNERS`), your
severity scale, review checklists (e.g. `CODEREVIEW.md`), the compliance
frameworks in scope, and any team reference files to load, each with its
condition.

## Output Contract

### Summary

One line: what was reviewed, the risk tier, and the verdict.

### Detail

```markdown
**Critical** — causes bugs, data loss, or a security incident if shipped
- `file:line` — what goes wrong, and when
**Important** — real risk, not certain failure
**Suggestions** — non-blocking
**Questions** — needs the author
```

### Verification

What was checked: angles run, files read, criteria traced to tests — and
what could not be assessed.

### Follow-ups

Proposed rules from the process loop, defects found outside the change, or
"None".

## Quality Bar

It fails when the author could not act on a finding without asking what
was meant, or when a finding would not survive the author's first reply.

## Anti-Patterns

**The rubber stamp.** Approving because the author is trusted or the diff is
small. Small changes on critical paths cause the worst incidents.

**The style review.** Twenty naming comments and a missed null dereference.

## Critical Rules

1. **Review the change, not the codebase.** Pre-existing defects go to
   follow-ups unless they interact with the change.
