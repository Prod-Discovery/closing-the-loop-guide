---
name: handover-project-stories
description: "Mechanically project the complete S-n story map and C-n chores from a context-first Delivery Context — a ticket description or a Confluence sub-page — into Linear, Jira, or Azure DevOps, after a dry-run confirmation, then reconcile them idempotently by stable ids and context hash. Use only when the Delivery Context carries a `### Story map` (header `Backlog shape: epic`) — the feature was shaped epic by handover-shape-feature — and the map is decision-ready."
---

# Project Context-First Stories

Create the tracker tree already designed in a context-first `## Delivery Context`. This skill is a
projector, not a planner: it validates and copies the `S-n`, `C-n`, `D-n`, and `AC-n` relationships
without changing the feature's meaning.

It is intentionally separate from governed `create-backlog-from-brief`. Context-first has no
Engineering Brief version or PM/Dev gate, while governed projection must preserve both.

## Preconditions

All must hold:

1. The source is explicitly marked `context-first-handover` — a label on a tracker ticket, or the
   requirements page's marker block on the Confluence surface.
2. The feature is epic-shaped: the Delivery Context carries a `### Story map` (header line
   `> **Backlog shape:** epic`; the legacy `Backlog mode:` label reads the same). Read it from the
   artifact, never from config; a Delivery Context without a Story map was shaped single-ticket —
   stop, there is nothing to project.
3. The source contains one complete `## Delivery Context` with a base commit and context hash.
4. The story map passes the mechanical checks below.
5. No unresolved decision changes story boundaries, dependencies, or acceptance behavior.

If the context is missing or needs substantive reshaping, invoke `handover-shape-feature` and stop
this run before tracker writes. Do not repair product intent inside the projector.

## Projection invariants

- Every delivery `D-n` belongs to exactly one `S-n`.
- Every behavioral `AC-n` belongs to exactly one `S-n`.
- Every story has a demonstrable vertical outcome and at least one `AC-n`.
- Every dependency names an existing `S-n` or `C-n`; cycles stop the run.
- Every `C-n` is independently completable prerequisite work and names the stories it blocks.
- Story bodies are self-contained slices of the shared context, not pointers that say “see parent.”
- Stable ids and the context hash—not titles—identify generated items.

## Workflow

### 1. Load and validate

Read the source in full. Parse its change map, acceptance examples, story map, chores, decisions,
metadata, and evidence index.

The source is the ticket description on the tracker surface. On the **Confluence** surface it is the
`<Feature> — Delivery Context` sub-page — accept the sub-page directly, or the requirements page and
walk to its child, or the delivery issue and follow its marker block. Read pages as **`html`**; a
`markdown` read flattens panels and task lists.

Run the projection invariants in both directions. Also verify that every story's named `D-n` and
`AC-n` exist, no item has two owners, and all cited dependencies resolve. **Sweep the acceptance set
for contradictions across stories** — two scenarios asserting different outcomes for the same
behavior, conflicting defaults, permissions, states, or message texts: a conflict stops the run
exactly like a missing owner, because contradictory criteria across an epic's tickets are worse
than missing ones. Report all failures together and write nothing.

When the context's `Prototype` header pins a source commit, compare it with that source's current
head. Newer commits are **prototype drift**: not a blocker, but the dry run must say "the prototype
changed after this context was written — these tickets may be stale" and name the stories whose
slices cite the UI reference.

### 2. Inspect live generated children

Resolve tracker access using `~/.config/closing-the-loop/config.json`, then inspect all current
children of the source.

Use these markers:

- every generated item: `context-first-backlog-item`;
- delivery story: `context-first-story`;
- body stamp: a line **anywhere in the description** that starts
  `Part of <PARENT> · Slice <S-n> · Context <sha256:...>` or
  `Part of <PARENT> · Chore <C-n> · Context <sha256:...>`. Anything on that line after the hash —
  such as the human-facing label Step 5 writes — is presentation; ignore it when matching.

Match by parent plus stable id. Include stamped legacy items even when a label is missing or the
stamp is still the first line of the description (the pre-divider format), but verify their parent.
Two children claiming one id is an ambiguity: stop. A labeled child without a valid stamp is an
orphan: flag and leave it untouched.

### 3. Show the dry run and confirm

Before any tracker mutation, show:

- the parent, whether Jira type conversion is required, and — on the Confluence surface with
  `delivery: none` — that a delivery issue will be created first, with its exact title and body;
- every story/chore to create, refresh, reuse, or flag;
- `D-n` and `AC-n` coverage per story;
- dependency/blocking edges;
- any removed ids whose existing tickets will be flagged, never deleted.

Ask for confirmation. This confirms outward-facing tracker writes; it is not product or engineering
sign-off. On “not yet,” stop with no writes.

### 4. Prepare the parent

Children are always **tracker issues** — pages cannot carry status, assignee, or sprint, and child pages
are not delivery items.

- **Linear:** use the source issue directly as parent; its hierarchy is untyped.
- **Jira:** when the selected project requires an Epic parent, convert the source issue to Epic only
  after confirmation and before creating children. Preserve its description and labels. If it has
  incompatible existing children, the conversion is unavailable, or the project uses a different
  hierarchy, stop and present the tracker-supported alternative; do not create a wrapper Epic or
  copy the source description without explicit user direction.
- **Azure DevOps:** the parent is the source work item. Stories belong one backlog level below
  their parent, so when the source sits at the team's requirement level (Product Backlog Item /
  User Story), offer — as part of the dry run — to raise it to `Feature`
  (`wit_work_item_write` `update` on `System.WorkItemType`) and create children at the requirement
  level from `azureDevops.workItemType`. If the process rejects the type change, fall back to
  `Task` children under the unchanged parent and say so; never invent a wrapper item without
  explicit user direction. Mechanics in *Azure DevOps specifics* below.
  When raising, also prepend a reader header to the parent description, shown verbatim in the dry
  run: a 2–4 sentence plain-language summary of the feature distilled from its requirements, then
  the line *“Everything below is the full requirements plus the delivery context that Closing the
  Loop reads and refreshes — it must stay on this item.”* Prepend only; never trim or reorder what
  is already there. Many teams keep Feature descriptions empty by convention — this header is what
  tells them why this one is not.
- **Confluence surface:** the parent is the Jira **delivery issue** named in the requirements page's
  marker block, and the Epic rules above then apply to it unchanged.
  - When the marker names an issue, use it.
  - When the marker says `delivery: none` — the discovery run was published page-only — **offer to
    create the delivery issue now**, as part of the Step 3 dry run so the user approves it with
    everything else. Create it exactly as `discovery-create-tracker-issue` specifies: a pointer to the
    requirements page plus 2-3 sentences of framing and the success metric, **never a copy of the
    requirements**. Then update the page's marker block to name the new key.
  - On decline, stop with no writes and report that projection needs a delivery issue.

Resolve/create the two labels before child creation. If the tracker cannot label generated items,
stop rather than create children that cannot be safely reconciled.

#### Azure DevOps specifics

The same Microsoft Azure DevOps MCP server the tracker integration uses; organization and project
come from the `azureDevops.*` config keys. Known quirk: project search by name checks only the
first 20 projects — list pages instead.

- **Markers are tags, not labels.** Append `context-first-backlog-item` (plus
  `context-first-story` on stories) to `System.Tags` — a `; `-separated string. Append only;
  never remove or rename existing team tags (Compello-style setups trigger their own agents from
  ADO tags).
- **Inspect children (Step 2):** `wit_query` action `wiql` — e.g. `SELECT [System.Id] FROM
  WorkItems WHERE [System.Parent] = <parent id>` — then `wit_work_item` `get` with
  `System.Description` to read the stamp lines.
- **Create children (Step 5):** `wit_work_item_write` action `add_child` with `parentId`, one
  `workItemType` per call, and `items` carrying title + description with `format: "Markdown"` —
  child descriptions take Markdown natively here, unlike the parent item's HTML description. At
  most 50 children per call; create chores first, then stories, so a partial failure resumes
  cleanly from live stamped children.
- **Acceptance Criteria field:** Scrum and Agile processes carry a native
  `Microsoft.VSTS.Common.AcceptanceCriteria` field on requirement-level items. After creating each
  story, write its complete Gherkin there (`wit_work_item_write` `update`; the field takes HTML
  like the parent description — use `<pre>` for scenarios) and leave `# Acceptance behavior` out of
  the description. Name this destination in the Step 3 dry run. If the process rejects the field,
  fall back to the description section below the divider and say so in the report.
- **Dependencies:** `wit_work_item_link_write` action `link` with type `predecessor` /
  `successor` (System.LinkTypes.Dependency), exactly as the story map states — `related` only
  when the map says so.
- **Refresh (Step 6):** `wit_work_item_write` action `update` on the child's
  `System.Description`, `System.Tags`, and the Acceptance Criteria field where it is in use; the
  stamp line changes only to carry the new context hash.
- **Field format is sticky.** A description stored as Markdown (how `add_child` wrote it) renders
  HTML as raw tags; ADO switches a multiline field's format only when the new value and the format
  change arrive **in the same update** — a separate format-switch patch is rejected (HTTP 400).
  When a refresh changes the markup language, send the content and the format together.

### 5. Project chores and stories

Create chores first, then stories in map order.

**Team format guide.** When the config names a `ticketFormatGuide`, read it in full and follow it
for everything human-facing — title convention, work-item fields, required tags, and the
Description and Acceptance Criteria structure above the divider — per
[`${CLAUDE_PLUGIN_ROOT}/references/ticket-format-guide.md`](../../references/ticket-format-guide.md):
map the Delivery Context into the team's templates (never invent facts; keep hint text where the
context has nothing), merge the guide's required tags with the `context-first-*` markers, and name
the guide in the Step 3 dry run with one fully rendered child. The divider, stamp, and machine
sections below it are unchanged by any guide, and when the guide's AC structure is not Gherkin,
the verbatim scenarios stay in the machine block while the AC field follows the guide. With no
guide configured, offer once — in the dry run, not as a blocker — that a team with its own ticket
format can add the key. Then use the default format below.

Titles are presentation only, and each must say what the item is about on its own — a backlog
reader meets titles first, without the parent:

- chore: `[Chore] <prerequisite outcome>`;
- story: `[Story] <demonstrable outcome>`.

Write the outcome in the product's plain domain language, naming the thing it touches (the invoice,
the comment, the approval…). Never prefix the feature's working name — the parent link carries the
grouping, and an opaque name repeated on every child tells readers nothing.

Every child body puts people first and the machine payload below a divider:

1. **Summary** — 2–4 plain sentences in end-user language: what this slice gives the user and what
   done looks like. No stable ids, file paths, or tool names. Distill it from the slice's outcome
   and acceptance behavior; never paste the slice.
2. The divider line, verbatim:
   `— Below this line: context for Closing the Loop's delivery agent, not required reading —`
3. The stamp, first line under the divider. **Do not change its identity part.** Everything from
   `Part of` through the hash is identity — stamped legacy children are matched by it — and only
   the hash changes on refresh; the trailing label is presentation for people who find the line.
   On the Confluence surface add the backlink as its **own** line directly under the stamp, so
   identity parsing is untouched:

   ```
   Part of <PARENT> · Slice <S-n> · Context <hash> · Closing the Loop sync marker — don't edit
   Context page: <Delivery Context sub-page URL>
   ```

4. The technical sections.

Chore:

```markdown
**Summary:** <2–3 plain sentences: the prerequisite this clears and which stories it unblocks>

— Below this line: context for Closing the Loop's delivery agent, not required reading —

Part of <PARENT> · Chore <C-n> · Context <hash> · Closing the Loop sync marker — don't edit

# Outcome
<independently completable prerequisite>

# Why it is required
<constraint and evidence from the Delivery Context>

# Blocks
<named S-n stories>
```

Story:

```markdown
**Summary:** <2–4 plain sentences in end-user language: what the user gets and what done looks like>

**Not in this story:** <the neighboring slices' outcomes with their ids, e.g. "posting comments —
S-1 (#3) · external visibility — S-3 (#5)"; omit when the map has one story>

— Below this line: context for Closing the Loop's delivery agent, not required reading —

Part of <PARENT> · Slice <S-n> · Context <hash> · Closing the Loop sync marker — don't edit

# Outcome
<demonstrable vertical outcome>

# Change slice
<the complete D-n rows owned by this story: intent, current behavior, delta, reuse/preserve,
verification, and evidence>

# Acceptance behavior
<the complete Given/When/Then scenarios for this story's AC-n ids — on a tracker with a native
Acceptance Criteria field, replace this section with the single line
“Acceptance behavior (<AC-n ids>) lives in this item's Acceptance Criteria field.”>

# Dependencies
<named S-n/C-n dependencies, or None>
```

When the acceptance scenarios name personas (“Anna the approver…”), append one **Who is who** line
wherever the scenarios live — the AC field, or the section above: `Who is who: Anna = approver ·
Ben = bookkeeper`, so nobody reading ticket 19 of 25 has to guess. Use the same persona names for
the same roles across every child of one parent.

Create native dependency/blocking relations exactly as the story map states. Do not add estimates,
assignees, sprint placement, or implementation tasks unless explicitly requested.

### 6. Reconcile idempotently

On every run, compare the desired stable-id set with live generated children:

- same id and same context hash → reuse; when its title or body layout predates the current
  templates (feature-name title prefix, stamp still the first line, no summary, or a newly
  configured team format guide) refresh that presentation from the same context and report it —
  meaning, hash, state, and relations untouched. **Skip items in a terminal state** (Done, Closed,
  Removed): a finished ticket's record is history, not presentation — list them as "left as
  finished" instead. A team-guide format on live children counts as current even when the config no
  longer names the guide: never flip a team's format back to the default without the user asking;
- same id, older hash, terminal state → flag for the user with what changed; never rewrite a
  finished item silently;
- same id and older hash → refresh body, labels, and relations from the current context;
- new id → create;
- live generated id removed from the current map → flag for the user to close; never delete or
  silently repurpose it;
- partial prior run → continue from the live stamped children without duplicating.

Write tracker updates incrementally so a partial failure can be retried safely. The parent Delivery
Context remains the source of truth — the ticket description, or the sub-page on the Confluence surface;
do not add a second manifest and do not copy the context into the delivery issue.

### 7. Report delivery order

Return the parent, every story/chore key and URL, context hash, coverage matrix, dependency order,
reused/refreshed/created/flagged counts, and any failed write.

Hand the whole set forward to `handover-deliver-epic` with the parent key; it walks the children in
the reported order, one delivery run each. A single story can still be delivered on its own from its
key — the delivery workflow walks to the context-first parent, compares the child's context hash with
the parent, and loads only that story's `D-n` and `AC-n` slice plus cross-cutting constraints.

## Offline fallback

When no tracker is connected, write a non-committed RFC-4180 CSV at
`handover/[feature]-stories-import.csv` with `Title`, `Type`, `Description`, `Parent`, `Labels`, and
`Blocks`. Apply the same checks and dry-run confirmation first. Report this as an import artifact,
not as completed live projection.

## Output Contract

### Summary

State the parent, context hash, created/refreshed/reused/flagged counts, and whether coverage checks
passed.

### Detail

List the ticket tree, URLs, ownership matrix, dependency order, and offline CSV path if applicable.

### Verification

Confirm dry-run approval preceded all writes, every `D-n`/`AC-n` has one owner, live children were
matched by stable stamp rather than title, and no removed item was deleted.

## Quality Bar

Projection succeeds when each child is independently understandable and opens with a summary anyone
on the team can read without touching the machine half, the live tree exactly represents the parent
story map, and rerunning after either a context refresh or partial failure cannot create duplicates.

It fails when it invents slices, weakens Gherkin, creates technical-layer stories, copies the whole
parent into every child, relies on titles for identity, puts machine text where a reader lands
first, or treats tracker-write confirmation as a handover approval gate.

## Critical Rules

1. **Project, do not plan.** Substantive changes go back to `handover-shape-feature`.
2. **Confirm before outward writes.** The confirmation is operational, not sign-off.
3. **Stable ids plus context hash.** Titles are presentation, never identity.
4. **Self-contained slices.** Each story carries its own delta and behavior.
5. **Never silently delete.** Removed generated items are reported for human disposition.

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (`AskUserQuestion` in Claude Code and Cowork), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. Buttons mirror the listed options exactly — never add one that isn't an option.
- **Every path you just offered is a button.** If the message names ways forward in prose ("you could also iterate…", "or start a new run"), they all become buttons — never surface only a subset of them; with more than 4, use the lettered list so no option disappears.
- **Fall back to the list.** Without such a tool, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** Start each pause with one line placing the user in the loop — the phase this skill belongs to and the step within it, for example `Loop · Handover — shaping #6` or `Loop · Delivery — S-2 of 7`. Skip it when the skill runs standalone.
