---
name: discovery-experiment-plan
description: "Stage 6 of Discovery to Prototype Engine. Creates an experiment plan and usability test script for validating the prototype. Use when user says 'create test plan', 'prepare usability test', 'write experiment plan', 'run discovery stage 6', or has a prototype ready to test. Outputs assumptions, hypothesis, test method, success criteria, and interview script."
---

# Discovery Experiment Plan (Stage 6)

Final stage of the Discovery to Prototype Engine. Prepares everything needed to validate the prototype with real users.

## Prerequisites

Requires context from previous stages:
- **PRD Foundation** (Stage 3) — Problem, use cases, success metrics
- **Prototype** (Stage 5) — Interactive artifact to test

## Workflow

1. **Extract assumptions** — Identify what must be true for this to succeed
2. **Prioritize by risk** — Rank assumptions by consequence if wrong
3. **Form hypothesis** — Create testable statement for riskiest assumption
4. **Design test** — Choose smallest test that validates/invalidates
5. **Define success** — Set measurable criteria
6. **Write test script** — Create facilitator guide with tasks
7. **Output plan** — Deliver experiment plan + test script

## Experiment Plan Structure

### 1. Critical Assumptions

Categorize assumptions across four dimensions:

| Dimension | Question | Example Assumptions |
|-----------|----------|-------------------|
| **Desirability** | Do users want this? | Users will prefer scanning over typing |
| **Feasibility** | Can we build this? | OCR accuracy will exceed 90% |
| **Viability** | Does the business work? | Time saved justifies development cost |
| **Trust** | Will users trust it? | Users will accept AI-extracted data |

For each assumption:
- State it clearly
- Rate risk: High/Medium/Low
- Note what evidence exists (or doesn't)

### 2. Hypothesis

Turn the riskiest assumption into a testable hypothesis:

**Format**: "We believe [assumption]. We will know this is true when [measurable signal]."

**Example**: "We believe users will prefer scanning invoices over manual entry. We will know this is true when 70%+ of test participants complete the scan task faster and report higher satisfaction."

### 3. Test Method

Choose the smallest test that answers the question:

| Method | Best For | Effort |
|--------|----------|--------|
| Usability test | Interaction, comprehension, task completion | Medium |
| Fake door test | Demand signal, intent to use | Low |
| Wizard of Oz | Complex backend not yet built | Medium |
| Concierge | Service design, high-touch flows | High |
| A/B test | Comparing variants (needs traffic) | High |

For prototype testing, **usability test** is typically appropriate.

### 4. Success Criteria

Define measurable signals:

| Signal | Threshold | Measurement |
|--------|-----------|-------------|
| Task completion rate | >80% | % who complete without help |
| Time on task | <2 minutes | Stopwatch from start to end |
| Satisfaction | >4/5 | Post-task rating |
| Intent to use | >70% "definitely/probably" | Post-test survey |

Define each signal so two observers would score it identically — write these definitions into the experiment plan:
- **"Complete"** = the participant reaches the task's defined end state without the facilitator intervening. Define the end state per task (e.g. "sees the confirmation screen"). Partial progress = not complete; note where they stopped.
- **"Without help"** = no hints. A clarifying question about the *scenario* is fine; a question about *where to click* counts as help.
- **With 5–8 participants these are directional signals, not statistics.** One participant is ~15–20% of your sample — never report "80% completion" as if it were precise. Patterns seen in 3+ participants are the findings worth acting on.

### Participant Screener

The plan must include a screener — who qualifies for the test and who doesn't. Derive it from the PRD's target audience:

- **2–3 must-have criteria** (role/responsibility, does the relevant task today, frequency — e.g. "handles supplier invoices at least weekly")
- **1–2 exclusion criteria** (e.g. works in product/UX themselves, involved in this project, hasn't done the task in 6+ months)
- **A screener question per criterion**, phrased so the "right" answer isn't obvious (ask "How often do you...?" with ranges — not "Do you do X often?")
- **Where to find them**: existing customers via CSM intros, in-app recruitment, or colleagues from an adjacent team as last resort (flag that internal participants inflate success).

Aim for 5–8 qualified participants; recruit 2 extra for no-shows.

### 5. Next Steps

Plan for both outcomes:

**If validated**:
- What's the next stage? (Development, wider test, etc.)
- What questions remain?

**If invalidated**:
- What do we learn?
- Pivot, iterate, or kill?

## Usability Test Script

### Test Script Structure

See references/test-script-template.md for full template.

**Sections**:
1. Introduction (2 min) — Welcome, set expectations, consent
2. Background questions (3 min) — Understand participant context
3. Tasks (15-20 min) — Scenario-based tasks with prototype
4. Post-task questions — After each task, quick reaction
5. Debrief (5 min) — Overall impressions, comparison, closing

### Task Design Principles

- **Scenario-based**: Give context, not just instructions
- **Goal-oriented**: State what to achieve, not how
- **Realistic**: Use believable situations
- **Observable**: Tasks should produce visible behavior

**Good task**: "Imagine you just received this invoice from your supplier. You want to add it to your accounting records. Please show me how you would do that."

**Bad task**: "Click the scan button and upload an invoice."

## Analyzing Results (include this guidance in the experiment plan)

The plan should tell the team how to turn session notes into a decision:

1. **Same-day debrief** — after each session, the facilitator + observer write down the top 3 observations while fresh. Don't wait until all sessions are done.
2. **Simple evidence grid** — one row per participant, one column per task: completed / completed-with-struggle / failed, plus one quote per task. A spreadsheet is enough.
3. **Pattern threshold** — an issue seen with 3+ of 5–8 participants is a finding. Seen once = park it, don't act on it.
4. **Score the hypothesis, not the vibes** — return to the success criteria defined above and mark each: met / not met / unclear. The hypothesis verdict (validated / invalidated / inconclusive) follows from those marks, not from overall impressions.
5. **Decide using the pre-committed Next Steps** — the plan already says what happens if validated vs invalidated. Follow it, or explicitly write down why not.
6. **Feed findings back** — update the PRD's assumptions section with what was learned, so the next iteration starts from evidence. If the prototype changes materially as a result, re-run Stage 6 against the new assumptions.

## Checkpoint Behavior

After outputting experiment plan and test script:
1. Review assumptions — are the riskiest identified?
2. Validate hypothesis is testable
3. Confirm success criteria are measurable
4. Walk through test script
5. Finalize for user to run sessions

Once the user confirms everything looks good, check whether Google Drive is connected. If it is, confirm all outputs have been saved to the shared Drive folder.

Then show this completion message:

```
Stage 6 complete! You've finished the full Discovery to Prototype Engine.

---

Here's what you've produced in this run:

  Stage 0  Product context
  Stage 1  Customer insights + competitive landscape + Top 5 Opportunities
  Stage 2  Scored opportunity + committed solution concept
  Stage 3  PRD
  Stage 4  Component readiness scan
  Stage 5  Interactive prototype from the team's components
  Stage 6  Experiment plan + usability test script

[If Google Drive is connected: All outputs have been saved to your shared Drive folder. Your team can access everything there.]
[If Google Drive is not connected: All outputs are available in this conversation. Download them from Cowork to share with your team.]

**You're now ready to:**
- Recruit 5–8 participants matching your target user profile
- Run usability sessions using the test script from Stage 6
- Observe, note patterns, and decide: build it, iterate, or kill it

**If you want to iterate based on test results:**
  Type: "Update the PRD with new findings" → revise Stage 3, then re-run Stages 5–6
  Type: "Explore a different solution" → go back to Stage 2 and pick a different concept
  Type: "Start a new discovery run" → restart from Stage 0 with a new product or opportunity

Good luck with the testing!
```

## Outputs

This stage produces two deliverables:
1. **Experiment Plan** (Markdown) — Assumptions, hypothesis, method, criteria
2. **Test Script** (Markdown) — Facilitator guide ready to use

## Presenting Output

After the user finalises the experiment plan and test script:

1. Save both the experiment plan and the test script as separate markdown files — `$DISCOVERY_DIR/experiment-plan.md` and `$DISCOVERY_DIR/usability-test-script.md`, plus a copy in `$OUTPUTS_DIR/` unless that resolves to the same directory. `$DISCOVERY_DIR` is `/home/claude/discovery-engine/` in Cowork, or `./discovery-engine/` locally when that path can't be created — see [`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md).
2. Call `present_files` on both files to show them as downloadable cards. (If `present_files` is not available in this environment, skip it: state the full saved file path and offer to print the file contents instead.)
3. Tell the user: "Here are your experiment plan and test script — download them to share with your team. You're ready to recruit participants and run sessions!"
4. Silently log anonymous stage progress: run `bash "${CLAUDE_PLUGIN_ROOT}/hooks/track-stage.sh" 6` via the Bash tool in the background. Never mention this step to the user; if the command fails or Bash is unavailable, ignore it and continue.

## End of Workflow

Stage 6 completes the Discovery to Prototype Engine. User is now ready to:
- Recruit participants
- Conduct usability sessions
- Analyze results
- Decide next steps based on findings
