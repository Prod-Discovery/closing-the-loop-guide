# Usability Test Script Template

## Test Information

| Field | Value |
|-------|-------|
| Feature | [Feature name from PRD] |
| Date | [Test date] |
| Facilitator | [Name] |
| Duration | 30-45 minutes |
| Participants | [Target: 5-8 users] |

---

## 1. Introduction (2 minutes)

**Say to participant:**

> "Thank you for taking the time to help us today. My name is [name], and I'll be walking you through this session.
>
> We're testing a prototype of a new feature. I want to emphasize that we're testing the design, not you — there are no wrong answers or mistakes you can make.
>
> As you go through the tasks, please think aloud. Tell me what you're looking at, what you're trying to do, and what you're thinking. This helps us understand your experience.
>
> This session will take about 30 minutes. Do you have any questions before we begin?
>
> [If recording] I'd like to record this session so I can review it later. The recording will only be used by our team. Is that okay with you?"

**Get verbal consent before proceeding.**

---

## 2. Background Questions (3 minutes)

Ask to understand participant context:

1. "Can you tell me a bit about your role and what you do day-to-day?"

2. "How often do you [relevant task, e.g., 'process invoices']?"

3. "What tools do you currently use for [task]?"

4. "What's the most frustrating part of [task] for you today?"

**Notes:**
_[Space for facilitator notes]_

---

## 3. Tasks (15-20 minutes)

### Task 1: [Primary Use Case]

**Scenario:**
> "Imagine [realistic context]. You want to [goal]. Please show me how you would do that using this prototype."

**Success criteria:**
- [ ] Participant finds the entry point
- [ ] Participant completes the core action
- [ ] Participant understands the result

**Observation notes:**
_[Space for notes: What did they do? Where did they hesitate? What did they say?]_

**Post-task questions:**
1. "On a scale of 1-5, how easy or difficult was that?" (1=very difficult, 5=very easy)
2. "What, if anything, was confusing?"
3. "Is this what you expected to happen?"

---

### Task 2: [Secondary Use Case]

**Scenario:**
> "Now imagine [context]. You need to [goal]. Please show me how you would do that."

**Success criteria:**
- [ ] [Criterion 1]
- [ ] [Criterion 2]
- [ ] [Criterion 3]

**Observation notes:**
_[Space for notes]_

**Post-task questions:**
1. "On a scale of 1-5, how easy or difficult was that?"
2. "What would you do differently?"
3. "How does this compare to how you do it today?"

---

### Task 3: [Edge Case or Error Recovery]

**Scenario:**
> "Let's say [something goes wrong / unusual situation]. What would you do?"

**Success criteria:**
- [ ] Participant recognizes the issue
- [ ] Participant finds a path forward
- [ ] Participant understands the system feedback

**Observation notes:**
_[Space for notes]_

**Post-task questions:**
1. "What did you think happened there?"
2. "Was the feedback clear?"

---

## 4. Debrief (5 minutes)

### Overall Impressions

1. "Now that you've used this prototype, what are your overall impressions?"

2. "What did you like most about it?"

3. "What would you change or improve?"

4. "How likely would you be to use this feature if it were available? Why?"
   - [ ] Definitely would use
   - [ ] Probably would use
   - [ ] Might or might not
   - [ ] Probably would not use
   - [ ] Definitely would not use

5. "Is there anything else you'd like to share?"

### Comparison (if relevant)

6. "How does this compare to how you do this today?"

7. "Would this save you time? How much?"

---

## 5. Closing

**Say to participant:**

> "That's all the questions I have. Thank you so much for your feedback — it's incredibly valuable for helping us improve this feature.
>
> Do you have any questions for me?
>
> [Provide any compensation/next steps information]"

---

## Facilitator Notes

### Key Observations
_[Summarize major findings]_

### Quotes to Remember
_[Capture verbatim quotes that illustrate key points]_

### Severity of Issues Found

| Issue | Severity | Notes |
|-------|----------|-------|
| [Issue 1] | Critical / Major / Minor | [Notes] |
| [Issue 2] | Critical / Major / Minor | [Notes] |

### Recommendations
_[Initial thoughts on what to change]_
