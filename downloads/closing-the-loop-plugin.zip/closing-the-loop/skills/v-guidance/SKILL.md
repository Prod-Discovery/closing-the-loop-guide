---
name: v-guidance
description: "Grounded, actionable guidance from Visma's official 'AI in Engineering' playbook: the agentic ladder, real Visma use cases, AI coding tools and frameworks, how to get started, impact KPIs, workshops and the AI Engineering Accelerator, and responsible-AI practices. Use when someone asks how to adopt or scale AI in engineering at Visma, where to start, which AI tools to use, how to measure AI impact, which workshop to join, or what the AI risks are."
trigger: [ai in engineering, how to get started with ai, agentic ladder, which ai coding tools, measure ai impact, ai engineering accelerator, visma ai use cases, responsible ai risks, agentic delivery]
license: Apache-2.0
output_contract_schema: custom
---

# AI in Engineering Guidance

## Objective

Turn Visma's official *AI in Engineering* playbook into on-demand, grounded
guidance — tips, suggestions, real examples, links, and contacts — for anyone
adopting or scaling AI in software engineering. The detailed content lives in
`references/`; this file routes a question to the right file and sets the rules
for answering well.

This is an **informational** skill. It advises and points; it does not produce a
report or change code. When the user actually wants to *do* the work (plan,
implement, review, ship), hand off to the matching stage skill — see "Handing
off" below.

## When to Use

- Someone asks how to **get started** with AI in engineering, or where their
  team should begin.
- Someone wants to know **which tool or framework** to use, or what the
  **agentic ladder** / agentic delivery means.
- Someone asks **how to measure** AI impact, or what KPIs to track.
- Someone wants **real Visma examples** ("has anyone here actually done this?").
- Someone asks about **workshops, the AI Engineering Accelerator**, or who to
  talk to.
- Someone raises **AI security/responsible-AI** questions for engineering.
- Someone wants the **frontier view** — how roles and teams are expected to
  evolve.

Do **not** use this skill to execute engineering work, to invent metrics or
links not in the playbook, or as a source for non-Visma AI strategy claims.

## Workflow

### 1. Identify the topic
Map the question to one or more entries in the **Reference Map** below. Most
questions touch one or two files; broad "how do we adopt AI?" questions usually
combine `getting-started.md` + `agentic-ladder.md` + `workshops.md`.

### 2. Read before answering
Open the relevant `references/` file(s) and answer from them — not from memory.
The playbook has specific numbers, names, and links that must be quoted
accurately. `references/links.md` is the **only** source for URLs.

### 3. Meet the user where they are
Tailor the answer to their situation — their stack, their current ladder rung,
their bottleneck. Lead with the foundations question if they're early (can they
ship small, prove quality automatically, and run isolated test environments?).

### 4. Give tips, not a dump
Surface 2–4 concrete, prioritized suggestions with the *why*. Prefer a relevant
use case to emulate and a single clear next step over an exhaustive recap. Keep
it skimmable.

### 5. Cite resources, links, and people
Name the specific workshop, use case, KPI, or contact, and include the exact
link from `references/links.md`. Flag Visma-internal links as login-required.
Never fabricate a URL, metric, attribution, or quote — if it isn't in the
playbook, say so.

### 6. Recommend a next step
Close with one actionable move: run the Accelerator self-assessment, join a
specific workshop, emulate a named use case, contact a named tech lead, or — if
they're ready to build — hand off to a doing-skill.

### Handing off
When the user shifts from "how should we approach this?" to "let's do it," point
them (in plain prose) to the right Visma stage/orchestrator skill — e.g.
`v-plan-work` to scope work, `v-implement-code` to build, `v-review-changes` or
`v-scored-code-review` to review, `v-setup-agent-context` to
make a repo agent-ready, `v-develop-feature` for end-to-end. This skill is the
front door; those skills do the work.

## Reference Map

The bundled `references/` files vendor the official Visma *AI in Engineering*
playbook. Playbook snapshot: 2026-06 (re-vendor and update this stamp when
the playbook changes).

| Topic / question | Read this file |
|---|---|
| The 4 rungs (Assistance → Orchestration), orchestration spectrum, the AI-Native loop, the amplifier principle | `references/agentic-ladder.md` |
| Real Visma examples with metrics, people, and resource links | `references/use-cases.md` |
| Foundations, the Plan → Do → Check loop, applied guidance per SDLC stage, a concrete starting path | `references/getting-started.md` |
| AI coding tools and multi-agent orchestration frameworks, how to choose | `references/tools.md` |
| KPIs, adoption signals, the 6-step AI Engineering Strategy | `references/measuring-impact.md` |
| The Accelerator, Masterclass/Modernization/Testing workshops, contacts | `references/workshops.md` |
| AI risks, mitigations, OWASP / EU AI Act / VSP playbooks | `references/responsible-ai.md` |
| The shifts ahead, team reinvention, the engineer's evolving role | `references/future-of-engineering.md` |
| Every URL the playbook references (single source of truth) | `references/links.md` |

## Output Contract

The deliverable is a **conversational answer**, not a file or report. A good
answer:

- Directly answers the question, grounded in the cited reference file(s).
- Includes 2–4 prioritized, actionable tips or suggestions with the reasoning.
- Names the specific Visma resources that apply — use case, workshop, KPI,
  contact — each with the exact link from `references/links.md`, and marks
  Visma-internal links as login-required.
- Ends with one concrete next step (and a hand-off to a doing-skill when the
  user is ready to execute).
- Makes no claim, metric, attribution, quote, or link that is not in the
  playbook; gaps are stated as gaps.

## Quality Bar

A response meets the bar when:

- Every figure, name, quote, and link traces to a `references/` file (and URLs
  to `references/links.md`); nothing is invented or rounded.
- The answer is tailored to the user's situation, not a generic recap.
- It is concise and prioritized — tips over transcript.
- Visma-internal vs. public links are distinguished.
- It closes with an actionable next step.

It fails when the answer dumps a whole reference verbatim, invents URLs or
numbers, presents the playbook's Visma-specific data as universal fact, or gives
process advice with no concrete Visma resource attached.

## Anti-Patterns

**Dumping the whole reference.** Loading a file and pasting it back is not
guidance. Synthesize 2–4 tailored suggestions and link the rest.

## Critical Rules

1. **Read the reference file before answering** — never answer playbook
   questions from memory.
2. **`references/links.md` is the only source of URLs** — never invent, guess,
   or "reconstruct" a link. See that file's "Notes on link fidelity" for the
   cases where the source deliberately has no link (e.g. no public BMAD repo)
   or no titles — cite only what exists.
3. **Quote metrics, names, and quotes exactly** as the playbook reports them; do
   not round, merge, or embellish.
4. **Mark Visma-internal links as login-required** so external readers aren't
   misled.
5. **Attribute Visma's reported data as Visma's**, not as universal truth.
6. **Stay informational** — hand execution off to the appropriate doing-skill
   rather than performing it here.
