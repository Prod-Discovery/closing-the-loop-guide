# The agentic ladder

How AI moves from *suggesting* code to *orchestrating* whole workstreams. Use
this to locate where a team is today and name the next rung — each step raises
the autonomy of AI, the level of abstraction the engineer works at, and the
return on investment.

## The four rungs

| Rung | What AI does | What the engineer does | Productivity |
|---|---|---|---|
| **1. Assistance** | Real-time code suggestions | Stays in control, writes code while accepting or editing suggestions | **10–15%** — by speeding up coding |
| **2. Supervision** | Solves more complex tasks across multiple files | Directs, supervises, approves, and coaches | **15–50%** |
| **3. Delegation** | Acts like an autonomous engineer; designs and runs single-agent workflows | Designs and delegates work to single-agent workflows | **2–10×** |
| **4. Orchestration** | Acts like an autonomous *team* of engineers | Orchestrates multiple parallel agentic workflows simultaneously | **5–20×** |

The progression: *suggestions → delegation → orchestration*. Climbing the
ladder means increasing the trust horizon and the return on investment, while
the human moves to a higher level of abstraction.

## Orchestration is a spectrum

Once a team reaches rung 4, orchestration itself comes in three levels:

| Level | Coordination | Task length | Engineer's role | Productivity | Example |
|---|---|---|---|---|---|
| **AI-Automated Workflows** | Independent, pipeline-based | Seconds–minutes (event-driven) | Designs triggers and rules | ~5× throughput on repetitive operational tasks | GitHub Actions + Copilot |
| **Parallel Agent Teams** | Dynamic, planning-agent led | Hours–days (task-driven) | Sets architecture and constraints | 5–15× on feature delivery | Claude Code Agent Teams |
| **Autonomous Orchestration** | Hierarchical, self-organizing | Days–weeks (outcome-driven) | Defines outcomes and acceptance criteria | 10–30× on full products | Gas Town, Symphony |

Key evolution: scope grows from **single steps/checks → features/multi-file
tasks → entire projects or workstreams**, enabled by moving from a single-agent
workflow to coordinated multi-agent workflows running in parallel. Task
horizons expand from hours to weeks.

## How the best teams operate (the "Build" practices)

- **Context engineering** — structure codebase knowledge, architecture
  decisions, constraints, data access, and validation loops so agents operate
  reliably at scale. This unlocks harder tasks (modernize or rewrite products).
- **AI-native workflows** — define plan → do → check loops, constraints, and
  success criteria, then delegate to agents that run the workflows
  autonomously. (See `getting-started.md` for the loop in detail.)
- **Parallel orchestration** — run multiple agentic workflows simultaneously
  instead of single-threaded, single-context execution.
- **Continuous quality** — agents write and maintain tests; testing is
  embedded in every change, not a separate phase.

## The AI-Native product loop

Engineering sits inside a wider continuous loop. AI amplifies every phase:

1. **Sense** — continuous discovery; AI gathers and analyzes real-time customer
   feedback, usage data, and market trends.
2. **Shape** — PMs and designers turn insights into solution concepts; AI
   co-pilots generate design alternatives and de-risk through rapid prototyping.
3. **Build** — engineers orchestrate analysis, implementation, testing, review,
   and release into agentic workflows; humans own intent, constraints, and
   outcomes.
4. **Optimize** — AI analyzes live product data and behavior to refine
   performance and surface new opportunities, feeding back into Sense.

The ambition stated in the playbook is roughly **10× across the loop** — eight
distinct targets AI-enhanced workflows aim for:

- 10× shorter cycle time to identify opportunities
- 10× faster idea-to-prototype lead time
- 10× experiments
- 10× faster prototype-to-production lead time
- 10× work done by copilots and agents
- 10× engineering performance
- 10× actionable insights per product release
- 10× faster iteration cycles based on usage insights

Two enablers underpin it: **human-led loops** (product trios decide while AI
empowers, accelerates, and automates) and **value-driven, small
cross-functional teams** that solve the right problems and deliver outcomes
fast.

## The amplifier principle

> AI mainly amplifies what's already there — strong teams get stronger;
> struggling teams' problems get louder.

- **Strong foundations** (fast feedback, clear ownership, automated quality) →
  AI is a **flywheel**: faster delivery, better results, more learning, more
  trust → bolder bets.
- **Weak foundations** (slow feedback, unclear ownership, fragile quality) → AI
  is a **megaphone**: more churn, more noise, more pressure.

Treat engineering success as a **system** — optimize quality, speed, and
developer experience together, and tie them to business outcomes. The flywheel
the playbook draws: agentic delivery (speed, quality) → trust (proven outcomes,
bolder bets) → business outcomes (revenue, learnings) → reinvested in stronger
foundations. AI accelerates the whole loop only when it's anchored to outcomes,
not output.

This is why `getting-started.md` leads with foundations, not tools.

## Links

See `links.md` → "Multi-agent orchestration frameworks" for the example tools
above, and `tools.md` for what each one is.
