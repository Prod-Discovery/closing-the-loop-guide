# Accelerator, workshops & contacts

How Visma teams get hands-on help. Start with the self-service Accelerator to
find your gaps, then join the workshop that matches your leverage point. All
links are in `links.md`; these are Visma-internal.

## AI Engineering Accelerator

> Stop guessing where your team stands with AI. Start knowing and get a clear
> path forward.

Most teams know they should do more with AI — but not what, or in what order.
The Accelerator assesses your agentic and engineering practices, then delivers a
prioritized action plan to close the gaps that matter most. Three steps:

1. **Understand current maturity** — an instant evaluation across both
   foundational and agentic dimensions (15 min, self-service). Find which
   capabilities hold the team back and which are already strong.
2. **Unlock your next level** — a prioritized action plan and improvement
   report, ready to share with leadership and re-run as the team levels up.
   (Close the main gaps.)
3. **Accelerate with us** — the AI Engineering & Technology team selects the
   most impactful use cases and provides continued guidance: workshops,
   coaching, and resources throughout the journey.

Start it at the Engineering Accelerator link in `links.md`.

## Masterclass workshops

- **GitHub Copilot Masterclass** — a 2-day hands-on workshop where Visma teams
  learn AI working on their *own* codebase.
- **Eficode workshop** — a 3-hour workshop on advanced GitHub Copilot concepts,
  funded by GitHub/Microsoft.

Reported results: **2,100+** engineers upskilled; **2×+** increase in usage of
advanced features; **77%** report an increase in efficiency one month after the
workshop. Participant quotes include "I felt like a rookie. Now, I'm amazed" and
"One of the most interesting days in my technological life."

## Modernization workshops

> Utilize AI fully in your modernization efforts — the ability to fix
> long-endured technical debt has never been possible to this degree.

The modernization workflow is applicable to everyday engineering and often
yields 2× or better. Recent results:

| Team | When | Use case | Impact |
|---|---|---|---|
| **Vesitieto** | Nov 2025 | C# .NET Framework 4.8 → .NET 8; Semantic-UI-React → Material UI | General speedup 2–4×; modernization tasks 20× |
| **SmartBill** | Oct 2025 | Legacy system → agentic AI workflows | General speedup 2–4×; modernization tasks 10–12× |
| **Visma Advantage** | Feb 2026 | AngularJS → Alpine.js | 90% completed during the workshop; general speedup 8×; modernization tasks 30× |

Technique throughout: context engineering and meta-prompting across hundreds of
files, the Plan-Do-Check agent workflow, and Playwright for testing/rendering
migrated components. Feedback: "Eye-opener for me was to use Copilot to verify
the code in such an efficient way. And using subagents was key!"

## AI in Testing workshop

> Use AI to generate, improve, and scale automated tests — broader coverage and
> faster feedback without the usual overhead.

One core idea: deploy agents that explore your service, spot missing test cases,
then generate reusable tests you plug straight into delivery. The workshop
covers getting started with a maintainable suite, expanding coverage by finding
and automating missing user flows, and refactoring/optimizing for speed and
reliability.

Reported results: **203** participants (40 in the queue); participants reporting
AI saving them 2+ hours/day rose **16% → 44%**; **100%** committed to using AI
(>25 teams, including 19% who had never used AI before). Participant quote:
"Incredibly valuable and practical — delivered real value."

## Who to talk to (AI Engineering & Technology team)

Reach out with questions and additional use cases:

| Person | Role |
|---|---|
| **Alin Iacob** | Head of AI Engineering and Technology |
| **Morten Hordes Bakken** | AI Tech Lead — leads the AI Engineering Accelerator |
| **Milli Orucevic** | AI Tech Lead — leads upskilling Testers (AI in Testing) |
| **Marcus Alanen** | AI Tech Lead — leads upskilling Developers (Masterclass) |
| **Kent Karlsson** | AI Tech Lead — leads the Modernization workshop |

## Matching a workshop to a need

- Coverage/regression bottleneck, manual QA → **AI in Testing** (see Taxy.io and
  Playwright MCP use cases).
- Legacy code, technical debt, framework migration → **Modernization workshop**
  (see SmartBill, Spiris, Vesitieto).
- General team upskilling on day-to-day AI coding → **Copilot Masterclass**.
- Don't know where to start → the **Accelerator** self-assessment first.
