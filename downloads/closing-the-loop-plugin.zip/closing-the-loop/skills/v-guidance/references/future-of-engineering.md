# Frontier vision & team reinvention

Where the playbook says engineering is heading, so guidance can frame today's
choices against tomorrow's direction. Modern AI workflows shift from *humans
doing the work* to *humans designing how work gets done*. Agents running
internal loops (plan, execute, validate) raise quality and stretch task horizons
from minutes to hours; orchestrated specialized agents push them from hours to
days/weeks.

## The shifts ahead

### Complex task delegation
- **Transformation:** Complex tasks are executed end-to-end by AI agents using
  advanced planning and incremental execution.
- **Capability:** AI continuously decomposes work, manages task dependencies,
  and re-plans in response to changing context and feedback.
- **Impact:** Dramatically shorter cycle times for complex, end-to-end changes;
  the time horizon of tasks AI handles moves from **minutes to hours**.

### AI orchestration
- **Transformation:** Engineers design the control plane for AI agents —
  defining context, handoffs, and feedback loops that coordinate agents across
  multi-step work.
- **Capability:** An orchestration layer routes work between specialized agents
  and advances execution dynamically.
- **Impact:** Engineering output scaled by orders of magnitude; the time horizon
  moves from **hours to days or weeks**.

### Scaling human oversight
- **Transformation:** As AI output grows, the bottleneck becomes human
  attention. Oversight shifts from "review everything" to "review what matters."
- **Capability:** Agentic QC as standard — agents review their own changes; and
  agents learn *when to ask for help* instead of guessing.
- **Impact:** Engineers stay in the loop, but human expertise is spent where it
  matters most.

A grounding trend the playbook cites: the time horizon of software tasks LLMs
complete 50% of the time has been climbing steeply across model generations —
the boundary between discovery and delivery is collapsing, and reimagined
workflows need to be fed by always-on discovery.

## Team reinvention

AI drives **role convergence** by empowering people to learn cross-disciplinary
skills. Engineers and PMs can prototype more easily; designers can hand work to
developers more cleanly, even build full-stack apps without deep coding skills.
AI supports rather than disrupts the **product trio** — used right, it's an
amplifier, not a replacement for collaboration. The envisioned future: small
cross-functional teams that solve the right problems and deliver outcomes fast.

- **Fewer, smaller teams.** Moving away from large "feature teams" of 10–15
  developers toward smaller, higher-leverage **orchestration pods**.
- **Fewer handoffs, more ownership** per person, and better collaboration with
  PMs and designers.
- **Reward outcome ownership, reliability, and system thinking** over speed or
  raw code output.

## The engineer's evolving role

> The engineer role shifts from building software to running a software
> factory — AI executes, humans design control.

- Success is no longer the perfect prompt, but the **quality of the system
  (harness)** surrounding the agents.
- Less time writing code; more time defining *what* to build and *why* —
  framing problems, choosing architectures, making trade-offs, ensuring the
  system solves the right problems correctly.
- **Specification, decomposition, and orchestration** become core skills.
- The **unit of work shifts from "tickets" to agent-runnable specs** with clear
  intent, constraints, acceptance criteria, and checkpoints — making it
  practical to run multiple value streams in parallel.
- An engineer's primary responsibility becomes **orchestration integrity**:
  strengthening the delivery system (verification loops — tests, builds,
  security checks, evals — reusable scaffolding, guardrails, and conventions
  that make agent output production-ready).

## Using this in guidance

- Frame a team's current rung on `agentic-ladder.md` against this direction:
  the destination is orchestration + scaled oversight, so prioritize the
  foundations and harness work that get them there.
- When someone worries AI will replace engineers, use the role-evolution framing
  above: the role moves up the abstraction stack (factory operator, system
  designer), it doesn't disappear.
