# Link directory

The authoritative URL list for the *AI in Engineering* playbook. Every other
reference file cites these; this file is the single source of truth for the
links so they never drift. Only surface a link that appears here — do not
invent or guess URLs.

> Many links point to **Visma-internal** resources (Visma Space, Visma Drive,
> the Engineering Accelerator). They require a Visma login and are intended for
> Visma engineers. The public links (tool vendors, OWASP, the EU AI Act) work
> for anyone.

## The playbook itself

- Visma Talk recording — https://drive.google.com/file/d/1EGFX4W81_qb79Tla-Z0M6aIX3OzrwDFc/view
- Visma Talk recording (alt) — https://drive.google.com/file/d/1aW6EAtpznjMQUxvdJZsmPav9fPi-uNPn/view

## AI coding tools (public)

- GitHub Copilot — https://github.com/features/copilot
- Claude Code — https://www.claude.com/product/claude-code
- Cursor — https://cursor.com
- CodeRabbit — https://www.coderabbit.ai
- Devin — https://devin.ai
- Junie (JetBrains) — https://www.jetbrains.com/junie/

## Multi-agent orchestration frameworks (public)

- Claude Code Agent Teams — https://code.claude.com/docs/en/agent-teams
- Gas Town — https://github.com/steveyegge/gastown
- Symphony — https://github.com/openai/symphony/tree/main
- Get Shit Done (GSD) — https://github.com/gsd-build/get-shit-done

## Accelerator and workshops (Visma-internal)

- AI Engineering Accelerator (self-service maturity assessment) — https://engineering-accelerator.visma.net/
- GitHub Copilot Masterclass — https://space.visma.com/pagesv2/1jed7r8fd3a04ldhg2/AIMasterclass/1jfvtkqaq06ik4ruhi
- Artificial Intelligence article (Masterclass channel) — https://space.visma.com/channels/266768609/ArtificialIntelligence/article/78687204
- Modernization workshop — https://space.visma.com/pagesv2/1jed7r8fd3a04ldhg2/ModernizationWorksho/1jgreb61n7kkpop1rq
- AI in Testing workshop — https://space.visma.com/pages/1h9q76b93ief5ghmos/AIInTesting/1j9hemv43sm3jp8q0j
- Accelerating Technical Modernizations with GenAI — https://space.visma.com/pages/1h9q76b93ief5ghmos/AcceleratingTechnicalModernizationsWithGenerativeai/1hvmi1njs4l8ii6mmh

## Responsible AI (public + Visma-internal)

- OWASP Top 10 for LLM Applications — https://owasp.org/www-project-top-10-for-large-language-model-applications/
- OWASP GenAI — Sensitive Information Disclosure (LLM02:2025) — https://genai.owasp.org/llmrisk/llm022025-sensitive-information-disclosure/
- EU AI Act — Article 50 (transparency obligations) — https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-50
- VSP: Offensive AI Playbook (Visma-internal) — https://docs.google.com/document/d/1FKpCOj8YFa09TEOOtyUpEmtoF5TsSeMWXehqAEqnfQo/edit
- VSP: Defensive AI Playbook (Visma-internal) — https://docs.google.com/document/d/1oGhf2oPj21S38X_waD_YjApmQqB-6UY9-sW3KF1TsrI/edit

## Use-case detail resources (Visma Drive)

Each use case in `use-cases.md` links to its own recording / write-up:

- Taxy.io (testing, 2x) — https://drive.google.com/file/d/1_wBvgkVAmZJSjWKLU1oUd-GL22spu6t6/view
- Taxy.io company site (not a playbook resource) — http://taxy.io
- Playwright MCP (Spiris) — https://drive.google.com/file/d/1R-zBterbAy8_izCgVIjHrx8RPr6uqaQe/view
- SmartBill (context engineering) — https://drive.google.com/file/d/1E0ArvcH0k8VtSWnJbfUorIAc8vukepbT/view
- Spiris monolith rewrite — https://drive.google.com/file/d/1kS70k4RJh4ycMh76rQmiwFJJCxCqPIsF/view
- Augment Code specs (Visma Amili) — https://drive.google.com/file/d/1V_eBC2kq6MZnf9mhyPmga4G0jfAzsl_E/view
- Devin (Rindegastos) — https://drive.google.com/file/d/1pW6A9wcyVoNauxTZVAX47BMlrbR-MwWM/view
- GiantLeap (delegation) — https://drive.google.com/file/d/18OOPMbNGf4ypZubBSnzIhxwaM2gGwE-5/view
- Continuous AI (Spiris) — https://drive.google.com/file/d/1eJKbyLFfdee7KrzFZF0jBcpDjaEklmg9/view
- Parallel orchestration (Visma PubliTech) — https://drive.google.com/file/d/1H2oTBNn0XAQw4G_N1ccEsbgZQMUphkSv/view
- Swarm coding (InFakt) — https://drive.google.com/file/d/1Z8oampienBoH8HXLliBwQ1zoxnh8Y41v/view
- Long-running-agent POCs (Visma Software BV) — https://drive.google.com/file/d/1oJ94aY4XWX8FMJFnozp0wo4c0OIUQtq0/view
- ecoai (e-conomic) — https://drive.google.com/file/d/1YTL3EmWxlSwAg1N7v07sETbKallbTHSz/view
- Teledec (BMAD) — https://drive.google.com/file/d/1PK1IcIsxknh5ZemN2LAgwazYEy3yruRy/view
- BOB (Visma Enterprise) — https://drive.google.com/file/d/1kf2jrkGU2cAQW2hh-U_nZWzjX-AOxLjQ/view

## Notes on link fidelity

- The **BMAD method** is named in the Teledec use case, but the playbook
  embeds only the Visma Drive write-up above — there is no public BMAD repo
  link in the source. Do not fabricate one.
- Slide 50 ("One playbook leads to another") carries hyperlinks to several
  further Visma presentations whose titles are not embedded in the source.
  Refer to them collectively as "related Visma playbooks" rather than naming
  or counting them.
