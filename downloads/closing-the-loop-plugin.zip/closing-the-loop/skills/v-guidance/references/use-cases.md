# Visma use cases

Real, attributed examples from Visma teams, grouped by where they sit on the
agentic ladder (`agentic-ladder.md`). Use these as proof points and as
templates to emulate — when someone asks "has anyone here actually done this?",
point them at the closest match and its resource link.

Every use case links to its detail recording/write-up in `links.md` →
"Use-case detail resources". Quote the metrics as the team reported them; don't
round or embellish.

---

## Assistance

### Taxy.io — 2× release frequency by transforming testing
- **Who:** Abdelrahman Abdelkawi, Director of Engineering, Taxy.io
- **Problem:** As Taxy.io Answers scaled, manual regression testing couldn't
  keep up; the team needed to ship faster without adding risk.
- **What they did:** Automated regression around the most critical journeys
  (question-to-answer flow, citation correctness). Proven practices (OKRs,
  reliable CI, stable test data) were the foundation; Cursor sped up test
  creation and refactoring, CodeRabbit improved review throughput.
- **Impact:** API + E2E flow coverage ~20% → ~80%; regression time hours/days →
  minutes; delivery frequency 2× releases per week.
- **Getting started:** Enroll in the AI in Testing workshop. Resource link in
  `links.md`.

---

## Delegation

### Spiris (Årsredovisning Online) — automating E2E testing with Playwright MCP
- **Who:** Adis Bacic, Software Developer, Årsredovisning Online (Spiris)
- **Problem:** Agentic code generation made delivery fast, but manual
  verification became the bottleneck; a Selenium suite couldn't keep pace.
- **What they did:** Adopted Playwright MCP. Testers write spec-driven
  natural-language prompts; the agent spins up a short-lived Chromium instance,
  navigates the DOM, validates requirements, self-heals on failure, retries,
  and generates a crash report (video + error + fix guidance) on failure. Setup
  took one day; refinement over a month.
- **Impact:** 92% faster E2E cycles (1 hour → 5 minutes); non-technical QAs and
  BAs now create and run complex API/UI tests independently; low token cost.
- **Getting started:** Article "Chrome DevTools MCP vs. Playwright MCP"; enroll
  in the AI in Testing workshop.

### SmartBill — context engineering for 10× faster legacy modernization
- **Who:** Cristian Badila, Software Engineer, SmartBill
- **Problem:** A breaking Windows update broke a critical legacy add-on —
  17k LOC, no docs, no tests, original developer gone. Pointed to ~1 month of
  risky manual work.
- **What they did:** Set up a structured workflow where Claude Code agents
  analyzed the legacy code, planned the migration, and generated most of the
  implementation. Work was broken into small, reviewable steps — review,
  adjust, commit after each — staying in control throughout. Built on learnings
  from the modernization workshop's context-engineering focus.
- **Impact:** ~7 days instead of ~1 month — 10–12× faster modernization.
- **Getting started:** Context engineering Visma Talk and slides.

### Spiris — 3.2× gains rewriting a 30-year-old monolith
- **Who:** Johan Yman, AI Innovation Engineer, Spiris
- **Problem:** Visma Administration — a flagship ERP generating 14 MEUR ARR —
  was a tangled web of C++ business logic, increasingly hard to maintain.
- **What they did:** A three-step AI workflow — **Analyze** (find core business
  rules in old C++), **Blueprint** (map rules to a new React architecture),
  **Generate** (write production-ready code from the plan).
- **Impact:** 95% of new code generated with AI; 65% reduction in effort
  (≈3.2× faster).
- **Getting started:** Enroll in the Modernization workshop.

### Visma Amili (Tech Ada) — specs for high-fidelity multi-agent output
- **Who:** Patrik Wiik, System Architect, Visma Amili AB, Tech Ada
- **Problem:** Standard prompting works for many tasks, but scaling distinct AI
  agents needs more structure.
- **What they did:** Augment Code writes all rules/specs for a multi-agent
  setup, connected to Jira to extract business requirements and technical docs.
  Per ticket: a planning agent researches and defines changes into the ticket
  MD file → implementation agent makes changes → test agent validates.
  Experienced humans stay in the loop to challenge and verify. Setup ~1 week.
- **Impact:** Within 6 weeks, delivery capacity +2.5×; delivery quality up
  across several dimensions; developer engagement higher than ever.
- **Getting started:** Augment's article on this workflow + the technical docs.

### Rindegastos — 9% → 60% delegated PRs with Devin (pNPS to 64)
- **Who:** Carlos Villarroel, CTPO, Rindegastos
- **Problem:** Scaling needed higher velocity while maintaining excellent
  service.
- **What they did:** 4 months of leadership/senior exploration of Devin, then a
  team-wide rollout. Key prep: ingesting PRDs, Devin ticket extraction via MCP
  and video analysis, automated front-end/multilingual updates, and pilot
  validation (recoded a legacy microservice in 3 days vs. an estimated 3 months,
  cutting latency up to 50%). Devin also processes videos of
  customer-support-flagged issues to propose solutions.
- **Impact:** AI-assisted PRs 9% → 60% in 3 months; pNPS to an all-time high of
  64; PRs Nov 299 → Feb 380 (EOM est.); Q1 roadmap cleared by mid-Q1 without
  added headcount.
- **Getting started:** PDAB session presentation (recording linked in source).

### GiantLeap — 5 developers producing the output of 16
- **Who:** Ove Andre Bendal, Developer, GiantLeap
- **Problem:** Wanted to move beyond AI-assisted coding to deeper delegation.
- **What they did:** A multi-agent development model on Claude Code —
  specialized agents for specification, planning, implementation, testing, and
  pre-review, with orchestration loops routing testing-agent findings back to
  the implementation agent automatically before anything reaches a human.
- **Impact:** Code production more than quadrupled; QA became "almost
  cost-free"; overall code quality improved.
- **Getting started:** Enroll in the Modernization workshop; learn about
  sub-agents for Claude Code, Cursor, VS Code.

### Spiris — first steps into Continuous AI (automated exception fixing)
- **Who:** Jimmy Stridh, Innovation Engineer, Spiris
- **Problem:** Manual analysis of crash dumps was tedious detective work.
- **What they did:** A detected crash file creates a GitHub Issue, triggering a
  GitHub Action where Claude Code analyzes the crash context, identifies the
  root cause (expressly instructed to avoid shallow fixes), and generates a PR
  for human approval. Setup took 1 day.
- **Impact:** Exception resolution from ~1 hour to a few minutes; in the first
  month all 8 crash fixes were accepted unchanged; eliminated stressful
  context-switching. Expanding to Polaris, Sentry, Aikido.
- **Getting started:** Jimmy's demo repo + further reading on Continuous AI.

---

## Orchestration

### Visma PubliTech — parallel agentic workflows cut delivery time in half
- **Who:** Pontus Nyberg, Software Developer, Visma PubliTech
- **Problem:** A single sequential agent hits a ceiling — diluted context, slow
  feedback, review work queued behind implementation.
- **What they did:** Orchestrated multiple Claude Code agents in VS Code, each
  specialized for a role (frontend, API, QA, security), running in parallel. A
  main agent coordinates sub-agents while a developer guides the work. AI wrote
  the agent prompts itself, creating project-specific specialists. Setup ~2
  hours.
- **Impact:** Delivery time cut in half; faster, higher-quality feedback across
  all four roles simultaneously; low barrier to entry.
- **Getting started:** "Run agent teams" + "Agent harness engineering" reading.

### InFakt — agentic swarm coding: a legacy mobile app rewritten 10× faster
- **Who:** Radosław Rochmalski, CTO, InFakt
- **Problem:** Rewriting a 10-year-old mobile app was estimated at 1 year for
  2 FTEs; none of the three engineers knew Swift.
- **What they did:** Used Claude Code with Claude Swarm, SuperClaude, and Claude
  Squad. First used AI to extract requirements from the existing app and
  generate architecture docs, conventions, and best practices. Then each
  engineer orchestrated a personal fleet of specialized agents (mobile lead,
  iOS developers, QA, architect) working in parallel.
- **Impact:** Near-production-ready replacement in two weeks — a 90% reduction
  in effort; code quality 8/10, up from the previous project's 6.5/10.
- **Resource:** use-case write-up in `links.md`.

### Visma Software BV — near-production POCs in minutes with long-running agents
- **Who:** Ron Koldeweid, Innovation Manager, Visma Software BV
- **Problem:** Manual-assisted POC generation (e.g. Loveable) capped quality.
- **What they did:** Requirements defined in a central `CLAUDE.md` as the source
  of truth; a continuous write-back loop validates against requirements every
  iteration to prevent hallucinations. Custom skills (`/go`, `/feature`, `/fix`)
  encode team conventions; MCP servers add external tooling (security scanning,
  repo analysis). A quality loop runs code → tests → read errors → fix → repeat
  until green, then commits. Configured in a few hours.
- **Impact:** Autonomous fix loops with no human intervention; parallel
  specialized agents (security, performance, architecture) on every change;
  presented to 109 Visma engineers with immediate buy-in.
- **Getting started:** Video walkthrough (from minute 8) + Ron's guide on
  multi-agents with Claude.

### e-conomic — ecoai: 8× ROI empowering employees with agents
- **Who:** Jacob Nielsen, Director of Engineering, e-conomic
- **What they did:** ecoai is an agent platform that orchestrates multiple
  agents as a "unified brain," translating natural language into complex
  queries across the stack. Use cases: correlating bug reports, screenshots,
  videos, and observability data to find root causes; continuous discovery
  combining qualitative (Airtable, Dovetail) and quantitative (Snowplow) data;
  a self-improvement loop that implements user-requested features.
- **Impact:** Time to query complex observability/behavior data from 30+ minutes
  to under 60 seconds; hundreds of hours saved monthly; 191 active users.
- **Closing the trust gap:** high adoption (191 active users) is treated as
  evidence that teams trust the data enough to move from "minor tweaks" to
  informed, high-impact automation — adoption *depth*, not license count, is the
  signal (reinforces "avg AI spend per engineer" in `measuring-impact.md`).
- **Resource:** use-case write-up in `links.md`.

### Teledec — from weeks to overnight with the BMAD method
- **Who:** Samy Abdallah, Tech Innovation Lead, Teledec
- **What they did:** Implemented the BMAD method — a "party" of specialized AI
  personas (Analyst, PM, Architect, Scrum Master, Developer) collaborating in
  sequence to autonomously design, build, and test software, with a continuous
  improvement loop feeding test logs back to coding agents.
- **Impact:** Three-week sprints collapsed into a single night; code quality
  consistently exceeds manual human effort.
- **Getting started:** The BMAD method is referenced as the technique; the
  source links only the Visma write-up (no public repo — see `links.md`).

### Visma Enterprise — BOB turned 3-week API rewrites into 2 hours
- **Who:** Toms Ābele, Software Developer, Visma Enterprise AS
- **Problem:** Cross-repository changes in a legacy app suffered severe context
  degradation with standard single-prompt agentic tools.
- **What they did:** Built BOB (Bots Orchestrating Bots), maturing after the
  January VS Code update enabled native agent orchestration. BOB scores each
  ticket on feasibility/clarity, asks for clarification, splits the goal into a
  JSON roadmap of atomic subtasks, routes each to a cost-appropriate model
  (advanced models only for complex work), and runs a fleet of sub-agents
  concurrently in **isolated worktrees** to prevent file clashes. It then
  resolves merge conflicts, runs Playwright/E2E tests, fixes bugs iteratively,
  and finalizes with a human PR review — all in VS Code.
- **Impact:** 90% of the pilot team's code now generated by BOB with a 99%
  success rate on .NET 9 APIs; token consumption down ~70% via model routing;
  zero context pollution; 3-week rewrites in 2 hours.
- **Getting started:** A recommended mindset article + Gas Town for inspiration.

---

## Reading the pattern across use cases

- **Assistance → Delegation → Orchestration** maps to autonomy: accept
  suggestions → delegate a workflow to one agent → coordinate many agents.
- The biggest multipliers (10×, 90% effort reduction) come from
  **modernization/rewrite** work where context engineering replaces missing
  docs and tests.
- Recurring enablers: a written source of truth (`CLAUDE.md`/specs), a
  verification loop the agent can close itself, isolated environments/worktrees,
  and humans owning intent and final approval. These are the foundations in
  `getting-started.md`.
