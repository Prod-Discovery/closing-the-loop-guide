# Tools & agentic frameworks

The playbook's shortlist for getting started. Two tiers: **AI coding tools**
(delegate engineering work to an agent) and **multi-agent orchestration
frameworks** (coordinate several specialized agents). The ecosystem evolves
fast — treat this as a starting point, not an exhaustive list.

> Tool choice follows the agentic ladder (`agentic-ladder.md`): coding tools
> get a team to Assistance/Delegation; orchestration frameworks are how teams
> reach rung 4. All links are in `links.md`.

## AI coding tools

Engineering teams already use AI to autocomplete code; the next step is
delegating end-to-end workflows to agents that collaborate alongside developers.

| Tool | What it is |
|---|---|
| **GitHub Copilot** | AI coding assistant offering real-time suggestions across the whole workflow — editor, command line, and GitHub. |
| **Claude Code** | An agentic AI assistant that lives in your terminal to autonomously plan, edit files, and execute complex engineering tasks across the codebase. |
| **Cursor** | An AI-native code editor (based on VS Code) that indexes the whole project for codebase-aware coding, natural-language editing, and autonomous multi-file generation. |
| **CodeRabbit** | AI code-review platform for GitHub/GitLab — auto-generates PR summaries, gives line-by-line feedback, and detects bugs/security issues pre-merge. |
| **Devin** | Fully autonomous AI software engineer: plans, codes, debugs, and deploys entire projects end-to-end in its own development environment. |
| **Junie** | AI coding agent integrated into JetBrains IDEs to plan, execute, and verify complex multi-step tasks like features or bug fixes. |

Which Visma teams use what: Cursor + CodeRabbit (Taxy.io testing), Claude Code
(SmartBill, GiantLeap, Continuous AI, swarm coding), Devin (Rindegastos). See
`use-cases.md`.

## Multi-agent orchestration frameworks

Engineering teams already delegate tasks to single agents; the next step is
coordinating multiple specialized agents that hand off and deliver together.
Orchestration is the coordination of multiple agents toward a shared outcome —
structured handoffs between stages, parallel execution, and integrated output no
single agent could produce alone. The engineer shifts from doing the work to
governing the system: defining goals, designing agent roles, and ensuring
quality at the boundaries.

| Framework | What it is |
|---|---|
| **Claude Code Agent Teams** | Built-in multi-agent coordination for Claude Code. Multiple instances work in parallel, each with its own context window, coordinating through shared task lists and peer-to-peer messaging, with a team lead synthesizing results. |
| **Gas Town** | Multi-agent workspace manager coordinating 20–30 parallel coding agents through a structured hierarchy. A "Mayor" agent orchestrates worker agents with persistent, git-backed state — enabling crash-recoverable, factory-scale workflows. |
| **Symphony** | Long-running orchestration service that monitors your issue tracker, spawns autonomous coding agents in isolated sandboxed workspaces, and delivers verified pull requests — turning project management into a scheduling system for AI agents. |
| **Get Shit Done (GSD)** | Spec-driven framework that orchestrates specialized sub-agents through a structured discuss → plan → execute → verify pipeline. One command runs an entire milestone autonomously, with atomic commits and clean git history. |

Gas Town and Symphony are flagged in the playbook as **experimental**. Map them
to the orchestration spectrum in `agentic-ladder.md`: GitHub Actions + Copilot →
AI-Automated Workflows; Claude Code Agent Teams → Parallel Agent Teams; Gas
Town / Symphony → Autonomous Orchestration.

## Other tools named in use cases

These appear in `use-cases.md` but without dedicated playbook entries:
**Playwright MCP** (E2E testing), **Augment Code** (spec/rule generation for
multi-agent setups), **Claude Swarm / SuperClaude / Claude Squad** (the InFakt
swarm stack), and the **BMAD method** (agent-persona framework, Teledec). MCP
(Model Context Protocol) servers recur as the way teams extend agents with
external tooling (security scanning, repo analysis, browser control).

## How to choose

- Start with one **AI coding tool** your team will actually adopt; the playbook
  reports ~90% of Visma engineers already use Copilot, Cursor, or Claude Code
  (see `measuring-impact.md`).
- Add an **AI review tool** (e.g. CodeRabbit, or a review agent) to get a
  consistent quality baseline on every PR — this is the "Review" applied
  guidance in `getting-started.md`.
- Reach for an **orchestration framework** only once Plan → Do → Check loops and
  isolated environments are in place — orchestration multiplies a working
  system, and amplifies a broken one.

## Cost & model routing

Token cost is a first-class engineering concern in the playbook, not a
footnote — it's an explicit "stay in control" lever in the AI strategy (see
`measuring-impact.md`) and a recurring design choice in the use cases:

- **Route by complexity.** BOB cut token consumption ~70% by routing each
  subtask to a cost-appropriate model — advanced models only for complex work.
- **Blend AI with existing automation.** Spiris's Playwright MCP setup kept
  "low token cost" by blending AI-driven MCP tests with existing automated
  tests rather than regenerating everything.
- **Track the spend.** "Avg AI spend per engineer" (tokens, not licenses) is the
  KPI that tells you AI is a daily habit — design workflows to be efficient, not
  just capable.
