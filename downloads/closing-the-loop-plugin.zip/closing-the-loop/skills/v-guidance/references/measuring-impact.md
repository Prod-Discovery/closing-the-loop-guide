# Measuring AI impact & building a strategy

AI in the SDLC isn't only about offloading work to agents — it changes how teams
deliver and how customers experience the product. Track adoption *and* its
downstream impact, alongside your core engineering KPIs.

## Where Visma stands (adoption signals)

- **~90%** of Visma engineers use GitHub Copilot, Cursor, or Claude Code.
- **72%** of 2,600 GitHub Copilot users used agentic features in the previous
  28 days — the majority is already delegating, not just autocompleting.
- Average PRs per engineer up **+14% YoY**.
- PRs reviewed by AI crossed the **50% milestone** and is trending up; the
  nature of review is shifting from *technical* to *intent and wider context*,
  and shifting left from post-implementation to within implementation (review
  agents). Most Visma teams say AI review pays for itself in days — *if AI
  finds even a single bug a year that humans wouldn't have caught, it's worth
  it.*

## The AI-delivery KPIs

These track the shift toward agentic delivery — raising productivity while
preserving stability, quality, and customer experience.

| KPI | What it tells you |
|---|---|
| **% of PRs created by AI** | The delegation-to-AI rate — how much work is delegated to AI, and whether productivity gains actually reach delivery. |
| **% of PRs reviewed by AI** | Whether you're creating a consistent quality baseline by scaling human attention with AI review. |
| **Avg AI spend per engineer** | Average AI tokens per engineer — measures sustained, ongoing usage beyond just holding a license; signals whether AI is part of daily work. |
| **pNPS** | Customer sentiment/experience — a check that faster delivery is improving the experience, not just output. |
| **Customer-reported defects rate** | Issues reported by customers after release — real-world quality, and the impact of higher throughput on quality. |
| **Deployment Frequency** | How often changes reach production — whether AI productivity translates into faster, continuous delivery. |

Pair these with the productivity multipliers per ladder rung in
`agentic-ladder.md` and the use-case metrics in `use-cases.md`.

## Build an AI Engineering Strategy

A strategy turns scattered experiments into compounding impact. Without one,
teams experiment but nothing scales, learning stays local, quality varies, and
ROI is unclear. Stop "trying AI" and start building true engineering
capability. Six steps, run as a **cycle**:

1. **Define the ambition.** What shifts early? e.g. 2× dev speed, fewer defects,
   % of PRs created by AI, avg PRs/engineer.
2. **Choose your leverage point.** Where does AI create the most value right
   now? e.g. agentic coding, the codebase, AI code reviews.
3. **Connect to product and business outcomes.** What materially improves if you
   succeed? e.g. time to market, % DevOpEx/ARR.
4. **Plan for scale.** How do you scale what works — do you have the right
   people, competence, and tools? e.g. shared practices, repeatable workflows,
   internal communities, champions.
5. **Stay in control.** What rules let you move fast without breaking trust?
   e.g. security, data policy, cost, quality. (See `responsible-ai.md`.)
6. **Close the loop.** Strategy isn't one-time — learn, adapt, iterate. Run
   retrospectives, share wins and failures, update your approach.

## Using KPIs well

- Lead with **delegation** (% PRs created by AI) and **quality baseline**
  (% PRs reviewed by AI) to show the agentic shift is real.
- Guard the shift with the **customer-facing** measures (pNPS,
  customer-reported defects) so throughput gains don't erode experience.
- Use **avg AI spend per engineer** to distinguish licenses-held from
  habit-formed; sustained token usage is the adoption signal that matters.
- For a structured starting assessment across foundational and agentic
  dimensions, point people at the AI Engineering Accelerator in `workshops.md`.
