# How to get started

Top tips for practitioners. The headline: AI increases throughput fast, but it
shifts the bottleneck into the engineering *system* — ownership, dependencies,
handoffs, and feedback loops. The teams that win aren't the ones that "add AI,"
but the ones whose foundations let change flow safely and continuously.

> Lead with foundations, not tools. AI amplifies whatever system it lands in
> (see the amplifier principle in `agentic-ladder.md`).

## Foundations — three readiness questions

Ask these before scaling AI. Each is a multiplier; a weak answer caps the gains.

1. **Ship small, independently, end to end.** Can you release multiple times a
   day / on demand? Small changes flowing quickly to production is the base
   multiplier. Clear ownership, low cross-team dependencies, and few manual
   handoffs keep changes moving. *If delivery is slow or coordination-heavy, AI
   amplifies the bottlenecks.*
2. **Quality proven automatically.** AI raises the rate of change; if quality
   isn't automatically proven, speed becomes instability, rework, and hidden
   risk. Strong tests + automated gates turn "more output" into "more value."
   *Without automated proof of quality, AI amplifies chaos.*
3. **Self-service, on-demand isolated test environments.** Can you test every
   change in a fully isolated instance (test or ephemeral environment)? This
   lets agents boot the app per change, drive the UI, inspect logs/metrics,
   reproduce bugs, and validate fixes without impacting others. *Without
   isolation, AI is advisory; with it, AI can execute, validate, and iterate
   autonomously.*

Data point: in Visma, top-performing engineering teams drive ~4× higher revenue
growth than the bottom tier.

## The core AI workflow: Plan → Do → Check

An AI workflow is a short, repeatable cycle — typically one to three hours —
that wraps around every coding session. *Speed without structure creates debt,
not value.* It extends agent autonomy from minutes to hours.

| Phase | What it means |
|---|---|
| **Plan** | Define the intent via a written specification and assemble relevant context *before* generating any code. |
| **Do** | Implement the plan in atomic, verifiable steps. Nothing more. |
| **Check** | Verify the output against acceptance criteria through automated testing. |

How to think about it:

- **Separate the phases into sub-agents with distinct context windows.** When an
  agent plans and builds in the same breath, it optimizes for finishing, not for
  understanding. Context isolation prevents bias.
- **An agent is only as good as its context.** Feed it the right documentation,
  rules, and tool access; keep noise out. This is the difference between useful
  output and expensive rework.
- **Teach the agent to close the loop.** Wire build tools, linters, test
  runners, and browser access into hooks or MCP tools. **If the agent can't
  verify its own work, you don't have a loop.**
- **Improve every cycle.** After each loop: what drifted, what would have
  prevented it, what do you update? This five-minute habit turns a speed boost
  into a system that compounds.

## Applied guidance across the SDLC

The collaboration pattern is the same at every stage: **delegate execution, own
the outcome.** Each stage has a Basic and an Advanced step.

### Implement — delegate execution, own the outcome
- Delegate scaffolding, wiring, and routine code changes end-to-end; engineers
  own intent, constraints, and outcomes, and review for architecture,
  performance, and core business logic.
- **Basic:** delegate single, atomic tasks with unambiguous success criteria; a
  minimal `AGENTS.md` enabling tests and linters.
- **Advanced:** enable plan → do → check agentic loops; parallel delegation —
  scoped tasks executed concurrently by specialized agents.

### Review — review only what matters
- Agents perform first-pass reviews on **every** PR (logic errors, race
  conditions, inconsistencies) and iterate with QA agents until validators pass.
  Engineers concentrate on architectural alignment, intent vs. requirements, and
  production risk — not line-by-line inspection. Final approval and merge stay
  with engineers.
- **Basic:** every PR reviewed by an agent by default; escalation rules surface
  critical/high-impact risks, not stylistic nitpicks.
- **Advanced:** close the loop — feed agent findings back into review rules and
  standards; multiple specialized agents review and iterate until all checks
  pass.

### Test — design tests as executable specs
- Agents generate test cases from specs and code, run suites, and iterate on
  failures — deriving edge cases and refactoring tests as implementations
  evolve. Engineers own test strategy and adversarial thinking.
- **Basic:** tests don't depend on local state, timing, or external systems
  without mocks/contracts; test, coverage, and lint commands documented and
  callable in `AGENTS.md`.
- **Advanced:** generate tests from specifications; agents identify and fill
  missing user flows, edge cases, and gaps.

### Ops & Maintenance — embed agents as first-line operators
- Agents continuously analyze logs, metrics, traces, deploy history, and code to
  detect anomalies, correlate signals, and propose mitigations or hotfixes.
  Engineers validate findings, assess blast radius, and decide whether actions
  are safe. (See the "Continuous AI" use case in `use-cases.md`.)
- **Basic:** scope agent access to logs/repos/deploy data with strict
  permissions; test agents with simulated incidents before real usage; use
  predefined incident runbooks.
- **Advanced:** shift reliability work from reactive fixes to proactive system
  improvement; reuse incident learnings to improve future diagnostics.

## A concrete starting path

1. Run the **AI Engineering Accelerator** self-assessment (15 minutes) to learn
   where the team stands and get a prioritized action plan — see
   `workshops.md`.
2. Fix the weakest of the three foundations above first; tools won't scale past
   a broken foundation.
3. Adopt the Plan → Do → Check loop on one real task; make sure the agent can
   verify its own work.
4. Pick the closest match in `use-cases.md` and emulate its approach.
5. Join the workshop that matches your leverage point (testing, modernization,
   or the Copilot Masterclass).

## Links

The Accelerator, workshops, and contacts are in `workshops.md` and `links.md`.
