# AI risk & responsible AI

With new technology comes new risks and responsibilities. We are in a period of
**higher risk** because developers and security tooling alike need time to catch
up. The job: learn the new risks, and know how to avoid, identify, and mitigate
new types of security vulnerabilities.

> When you delegate execution to agents, design for **observability and control
> from day one** — not as an afterthought.

## The core risks and mitigations

### Prompt injection & adversarial exploits
- **Risk:** Untrusted text (PRs, tickets, docs, web/RAG content) steers the AI
  to ignore rules, leak data, or take unauthorized actions.
- **Mitigation:** Treat all inputs as untrusted; sandbox execution;
  least-privilege tools; ensure the AI can't "grant itself" access; apply
  output-handling controls.

### Sensitive information disclosure
- **Risk:** Developers or agents expose credentials or personal data via
  prompts, traces, or logs — or the system reveals PII, confidential business
  data, or secrets through outputs, logs, or retrieval.
- **Mitigation:** Data minimization (minimize what goes into context);
  tenant/isolation in retrieval; DLP + secret scanning on prompts, outputs, and
  logs.

### Supply-chain compromise in AI tooling
- **Risk:** Compromised packages or update channels introduce backdoors.
- **Mitigation:** Verify dependencies; restrict which tools/agents can run
  (approved registry); run SCA/SAST as **hard gates**.

### Regulatory non-compliance
- **Risk:** Missing required controls becomes a business risk when conformity
  can't be demonstrated.
- **Mitigation:** Use a quality-management system; maintain technical
  documentation; keep system logs; run the conformity assessment.

## Reference standards

- **OWASP Top 10 for LLM Applications** — the canonical catalogue of LLM risks
  the playbook draws on.
- **OWASP GenAI — Sensitive Information Disclosure (LLM02:2025)** — deeper
  guidance on the disclosure risk above.
- **EU AI Act — Article 50** — transparency obligations relevant to regulatory
  compliance.

Visma-internal deep dives:

- **VSP: Offensive AI Playbook** — the offensive/attacker perspective.
- **VSP: Defensive AI Playbook** — the defensive/mitigation perspective.

All links in `links.md`.

## Applying this as guidance

- For any "should we let an agent do X autonomously?" question, anchor on the
  three foundations in `getting-started.md` (especially **isolated
  environments** and **least-privilege access**) plus the mitigations above.
- Tie responsible-AI controls to **step 5 ("Stay in control")** of the AI
  Engineering Strategy in `measuring-impact.md` — security, data policy, cost,
  and quality are the rules that let a team move fast without breaking trust.
- When advising on agent permissions, default to least privilege and explicit
  human approval for production changes — the use cases that scale safely
  (e.g. Continuous AI, BOB) all keep a human on the merge decision.
