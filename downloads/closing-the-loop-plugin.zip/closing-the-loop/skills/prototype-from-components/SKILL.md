---
name: prototype-from-components
description: Build a clickable prototype from a brief, a PRD, and/or a Figma frame using a team's OWN components (from component-readiness-scan's inventory) — any stack. Real components wherever possible; missing or coupled ones get a flagged stand-in composed from real components and tokens, never a silent invention. Primary output is a live dev surface; a standalone single-file HTML export covers workshops and sharing. Stage 5 of the Discovery to Prototype Engine. Use for "build a [screen] with our components", "prototype a [feature]", or "build this Figma screen".
trigger: [build a screen with our components, prototype a feature, make a page using our components, prototype this, build a flow with our components, mock up a screen with our components, build this figma screen, run discovery stage 5]
license: Apache-2.0
---

# Prototype From Components

Turn a plain-language brief — or a Figma frame — into a complete, clickable screen
built from the team's real components — and be **transparent** about anything that
isn't real, so `prototype-fidelity-report` can explain it.

**One rule is deliberate:** never stop on a gap. When a needed component is missing or
can't render standalone, **substitute + flag** so the user always gets a full screen.
The flags are the contract the fidelity report depends on.

## Prerequisites

- `component-inventory.md` and `prototype-rules.md` from `component-readiness-scan`.
  If they don't exist, run the scan first — don't guess at the library.
- A prototyping surface set up (Storybook, a minimal app importing their library, or a
  throwaway route in their app — whichever the scan recommended).

## Inputs

Any of these — alone or combined — describes what to build:

- **A brief** in natural language ("a settings page with a billing section").
- **A PRD** — many teams (and workshop groups) start from a written PRD; its use cases
  and user flows are the brief. When run as Stage 5 of the engine, **read the PRD from
  `$DISCOVERY_DIR` automatically** (Stage 3 wrote it there) — don't ask the user to
  restate what the PRD already says.
- **A Figma frame URL** — fetch the screen via the Figma MCP (`get_design_context`,
  `get_screenshot`) and treat the frame as the brief: its elements become the UI list
  in Step 2, and its screenshot becomes the visual reference the fidelity report can
  diff against.

## Workflow

### 1. Read the context

- `component-inventory.md` — components, import paths, props, verdicts (🟢/🟡/🟠/🔴).
- `prototype-rules.md` — how to build on-brand (imports, tokens, banned patterns).
- On the agent path: the PRD's Agent Behavior Script, and `stage-3-pattern-card-*.md` when
  the optional pattern check made one — see 3a.

### 2. Plan the screen

From the brief (the PRD's use cases and flows, or the Figma frame's element list), list
the UI pieces needed and map each to a component in the inventory:

- 🟢 (or 🟡 with the known wrapper) → use the **real** component, imported the real way.
- **Not in the inventory**, or **🔴 (won't render standalone)** → it will be a **stand-in**.

### 3. Build it

- Use real components for everything mapped in Step 2.
- Follow the rules file: real import paths, their tokens (no invented colours), mock
  data only.
- **Stand-ins compose from real components.** A stand-in is not a grey box: build it
  from the 🟢 components in the inventory wherever possible — a stand-in table uses
  the real Button, Link, and Icon inside its cells; only the parts that truly don't
  exist are plain elements styled with the project's tokens.
- Flag every stand-in **inline immediately above it**:

  ```tsx
  {/* SUBSTITUTE — not <TheirLib>'s real <ComponentName>: <reason>.
      Fix: <one-line: decouple / promote / extract / extend / build> */}
  ```

  Reasons come from the inventory verdict, e.g.:
  - `not found in the component library` (needs **build/extract**)
  - `couples to the app store — can't render standalone` (needs **decouple**)
  - `requires the app router — can't render standalone` (needs **decouple**)

  **Never silently invent.** Every non-real piece gets a `SUBSTITUTE` flag.

### 3a. Agent path: simulate the agent, don't build one

When the PRD has an **Agent Behavior Script** (Stage 3.2+3.3), plain screens are not enough:
what gets tested is the agent's behaviour and the user's trust in it. Fake the agent with
scripted, deterministic states and mock data — the same for every test participant:

- Agent actions become click- or timer-driven state changes: a visible working state, then
  the result.
- A visible **agent activity** panel says what the agent is doing, step by step, in the
  behaviour script's words.
- Every human checkpoint in the script becomes a real approval moment (approve / adjust /
  reject) — the core of what Stage 6 tests.
- Script **one failure mode** from the behaviour script (e.g. the agent is unsure and hands over).

**If a Pattern Card exists**, build each of its **design moments** as a visible, testable
moment: what the person sees and does at that point, as the card describes it. Its level per
task decides what the agent does: Auto acts on its own and says so, Ask first prepares and
waits for approval, Suggest only suggests, Off is left to the person. Build only the moments
under "Design moments"; patterns under "Applies, not prototyped" stay out. Never show pattern
names or ids in the prototype's UI. The stand-in rules still apply to the activity panel and
approval moments.

### 3b. Keep the decision log (every build and every refine)

Append one entry to `prototype-decision-log.md` (next to the prototype source; create it on the
first build) for the initial build and for **every refine round** — pilot teams review prototypes
with their developers, and the log is how a reviewer sees what changed and why without replaying
the chat:

```markdown
## 2026-09-25 14:32 — refine 3
- **Requested by:** usability session feedback (participant 2 of 5)
- **Change:** delta badge turns green for positive, red for negative values
- **Why:** users read all badges as warnings when they were one color
- **Touched:** DeltaBadge (stand-in), MetricCard usage in DashboardGrid
```

Four lines per entry — requested by, change, why, touched — nothing more. Write it silently as
part of the build/refine; don't ask permission per entry. The log is an input to the handover:
`handover-shape-feature` and `discovery-handover-package` may cite it as evidence for decisions.

### 4. Run it and hand off

- Make sure it renders in the prototyping surface — this live surface is the
  **primary deliverable**.
- **Always finish by invoking `prototype-fidelity-report`** on the file(s) just
  written, so the user sees which components are real vs. stand-ins and why — even if
  they wouldn't think to ask. (Auto-chain; don't wait to be asked.) Pass the Figma
  frame reference along if one was used, so the report can run its visual check.

### 5. Standalone HTML export (always write it)

Export a **single standalone HTML file** (inlined styles and behaviour, double-click to
open, no install) — **every time, not only on request**. Downstream steps depend on this
file existing: Stage 6 tests against it, `discovery-create-tracker-issue` attaches or
links it to the feature issue, and `discovery-handover-package` reads it as the
interaction spec. It's also the easy-sharing format for workshops and stakeholders
without the repo. Keep the `SUBSTITUTE` flags as HTML comments so fidelity information
survives the export. The live surface remains the source of truth; the export is a
snapshot — refresh it after each refine.

**`$DISCOVERY_DIR`** — write the export to `$DISCOVERY_DIR/stage-5-prototype.html`; full
rules:
[`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md).

## Output

A working prototype on the live surface, the standalone HTML export at
`$DISCOVERY_DIR/stage-5-prototype.html`, the running `prototype-decision-log.md`, the
`prototype-pack.md` once approved, and (via the chained report) a plain-language fidelity note. Refine on request ("add a search", "make it two columns") — keep
flagging any new stand-ins the same way, re-run the fidelity report, and refresh the
export after each refine.

**Long refine sessions: suggest `/compact` proactively.** Heavy prototype rework fills
the conversation with stale versions of the same screens, and stale drafts are what
degrade output quality. After roughly every third refine round — or whenever a screen is
finished and the next one begins — add one friendly line to the completion message, e.g.:
*"Tip: we've iterated a lot on this screen — running `/compact` now keeps the session
sharp. It summarizes the history and drops old drafts; your prototype, inventory and PRD
files are not affected, and we continue right here."* Recommend `/compact` in the same
session — never suggest starting a fresh session, which would drop the user out of the
guided flow. Field-tested: a Dialog pilot user hit exactly this and `/compact` fixed it.

**The prototype source files are a handover deliverable in their own right.** They are
real framework code importing the team's components at their production paths — the UI
reference implementation delivery builds from. The HTML export and any hosted build are
for people to view; never point an agent at either as the thing to build from. A
deployed build serves a minified bundle with the tokens compiled away. Keep the source
where the handover can reach it (a branch or a folder in the prototyping surface).

When the user approves the prototype, write **`prototype-pack.md`** at the source root,
next to the decision log, and refresh it after every refine. It names the source location
with a pinned commit, where the design-system copy came from, how to run it, and which
files render each screen and state. Shape and port rule:
[`${CLAUDE_PLUGIN_ROOT}/references/prototype-handover.md`](../../references/prototype-handover.md).
Record the pack's path as one line in `$DISCOVERY_DIR/stage-5-prototype-source.md`, so later
stages find the source without scanning. `discovery-create-tracker-issue` puts the source on
the ticket, and `handover-shape-feature` turns the pack into the Delivery Context's UI
reference.

**After approval, on the agent path only**, offer the optional pattern audit before Stage 6:

```
Optional before testing: a pattern audit checks this prototype against the
patterns in Visma's guide for Great Agentic Experiences and shows, per pattern,
what's there and what's missing.

A) Run the pattern audit (recommended if you made a Pattern Card)
B) Go straight to Stage 6, the experiment plan
```

**A** → invoke `discovery-agent-patterns` (Mode 2); it hands off to Stage 6 when done. **B** →
"Next step → Stage 6. Type: 'Create test plan' or 'Run Stage 6'". Never run the audit unless the
user chooses it; on the standard path, skip the offer.

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (`AskUserQuestion` in Claude Code and Cowork), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. Buttons mirror the listed options exactly — never add one that isn't an option. A `Type: "..."` handoff becomes a button with that wording, for example "Run Stage 4", next to "Stop here".
- **Fall back to the list.** Without such a tool, or with more than 4 options, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** When this skill runs as part of the full engine (earlier stage files exist in `$DISCOVERY_DIR`), start each checkpoint with one line: this stage, then `Sense` before the path is set, or `Standard path` / `Agent path` from the agentic flag in `stage-2-selected-opportunity.md` — for example `Stage 1.1 of 6 · Sense` or `Stage 4 of 6 · Agent path`. Skip the line when the skill runs standalone.
