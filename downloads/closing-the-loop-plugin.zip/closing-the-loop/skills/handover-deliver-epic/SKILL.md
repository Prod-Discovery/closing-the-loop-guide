---
name: handover-deliver-epic
description: Walk an epic's projected children through delivery one at a time — chores first, then slices in dependency order — deriving the queue and the resume point from live tracker state, delegating each child to a single-ticket delivery run, and pausing between children. Use when the parent is epic-shaped (Brief §6.3 or Delivery Context Story map present, or projected children exist) and nothing is delivering them. Never for a single-ticket-shaped feature, never to change scope or slicing.
trigger: [deliver the epic, walk the stories, deliver the projected stories, next story in the epic, resume delivering the epic]
license: Apache-2.0
---

# Deliver an Epic's Projected Children

The projectors create one tracker child per slice and stop. This skill is the missing iterator: it
enumerates that child set, orders it, hands each child to the delivery entry point as its own run,
and stops the moment an outcome cannot be confirmed.

It serves **both** handover paths. Per-child readiness — a governed sign-off gate, a context-first
context hash — is already dispatched by the delivery entry point's own ticket-fetch phase, so the
loop itself is path-blind. Only enumeration, the advisory pre-flight, and the close-out criteria
differ, and those are the three rows of the path table below.

> **Path guard:** this skill needs an **epic-shaped** parent carrying exactly one handover marker. The
> shape is read from the artifact, never from config: the parent's payload shows a story-map heading
> (Brief `### 6.3 Story map` or Delivery Context `### Story map`) and/or it has projected children in
> the path's marker family. Neither → single-ticket-shaped: there is no set to walk; hand back to the
> single-ticket delivery entry point.

## When to Use

- A projected child set exists and nothing is delivering it
- A walk was interrupted and needs to resume from wherever the board actually is
- The team wants each slice to land as its own reviewable change rather than one epic-wide branch

Do not use it to change what the children say. Scope, slicing, dependencies, and acceptance behaviour
belong to the shaping and projection skills; this skill only delivers what they already agreed.

## Preconditions

1. The parent is epic-shaped — a story-map section heading in its payload and/or projected children
   (Step 1). Never read this from config.
2. The parent carries one handover marker, and its children were projected by the matching projector.
3. The delivery entry point is available, and the repository is on the project's default branch.

## The path branch

Resolved once, from the parent, at Step 1 — never re-derived per child.

| Aspect | Governed parent | Context-first parent |
|---|---|---|
| Child markers | the governed story / backlog-item labels and `Slice`/`Chore` stamps | the context-first story / backlog-item labels and the `Part of … · Context <hash>` stamp |
| Pre-flight, once, **advisory only** | `handover-retrieval` in `gate-status` mode — an open sign-off gate halts before the first child | the parent's recorded base commit resolves and its context hash is current |
| Remedy named on a staleness halt | re-ratify the changed Brief, then `create-backlog-from-brief` reconciliation | `handover-project-stories` reconciliation |
| Close-out criteria source | the Brief's acceptance criteria and success metrics | the acceptance-behaviour set and declared exclusions — on the ticket surface the parent's own Delivery Context, on the Confluence surface its Delivery Context sub-page |

## Tooling Note

Child enumeration, live status, blocking relations, and the recorded merge reference come off the
tracker: tracker MCP server > tracker CLI or API > user-pasted board state. Unlike a single-ticket
delivery run, the child set **is** this skill's entire input — there is nothing to degrade to but a
user-supplied ordered key list, and a walk run that way reports itself as unverified against live
state rather than claiming confirmed progress.

## Workflow

### 1. Resolve the parent and the path

Accept a parent key, or any child key and walk up to its parent. Read the parent's handover marker and
set the path for the whole walk. **Stop** when the parent carries both markers or neither — an
ambiguous parent makes every downstream readiness check meaningless.

Confirm the parent is epic-shaped, from the artifact only: look for the `### 6.3 Story map` /
`### Story map` heading (and the `> **Backlog shape:**` header line; legacy `Backlog mode:`) in its
payload **by heading presence only** — this is the one touch of the parent's payload, and it reads
the heading and header line, never the section content (Step 2's rule stands) — and/or for projected
children in the path's marker family; children corroborate the shape here because this is a
delivery-side skill. Neither present → the feature was shaped single-ticket: stop and hand back to
the single-ticket delivery entry point. Never read the shape from config.

### 2. Enumerate the generated children

Match children by the path's marker family plus the body stamp, never by title — the projectors own
that matching rule and it is not restated here. Read only labels, stamps, live status, blocking
relations, and any recorded merge reference. **Do not read the parent's payload body** (Step 1's shape
check reads only the story-map heading and header line, never the section content): the delivery
entry point performs its own walk-up, slice load, and freshness check per child, and staging that
context here fights the check that protects the walk.

Stop on a duplicate stable id. A labelled child with no valid stamp is flagged as an orphan, left
untouched, and excluded from the walk. Stop on a child whose marker family contradicts the parent's
path — a governed story checked only for hash freshness is a bypassed sign-off gate.

### 3. Build the ledger and derive the order

Classify every child on five axes. The first four are the projector's reconcile classes; `delivered`
is the axis a projector never needs and a walk cannot work without:

- **delivered** — a terminal live status **and** a recorded merge reference. The pair, never the status
  alone; a ticket closed by hand outside the walk has no merge behind it.
- **in flight** — claimed by a run that has not reported.
- **ready** — no outstanding blocking relation.
- **blocked** — a blocking relation not in a done-type state.
- **flagged** — orphan, duplicate, or projector-flagged for human disposition.

Order the deliverable set by the live blocking relations: chores before slices, then dependency
order, with the projector's map order breaking ties. A cycle, or a terminal status with no merge
reference behind it, stops the walk here — before anything is invoked.

Derive the blocked predicate here, inline. `handover-retrieval`'s child walk-up is governed-only and
stops on a context-first parent, so it cannot serve as the shared predicate; mirror the rule it states
— an approved parent does not make an out-of-order child deliverable — without invoking it.

### 4. Show the queue, confirm it, and set the merge posture

Render the ledger, the ordered remaining queue, and the count of children this walk will merge. Where
the host has no automated merge path, state the number of human round-trips the walk will cost, so the
team can choose to fix that rung first rather than discover the cost at the second child.

Establish the merge posture for the walk now, in one exchange: the default is to confirm before each
merge, and an unattended walk must be asked for explicitly and restated as the number of merges it
authorises. Relay whatever was granted **verbatim** into each run — the walk cannot grant, reword,
infer, or reconstruct that authorisation. **A blanket grant does not remove the pause between
children;** it removes only the per-merge confirmation inside each run.

Confirming a delivery sequence is not product or engineering sign-off. On "not yet", stop having
invoked nothing.

### 5. Establish the repository precondition for this child

Before **each** run, not once for the walk: confirm a clean tree on the updated default branch, and
that the previous child's merge actually landed. The next child's base is the default branch as it
stands after the previous child merged.

### 6. Deliver the child — invoke **v-ticket-to-release**

Pass exactly one child key, plus the Step 4 authorisation sentence verbatim when it was granted. Pass
nothing else — no slice text, no parent payload, no ordering hint, and no claim that readiness was
already checked. The run re-checks readiness itself, and that re-check is what blocks the next child
when the parent changed mid-walk.

### 7. Classify the return, report, and pause

The run reports in prose, not as a status. Read its report against live tracker state:

| Observed | Class | Action |
|---|---|---|
| merge reference set, not reverted, transition names a state, **and** live status terminal | delivered | pause, then continue |
| reported as reverted | walk-fatal | stop — the default branch is being unwound beneath every remaining base |
| a stale context hash or an unratified parent reported at ticket fetch | walk-fatal | stop — the whole sibling set is invalid; reconcile, then resume |
| report present, no merge reference, change proposed for review, merge listed as a user action | awaiting-merge | stop; surface the review link and the exact outstanding merge and transition |
| report present, no merge reference, merge attempted and refused | blocked | stop; quote the refusing gate |
| no closing report at all | blocked | stop; name the phase it stopped in — never infer an outcome |
| any decisive row absent or unreadable | blocked | stop — an unreadable row is not a passing row |
| the report claims a merge but live status is not terminal | blocked | trust the tracker over the prose |

The last two rows carry the weight. `awaiting-merge` and `blocked` must stay distinct: a host with no
automated merge path returns a *complete* report with no merge reference, which is otherwise
indistinguishable from a merge that branch protection refused — collapse them and every walk on such
a host reports as blocked, hiding a host limitation behind a false gate failure.

Report progress as `Children: [N delivered / M total, in dependency order]`, then confirm with the
user before the next child. Return to Step 5 **only** on `delivered`.

### 8. Close out the epic

Only when every child is `delivered`: verify the sum of the delivered changes against the path's
close-out criteria source, transition the parent, and name release preparation as the calling
orchestrator's to run, so that pass happens once. A `flagged` child blocks close-out — report it for
human disposition rather than absorbing it into the total.

## Resume

There is no manifest and no progress file. Re-invoking on the parent re-runs Steps 1–3 and starts at
the first `ready` child; the tracker is the walk's only state. After a walk-fatal staleness stop the
same phrase resumes, but Step 3 refuses until the projector has reconciled.

## Output Contract

### Summary

Parent key, path, child count, `N delivered / M total`, and the stop reason — `complete`,
`awaiting-merge`, `blocked`, or `walk-fatal`.

### Detail

The ledger: order, key, chore or slice id, class, outstanding blockers, merge reference, live status,
review link. Plus the per-child progress lines as they were emitted.

### Verification

Merge posture established once and relayed verbatim; a clean tree on the updated default branch
confirmed before every run; each `delivered` child confirmed against live tracker status rather than
the run's prose; no parent payload staged ahead of a run; no staleness escalation converted into a
skip.

### Follow-ups

Outstanding manual merges or transitions, flagged children, the close-out if unreached, and the
release pass owed to the caller. `None` only when Step 8 completed.

## Quality Bar

A walk meets the bar when every child that entered delivery entered as its own run on its own branch;
when the order it delivered in is reproducible from the board rather than from the walk's own memory;
when the walk's report and the tracker agree on which children are done; and when the walk stopped at
the first child whose outcome it could not confirm.

It fails when one branch carried more than one child's changes, when it reported an epic complete
while the board still showed unstarted children, or when it repaired story scope instead of handing
back to the projector.

## Anti-Patterns

**The one-branch epic.** After the first child lands, momentum carries the rest onto a single
epic-wide branch. Observed in the pilot: fifteen commits, one branch, ten children left untouched on
the board. The walk exists to make this shape impossible, so its own progress report must be
reconcilable against the tracker at any point.

**The silent skip.** Stepping over a blocked or flagged child to keep the queue moving, so the walk
reaches the end and reports complete with holes in it.

**The batched pause.** Collecting several children's confirmations up front to avoid interruption,
which turns the between-children gate into a rubber stamp and reintroduces the one-branch epic by
another route.

## Critical Rules

1. **Delegate, never implement.** This skill enumerates, orders, invokes, classifies, and reports. It
   writes no code and proposes no change of its own.
2. **The tracker is the ledger.** Walk state is re-derived from live children every run. No manifest,
   no progress file, no second source of truth beside the parent's payload.
3. **Readiness belongs to the run, and is never cached.** The pre-flight is advisory. A parent that
   changed mid-walk must block the next child, which only happens if each run re-checks for itself.
4. **Never continue past an unmerged child.** The next child's base is the default branch after the
   previous child merged; without that merge there is no correct base to branch from.
5. **A stale sibling set stops the walk.** Reconciliation is the projector's, and skipping to the next
   child would deliver against a set that no longer describes the feature.
