---
name: v-investigate
description: Use when something fails, regresses, or behaves unexpectedly — 'find out why', 'debug this', 'fix this bug', a red test or build — and before changing code you have not read ('how does X work?'), or to spike an uncertain approach. Reproduces the problem and proves the root cause with evidence instead of guessing, then hands the fix to v-build. Not for applying a known fix (v-build) or reviewing a change (v-challenge).
license: Apache-2.0
---

# Investigate

**Where does reality differ from what we believe?**

Bugs, spikes, and unfamiliar code are one move: state the belief, observe
reality, and run the cheapest experiment that tells them apart.

## When to Use

- **Bug** — a failure, regression, intermittent error, or slowdown with no
  obvious cause
- **Spike** — an approach, library, or assumption is too uncertain to build on
- **Orient** — the change touches code you have not read

Skip when the error names its own cause (a typo, a missing import): fix it
with **v-build**.

## Workflow

### 1. State the belief and the observation

Write down what should happen and what actually happens — the exact error,
output, or question, never a paraphrase. For a bug, also establish when it
last worked. The bug type sets where to look first:

| Bug type | Look first at |
|---|---|
| Regression — worked before | What changed since: commits, dependency bumps, config |
| Latent — existed, newly triggered | The triggering conditions |
| Integration — parts work alone | Boundaries and contracts between them |
| Data-dependent — specific inputs only | Edge cases and validation |

### 2. Observe directly

- **Bug:** reproduce with the exact command, arguments, environment, and
  data, and keep the output to compare against later. When the project has
  tests, the reproduction is a failing test. If it will not reproduce, say so
  and lower your confidence — never present a guess as a reproduction.
- **Spike:** build the smallest throwaway thing that answers the question,
  inside a timebox agreed up front.
- **Orient:** read the entry points, the change site, its callers, and its
  tests. Note the patterns to copy and the traps to avoid.

### 3. Hypothesize, then test

State a hypothesis specific enough to predict what you will see if it is
right and if it is wrong. Change one variable per experiment and record every
result, including the ones that rule something out. After three failed
attempts in one direction, stop and list what is known, what is ruled out,
and what is untried — the next direction is usually in that list.

### 4. Conclude with evidence

- **Bug:** name the exact location and condition. You have the root cause
  when you can predict the fix: the error says *what* failed, the cause says
  *why*. Then search for siblings — the same pattern elsewhere in the code.
- **Spike:** the answer and the decision it drives; a hard-to-undo one goes
  to **v-scope** step 5 for the user's call. Delete the spike code; the
  finding is the deliverable. Notes worth keeping between sessions go in
  `.visma-skills/local/notes/` (gitignored — create `.visma-skills/.gitignore` containing `local/` if it is missing).
- **Orient:** a terrain map — where the change belongs, what to copy, what
  depends on it, where the traps are.

### 5. Hand off

To fix or build: invoke **v-build** with the root cause and the failing test.
Symptom to merged fix in one flow: follow **v-scope**
(`references/recipe-bug.md`).
If the finding changes the work — bigger than thought, or the premise was
wrong: invoke **v-scope**.

Called by a recipe or another skill's reference for one step: do that
step, return the result to the caller, and let it continue.

## Make it yours

Before step 1, read the team's `.visma-skills/project.md` if it exists.
Precedence: the user's instruction for this task, then that file and
`AGENTS.md` (or `CLAUDE.md`), then your own
`.visma-skills/local/preferences.md` — which never relaxes an approval gate
— then this skill. The layout is in **v-ship** (`references/project-settings.md`). This skill reads: how to
run the app and tests locally, where logs and traces live, known flaky
areas, where spike findings are recorded (a ticket comment, a decision log),
and any team reference files to load, each with its condition.

## Output Contract

### Summary

One line: what was investigated, the conclusion, and the confidence
(confirmed / likely / unknown).

### Detail

```markdown
**Belief:** what should happen
**Observation:** what actually happens (exact)
**Evidence:** each experiment and what it showed, including what it ruled out
**Conclusion:** root cause at file:line / answer and decision / terrain map
**Siblings:** other places with the same pattern, or "none found"
```

### Verification

The reproduction command and its output, the failing test if one was
written, or what the spike ran.

### Follow-ups

Decisions the user must make, siblings left unfixed, or "None".

## Quality Bar

It fails when someone rerunning the recorded experiments would not reach
the same conclusion.

## Anti-Patterns

**Stopping at the crash site.** The stack trace shows where it failed; the
cause is usually upstream. A guard at the crash site hides the bug until it
surfaces somewhere worse.

## Critical Rules

1. **Investigation does not change behavior.** Remove temporary diagnostics
   when done; the fix belongs to **v-build**, where it gets a test and a
   review.
