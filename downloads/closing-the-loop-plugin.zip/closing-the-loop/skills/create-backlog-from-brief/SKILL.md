---
name: create-backlog-from-brief
description: "Governed-path story-map projector: renders the Brief's §6.3 Story map into a Linear/Jira backlog. Epic-shaped Briefs only (§6.3 present)—post-gate by default, or pre-gate through an approved bridge orchestrator; no story is deliverable until the gate passes. Never use for context-first-handover; that path has its own Delivery Context projector."
trigger: [create the backlog, provision the epic, break down the brief, project the story map, epic with stories]
license: Apache-2.0
metadata:
  requires: [Engineering Brief with a §6.3 Story map promoted to the ticket description, sign-off sub-issues existing (both Done in post-gate timing)]
---

# Create Backlog From Brief (Story-Map Projector)

> **Path guard:** this skill belongs only to `handoverPath: "governed"`. If the ticket carries
> `context-first-handover`, stop without creating or changing tracker children. Context-first epic-shaped
> features use `handover-project-stories`, never a Brief projector.

Turns a **reviewed** Engineering Brief into a sprint-ready backlog: the **source ticket becomes the
Epic**, and the Brief's **§6.3 Story map** is rendered into child stories and blocking chores,
verbatim. Post-gate timing renders the ratified map; pre-gate timing renders the reviewed map as a
provisional surface for the PM + Dev gate to ratify.

The one-sentence contract: **this skill is a projector, not a planner.** The breakdown was decided in
the Brief; this skill renders it into tracker objects and mechanically verifies the projection lost
nothing. Approval timing determines whether the rendered items are provisional or ratified. If this
skill finds itself inventing a slice, it has already failed.

> [!note] Runs against the approval gate — distinct from sign-off
> This skill provisions the **implementation backlog**. It is separate from the **sign-off
> sub-issues** (`✋ PM sign-off` / `✋ Dev sign-off`) that `discovery-handover-package` creates to gate
> the handover. Its timing follows `backlogTiming` (`~/.config/closing-the-loop/config.json`; default
> `post-gate`):
> - **`post-gate`** — run it only once both sign-off sub-issues are Done; the backlog implements an
>   approved breakdown, it does not approve one.
> - **`pre-gate`** — run it via **`handover-workflow` or `prepare-amigo-session` only**, right after
>   the mandatory brief review, so the team's refinement session walks real tracker stories and the
>   sign-off then ratifies the Brief *and* the visible breakdown. Pre-gate stories carry **no draft label** — a
>   label nothing reliably removes is a stamped state that duplicates the tracker; the sign-off issues
>   blocking each story, the `Cut from Brief v<x>` stamp, and the live gate read at delivery *are* the
>   state. Delivery stays locked either way: `handover-retrieval` refuses to load any story until both
>   sign-offs are Done.
>
> **Inspection is not loading.** Parsing the Brief (the ticket description) to project stories is not
> loading the payload for engineering delivery. This skill invokes `handover-retrieval` with
> `mode: gate-status`; the reader returns the live gate state without loading any payload.

## What this produces

1. **The Epic = the source ticket.** No new epic is created and nothing is copied into one — the
   Engineering Brief already *is* the source ticket's description, and every mechanism in the bridge
   (the `discovery-handover` label, the sign-off sub-issues, the attachments, the manifest) hangs off
   that one key. On Jira, the conversion to Epic happens at **handover time** (the preflight in
   `discovery-handover-package`, run when the Brief carries §6.3), never here — converting mid-flight with Sub-task
   sign-offs attached **silently orphans them** (verified on staging). On Linear, the hierarchy is
   untyped — just parent the children.
2. **Child stories — one per §6.3 story row**, each self-contained: its keyed acceptance criteria
   (§6.2), its §6.1 spec slice **copied in verbatim**, its demonstrable outcome, its §7 import paths,
   a parent stamp, a Brief-version stamp, and the `discovery-handover-story` plus
   `discovery-handover-backlog-item` labels.
3. **Technical chores — one per §6.3 chore row** (prerequisite work from §8: migrations, seams),
   linked with *blocks* relations so they run first. Stories and chores both carry the stable
   `discovery-handover-backlog-item` label and a Brief-versioned `Slice <S-n>` / `Chore <C-n>` body
   stamp for retry-safe live reconciliation; stories additionally carry `discovery-handover-story` for delivery walk-up.
4. **A `backlog` block in the manifest** — the criteria↔story matrix that makes coverage auditable
   and stale-story detection possible when the Brief later changes.

## Prerequisites — both gate this skill

1. **The Brief is epic-shaped — it carries `### 6.3 Story map`** (header line
   `> **Backlog shape:** epic`; the legacy `Backlog mode:` label reads the same). The Brief is the
   ticket description (or `handover/[feature]-brief.md` locally). Read the shape from the Brief, never
   from config — the team's default was only the shaper's tie-breaker
   ([`${CLAUDE_PLUGIN_ROOT}/references/backlog-shape-decision.md`](../../references/backlog-shape-decision.md)).
   If §6.3 is absent, **stop — never invent a breakdown.** Report that this feature was shaped
   single-ticket at handover and offer the two legitimate paths: (a) nothing to project — deliver it
   single-ticket; or (b) reshape it epic via the normal revision route (`discovery-handover-package`
   Step 3.5 re-run on the existing Brief, or a `handover-brief-review` fold), which adds §6.3, bumps
   the version, and **re-opens both sign-off sub-issues** — the breakdown must be ratified before it
   is projected. **Jira caveat for (b):** the sign-offs are Sub-tasks under a non-Epic source — do
   **not** convert the ticket (conversion orphans them); use the wrapper-Epic model (Step 5.1).
2. **The timing prerequisite holds.** Read `backlogTiming` from the config (default `post-gate`) and
   branch:
   - **`post-gate`:** the gate is passed — verify via **handover-retrieval** (never re-implement the
     gate read): both sign-off sub-issues in a Done-type state. If either is open — including
     re-opened after a post-sign-off Brief change — stop and report; an unratified breakdown must not
     become tickets.
   - **`pre-gate`:** the gate must **exist and be readable, not passed** — (a) the Brief is the
     ticket description (`discovery-handover-package` Step 7.0 ran), (b) both sign-off sub-issues
     exist (manifest `signoffIssues`), and (c) the invoking **`handover-workflow` or
     `prepare-amigo-session` run completed the mandatory brief review on the current Brief version in
     this same run**. The caller must pass its name, review-complete fact, and reviewed Brief version;
     otherwise stop and tell the user to use one of those orchestrators. Read the gate's live state via
     `handover-retrieval` with `mode: gate-status` and record it in the report: an open gate is the
     expected drafts-for-ratification state, not a projector failure.

### Tracker integration

- **Linear:** the Linear connector (or `LINEAR_API_KEY`).
- **Jira:** the Atlassian connector, plus the site/auth from the Closing the Loop config for REST
  operations the connector lacks.
- **Fallback (post-gate timing only):** with no tracker connection, write a pre-structured import
  file (`handover/[feature]-tickets-import.csv`, RFC-4180: `Title`, `Type`, `Description`, `Parent`,
  `Status`, `Labels`, `Blocks`) plus the manifest `backlog` block, and print upload instructions.
  Never abort for a missing integration. **In pre-gate timing, a CSV defeats the purpose** — the
  refinement session has nothing live to walk through: stop and ask (connect the tracker, or
  downgrade this handover to post-gate timing); never report a CSV as a successful pre-gate projection.

## Workflow

### Step 1: Verify both prerequisites

Run the checks above in order: the Brief shape (§6.3 present — the section is the source of truth,
the `Backlog shape:` header line corroborates it), then the timing prerequisite (via
**handover-retrieval**; use `mode: gate-status` for pre-gate inspection). Read the manifest
(`handover/[feature]-manifest.json`) for the source ticket key, the Brief version, and the sign-off
issue keys. Record the **Brief version** — every generated item is stamped with it.

If the manifest already carries a `backlog` block, this is a **re-run**: reconcile instead of
duplicating (Step 6).

### Step 2: Parse the Brief's breakdown

From the Brief (the ticket description at the current reviewed version):

- **§6.2** — the keyed criteria (`AC-n`), each tagged with its §4 flow.
- **§6.3** — the story map rows: slice id, flow, criteria keys, §6.1 blocks carried, demo prototype
  state, dependencies. This table **is** the backlog; nothing else is.
- **§6.1** — the spec blocks each slice names (copied into the story bodies verbatim).
- **§7** — production component import paths for the components each slice touches.
- **§4** — the prototype link when one exists (every story links it directly); omit it on a
  declared no-prototype handover.
- **§8** — constraints, to cross-check that each is a chore row or named in a slice.

### Step 3: Mechanical verification — before anything is created

Run the coverage checks; every failure is reported with the fix, and **a failed check stops the
provisioning** (the fix happens in the Brief via `handover-brief-review`, not by this skill
improvising):

- **Criteria bijection:** every §6.2 `AC-n` appears in exactly one §6.3 slice; no slice cites a key
  that does not exist. Criteria-in-Brief minus criteria-in-slices = ∅, both directions.
- **Self-containment:** every §6.1 block a slice names actually exists in §6.1; every slice has ≥1
  criterion (chores excepted) and a **demonstrable outcome** — a prototype state/screen, an observable
  behaviour tied to one of its criteria (when the handover declared no prototype), or a
  state/transition (agentic slices).
- **Constraint routing:** every §8 constraint is a chore row or named in a slice's spec column.
- **Explicit dependencies:** every `Depends on` entry references an existing slice; no story body may
  end up referencing a sibling's output without an edge.
- **Size flags (warn, not stop):** a slice spanning more than one flow or citing more than ~5
  criteria → flag "consider splitting"; these route to the humans, never auto-fixed.

### Step 4: Dry-run — show the tree, confirm before creating

Tickets are outward-facing artifacts the team will see. Print the full proposed tree first — epic
key, each chore and story with its criteria count, labels, and *blocks* edges — and confirm with the
user before any ticket is created. On confirmation, proceed; on "not yet", stop cleanly having
written nothing. This applies in **both timings** — pre-gate stories are exactly what the refinement
session will walk through, so the outward-facing bar is higher there, not lower. On reconcile
re-runs, confirm before any tracker write, refresh or create.

### Step 5: Provision

0. **Resolve labels, then retry-check — before every create.** Make the stable generated-item label
   operational before relying on it. **Linear:** `list_issue_labels`, call `create_issue_label` for
   `discovery-handover-backlog-item` if absent, and retain its id in `labelIds` for story/chore creates;
   resolve `discovery-handover-story` the same way before story creates. **Jira:** use the literal label strings
   (and stop with the project/field error if Labels is not writable; do not create unlabeled generated
   items). List all live Epic children, then select those carrying `discovery-handover-backlog-item`; also
   include legacy children carrying only `discovery-handover-story`. For a pre-change chore with no
   generated label or stamp, use `manifest.backlog.chores[].key/slice` as the only legacy fallback:
   fetch that live key and confirm its parent is this Epic before treating the manifest slice as its
   identity. A missing/deleted key may be recreated; a parent mismatch stops the run. Never infer a
   legacy chore from its title. Match labeled children against §6.3 by their
   `Slice <S-n>` / `Chore <C-n>` body stamp (pre-change stories already carry `Slice <S-n>`, so the
   same match covers them). A matching child already exists → **reuse it** (refresh its
   body only if its cited §s changed since its Brief-version stamp), never create a duplicate. **Two
   children claiming the same slice/chore id → stop and report** — a human resolves which is real.
   A generated child with **no slice/chore stamp → flag it as an orphan** and leave it alone;
   never guess. Run this check against both stories and chores before every create. This makes a retry
   after a partial failure safe even when the manifest write never happened.
1. **Epic.** Use the source ticket as the parent. **Jira: the conversion to Epic already happened at
   handover time** (`discovery-handover-package`'s preflight for an epic-shaped Brief, run before the
   sign-off children were created). Never convert here: a mid-flight conversion with Sub-task sign-offs
   attached succeeds silently and **orphans both sign-offs** — verified on the staging instance. If
   the source is still not an Epic (a handover that predates the preflight, or a feature reshaped epic
   after handover with Sub-task sign-offs already attached), stop and route back: re-run the preflight
   (only while no sign-off children exist yet), or explicitly choose the wrapper-Epic model (a new Epic that *links*, never
   copies, the source ticket) — ask, don't improvise. Linear: no conversion needed.
   Do not touch the description — it is the Brief.
2. **Chores** (first, so relations can point at them). Title: `[Chore] [Feature] — <chore name>`.
   Labels: `discovery-handover-backlog-item`. Parent: the Epic. Body starts with
   `Part of <EPIC-KEY> · Chore <C-n> · Cut from Brief v<version> · Constraint: <§8 ref>`, followed by the §8
   constraint text, why it matters, and suggested mitigation. Relation: *blocks* the stories that
   depend on it (per §6.3) and the Epic.
3. **Stories** — one per §6.3 story row, in map order. Title: `[Story] [Feature] — <slice name>`.
   Labels: `discovery-handover-story`, `discovery-handover-backlog-item`. Parent: the Epic. Body,
   verbatim from the Brief:

   ```markdown
   Part of <EPIC-KEY> — the Engineering Brief (the Epic's description) is the source of truth;
   on any conflict with the frozen PRD, the Brief wins. Delivery is gated by the Epic's
   ✋ PM + ✋ Dev sign-off — this story cannot be loaded for implementation until both are Done.
   Cut from Brief v<version> · Slice <S-n> · Flow: <§4 flow>

   # Acceptance criteria
   [The slice's §6.2 criteria, keys and Given/When/Then text copied in full]

   # Demo
   Done looks like: <the demonstrable outcome from the map row — a prototype state/screen, an
   observable behaviour tied to one of the criteria above, or an agentic state/transition>
   Prototype: <link from §4 — omit this line when the handover declared no prototype>

   # Specification (§6.1 slice)
   [Every §6.1 block the map row names, copied verbatim — never "see the Brief §6.1"]

   # Components
   [The §7 import paths for the components this slice touches]

   # Depends on
   [The blocks-relations, named — e.g. "C1 (migration) must be Done first"]
   ```

4. **Relations.** Create the *blocks* edges exactly as §6.3's `Depends on` column states — a
   dependency in the map that is not a tracker relation is a silent coupling the next dev misses.
5. **Gate visibility (pre-gate timing only).** After creating each story, add a *blocks* relation
   **from each sign-off issue to the story** (`✋ PM sign-off` blocks `S-n`; `✋ Dev sign-off` blocks
   `S-n`) so the not-yet-ratified state is visible natively — sprint tooling sees a blocked story, no
   label needed. Linear clears the blocked state automatically when the sign-offs complete; Jira keeps
   the link (a Done blocker reads as cleared by convention). The *mechanical* gate remains
   `handover-retrieval`'s live check at delivery time.

### Step 6: Record, reconcile, report

**Manifest — written incrementally, not once at the end.** Update the `backlog` block in
`handover/[feature]-manifest.json` **after each successful creation** (append the story/chore entry
as soon as its ticket exists), so a crash mid-provisioning leaves a manifest that reflects what was
actually created; sync the final block at completion. Shape:

```json
"backlog": {
  "epic": "<KEY>",
  "briefVersion": "<version the stories were cut from>",
  "provisionedAt": "<ISO date>",
  "stories": [ { "key": "<KEY>", "slice": "S1", "criteria": ["AC-1", "AC-2"], "briefVersion": "<v>" } ],
  "chores":  [ { "key": "<KEY>", "slice": "C1", "constraint": "<§8 ref>", "briefVersion": "<v>" } ]
}
```

**Re-runs reconcile against live tracker state, never duplicate.** Reconciliation keys off the
**Epic's live generated children** (the Step 5.0 generated-item-stamp match), not off manifest
presence — a missing or stale manifest (e.g. created-tickets-but-manifest-write-failed) must not cause
duplicates. Match §6.3 rows to live tickets by generated item id: unchanged rows are left alone; a row
whose cited §s changed since its `briefVersion` stamp gets its ticket body refreshed from the new Brief
version (and re-stamped); a new row becomes a new ticket; a removed row's ticket is flagged for the
user to close — never
deleted silently. Rebuild the manifest `backlog` block from the reconciled live state.

**Report.** The epic, each story/chore with its URL, the coverage-check results (including size
flags), and the next step: `handover-deliver-epic` takes the Epic key and walks the whole set — chores
first, in dependency order, one delivery run per child. `handover-workflow` Step 4 invokes it in the
autonomous mode; sprint planning may instead pick single stories up through the engineering entry point
directly.

## Output Contract

### Summary
One line: the epic key, N stories + M chores provisioned (or reconciled) from Brief v<version>, and
whether all coverage checks passed.

### Detail
The ticket tree with URLs; the criteria↔story matrix as written to the manifest `backlog` block; any
size flags routed to the humans; the CSV path when the offline fallback ran.

### Verification
The timing prerequisite held before anything was created (post-gate: both sign-off sub-issues Done;
pre-gate: invoked by `handover-workflow` or `prepare-amigo-session` after its mandatory review,
sub-issues existing, live gate state recorded); §6.3 existed and was projected verbatim (no invented
slices, no reduced spec); the
bijection/self-containment/routing/dependency checks all passed; every story carries its §6.1 slice
in-body and its Brief-version stamp (plus, pre-gate, its sign-off *blocks* relations); the dry-run
tree was confirmed before creation; no duplicate was created for a story or chore that already had a
live generated child.

### Follow-ups
Size flags awaiting a human split/merge decision; any removed-row tickets flagged for closing; "None"
when clean.

## Quality Bar

A run meets the bar when the timing prerequisite was verified via `handover-retrieval` before any
write; the source ticket is the Epic (no second epic, no copied description); every story is
buildable from its own body — criteria, §6.1 slice, demonstrable outcome, import paths, dependencies
all in-body; the manifest `backlog` block reproduces the criteria↔story matrix exactly; and a re-run
— including a retry against a half-provisioned Epic — reconciled by generated item id against live
children without duplicating stories or chores.

It fails the bar when a breakdown was invented (§6.3 absent but tickets created anyway), a story
names a behaviour without carrying its §6.1 spec (the "points-instead-of-states" failure at story
level), a coverage-check failure was papered over instead of routed back to the Brief, tickets were
created without the dry-run confirmation, or the Epic duplicates Brief content into a second surface.

## Anti-Patterns

**Inventing the breakdown.** §6.3 missing → the answer is "not ratified yet", never "I'll slice it
myself". The whole trust model rests on PM + Dev having approved the map at the gate.

**A second epic.** Creating a fresh Epic and copying the problem statement into it forks the source
of truth the moment the Brief revises. The source ticket, whose description already is the Brief, is
the Epic.

**Stories that point instead of state.** `See Brief §6.1 for the column spec` forces every dev to
open the Epic and find the right block. Copy the slice's spec into the story body — the map row says
exactly which blocks belong to it.

**Silent scope edits on re-run.** A re-run that quietly rewrites story bodies from a newer Brief
version without re-stamping, or deletes tickets for removed rows, destroys the audit trail. Refresh
and re-stamp visibly; flag removals for a human.

**Risk tickets.** A §10 "watch out for X" risk with no completable work is backlog noise nobody can
close. Risks stay in the Brief and reach every story session through the payload load; only §8
prerequisite *work* becomes chores.

## Critical Rules

- **Projector, not planner.** Render §6.3 verbatim. No slice, criterion, or dependency exists in the
  backlog that does not exist in the Brief.
- **Gate before write (post-gate timing); gate before delivery, always — via `handover-retrieval`.**
  Post-gate: both sub-issues Done before any write, read live — never from a file. Pre-gate: invoked
  by `handover-workflow` or `prepare-amigo-session` only (review-then-project in one run), sub-issues
  existing, gate state read live and reported — and the un-passed gate still blocks every story's
  delivery through the walk-up.
- **The source ticket is the Epic.** One key threads the label, the Brief, the gate, the attachments,
  the backlog, and later the PRs.
- **Every story stands alone** — §6.1 slice in-body, criteria in-body, Brief-version stamp,
  `discovery-handover-story` label, parent stamp, explicit *blocks* relations.
- **Coverage failures route back to the Brief** (`handover-brief-review`), never get fixed by this
  skill improvising in the tickets.
- **Dry-run confirm before creation; reconcile every generated story and chore by id on re-run.** In
  post-gate timing only, degrade to the CSV fallback when no tracker is connected. Pre-gate projection
  requires a live tracker and must stop rather than report a CSV as session-ready.
