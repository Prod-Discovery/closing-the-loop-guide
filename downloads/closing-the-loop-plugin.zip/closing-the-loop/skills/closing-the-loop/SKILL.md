---
name: closing-the-loop
description: "End-to-end orchestrator that closes the loop from product discovery to engineering delivery. It locates where a feature already is, then sequences the discovery engine, the configured handover path (governed PM + Dev approval or context-first code-grounded shaping with optional stories), and engineering delivery while threading one source of truth throughout. Use when someone says 'close the loop', 'take this from discovery to delivery', or wants one spine across product, design, and engineering."
trigger: [close the loop, discovery to delivery, prototype to production, end to end feature, product to engineering handover]
license: Apache-2.0
---

# Closing the Loop (Discovery → Delivery Orchestrator)

One spine across the whole arc a feature travels: from raw customer signal,
through a validated prototype, across the PM/engineering seam, into
implementation and a reviewed release. It sequences orchestrators that already
exist — it adds *entry detection*, *ordering*, *configured seam routing*, and
*forward hand-off of context*, not new behaviour.

> [!note] This is a draft spine, not a prescription
> The "Closing the Loop" project exists to develop a process the three
> disciplines build and stress-test themselves — not to follow a fixed
> playbook. Treat this skill as a starting point a team runs on a real feature,
> notices where it breaks, and adapts. Honesty about where it broke is the
> deliverable; a clean run that hid the seams is not.

> [!note] Spans three packages and two roles
> Discovery (Sense & Shape) is PM/designer work that can run without codebase
> access. The handover bridge is the PM/dev hybrid seam. Delivery is developer
> work that needs the repo. This orchestrator can drive the full chain in one
> session inside the target repo, or pick up partway when earlier stages already
> happened elsewhere.

## Objective

Drive a scoped feature from wherever it is in the loop to a reviewed,
release-ready implementation — without forking requirements or re-deriving
context that an upstream stage already produced. The configured handover path
defines the seam: `governed` ratifies a package through PM + Dev sign-off;
`context-first` shapes intent against code on the live ticket, optionally projects vertical stories,
and relies on ordinary collaborative engineering planning rather than a handover gate.

## When to Use

- A team wants to run discovery → delivery end to end on one feature and see the whole process work.
- A validated prototype (PM-authored) needs to become something engineering can implement confidently.
- A feature is partway through the loop and you want the right next stage run with full prior context carried forward.
- Someone names a feature, ticket, or prototype and asks to "take it all the way."

Do not use this skill when:
- The work is a single isolated edit or bug with no discovery or handover context — use `v-fix-bug` or `v-implement-code` directly.
- You only need one lane (just discovery, or just delivery) — invoke that lane's orchestrator (`discovery-to-prototype-engine`, `v-develop-feature`, `v-ticket-to-release`) directly.

## Workflow

### 1. Locate where the feature already is

Do not assume the loop starts at zero. Establish the current state first, then
run forward from there — never re-run a stage whose output already exists.

| If you have... | Enter at | Skip |
|---|---|---|
| Raw customer/competitive signal, no opportunity yet | Step 2 (Sense & Shape) | nothing |
| A chosen opportunity + validated prototype | Step 3 (the seam) | discovery |
| A governed approved package or context-first delivery-ready ticket | Step 4 (Deliver) | discovery + seam |

Confirm the entry point with the user before proceeding. Record what is being
treated as already-done so the hand-off forward is honest about its inputs.

### 2. Sense & Shape — delegate to the discovery engine

Invoke **discovery-to-prototype-engine**. Let it own the Sense → Shape stages:
customer insight synthesis, competitive landscape, opportunity scoring, PRD,
component readiness scan, interactive prototype, and experiment plan. Each stage has its
own checkpoint; do not collapse them. This orchestrator does not duplicate that
work — it only ensures the discovery outputs (PRD, validated prototype,
component/pattern decisions) exist before the seam.

The exit condition for this step is a **validated** prototype with the decisions
and rationale recorded — not just a generated one.

### 3. Cross the seam — delegate to the handover bridge

Read `handoverPath` from `~/.config/closing-the-loop/config.json`; default to `governed` when absent.

**Governed:** invoke **handover-workflow**. It compiles the Engineering Brief package, runs the
mandatory Brief review, optionally projects the ratified story map, and holds at the PM + Dev
approval gate. That gate is a hard stop for this path.

**Context-first:** invoke **handover-shape-feature** once. It preserves the live requirements and
appends a compact, sourced Delivery Context containing the code-grounded delta and behavioral
Gherkin. It recommends and confirms the backlog shape per feature; when the feature is epic-shaped it
also authors vertical `S-n` slices. If the Delivery Context carries a `### Story map`, invoke
**handover-project-stories** to show the proposed tree, obtain confirmation for tracker writes, and
project/reconcile the children; otherwise skip projection entirely. This path creates
no Brief, PRD freeze, AGENTS block, manifest, sign-off issue, or handover gate. Unresolved decisions
flow into the normal engineering plan gate.

Never mix the paths on one ticket. `discovery-handover` selects governed;
`context-first-handover` selects context-first.

**Re-evaluating the shape.** "Should <KEY> be an epic?" / "re-evaluate the backlog shape for <KEY>"
routes to the shaper for the ticket's path — `discovery-handover-package` (governed) or
`handover-shape-feature` (context-first) — run against the existing artifact, per
[`${CLAUDE_PLUGIN_ROOT}/references/backlog-shape-decision.md`](../../references/backlog-shape-decision.md).

### 4. Deliver — delegate to the engineering skills

Start the engineering chain from the selected seam output, never from scratch:

- **Governed:** `handover-retrieval` loads the approved Brief, frozen PRD, and AGENTS block.
- **Context-first:** delivery reads the live requirements plus Delivery Context directly using
  [`handover-shape-feature`'s delivery contract](../handover-shape-feature/references/delivery-contract.md).
  It checks only cited-code freshness; `gate: not applicable`.

Resolve the backlog shape from the artifact, never from config: the Brief carries `### 6.3 Story map`
(governed) or the Delivery Context carries `### Story map` (context-first), corroborated by projected
children in the path's marker family. **Epic-shaped — either path — invoke **handover-deliver-epic**
with the parent key.** It owns the walk over the projected children: enumeration, order, one delivery
run per child, and the close-out. Do not also drive the children yourself; one epic has one walker.

Single-ticket-shaped: prefer **v-ticket-to-release** for a tracker ticket. For local inputs, begin
**v-develop-feature** with the governed package or context-first requirements/context as
appropriate. Both paths plan before code; only the governed path treats a ratified Brief as an
already-clear spec.

Delivery does not exit this step on static signals. Hold the chain to three
conditions before treating the implementation as review-ready:

- **Behavioral evidence.** The feature ran in the application — not just a
  green unit suite and a passing linter. If the environment cannot run the
  app, that gap is stated prominently in the hand-off, never absorbed into a
  "done" claim.
- **Adversarial review with fail-without-fix tests.** The review stage tried
  to refute the implementation's own success claims, and every must-fix
  finding it confirmed is locked in by a test that fails without the fix.
- **A code-only branch.** Process artifacts — discovery trails, handover
  packages, specs, plans, review write-ups, prototypes — stay out of the
  production branch. They live on the ticket (the durable home the bridge
  already maintains) or in untracked local directories. Committing them, or
  editing `.gitignore` to force them in, pollutes the production repo with
  pilot exhaust; the branch carries code, tests, and real documentation only.

### 5. Release

When implementation has merged or is release-ready, invoke **v-prepare-release**
to verify, document, and package the change. Check the result back against the
governed Engineering Brief or the context-first ticket's intended outcomes and
preserve/delta statements, plus the original success criteria.

When the feature was epic-shaped, the walker has already verified the delivered children and closed the
parent, so this pass runs once here over the merged set — never per child.

### 6. Into production (Phase 2 — known gap)

Taking an AI-assisted implementation into a real production environment — behind
a feature toggle, observable with a pilot group, optimisable before full launch
— is a deliberately open Phase 2 question this bundle does **not** yet cover with
a dedicated skill. When the chain reaches a release, name this as the next step
and hand off to the team's production process; do not pretend a generic release
equals production readiness. Record what was needed here — it is direct input to
the Phase 2 "stage 8" work.

## Output Contract

### Summary
One line: the source of truth (opportunity/ticket key), the entry point used,
the selected handover path, the governed gate result or `gate: not applicable`,
and the resulting PR/release or stopping point.

### Detail
References to the discovery outputs; the governed package/manifest or
context-first live ticket; and the engineering PR/release. This skill produces
no document of its own.

### Verification
Confirm the configured path was followed: governed sign-off passed before
implementation, or context-first loaded fresh Delivery Context without
creating governed artifacts. Also confirm no stage was silently repeated and
one source threads from opportunity to PR.

### Follow-ups
Anything left open: an unvalidated prototype, governed blocked approval,
context-first planning decision, PR awaiting review, or the Phase 2 production
step.

## Quality Bar

A run meets the bar when:
- The entry point was confirmed and any already-done stages were recorded, not re-run.
- The configured handover path was followed; governed cleared sign-off, while
  context-first created no handover-specific sign-off and loaded its shaped
  Delivery Context before planning.
- Context flowed forward (each stage was seeded from the prior stage's output, not re-derived).
- The delivered implementation was exercised in the running application, adversarially reviewed, and every fixed must-fix finding has a test that fails without the fix.
- The production branch carries code, tests, and real documentation only — no process artifacts.
- One source of truth threads end to end and the run reports where it broke, honestly.

It fails the bar when:
- Governed implementation began before sign-off, or context-first began
  planning without loading its Delivery Context.
- Requirements were forked into a second document at any step.
- A stage was re-implemented here instead of delegated to the skill that owns it.
- "Done" was declared on static signals — green unit tests, lint, a DI smoke-test — without the application ever running, or a success claim outran what actually executed.
- Process artifacts (discovery/handover/spec/delivery docs, prototypes) were committed to the production branch, or `.gitignore` was edited to force them in.
- The run presented a frictionless story that hid the seams the project exists to find.

## Anti-Patterns

**Cold-starting the loop.** Re-running discovery when a validated prototype
already exists wastes effort and erodes trust. Detect the entry point and run
forward.

**Silently waiving or inventing a gate.** Governed requires its explicit PM +
Dev gate. Context-first deliberately has no handover gate. Applying either
rule to the other path defeats the configured working model — and waiving the
governed gate to "move fast" ships unvalidated intent into code. "We're moving
fast" is exactly when that gate matters most.

**Re-deriving requirements.** Each stage hands its output forward. Writing a
fresh spec or brief that ignores the upstream artifact forks the source of truth
and breaks traceability.

**Polishing away the breaks.** This is a process-discovery exercise. A run that
hides where the handover was thin or the prototype under-specified destroys the
most valuable output: knowing what to fix.

**Declaring victory on static signals.** "All tests pass, feature complete" on
a feature the application never executed. Green unit tests prove the units,
not the feature — the crash at the framework boundary, the dialog that never
renders, the corrupted export all hide behind a green suite. The loop is not
closed until the feature has actually run.

**Shipping the process with the product.** Committing the discovery trail,
handover package, or review write-ups to the production feature branch — or
editing `.gitignore` so they slip in. The ticket is the durable home for
process artifacts; the branch is for the change itself.

## Critical Rules

1. **Detect, then run forward.** Confirm where the feature is and never re-run a stage whose output exists. Record what was treated as already-done.
2. **Never skip the governed approval gate.** Governed delivery must not begin
   until both PM + Dev sign-off sub-issues are Done (their routed checklist
   items, open questions included, ticked first). Context-first creates no
   handover sign-offs and may enter planning as soon as its reconciled context
   is loaded. Apply each path's contract only to that path.
3. **Orchestrate, do not re-implement.** Every stage delegates to the skill that owns it; this skill only sequences, gates, and passes context forward.
4. **One source of truth, end to end.** The opportunity/ticket key threads through discovery, handover, and the PR. Do not fork it.
5. **Degrade gracefully.** If a downstream skill is absent, stop at the last completed gate and hand its output over for a manual continuation rather than failing.
6. **Production is Phase 2.** Always name the into-production step as an out-of-scope follow-up; never equate a generic release with production readiness.
7. **No "done" without a behavioral run.** The delivery stage exits only when the feature was exercised in the running application (or the inability to run it is reported as an explicit gap), the review was adversarial, and fixed findings are locked in by fail-without-fix tests.
8. **The production branch is code-only.** Process artifacts live on the ticket or in untracked directories — never committed to the feature branch, never smuggled in through `.gitignore` edits.

## Triggers

| To run... | Say... |
|-----------|--------|
| The full loop from raw signal | "Close the loop on <feature>" / "Take this from discovery to delivery" |
| From a validated prototype | "We have a validated prototype — take it through to a PR" |
| From a prepared handover / ticket | "Run delivery from this handover" / "Take PRO-5 all the way" |
| Context-first seam only | "Reconcile this ticket with the codebase and stop before delivery" |
| Governed approval only | "Run the governed loop but stop at the approval gate" |
| Re-evaluate a feature's backlog shape | "Should KAN-63 be an epic?" / "Re-evaluate the backlog shape for <KEY>" — routed to the path's shaper |
