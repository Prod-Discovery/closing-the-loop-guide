---
name: v-setup-agent-context
description: Create and maintain AGENTS.md, CLAUDE.md, or equivalent context files that help AI coding agents work effectively in a repository, including first-time bootstrap of a repo for AI-assisted development. Use when authoring or regenerating AGENTS.md or CLAUDE.md, when onboarding a repo for agents the first time, when agents repeatedly miss the same project context, when commands or conventions are non-standard, or when the user says "set up AGENTS.md" or "make this agent-ready".
trigger: [author agents.md, write the agent instructions, regenerate agents.md, update conventions doc, refresh repo context for ai, first time setup, new repo onboarding, bootstrap this repo for ai, one-shot agent setup, prepare repo for agents]
license: Apache-2.0
---

# Setup Agent Context

## Objective

Create concise, high-signal context files that help AI coding agents work
effectively in a repository without wasting tokens on information they can
discover themselves. The goal is a file that contains only what an agent
cannot infer from the code — specific build commands, non-obvious conventions,
custom tooling quirks, and project-specific constraints.

## When to Use

- Setting up a repository for AI-assisted development for the first time
- Agents repeatedly make the same mistakes due to missing project context
- Build, test, or deployment commands are non-standard, or conventions differ
  from common defaults
- The user asks to "set up AGENTS.md", "onboard this repo", or "make this
  agent-ready"

Do not create a context file when the project uses standard tooling with no
customization, when the only content would repeat README.md, or when the file
would just describe what the code does — agents discover all of that
themselves.

## Workflow

### 1. Audit Current Agent Friction Points

Before writing anything, identify the specific problems: what agents get
wrong repeatedly in this repo, which commands fail because the agent guesses
wrong, which conventions get violated, which setup steps are not obvious. If
you have no evidence of agent friction, observe one session and note where
the agent stumbles. Do not write a context file based on speculation.

### 2. Choose the File Format

Pick the format that matches your primary AI tool:

| Tool | File | Scope |
|------|------|-------|
| Cross-tool standard | `AGENTS.md` (repo root) | All agents |
| Claude Code | `CLAUDE.md` (repo root) | Claude Code sessions |
| GitHub Copilot | `.github/copilot-instructions.md` | Copilot workspace |
| Cursor | `.cursor/rules/*.md` | Cursor sessions |
| Codex CLI | `AGENTS.md` + `AGENTS.override.md` | Codex sessions |

For maximum compatibility, write `AGENTS.md` at the repo root. Add
tool-specific files only if you need tool-specific instructions. For
monorepos, place additional context files in subdirectories — most agents
read the nearest file in the directory tree upward.

### 3. Write Only Non-Inferable Content

Structure the file with short, specific sections. Every line must pass the
test: "Could an agent figure this out by reading the code?" If yes, omit it.

**Include:** custom build, test, lint, and deploy commands; environment setup
steps (required env vars, services, databases); non-obvious conventions and
why they exist; security constraints (what not to do, what requires manual
approval); common pitfalls specific to this codebase; dependency management
quirks.

**Exclude:** project description, architecture overview, technology stack,
coding style basics, and anything already in README, CONTRIBUTING, or package
configs — agents read those.

### 4. Keep It Under 100 Lines

The best context files are 30-80 lines. Every additional line is tokens the
agent processes before doing useful work; longer files increase the number of
steps agents take without improving task success.

If you need more than 100 lines, split into directory-scoped files: a root
`AGENTS.md` for repo-wide conventions and commands, plus per-directory
context files for area-specific instructions.

### 5. Use Imperative, Agent-Directed Language

Write instructions as direct commands, not descriptive prose. "Run
`make test-integration` for integration tests, not `make test`" beats "the
project has integration tests that can be run using make."

### 6. Validate With a Real Agent Session

After creating the file, run a representative task with an AI agent and
verify: the agent uses the correct build/test commands, follows the
conventions specified, and does not waste time on things the context file
should prevent — or on processing verbose context. If the agent ignores part
of the context file or performs worse, trim or rewrite that section.

### First-Time Bootstrap

When onboarding a repo that has never had agent context (no `AGENTS.md` or
equivalent exists), extend the workflow with two additions:

- **Inventory the verification commands.** Discover every lint, type-check,
  test, and format command from configs and CI — verify, do not assume
  standard tooling. Record each command's status: configured and passing,
  configured but failing, or not configured. The context file must include
  these commands — they are the safety net for agent-generated code.
  Recommend closing gaps (missing formatter, broken suite), but do not block
  the bootstrap on perfect CI.
- **Exit through a real task.** The bootstrap is complete only when an agent
  finishes one representative task — a small fix or feature that exercises
  the documented commands and conventions — using the new context file, and
  verification confirms the output. If the agent still struggles, refine the
  file based on what you observe before calling the repo onboarded.

Optionally, add a short "working with agents here" note to the README
(which context file agents read, the verify command). Prefer keeping
everything in the context file itself — a second document is a second
thing to keep current.

## Output Contract

A completed v-setup-agent-context pass produces these sections under `## Output Contract`:

### Summary

One sentence stating what was created or updated (e.g. "Wrote 62-line AGENTS.md
covering build/test/lint commands, monorepo conventions, and known pitfalls").

### Detail

The context file itself. Include only the sections relevant to the project; use
this template and delete what's not needed:

```markdown
# AGENTS.md

## Build & Test
- Build: `[exact command]`
- Test: `[exact command]`
- Lint: `[exact command]`
- Type check: `[exact command]`

## Environment Setup
- [Required setup step with exact command]
- [Required env var: what it's for, not the value]

## Conventions
- [Convention with rationale if non-obvious]

## Do Not
- [Prohibited action with brief reason]

## Common Pitfalls
- [Pitfall: what goes wrong and how to avoid it]
```

See ./references/example-agents-md.md for a worked example following this template.

For a first-time bootstrap, also report the verification-command inventory:
each lint/type/test/format command with its configured/passing status.

### Verification

- File path written and final line count (target 30–80, hard cap 100)
- Confirmation that every line passes the "could an agent infer this from
  the code?" test
- Result of a representative agent session run with the file (correct
  commands used, conventions followed, no wasted exploration)

### Follow-ups

- Content explicitly deferred to directory-scoped context files
- Known gaps that are not yet observed but may need entries later
- Verification tooling gaps found during a first-time bootstrap
- "None" when the file is complete and validated

## Quality Bar

A context file meets the quality bar when:

- Every line contains information an agent cannot discover from the code
- Total length is within the line budget (30-80 lines, hard cap 100)
- Commands are exact and copy-pasteable, not described in prose
- An agent session using this file makes fewer mistakes than one without it
- No duplication with README, CONTRIBUTING, or config files
- Instructions are imperative and specific, not descriptive and vague
- The file is actually maintained — stale instructions are worse than none

## Anti-Patterns

**The kitchen sink.** Including every possible instruction "just in case."
Each unnecessary line costs tokens and attention. Include only instructions
that address observed problems or non-obvious conventions.

## Critical Rules

1. **Only non-inferable content.** Every line must pass the test: "Could an
   agent figure this out from the code?" If yes, delete it. The context file
   is for the gaps, not a summary.

2. **Commands, not descriptions.** Show the exact command. Agents execute
   commands; they do not read about commands.

3. **Evidence-derived, never boilerplate.** Derive every line from observed
   friction and verified repo facts — never from generic LLM boilerplate.
   Whether a human or an agent writes the file, judgment about what agents
   actually struggle with in this repo is the entire value.

4. **Maintain or delete.** When commands, conventions, or tooling change,
   update the file. If no one is maintaining it, delete it — stale guidance
   is worse than no guidance.

5. **One source of truth.** Use AGENTS.md as the cross-tool standard. Add
   tool-specific files only when tool-specific instructions are needed.
   Never duplicate content across files.
