---
name: v-update-docs
description: Keep documentation accurate and current as behavior changes, treating docs as a deliverable that ships with code. Use when behavior has changed and existing docs describe the old behavior, when an interface or configuration has been modified, when new functionality needs user- or developer-facing explanation, when examples or commands in docs have gone stale, or whenever a change would leave the README, onboarding, or handoff content out of sync.
trigger: [update docs, fix the readme, document this change, add documentation, check if docs are stale]
license: Apache-2.0
---

# Update Docs

## Objective

Maintain documentation as a first-class deliverable that ships in the same
changeset as the code it describes. Documentation is not a follow-up task — it
is part of the definition of done. The goal is accurate, verifiable
documentation that reflects the current state of the system.

## When to Use

- Behavior has changed and documentation describes the old behavior
- An interface, configuration, or setup process has been modified
- New functionality has been added that users or developers need to understand
- Existing documentation contains stale examples, broken commands, or dead
  links
- The user asks to "update docs", "fix the README", or "check if docs are
  stale"

Do not use this skill when no behavior has changed and documentation is
accurate. Documentation exists to describe something real — if nothing has
changed, nothing needs documenting.

## Workflow

### 1. Discover Existing Documentation

Before writing or changing anything, find what documentation exists: README
and contribution guides at the repository root, any dedicated documentation
directory, inline comments and docstrings in the changed code, configuration
files that carry documentation, onboarding and setup guides, decision
records, and generated docs. Do not assume you know the layout — different
projects organize documentation differently. Search before assuming, and
note the audience and conventions of what you find so updates match the
surrounding style.

### 2. Audit Documentation Scope

- **Map changed files to documentation.** For every file or module changed in
  the current work, identify which documentation references it — direct
  mentions (paths, function names) and indirect ones (described behavior,
  examples that exercise the changed code).
- **Check for stale references.** Search docs for renamed files, removed
  functions, changed defaults, or deprecated patterns — these are often
  missed because they are not in the diff.
- **Identify gaps.** New functionality with no documentation at all — a new
  option, command, or error message — is as important as inaccuracies.
- **Prioritize by impact.** User-facing docs (README, setup,
  troubleshooting) before internal ones.

### 3. Update or Create Content

When updating existing documentation, fix factual inaccuracies first — wrong
commands, incorrect paths, outdated parameter names — then remove content
about removed features or obsolete configurations rather than leaving it
alongside current content. Preserve the existing structure and style; do not
rewrite a section in a different voice unless the whole document is being
restructured.

When creating new documentation, start with the reader's most common
question, qualify any claim you have not verified in all cases, and link the
new content from discovery points (README, docs index, logical parent pages)
— an unlinked guide effectively does not exist.

### 4. Verify by Execution

Every piece of documentation must be verified, not assumed:

- **Run every command** shown in the documentation and confirm it produces
  the described output.
- **Test every example.** If docs reference specific signatures or return
  values, verify those match the current code. Stale examples are worse than
  no examples — they teach wrong things with the authority of documentation.
- **Check every link** — internal, external, and same-page anchors.
- **Walk the described path.** Read the docs as a new user following them
  step by step: does each step follow, are prerequisites stated, does the
  described result match what actually happens?

### 5. Record Known Gaps

Not all documentation can be written in one pass. Record remaining gaps
explicitly — what is missing and where it should live — and prioritize them
by user impact. Never write aspirational documentation: if a feature is not
built, do not document it as if it exists. Document the current state; future
documentation belongs with the future work.

## Output Contract

Every documentation update produces these sections under `## Output Contract`:

### Summary

One sentence stating which docs were touched and why (e.g. "Updated README and
two reference pages to reflect the new auth flow").

### Detail

- **Docs reviewed:** [list of documentation files examined]
- **Docs updated:** [file path]: [what changed and why]
- **Docs created:** [file path]: [what it covers and why it was needed]

### Verification

- [commands tested: pass/fail]
- [examples verified: pass/fail]
- [links checked: pass/fail]

### Follow-ups

- [documentation still needed, with priority and location]
- "None" when documentation is complete for the shipped behavior

## Quality Bar

Documentation meets the quality bar when:

- Every command, example, and link has been verified to work
- The documentation describes the current behavior, not a previous or
  planned version
- Doc changes ship in the same changeset as the behavior change
- The writing matches the surrounding documentation conventions
- New documentation is linked from discovery points
- Stale content has been removed or updated, not left alongside current
  content

## Anti-Patterns

**The orphan update.** Updating the primary README but missing documentation
in other locations (setup guides, inline comments, configuration docs, API
references) that also reference the changed behavior. Always search for all
references, not just the most obvious one.

## Critical Rules

1. **Ship docs with code.** Documentation updates belong in the same
   changeset as the behavior change — never deferred to a separate task.

2. **Verify everything by execution.** Every command, example, and link must
   be verified. Do not assume unchanged documentation is still correct.

3. **Discover before writing.** Always search for existing documentation
   before creating new content. Duplicates diverge and create conflicting
   sources of truth.

4. **Write for the current state.** Never document planned functionality as
   if it exists, and never leave removed functionality documented "for
   reference." Record gaps explicitly instead.

5. **Match the conventions.** Consistency across the project's documentation
   is more valuable than any individual improvement to style or organization.
