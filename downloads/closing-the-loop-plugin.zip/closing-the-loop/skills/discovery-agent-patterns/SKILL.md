---
name: discovery-agent-patterns
description: "Optional agent-path add-on: applies Visma's guide for Great Agentic Experiences (formerly the Agent Design Guidelines). Mode 1, after the agent PRD, writes a Pattern Card: patterns, level per task, design moments to prototype. Mode 2, after the prototype, audits it against them. Opt-in; also standalone on any agent PRD or prototype. Use for 'run the agent pattern check', 'pattern card', 'check my agent against the guide', 'which agent patterns do I need', 'pattern audit', 'assess my agent'."
license: Apache-2.0
---

# Agent Patterns Add-on (optional, agent path)

Applies **Visma's guide for Great Agentic Experiences** to one agent: picks only the patterns this agent actually needs, turns them into a few concrete design moments for the prototype, and later checks the prototype against them.

Two modes:

- **Mode 1: Pattern check.** Reads an agent PRD and writes a **Pattern Card**: the selected patterns, a level-per-task table, and 4 to 5 design moments. Runs after Stage 3.2+3.3.
- **Mode 2: Pattern audit.** Reads a prototype and its Pattern Card and reports, per pattern, whether the prototype shows it. Fixes only on request. Runs after Stage 5.

## Workflow

1. Load the patterns once — see [Source of the patterns](#source-of-the-patterns).
2. **Mode 1** (after the agent PRD): read the behaviour script, select the patterns, set a level per
   task, write 4 to 5 design moments, confirm the Pattern Card, save it, hand off to Stage 4.
3. **Mode 2** (after the prototype): check every pattern across all the agent's files, report verdicts
   without a score, fix only on request, save the audit, hand off to Stage 6.

## Opt-in, always

This add-on never runs by itself. Run it only when the user asks for it, or says yes to the offer made after the agent PRD or the prototype. If they decline, drop it without comment and continue where they were. Users on the standard (non-agentic) path are never offered it.

It never edits the PRD or changes the autonomy level the user confirmed in Stage 3. It reads saved files and writes its own.

## Where files live

Read and write in the discovery working directory, `$DISCOVERY_DIR` (`/home/claude/discovery-engine/` in Cowork, `./discovery-engine/` locally), with a copy in `$OUTPUTS_DIR` unless that resolves to the same directory. Full rules: [`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md).

## Source of the patterns

**Naming.** Always call it **Visma's guide for Great Agentic Experiences** the first time, and "the guide" after that. It used to be called the Agent Design Guidelines, and the sources below may still use that name. Don't repeat the old name to the user, unless they use it themselves.

The guide changes over time: patterns get reworded, added and sometimes removed. So before anything else, load the patterns **once** per run, from the first of these that works:

1. **The live guide, through GitHub.** The guide's repository (`Prod-Discovery/agent-design-guidelines`) is internal to Visma's GitHub, so an anonymous download fails. If you can run shell commands and `gh` is signed in, run `gh api repos/Prod-Discovery/agent-design-guidelines/contents/patterns.json -H "Accept: application/vnd.github.raw"`. If that fails, try `curl -fsSL https://raw.githubusercontent.com/Prod-Discovery/agent-design-guidelines/main/patterns.json` (works only if the repository is public again). Use the result only if it is complete, valid JSON with a non-empty `"patterns"` list. In that file each pattern has `id`, `name`, `rule`, `intro`, `look_for`, `do` and `avoid`, and its page in the patterns library is the top-level `site` address followed by `#patterns-<id>`.
2. **The bundled copy**, [`references/patterns.md`](references/patterns.md) in this skill's folder: the same guide as of its last sync (the first line says when, and which build). Each pattern lists its id, rule, "What to look for", Do, Avoid and its `page:` link. Maintainers refresh it with `python3 scripts/sync_patterns.py`.

If the live read fails (offline, `gh` not signed in, no access, or the file is cut off), use the bundled copy without making a fuss about it. If neither is available, say so and stop: "The patterns reference is missing from this plugin install. Please update the Closing the Loop plugin." Do not improvise.

Say which source you used, in one short line in the Pattern Card or audit header: "Patterns: live guide, fetched [date]" or "Patterns: bundled copy, build [build id from references/patterns.md]".

- **Cite every pattern by its id and its name**, e.g. `autonomy-levels` (Autonomy levels). Ids never change; names can. Always use the name from the source you loaded, not the names in this file.
- **Link every pattern you mention** to its page in the patterns library, taking the address from the source you loaded, never from memory. The library shows each pattern with live examples, which says more than any summary in chat. (It needs a Visma sign-in.)
- **Never invent a pattern**, and never describe one from memory. Use its rule, "What to look for", Do and Avoid from the source.
- **Only use patterns that exist in the source.** The ids in the tables below are a guide, not a promise: if one isn't in the source (it was removed from the guide), skip it silently and carry on with the rest. A pattern in the source that isn't in the tables can still be selected when the behaviour script clearly calls for it; use its own rule and "What to look for".

---

## Mode 1: Pattern check

### Input

The agent PRD with its **Agent Behavior Script**. Look for it in this order:
1. `stage-3-prd-agent-*.md` in `$DISCOVERY_DIR` (runs before 0.2.11 named it `agent-prd-*.md`)
2. A file the user uploads or names
3. A pasted agent spec or description. Any agent design works, made in the engine or not.

If several agent PRDs exist, ask which one, as a lettered list. If there is none, ask the user to share one or describe the agent in a few sentences.

### Step 1: Read the behaviour script

Extract, quoting the PRD where you can: the autonomy level, goal, trigger, inputs, tools (read and read-write), human checkpoints and failure scenarios.

Two signals are not fields in the behaviour script, so infer them and say what you inferred them from:
- **Batch or high-volume work**: from Inputs and Goal (many invoices, all employees, every transaction).
- **Recurring or long-running work**: from Trigger (a schedule, a monthly close, work that spans days).

### Step 2: Select the patterns

Each field pulls in specific patterns, if they exist in the source you loaded. A typical agent ends up with 5 to 7 patterns, never all of them.

| Behaviour script field | Patterns it pulls in |
|---|---|
| **Always included** (when present in the source) | `say-its-an-agent` (disclosure is required by the AI Act, article 50), `activity-log` (whenever the agent can write data) |
| Autonomy level | `autonomy-levels`, `suggestions`, `autonomy-evolution` |
| Trigger, when it isn't user-initiated | `triggers` |
| Tools with read-write access | `actions`, `undo` |
| Human checkpoints | `actions`, `suggestions`, `hand-over` |
| Failure scenarios | `failure-disclosure`, `uncertainty`, `hand-over` |
| Batch or high-volume inputs (inferred) | `exceptions`, `live-progress` |
| Recurring or long-running work (inferred) | `recap`, `activity-log` |

For every selected pattern, write one line on **why** (which field pulled it in) and one or two lines on **what it means for this agent**, using the pattern's "What to look for" and Do. Make it concrete: "every reminder email says 'Drafted by Reminder agent'", not "disclose the agent". If a pattern only applies weakly, leave it out rather than padding the list.

### Step 3: Level per task

The guide sets a level **per task**, not for the whole agent. Split the agent's work into its tasks (usually 3 to 6) and give each one a level, using the guide's words:

- **Off**: the person does it, the agent doesn't touch it (salary changes, filings, anything the PRD reserves for a human)
- **Suggest**: the agent suggests, the person starts it
- **Ask first**: the agent prepares it, the person approves
- **Auto**: the agent acts on its own and tells the person

Base each level on the stakes and on the PRD's human checkpoints. Pay, filings and salary changes never run on Auto.

These levels sit beside the PRD's **autonomy level** (Chatbot, Copilot, Assistant or Agent) and don't replace it. The autonomy level says what kind of agent this is. The level per task says how much it may do on its own for each task. Keep both sets of names as they are. Under the table, add one line on how the levels fit the autonomy level the user confirmed in Stage 3:

| Autonomy level (Stage 3) | Typical levels per task |
|---|---|
| Chatbot | Off or Suggest. It answers questions and never acts |
| Copilot | Suggest |
| Assistant | Ask first. Auto only for simple, reversible tasks the user asked for |
| Agent | Auto for routine tasks, Ask first at the PRD's human checkpoints, Off for pay, filings and salary changes |

If the source still names the levels per task Assistant, Copilot or Autopilot, it is an older copy of the guide. Use Off, Suggest, Ask first and Auto anyway, and don't quote the old names.

Do not change the PRD's autonomy level. The table sits beside it.

### Step 4: Design moments

Do not hand the user a list of patterns to read and approve. Show the patterns as **4 to 5 design moments in the user's flow**: the moments in a working day where a person meets the agent, in the order they happen.

Pick the moments from the **riskiest human checkpoint** and the **scripted failure scenario** first, then the agent's first appearance (where disclosure lands). Each moment covers one or two patterns. Write each one like this:

```
Moment 2 · Tuesday 09:12, the reminders are ready
What the person sees: a batch of 14 drafted reminders, "3 need you" at the top,
each draft marked "Drafted by Reminder agent".
What they do: approve the 11 routine ones together, open the 3 exceptions.
Patterns: `exceptions` (Exceptions), `say-its-an-agent` (Agent disclosure)
See it: <each pattern's page link, from the source you loaded>
```

At most 5 moments get built into the prototype, so Stage 6 can test a few moments well. List every other selected pattern under **"Applies, not prototyped"** with one line each, so nothing is lost.

### Step 5: Checkpoint

First explain what the card is, in plain words, before showing it. Many users have never seen one. Say it like this, adapted to the agent:

```
Here's your Pattern Card. It's a one-page summary of how this agent should
behave with people: which patterns from Visma's guide for Great Agentic
Experiences it needs, how much it may do on its own for each task, and the
4 to 5 moments to build into the prototype.

Why save it: Stage 5 builds these moments into your prototype, and the pattern
audit after Stage 5 checks the prototype against this same card. It's also a
quick way to brief your designer or developer.
```

Then present the Pattern Card (format below) and ask:

```
Does this match how your agent should work?

A) Looks right, save the Pattern Card
B) Change a moment or a task's level (tell me which)
C) Add or drop a pattern
```

Iterate until the user picks A.

### Step 6: Save and hand off

1. Write the card to `$DISCOVERY_DIR/stage-3-pattern-card-[feature-name].md`, using the same feature name as the PRD (keep the `stage-3-pattern-card` prefix — it is how progress is detected)
2. Copy it to `$OUTPUTS_DIR` unless that is the same directory
3. Call `present_files` to show it. (If `present_files` is not available, state the saved file path instead.)
4. Only now point to the next stage:

```
Pattern Card saved. Next step → Stage 4: Scan your component library.
When we get to the prototype (Stage 5), I'll build these design moments into it,
so you can test them with real users.

Type: "Scan our component library" or "Run Stage 4"
```

### Pattern Card format

```markdown
# Pattern Card: [Feature name]

> What this is: the patterns this agent needs from Visma's guide for Great Agentic Experiences, how much it may do on its own per task, and the moments to build into the prototype. Stage 5 builds the prototype from it, and the pattern audit checks the prototype against it.

Agent PRD: [file name] · Autonomy level (Stage 3): [level]
Patterns: [live guide, fetched YYYY-MM-DD | bundled copy, build abc1234]

## Selected patterns
| Pattern | Why | What it means for this agent |
|---|---|---|
| `say-its-an-agent` Agent disclosure | Always included | ... |

## Level per task
| Task | Level | Why |
|---|---|---|
Fits the Stage 3 autonomy level ([level]): [one line]

## Design moments (built into the prototype)
### Moment 1 · [when]
What the person sees: ...
What they do: ...
Patterns: ...
See it: [link]

## Applies, not prototyped
- `pattern-id` Name: one line

## Inferred
- Batch work: [yes/no], from [field]
- Recurring work: [yes/no], from [field]
```

---

## Mode 2: Pattern audit

### Input

Everything the user shares about the agent is **one agent**, audited once:

- The prototype: the standalone export `$DISCOVERY_DIR/stage-5-prototype.html`, and for a component prototype the source that `stage-5-prototype-source.md` points to (its `prototype-pack.md` names which files render each screen) — or any prototype file the user gives you
- Anything that describes the agent: agent instructions or a system prompt (for example an agent `.md` file), the agent PRD, a spec, screenshots or a description
- The Pattern Card: `stage-3-pattern-card-*.md`

Read every file before writing any verdict. Never audit file by file, and never give separate verdicts, summaries or results per file.

If there is no Pattern Card, ask:

```
I don't have a Pattern Card for this agent yet. How should I audit it?

A) Build the Pattern Card first from the agent PRD (recommended, takes a few minutes)
B) Audit against the always-included patterns and what your files show
```

With **B**, check the two always-included patterns plus any pattern the files clearly show or describe. Don't report the other patterns as gaps: a pattern this agent doesn't need is not a gap. Say once that the audit is narrower without a card.

### Step 1: Check each pattern

Load the patterns as described in "Source of the patterns". For each design moment's patterns, and for the always-included patterns that exist in the source, check all the files together against that pattern's "What to look for" list. If the Pattern Card names a pattern that is no longer in the source, say it was removed from the guide and leave it out of the audit. Give one verdict per pattern:

- **Pass**: the prototype shows it. Point to where (screen, element, the visible text).
- **Pass (described, not shown)**: the instructions, PRD or spec cover it, but the prototype doesn't show it. Name the file and quote the line. Keep this separate from a full pass, because test users only see the prototype.
- **Partial**: some of it is there. Say which "What to look for" items are missing.
- **Gap**: not in any file. Say what the person would need to see.

Base every verdict on something you can point to, and name the file it's in. If you can't tell (e.g. a state that only appears after an interaction you can't see), say "can't tell from the files" instead of guessing. List the "Applies, not prototyped" patterns without a verdict.

### No score in the plugin

Don't give a score, a percentage, a grade or a band, and don't calculate the guide's Assess score from the source you loaded, even when the user asks for "a score". The official score comes from **Assess your agent** on the guide's website. This way the plugin and the website never show two different numbers for the same agent. If the user asks for a score, say so and point them to the website (below).

### Step 2: Report and offer fixes

Lead with a one-line summary of verdicts only, no score ("4 of 6 patterns pass, 1 of them described but not shown, 1 partial, 1 gap"). Then a table per pattern with verdict, evidence (file and location) and the missing items, each pattern linked to its page in the library.

Under the table, send them to the website for the official score, naming the files you audited:

```
For the official score, upload [the files you audited] to Assess your agent
on the guide's website: [the Assess page link]
```

Take the link from the source you loaded, never from memory: from the live guide, the top-level `site` address followed by `#assess`; from the bundled copy, the `Page:` line in its "Assess your agent" section.

Never change the prototype unless the user asks. Then offer:

```
A) Fix the gaps in the prototype (I'll update it and re-check)
B) Save the audit and continue to Stage 6, the experiment plan
C) Save the audit and stop here
```

**Fixing goes through the prototype skill.** Hand the gaps to `prototype-from-components` as one refine round: it changes the live surface, keeps its stand-in flags, appends the decision log, refreshes `prototype-pack.md` and re-exports `stage-5-prototype.html`. Change only what the gaps need, then re-run this audit on the refreshed prototype.

### Step 3: Save

1. Write the audit to `$DISCOVERY_DIR/stage-5-pattern-audit-[feature-name].md` (keep the `stage-5-pattern-audit` prefix). Include the files audited and the line pointing to Assess your agent
2. Copy it to `$OUTPUTS_DIR` unless that is the same directory, and call `present_files` (or state the path)
3. If the user continues, hand off to Stage 6: "Create test plan" or "Run Stage 6". The audit's gaps and partials are useful test questions for the usability script.

---

## Writing guidelines

- Plain language, concrete to this agent. "The agent asks before sending anything over €2,000", not "human-in-the-loop for high-value actions".
- Use the guide's own words from the source you loaded for rules and checks; don't paraphrase them into something new.
- Pattern names are for the people designing, not for the end user. Never put pattern names or ids into the prototype's UI.
- Every pause ends with a short choice the user can answer with one click or one letter (see "Choices and next steps").

## Chaining

### Standalone use
Both modes run on any agent design, made in the engine or not: a pasted agent spec, an agent instructions file, a PRD from another tool, or a prototype file. When invoked cold, ask for what the mode needs (an agent PRD or description for Mode 1; a prototype for Mode 2) and work from that. Don't require earlier stage files.

### As part of the engine
- **Mode 1 input from**: Stage 3.2+3.3 (`discovery-agent-prd`), the saved `stage-3-prd-agent-*.md`
- **Mode 1 output to**: Stage 5 (`prototype-from-components`) builds the design moments into the prototype
- **Mode 2 input from**: Stage 5, the saved prototype + the Pattern Card
- **Mode 2 output to**: Stage 6 (`discovery-experiment-plan`)

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (`AskUserQuestion` in Claude Code and Cowork), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. Buttons mirror the listed options exactly — never add one that isn't an option. A `Type: "..."` handoff becomes a button with that wording, for example "Run Stage 4", next to "Stop here".
- **Fall back to the list.** Without such a tool, or with more than 4 options, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** When this skill runs as part of the full engine (earlier stage files exist in `$DISCOVERY_DIR`), start each checkpoint with one line: `Pattern check (optional) · Agent path` or `Pattern audit (optional) · Agent path`. Skip the line when the skill runs standalone.
