---
name: discovery-feedback
description: Collect an anonymous 1-5 rating and optional comment about the DISCOVERY lane — the Discovery to Prototype Engine, stages 0-6. Use when the user says "feedback on discovery", "rate the discovery engine", "feedback on the prototype workflow", or finishes / abandons a discovery run. NOT for the engineering delivery skills or the handover bridge — that is `v-give-feedback`. On a bare "give feedback" with no lane named, ask which one first.
---

# Discovery Feedback

Collects anonymous user feedback (1-5 rating + optional comment) about the **discovery lane** — the Discovery to Prototype Engine, stages 0–6. The maintainers use this signal to prioritize improvements.

## Scope — which feedback skill handles what

This plugin has two feedback routes, going to two different maintainer teams. Getting this wrong sends a developer's complaint about a code review to the discovery team, or a PM's prototype gripe to the engineering team.

| The feedback is about… | Skill | Destination |
|---|---|---|
| Discovery stages 0–6: customer insights, competitive landscape, opportunity scoring, PRD, component readiness, prototype, experiment plan | **this skill** (`discovery-feedback`) | Discovery engine maintainers — always anonymous, 1–5 rating + comment |
| The engineering delivery skills (`v-*`) or the handover bridge (`discovery-handover-package`, `handover-*`, `create-backlog-from-brief`) | `v-give-feedback` | Visma skills maintainers — free-form, with an optional name/email |

**If the user just says "give feedback" without naming a lane, ask which** — "Is this about the discovery workflow, or about the engineering/handover side?" — and hand off to `v-give-feedback` if they pick the latter. Never guess.

## When to invoke

- After the user completes a full discovery run (typically at the end of Stage 6 — Experiment Plan)
- When the user explicitly asks to rate or comment on **the discovery engine** — by name, or by clearly referring to a discovery stage
- When the user expresses strong opinions (positive or negative) about a discovery stage and you want to capture them
- When they abandon a discovery run partway — that drop-off is exactly the signal worth having

Do NOT auto-invoke this skill more than once per session. If the user has already submitted feedback in the current session, don't ask again.

## What to do

1. **Ask the user for a rating** on a 1–5 scale:

   > "How would you rate your experience with the Discovery to Prototype Engine? (1 = poor, 5 = excellent)"

2. **Ask for an optional comment**:

   > "Anything else you'd like to share? (optional — press Enter to skip)"

   - Accept any text. Keep it to one prompt — don't pepper them with questions.
   - If the user skips, comment stays empty.

3. **Submit the feedback** by writing one small file with the Write tool. A plugin hook picks it up
   and sends it — do **not** run any tracking script via Bash (that prompts the user in default
   permission mode and can't find the script in Cowork).

   - Path: `$DISCOVERY_DIR/feedback/discovery-feedback-<YYYYMMDD-HHMMSS>.md` — the discovery working
     directory (see [`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md)).
     The `discovery-feedback-` filename prefix is required: it is how the hook recognizes the file.
   - Exact content, three lines, nothing else:

   ```
   Rating: <1-5>
   About: <the part of the loop it concerns>
   Comment: <the user's comment, or nothing after the colon>
   ```

   - `Rating` is a single digit 1–5. Comments are trimmed to 500 characters on send.
   - `About` names the part of the loop the feedback concerns, so the maintainers can route it.
     Derive it from the conversation — what the user said they are rating, or the stage/skill they
     just finished: e.g. `discovery`, `stage 2 — prioritization`, `prototype-from-components`.
     When nothing more specific is known, write `discovery`. Never put identifying info in it.

4. **Confirm to the user**: "Thanks! Your feedback was submitted anonymously."

## What NOT to do

- Do NOT include the user's name, email, project name, customer names, or any identifiable info in the comment string — even if they say their name. Substitute generically ("user mentioned a team in their feedback") or omit.
- Do NOT push back on the rating. If they say 1, accept it and move on. Negative feedback is valuable.
- Do NOT ask follow-up questions ("why only 3 stars?") unless they invite the conversation. Respect their time.
- Do NOT submit feedback if the user changed their mind or asked you to cancel.

## Privacy note

This skill sends an anonymous event (rating + comment + anonymized user hash + plugin version) to the maintainers' usage tracking sheet. No conversation context, file contents, prompts, or identifying info is included.

With `CLOSING_THE_LOOP_TELEMETRY_DISABLED=1` (or the legacy `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1`) set, the file is still written locally but nothing is sent — if you know telemetry is disabled, tell the user their feedback was saved locally only.
