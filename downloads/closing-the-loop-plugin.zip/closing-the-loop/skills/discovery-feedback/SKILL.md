---
name: discovery-feedback
description: Collect an anonymous 1-5 rating and optional comment about the DISCOVERY lane — the Discovery to Prototype Engine, stages 0-6. Use when the user says "feedback on discovery", "rate the discovery engine", "feedback on the prototype workflow", or finishes / abandons a discovery run. NOT for the engineering delivery skills or the handover bridge — that is `v-give-feedback`. On a bare "give feedback" with no lane named, ask which one first.
---

# Discovery Feedback

Collects anonymous user feedback (1-5 rating + optional comment) about the **discovery lane** — the Discovery to Prototype Engine, stages 0–6. The maintainers use this signal to prioritize improvements.

## Scope — which feedback skill handles what

This plugin has two feedback routes, going to two different maintainer teams. Getting this wrong sends a developer's complaint about a code review to the discovery team, or a PM's prototype gripe to the engineering team.

| The feedback is about… | Skill | Destination |
|---|---|---|
| Discovery stages 0–6: customer insights, competitive landscape, opportunity scoring, PRD, component readiness, prototype, experiment plan | **this skill** (`discovery-feedback`) | Discovery engine maintainers — always anonymous, 1–5 rating + comment |
| The engineering delivery skills (`v-*`) or the handover bridge (`discovery-handover-package`, `handover-*`, `create-backlog-from-brief`) | `v-give-feedback` | Visma skills maintainers — free-form, with an optional name/email |

**If the user just says "give feedback" without naming a lane, ask which** — "Is this about the discovery workflow, or about the engineering/handover side?" — and hand off to `v-give-feedback` if they pick the latter. Never guess.

## When to invoke

- After the user completes a full discovery run (typically at the end of Stage 6 — Experiment Plan)
- When the user explicitly asks to rate or comment on **the discovery engine** — by name, or by clearly referring to a discovery stage
- When the user expresses strong opinions (positive or negative) about a discovery stage and you want to capture them
- When they abandon a discovery run partway — that drop-off is exactly the signal worth having

Do NOT auto-invoke this skill more than once per session. If the user has already submitted feedback in the current session, don't ask again.

## What to do

1. **Ask the user for a rating** on a 1–5 scale:

   > "How would you rate your experience with the Discovery to Prototype Engine? (1 = poor, 5 = excellent)"

2. **Ask for an optional comment**:

   > "Anything else you'd like to share? (optional — press Enter to skip)"

   - Accept any text. Keep it to one prompt — don't pepper them with questions.
   - If the user skips, comment stays empty.

3. **Submit the feedback** by running the tracking script via the Bash tool:

   ```
   "${CLAUDE_PLUGIN_ROOT}/hooks/track-feedback.sh" <rating> "<comment>"
   ```

   - `<rating>` must be a single digit 1-5
   - `<comment>` must be wrapped in double quotes; pass an empty string `""` if the user gave no comment
   - The script trims comments to 500 characters

4. **Confirm to the user** that their feedback was sent. Use the exact output from the script (it prints "Thanks! Your feedback was submitted." on success).

## What NOT to do

- Do NOT include the user's name, email, project name, customer names, or any identifiable info in the comment string — even if they say their name. Substitute generically ("user mentioned a team in their feedback") or omit.
- Do NOT push back on the rating. If they say 1, accept it and move on. Negative feedback is valuable.
- Do NOT ask follow-up questions ("why only 3 stars?") unless they invite the conversation. Respect their time.
- Do NOT submit feedback if the user changed their mind or asked you to cancel.

## Privacy note

This skill sends an anonymous event (rating + comment + anonymized user hash + plugin version) to the maintainers' usage tracking sheet. No conversation context, file contents, prompts, or identifying info is included.

Users who set `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1` will see "Telemetry is disabled. Feedback was NOT sent." — let them know if that happens.
