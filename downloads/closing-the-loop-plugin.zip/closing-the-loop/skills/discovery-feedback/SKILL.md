---
name: discovery-feedback
description: Collect an anonymous 1-5 rating and optional comment about Closing the Loop — the discovery lane (the Discovery to Prototype Engine, stages 0-6), the handover bridge, or the bundled delivery skills. Use when the user says "give feedback", "feedback on discovery", "rate the discovery engine", "feedback on the prototype workflow", "feedback on the handover", or finishes / abandons a discovery run.
---

# Discovery Feedback

Collects anonymous user feedback (1-5 rating + optional comment) about this plugin: the **discovery lane** — the Discovery to Prototype Engine, stages 0–6 — the **handover bridge**, and the five bundled **delivery skills**. The maintainers use this signal to prioritize improvements.

## Scope — what this skill covers

This is the plugin's one feedback route. The `About` line in the submission says which part it concerns, so nobody has to be routed to a different skill.

| The feedback is about… | Handled here? | `About` |
|---|---|---|
| Discovery stages 0–6: customer insights, competitive landscape, opportunity scoring, PRD, component readiness, prototype, experiment plan | Yes | `discovery`, or the stage or skill |
| The handover bridge: `handover-*`, `discovery-handover-package`, `create-backlog-from-brief`, `prepare-amigo-session`, publishing the ticket | Yes | `handover`, or the skill |
| The bundled delivery skills: `v-scope`, `v-investigate`, `v-build`, `v-challenge`, `v-ship` | Yes | `delivery`, or the skill |

**If the user just says "give feedback" and the conversation doesn't show which part they mean, ask once** — "Is this about the discovery workflow, the handover, or the delivery skills?" Never guess.

## When to invoke

- After the user completes a full discovery run (typically at the end of Stage 6 — Experiment Plan)
- When the user explicitly asks to rate or comment on **the discovery engine or the handover** — by name, or by clearly referring to a stage or a handover skill
- When the user expresses strong opinions (positive or negative) about a discovery stage and you want to capture them
- When they abandon a discovery run partway — that drop-off is exactly the signal worth having

Do NOT auto-invoke this skill more than once per session. If the user has already submitted feedback in the current session, don't ask again.

## What to do

1. **Ask the user for a rating** on a 1–5 scale:

   > "How would you rate your experience with the Discovery to Prototype Engine? (1 = poor, 5 = excellent)"

   For handover feedback, ask about "the handover" instead.

2. **Ask for an optional comment**:

   > "Anything else you'd like to share? (optional — press Enter to skip)"

   - Accept any text. Keep it to one prompt — don't pepper them with questions.
   - If the user skips, comment stays empty.

3. **Submit the feedback** by writing one small file with the Write tool. A plugin hook picks it up
   and sends it — do **not** run any tracking script via Bash (that prompts the user in default
   permission mode and can't find the script in Cowork).

   - Path: `$DISCOVERY_DIR/feedback/discovery-feedback-<YYYYMMDD-HHMMSS>.md` — the discovery working
     directory (see [`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md)).
     The `discovery-feedback-` filename prefix is required: it is how the hook recognizes the file.
   - Exact content, three lines, nothing else:

   ```
   Rating: <1-5>
   About: <the part of the loop it concerns>
   Comment: <the user's comment, or nothing after the colon>
   ```

   - `Rating` is a single digit 1–5. Comments are trimmed to 500 characters on send.
   - `About` names the part of the loop the feedback concerns, so the maintainers can route it.
     Derive it from the conversation — what the user said they are rating, or the stage/skill they
     just finished: e.g. `discovery`, `stage 2 — prioritization`, `prototype-from-components`,
     `handover`, `handover-shape-feature`. When nothing more specific is known, write `discovery` or
     `handover`. Never put identifying info in it.

4. **Confirm to the user**: "Thanks! Your feedback was submitted anonymously."

## What NOT to do

- Do NOT include the user's name, email, project name, customer names, or any identifiable info in the comment string — even if they say their name. Substitute generically ("user mentioned a team in their feedback") or omit.
- Do NOT push back on the rating. If they say 1, accept it and move on. Negative feedback is valuable.
- Do NOT ask follow-up questions ("why only 3 stars?") unless they invite the conversation. Respect their time.
- Do NOT submit feedback if the user changed their mind or asked you to cancel.

## Privacy note

This skill sends an anonymous event (rating + comment + anonymized user hash + plugin version) to the maintainers' usage tracking sheet. No conversation context, file contents, prompts, or identifying info is included.

With `CLOSING_THE_LOOP_TELEMETRY_DISABLED=1` (or the legacy `DISCOVERY_ENGINE_TELEMETRY_DISABLED=1`) set, the file is still written locally but nothing is sent — if you know telemetry is disabled, tell the user their feedback was saved locally only.
