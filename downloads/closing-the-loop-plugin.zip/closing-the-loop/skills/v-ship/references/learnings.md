# Capturing Learnings

Read by **v-ship** when a high-friction task left a lesson the next person
or agent would otherwise have to rediscover.

Contents: Workflow · Reporting a Capture · Quality Bar · Critical Rules

## Workflow

### 1. Assess Capture Worthiness

Not every piece of task knowledge deserves a permanent entry. Evaluate:

- **Recurrence likelihood:** Will this situation come up again? A one-off
  issue with a since-deleted file is not worth capturing. A gotcha in a
  commonly-used library is.
- **Investigation cost:** How long did it take to figure this out? If the
  answer took five minutes of reading docs, it's probably not worth a learning
  entry. If it took an hour of debugging with misleading error messages, it
  is.
- **Discoverability gap:** Is this knowledge easy to find through normal
  channels (official docs, error messages, search)? If yes, skip it. If the
  answer is buried in a forum thread from three years ago or requires
  combining information from multiple sources, capture it.
- **Scope match:** Is this specific to the current project, or is it general
  knowledge? Project-specific learnings go in the project's `AGENTS.md` or docs.
  General tool behavior might belong in a personal reference instead.

If fewer than two of these criteria are met, the learning probably doesn't
warrant capture. Move on.

### 2. Identify the Trigger Condition

A learning that says "the library has a bug" is useless; "when you see error
X after doing Y, the cause is Z" is immediately actionable. Before writing
the entry, identify the observable situation that activates this knowledge —
an error message, a configuration pattern, a sequence of operations — and
what a future agent or developer would be doing when they need it. If you
can't state the trigger concretely, the learning won't activate when needed.

### 3. Choose Where It Goes

There is no separate memory store. A lesson goes where people already
review it:

- **`AGENTS.md`** — what an agent needs on most tasks in this repo: a line
  or two under the section it belongs to, in the file's existing style.
- **The docs** — anything longer, or needed only in one area (a runbook, a
  module's README), with a one-line pointer from `AGENTS.md` when agents
  would otherwise miss it.

When the team settings name another place for lessons, use it. Never create
a new memory file or directory. A harness's own memory is not shared or
reviewed, so what the team needs is captured in the repo.

### 4. Capture Raw, Then Distill

Immediately after the friction event, write down what happened — the task,
the obstacle, the exact error messages or misleading signals, what didn't
work and why, the version context if behavior is version-specific. Then
strip it to what a future reader needs:

- **Remove narrative and ephemeral details** — the story of the debugging
  session, file paths that will change, ticket numbers, names of people.
- **Preserve the trigger, the resolution, and the reason it works** —
  without the reason, the learning can't be adapted to
  similar-but-different situations.

A distilled learning should be readable in under 30 seconds and actionable
immediately. If it takes more than a paragraph, split it or capture it as
documentation instead.

### 5. Categorize the Entry

Assign a category that helps with retrieval and staleness management:

- **Gotcha:** a non-obvious behavior that causes confusion or errors
- **Pattern:** a recurring solution shape that applies across situations
- **Convention:** a project-specific rule not enforced by tooling
- **Tool behavior:** tool/library behavior that differs from documentation
  or reasonable expectation

If a learning doesn't fit any category, it might be too vague — sharpen the
trigger condition and try again.

### 6. Format and Store the Entry

Write the learning in a consistent format that supports scanning and search:

- **Trigger:** One line describing the observable situation that activates
  this learning (error message, pattern, task type)
- **Learning:** One to three sentences with the actual knowledge — what's
  happening, why, and what to do about it
- **Category:** One of: gotcha, pattern, convention, tool-behavior
- **Scope:** Project-specific or general
- **Added:** Date of capture for staleness tracking

Add it to the chosen file in that file's existing style, without
reformatting what is already there. In `AGENTS.md`, fold the fields into a
line or two: the trigger, then what to do and why.

### 7. Verify Retrievability

Search the repo for the trigger condition terms and confirm the entry
surfaces. Read the entry cold, as if you'd never seen the original
problem — is it clear what situation it addresses and what to do? If the
trigger matches too many situations or only one exact scenario, adjust it.

### 8. Set Staleness Expectations

Not all learnings age the same way:

- **Tool behavior** entries become stale when the tool version changes.
  Note the version if the behavior is version-specific.
- **Convention** entries become stale when the project's practices evolve.
  These should be reviewed when major structural changes happen.
- **Gotcha** entries may become stale when the underlying cause is fixed
  upstream. Note the conditions under which the gotcha would no longer apply.
- **Pattern** entries are the most durable — they encode problem-solving
  approaches that outlast specific tool versions. These rarely go stale.

## Reporting a Capture

- **Entry:** the learning as it appears in `AGENTS.md` or the docs
- **Location:** file path, position within the file, and whether a new file
  or section was created
- **Reuse trigger:** when this learning should surface in future work, and
  recommended search terms or file patterns for retrieval

## Quality Bar

It fails when a cold reader cannot act on the entry without context from the
original task, or when the entry was captured without meeting two of the
step 1 criteria.

## Critical Rules

1. **Never capture credentials, tokens, or personal data.** Learnings are
   stored in files that may be shared, version-controlled, or read by
   automated tools. Secrets in a committed file are a security incident.
   If the learning involves authentication, capture the pattern without
   the actual values.

2. **One learning per entry.** If a single friction event yielded multiple
   independent insights, capture them as separate entries with separate
   trigger conditions. Combined entries are harder to retrieve and harder
   to evaluate for staleness.
