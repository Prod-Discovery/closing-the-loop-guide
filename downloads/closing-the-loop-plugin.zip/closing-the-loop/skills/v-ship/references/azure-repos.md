# Azure Repos PR operations (Azure DevOps MCP server)

> Added by the Closing the Loop bundle; not part of the upstream `visma-skills` library.

This rung applies when the repo's `origin` remote points at Azure Repos —
`https://dev.azure.com/<org>/<project>/_git/<repo>` or the older
`https://<org>.visualstudio.com/<project>/_git/<repo>` — and the Microsoft
**Azure DevOps MCP server** (`@azure-devops/mcp`) is connected. That is the
same server the `azure-devops` tracker integration uses (`wit_*` tools), so
a team whose tickets live in Azure Boards needs **no second connection**.

Derive `project` and `repositoryId` from the remote URL (the repository
*name* works as `repositoryId` when `project` is also passed) and
cross-check `azureDevops.organization` / `azureDevops.project` in
`~/.config/closing-the-loop/config.json` when it exists.

**Verify before relying on this rung.** List the session's available tools
first. The current server generation exposes consolidated names (the ones
below); older releases expose per-action names (`repo_create_pull_request`,
`repo_list_pull_request_threads`, …) — same operations, so match by the
`repo_` prefix and the tool descriptions rather than exact names. If no
`repo_*` tools are available at all, this rung is absent: fall down the
ladder (user-provided actions) exactly as before, and say so.

## Operation → tool mapping

| Operation | Call |
| --- | --- |
| Open a PR | `repo_pull_request_write` action `create` — `sourceRefName`/`targetRefName` as full refs (`refs/heads/…`), `title`, `description`, `isDraft` while work is in progress, and `workItems` with the PBI id(s) — **one space-separated string (`"12 34"`), not an array** — so the ticket↔PR link exists from birth |
| Read PR status | `repo_pull_request` action `get` (by id) or `list` (by repo) |
| Fetch review comments | `repo_pull_request_thread` action `list`, then `list_comments` per thread |
| Reply / resolve a thread | `repo_pull_request_thread_write` action `reply` / `update_status` — the resolving status value is `Fixed` or `Closed` |
| Request reviewers | `repo_pull_request_write` action `update_reviewers` with `reviewerIds` |
| Merge | `repo_pull_request_write` action `update` with `autoComplete: true` + `mergeStrategy`; set `deleteSourceBranch: true` to clean up, and `mergeCommitMessage` to control the squash commit's message |
| Abandon | `repo_pull_request_write` action `update` with `status: "Abandoned"` |
| CI status / logs | `pipelines_build` (builds for the branch/PR), `pipelines_build_log` for failure details, `pipelines_run` to trigger a definition |

## Behavioral notes

- **There is no merge-now action.** Azure Repos merges through
  *autocomplete*: the `update` call registers the intent, and the platform
  merges once branch policies (required reviewers, build validation) pass.
  Treat a successful autocomplete call as "merge submitted", then confirm
  completion with `repo_pull_request` `get` — never report merged until the
  PR status says so. On a policy-blocked PR this is the honest
  `awaiting-merge` state the epic walker already models. On a **policy-free
  repo** autocomplete completes near-instantly — the "awaiting merge" state
  never appears, so the confirming `get` right after the call may already
  say Completed.
- **Write calls don't echo their own effect.** `create` and `update`
  responses omit the work-item link; confirm it with `repo_pull_request`
  `get` passing `includeWorkItemRefs: true`, the same way merge completion
  is confirmed.
- **Statuses come back as numbers**, even when the call took text: PR
  `1` = Active, `3` = Completed; thread `1` = Active, `2` = Fixed.
  Translate before reporting.
- **Work-item transitions ride the merge.** `transitionWorkItems` defaults
  to true on autocomplete, so ADO itself moves linked work items when the
  merge lands — the post-merge ticket transition needs no separate `wit_*`
  call when the PR was created with `workItems` set.
- **Description budget is 4,000 characters.** The full story belongs on the
  work item; keep the PR description within budget and link the item rather
  than truncating mid-sentence.
- **Never bypass policies or vote.** `bypassPolicy` exists — only on the
  user's explicit, quoted instruction. `vote` casts the agent's own review
  vote; approving your own PR defeats the review gate, so leave voting to
  humans.
- **Known server quirk** (same as the tracker side): project search by
  name checks only the first 20 projects — list pages instead.
- **Auth troubleshooting:** `AadUserStateException` / "identity has not
  been materialized" means the signed-in account needs one interactive
  browser sign-in to the organization, or the server needs
  `--authentication azcli` to reuse the az CLI login. It is an account
  state, not a missing tool — stop and fix the sign-in; do not fall down
  the ladder to user-provided actions. Also: comment authors can show a
  different email than the PR creator for the same person — never match
  identities by email.
