# Project Settings: `.visma-skills/`

Read by **v-ship** when setting up where the skills keep team settings and
the artifacts worth persisting, and by any core skill that needs the layout.

Contents: Layout · project.md · decisions/ · outcomes.md · local/ · Rules

## Layout

```
.visma-skills/
  config.yml, *.mjs         # the installer's files — leave them alone
  project.md                # team settings for these skills        (committed)
  specs/<ticket-or-slug>.md # specs and plans the ticket cannot hold (committed)
  decisions/NNNN-<slug>.md  # decisions that are hard to undo        (committed)
  outcomes.md               # open outcome checks, when no tracker holds them (committed)
  .gitignore                # one line: local/
  local/                    # per person, never committed
    preferences.md          #   personal settings
    handoff.md              #   where a paused flow stopped
    notes/                  #   investigation and spike notes
```

Create a file the first time something needs it — never the empty skeleton.
Whoever first writes to `local/` also creates `.visma-skills/.gitignore`
containing `local/`. Repo conventions every agent needs (commands, layout,
gotchas) stay in `AGENTS.md`; `project.md` holds what only these skills
read, so it costs context only when a skill runs.

## project.md

Only values that differ from the skill defaults, one per line:

```markdown
# Visma skills — team settings

## Scope
- Questions per reply when grilling: a numbered round   # default: one
- Ready also requires: design sign-off for UI changes
- Specs and plans live in: the ticket   # or .visma-skills/specs/, or a wiki URL
- Largest slice: one PR under ~400 changed lines

## Challenge
- High risk also includes: pricing rules, tax calculation
- Required reviewers: see CODEOWNERS

## Ship
- Merge strategy: squash; only maintainers merge
- Pre-approved: merging green dependency-update PRs
- Outcome follow-ups live in: the tracker   # or .visma-skills/outcomes.md
- Lessons go to: AGENTS.md

## Team references
- End-to-end tests (Cypress): read docs/agents/e2e.md
```

## decisions/

One numbered file per decision that is hard to undo, written by **v-scope**
once the user decides (spikes that settle one go through it) and checked by
**v-challenge** against each change. A team with an existing decision log
names it in `project.md` instead:

```markdown
# 0007 — Invoices export as CSV, not a new API endpoint
**Context:** … **Decision:** … **Why:** … **Would reverse it:** …
```

An accepted decision is never edited; a new number supersedes it and says
which one.

## outcomes.md

One line per open check, added by **v-ship** while packaging the change
when no tracker holds the follow-up, so it merges with the change:

```markdown
- [ ] 2026-11-15 — PAY-142 (#123) — export used by 20+ accounts a week
```

At the outcome check, **v-scope** ticks the line, writes the result after
it, and ships that edit like any change.

## local/

Never committed: `.visma-skills/.gitignore` holds `local/`.

- **preferences.md** — personal settings (tone, how much detail to
  report). They apply only where team settings are silent and never relax
  an approval gate.
- **handoff.md** — written when a flow pauses: where it stopped, what is
  next, open questions. Read it first on resume; delete it when the flow
  ends.
- **notes/** — findings worth keeping between sessions but not worth
  committing.

## Rules

- Settings never relax a skill's Critical Rules or approval gates; a
  pre-approval names a specific action.
- Settings and records here survive skill updates; edits to the installed
  skill files do not.
- There is no memory store here. Lessons the team needs go into `AGENTS.md`
  or the docs ([learnings.md](learnings.md)), where people review them.
