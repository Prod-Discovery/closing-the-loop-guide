# Continuous Integration

Read by **v-ship** when a CI workflow or environment is broken or flaky,
or is being set up or hardened. A failing test is **v-investigate**'s job.

Contents: Before Changing a Workflow · Workflow · Reporting a CI Change · Quality Bar · Anti-Patterns · Critical Rules

## Before Changing a Workflow

Understand the current state: read the existing workflow files, their
triggers, and the job dependency graph; note current permission scopes,
secret usage, and caching. Identify what must be verified on every change
(build, tests, lint, types, formatting, security scanning), which platforms
and runtime versions matter, and the acceptable feedback time — a workflow
that takes 30 minutes discourages frequent pushes.

## Workflow

### 1. Organize Workflow Structure

Separate concerns into distinct jobs — build, test, quality, security — so
failures are immediately attributable and unrelated checks are not blocked by
one failure. A single job that builds, tests, lints, and deploys gives poor
diagnostics.

### 2. Eliminate Nondeterminism

Flaky workflows erode trust. Keep outputs deterministic so the same inputs
always produce the same result:

- Pin all action versions by commit SHA (with a version comment), runtime
  versions by exact number, and base images by digest — mutable references
  (tags, "latest", ranges) are a supply-chain risk and can change under you.
- Install dependencies from the lock file, using the mode that respects it
  without modifying it.
- Cache with keys that incorporate the lock file hash, so caches invalidate
  when dependencies change — not randomly, and not never.
- Set explicit timeouts on jobs and steps so a hung process fails fast.

### 3. Harden Permissions

Apply least privilege to every workflow:

- Set top-level permissions to read-only, then grant write only to the
  specific jobs and steps that demonstrably need it.
- Pass secrets to the specific steps that need them via environment
  variables, never as workflow-level defaults.
- **Restrict fork access.** Workflows triggered by forks must not have access
  to repository secrets. Use event types that distinguish trusted from
  untrusted sources.
- Audit third-party actions before adding them: verify the source, check the
  permissions they request, pin by SHA.

### 4. Configure Matrix Testing

Define matrices explicitly and include only combinations your users actually
run. Use fail-fast judiciously: for PR checks, fail-fast saves time; for
scheduled or release builds, run all combinations to get the full picture.

### 5. Manage Artifacts

Upload build outputs, test results, and coverage reports as artifacts when
needed for debugging or downstream use, named clearly, with retention periods
matched to the artifact type.

### 6. Engineer Failure Diagnostics

When a workflow fails, the developer's first question is "what broke and
why?" Make that answer immediate: print actionable context on failure
(test results, error summaries) without requiring artifact download, use
conditional on-failure steps to collect diagnostics, annotate results so
failures surface in the PR rather than buried in logs, and gate verbose
output behind a debug flag.

### 7. Triage Workflow Failures

**Tooling note:** Use the strongest CI-status integration available —
GitHub MCP server or `gh` CLI (`gh run list`, `gh run view`, `gh run
view --log-failed`) for GitHub-hosted CI, the equivalent CLI or MCP for
Bitbucket, Azure DevOps, GitLab, or whatever CI host the project uses.
If none is available, ask the user to share the failing job log; missing
integration is not a fail-stop.

When diagnosing, distinguish flaky from broken: a pass on the one re-run
points to nondeterminism (timing, external services, resource contention);
consistent failure points to a real defect. Reproduce locally when possible,
and check whether a dependency, workflow, or infrastructure change coincided
with the failure.

## Reporting a CI Change

- **Changes:** what was added, modified, or removed in workflow
  configuration, and which jobs or steps are affected
- **Impact:** on build time (faster, slower, unchanged), on security posture
  (tighter permissions, new secret usage), and on reliability (reduced
  flakiness, added determinism)
- **Verification:** the jobs and steps observed passing or failing after the
  change, compared with previous behavior when relevant

## Quality Bar

It fails when a new contributor cannot tell what a workflow does from the
file alone, when any action, runtime, or image is referenced by a mutable
tag, or when a failure's output does not say what to fix.

## Anti-Patterns

**The retry hammer.** Automatically retrying failed steps instead of fixing
the root cause. Retries mask flakiness and make failures intermittent instead
of visible. Fix nondeterminism at the source.

**The snowflake workflow.** A workflow that works only because of undocumented
assumptions about the CI environment — specific tools pre-installed, specific
network access, specific file system state. Make all dependencies explicit.

## Critical Rules

1. **Never hardcode secrets in workflow files.** Not in environment variables,
   not in command arguments, not in comments. Use your CI system's secret
   storage exclusively.

2. **Test the workflow itself.** After modifying CI configuration, verify the
   change works. Don't merge workflow changes without evidence that the
   modified jobs run correctly.
