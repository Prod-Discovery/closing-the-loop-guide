# Cutting a Release

Read by **v-ship** when packaging merged work as a versioned release. A
release is not "bump the version and push": it verifies that what
accumulated since the last release is correct, complete, documented, and
ready for users.

Contents: Before Starting · Workflow · Release Report · Quality Bar ·
Anti-Patterns · Critical Rules

## Before Starting

1. **Identify what is being released.** Review the commit log, merged
   branches, and closed issues since the last release for a rough picture
   of scope — the Phase 1 audit will make it precise.

2. **Determine the version.** Choose the next version number according to
   the project's versioning scheme; if unsure, the Phase 1 audit clarifies.

3. **Check preconditions.** All intended changes are merged to the release
   branch, no work-in-progress branches are expected to land, CI is green
   on the release branch, and release-blocking issues are resolved.

4. **Identify the release type.** This shapes the depth of each phase:
   - **Standard release:** Full audit, full test suite, complete changelog
   - **Hotfix release:** Narrow audit (only the fix), targeted test run,
     minimal changelog entry
   - **Major release:** Deep audit, extended testing including migration
     paths, comprehensive documentation updates

## Workflow

The release proceeds through 5 phases. Each names the skill or reference
that teaches it — follow that rather than re-implementing it here.

### Phase 1: Audit Changes — invoke **v-challenge**

This is not a code review of a single feature — it is an audit of the
complete changeset between the last release tag and current HEAD, reviewed
as a whole.

**Gate:** The change audit is complete. All included changes are
intentional, individually reviewed during development, and ready for
release. Any unintended inclusions are removed. No debug code, temporary
workarounds, or incomplete features remain in the changeset.

### Phase 2: Verify — run the full test suite

Run the project's full test command — the complete suite, not just tests
for recent changes — plus any integration, end-to-end, and smoke tests and
release-specific validation (build artifacts, package integrity). Any
failure stops the release, per the loop-back below. Do not invoke an
implementation or test-writing stage here: the changeset is frozen and this
phase only observes it.

**Gate:** All tests pass. No test failures are accepted in a release build —
flaky tests must be fixed or quarantined with documented justification before
proceeding. Test coverage has not regressed below the level at the last
release.

**Loop-back condition:** If tests reveal issues that need code changes, stop
the release process. The fix goes through **v-scope**
(`references/recipe-bug.md`) separately; restart the release from Phase 1
after the fix is merged.

### Phase 3: Configure Release CI — [ci.md](ci.md)

Verify the release build configuration (version numbers, build flags,
artifact paths), release-specific steps (publishing, deployment, artifact
signing), secrets for release targets, that release tags trigger the
correct CI workflows, and that post-release automation is configured.

**Skip criteria:** Projects without CI, or releases that use the same CI
configuration as development builds, may skip this phase.

**Gate:** CI is configured to handle the release correctly. Build, publish,
and deploy steps are validated.

### Phase 4: Document the Release — **v-build** (`references/docs.md`)

This goes beyond code documentation — it includes user-facing release notes
and versioning:

- Write or update the changelog with all changes in this release, organized
  by category (features, fixes, breaking changes)
- Update version numbers in configuration files, package manifests, and
  documentation
- Update migration guides if the release includes breaking changes
- Review and update README if the release changes setup, usage, or
  requirements

**Gate:** The changelog accurately reflects all changes. Version numbers are
consistent across all files. Migration guides exist for any breaking changes.
No documentation references stale behavior.

### Phase 5: Release Commit — [commit-pr.md](commit-pr.md)

Stage the version bump, changelog, and release-related file changes only,
and create or prepare the release tag with the correct version.

**Gate:** The release commit is clean and well-messaged. The tag matches the
version. Only release-related changes are included — no feature code, no
bug fixes, no refactors in the release commit itself.

## Release Report

```markdown
**Version:** [version number being released]
**Type:** [major / minor / patch / hotfix]
**Phases completed:** [list, with any skipped and why]

**Changes included**
- Features: [list or count]
- Fixes: [list or count]
- Breaking changes: [list — or "None"]

**Per phase**
- Audit: [changes reviewed, any issues found and resolved]
- Tests: [suite results, coverage status]
- CI: [release configuration verified — or "N/A: no CI changes needed"]
- Documentation: [changelog updated, version bumped, migration guide if needed]
- Commit: [release commit message and tag]
```

| Check | Command | Result |
|-------|---------|--------|
| Full test suite | [command] | pass |
| Build artifacts | [command] | pass |
| Version consistency | [specific check] | consistent |
| Changelog complete | [specific check] | complete |

Follow-ups: items deferred to a later release and post-release
verifications still pending, or "None".

## Quality Bar

It fails when a user reading only the changelog cannot tell what changed for
them and what they must do to upgrade, or when anything in the release
escaped the whole-changeset audit.

## Anti-Patterns

**Changelog by commit log.** Dumping raw commit messages into the changelog
and calling it documentation. Users do not care about "refactored auth
module internals." They care about "added support for OAuth2 PKCE flow."
The changelog is a curated, user-facing document, grouped by impact
(features, fixes, breaking), not by technical area.

**Version roulette.** Bumping the major version for a patch fix, or shipping
breaking changes as a minor version. Version numbers are a contract with
users. Respect the versioning scheme.

## Critical Rules

1. **No code changes during release.** This is a verification and packaging
   workflow. If the audit or tests reveal a code problem, take the
   Phase 2 loop-back — never fix inside the release.
