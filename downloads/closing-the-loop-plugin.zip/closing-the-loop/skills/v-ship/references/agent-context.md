# Agent Context Files

Read by **v-ship** when creating or refreshing `AGENTS.md`, `CLAUDE.md`, or
an equivalent context file — including a repo's first-time bootstrap for
AI-assisted development.

Contents: Workflow (including First-Time Bootstrap) · Template ·
Quality Bar · Critical Rules

Do not create a context file when the project uses standard tooling with no
customization, when the only content would repeat README.md, or when the file
would just describe what the code does — agents discover all of that
themselves.

## Workflow

### 1. Audit Current Agent Friction Points

Before writing anything, identify the specific problems: what agents get
wrong repeatedly in this repo, which commands fail because the agent guesses
wrong, which conventions get violated, which setup steps are not obvious. If
you have no evidence of agent friction, observe one session and note where
the agent stumbles. Do not write a context file based on speculation.

### 2. Choose the File Format

Pick the format that matches your primary AI tool:

| Tool | File | Scope |
|------|------|-------|
| Cross-tool standard | `AGENTS.md` (repo root) | All agents |
| Claude Code | `CLAUDE.md` (repo root) | Claude Code sessions |
| GitHub Copilot | `.github/copilot-instructions.md` | Copilot workspace |
| Cursor | `.cursor/rules/*.md` | Cursor sessions |
| Codex CLI | `AGENTS.md` + `AGENTS.override.md` | Codex sessions |

For maximum compatibility, write `AGENTS.md` at the repo root. Add
tool-specific files only if you need tool-specific instructions, and never
duplicate content across them. One exception is required, not optional:
Claude Code reads `CLAUDE.md`, never `AGENTS.md` — without a bridge, none of
`AGENTS.md` (commands, conventions, the Skills section) reaches a Claude Code
session. When anyone on the team uses it, add a `CLAUDE.md` whose first line
is `@AGENTS.md`, which imports the file instead of copying it. For monorepos, place additional context files
in subdirectories — most agents read the nearest file in the directory tree
upward.

### 3. Write Only Non-Inferable Content

Structure the file with short, specific sections. Every line must pass the
test: "Could an agent figure this out by reading the code?" If yes, omit it.

**Include:** custom build, test, lint, and deploy commands; environment setup
steps (required env vars, services, databases); non-obvious conventions and
why they exist; security constraints (what not to do, what requires manual
approval); common pitfalls specific to this codebase; dependency management
quirks.

**Exclude:** project description, architecture overview, technology stack,
coding style basics, and anything already in README, CONTRIBUTING, or package
configs — agents read those.

### 4. Keep It Under 100 Lines

The best context files are 30-80 lines. Every additional line is tokens the
agent processes before doing useful work; longer files increase the number of
steps agents take without improving task success.

If you need more than 100 lines, split into directory-scoped files: a root
`AGENTS.md` for repo-wide conventions and commands, plus per-directory
context files for area-specific instructions.

### 5. Use Imperative, Agent-Directed Language

Write instructions as direct commands, not descriptive prose. "Run
`make test-integration` for integration tests, not `make test`" beats "the
project has integration tests that can be run using make."

### 6. Validate With a Real Agent Session

After creating the file, run a representative task with an AI agent and
verify: the agent uses the correct build/test commands, follows the
conventions specified, and does not waste time on things the context file
should prevent — or on processing verbose context. If the agent ignores part
of the context file or performs worse, trim or rewrite that section.

### First-Time Bootstrap

When onboarding a repo that has never had agent context (no `AGENTS.md` or
equivalent exists), extend the workflow with two additions:

- **Inventory the verification commands.** Discover every lint, type-check,
  test, and format command from configs and CI — verify, do not assume
  standard tooling. Record each command's status: configured and passing,
  configured but failing, or not configured. The context file must include
  these commands — they are the safety net for agent-generated code.
  Recommend closing gaps (missing formatter, broken suite), but do not block
  the bootstrap on perfect CI.
- **Exit through a real task.** The bootstrap is complete only when an agent
  finishes one representative task — a small fix or feature that exercises
  the documented commands and conventions — using the new context file, and
  verification confirms the output. If the agent still struggles, refine the
  file based on what you observe before calling the repo onboarded.

Settings only the Visma skills read — definition of ready, risk tiers, who
may merge, pre-approved actions — go in `.visma-skills/project.md`, not the
context file ([project-settings.md](project-settings.md)). Add it only when
the team's values differ from the skill defaults.

Optionally, add a short "working with agents here" note to the README
(which context file agents read, the verify command). Prefer keeping
everything in the context file itself — a second document is a second
thing to keep current.

## Template

Include only the sections relevant to the project; delete what's not needed
— except **Skills**, which every context file keeps, new or refreshed: agents
decide on their own when a skill applies and skip them on tasks that look
simple, and in trials this section is what made them use the full chain.

```markdown
# AGENTS.md

## Skills
For any ticket, bug, change, review, or landing work, load the matching Visma
skill before starting: `v-scope`, `v-investigate`, `v-build`, `v-challenge`, `v-ship`.

## Build & Test
- Build: `[exact command]`
- Test: `[exact command]`
- Lint: `[exact command]`
- Type check: `[exact command]`

## Environment Setup
- [Required setup step with exact command]
- [Required env var: what it's for, not the value]

## Conventions
- [Convention with rationale if non-obvious]

## Do Not
- [Prohibited action with brief reason]

## Common Pitfalls
- [Pitfall: what goes wrong and how to avoid it]
```

See [agent-context-example.md](agent-context-example.md) for a worked
example following this template.

Report the file path and final line count, the result of the step 6
validation session, and content deferred to directory-scoped files. For a
first-time bootstrap, also report the verification-command inventory — each
lint/type/test/format command with its configured/passing status — and list
its gaps as follow-ups.

## Quality Bar

It fails when an agent session using the file makes the same mistakes as one
without it, when a command is described instead of shown, or when the file
passes 100 lines without being split.

## Critical Rules

1. **Evidence-derived, never boilerplate.** Derive every line from observed
   friction and verified repo facts — never from generic LLM boilerplate.
   Whether a human or an agent writes the file, judgment about what agents
   actually struggle with in this repo is the entire value.

2. **Maintain or delete.** When commands, conventions, or tooling change,
   update the file. If no one is maintaining it, delete it — stale guidance
   is worse than no guidance.
