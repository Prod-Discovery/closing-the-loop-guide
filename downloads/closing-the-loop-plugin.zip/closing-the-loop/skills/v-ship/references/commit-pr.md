# Commits and Pull Requests

Read by **v-ship** when packaging finished work into commits and a pull
request.

Contents: Workflow · PR Description Template · Quality Bar · Anti-Patterns · Critical Rules

## Workflow

### 1. Scope the Change

A commit is one logical change. Keep together: an implementation change and
its tests, a rename and all its call sites, a configuration change and the
code that depends on it. Separate: an unrelated formatting fix found along
the way, a refactoring that enables a feature (it precedes the feature
commit), a dependency update and the code changes that use it, a bug fix
discovered while implementing something else.

The test: "If this commit were reverted, would everything still make sense?"
If reverting would leave the codebase broken because unrelated changes were
mixed in, the scope is wrong.

### 2. Run Pre-Commit Verification

Before committing:

- Run the project's test command, linter, formatter, and type checker
- Search the diff for common mistakes: debug statements, commented-out code,
  hardcoded values that should be configuration, secrets or credentials
- Review every file in the staging area — each change intentional and
  related to the stated purpose, no unexpected tool-generated files or
  editor artifacts

Do not commit changes that fail verification. Fix the issues first.

### 3. Write the Commit Message

Subject line: imperative mood, under 72 characters, specific to the change —
"Fix null pointer in user search when query is empty", not "Fix bug". Follow
the project's convention if one exists. Add a body when the subject alone
can't carry the why: the reason for the change, non-obvious decisions or
tradeoffs, side effects, migration requirements, related issues.

### 4. Clean Commit History (When Needed)

Before review, the history should tell a coherent story: squash fixup commits
into the commits they correct, reorder so enabling changes precede the
features they enable, split commits that do unrelated things. Rewrite only
within the bounds of Critical Rule 2.

### 5. Prepare the Pull Request

**Tooling note:** Use the strongest PR-creation integration your environment
supports — GitHub MCP server or `gh` CLI for GitHub repos (`gh pr create
--draft` for draft PRs), Bitbucket / Azure Repos / GitLab equivalents for
those hosts. If no integration is available, produce the title and
description text and ask the user to open the PR. Never fail-stop the flow
on a missing integration.

Give the PR a clear, specific title and a description following the template
below, plus reviewer guidance: which files need careful review, a suggested
review order for large diffs, known limitations upfront.

If the project's tracker auto-links PRs (e.g. Linear: a `Closes <ticket-id>`
line transitions the issue on merge), include the closing line in the PR body.

### 6. Record Release Notes

When a commit changes user-visible behavior, write a changelog entry from the
user's perspective, classify the change (feature, bug fix, breaking change,
deprecation, performance), and include migration instructions for breaking
changes.

## PR Description Template

```markdown
## What

[1-2 sentence summary of what this PR does and why]
Ticket: [link — link it, do not paste its contents]

## How

[Brief description of the approach — key files changed, design decisions]

## Risk

[What could go wrong, what areas to review carefully, and how to roll back]

## Testing

| Acceptance criterion | Proof |
|---|---|
| [criterion, as worded in the ticket or scope] | [test name, command and result, or manual check] |

[Other verification — commands run, tests added]

## Follow-up

[Anything deferred to a future change, or "None"]
```

## Quality Bar

It fails when a reviewer has to read the code to learn what changed and why,
or when a commit cannot be reverted on its own without breaking the build.

## Anti-Patterns

**The empty description.** A pull request with no description forces
reviewers to reconstruct the intent from the diff alone. The five minutes
saved by the author costs ten minutes per reviewer.

**The "address feedback" commit.** A commit whose message gives no indication
of what actually changed. Review responses are regular commits — each gets a
specific, descriptive message.

## Critical Rules

1. **Never commit secrets.** No API keys, tokens, passwords, private keys, or
   credentials — not in code, configuration, comments, or test fixtures.
   Check the diff before every commit. If a secret is accidentally committed,
   treat it as compromised immediately — rotate the credential, don't just
   remove it from the repository.

2. **Never rewrite trunk or shared history.** Do not amend, rebase, or
   force-push mainline history or commits others are building on. One
   carve-out: a PR branch under active review may be force-pushed following
   the protocol in [review-loop.md](review-loop.md) — name what changed and
   re-request review after. Clean your own unpushed commits freely.
