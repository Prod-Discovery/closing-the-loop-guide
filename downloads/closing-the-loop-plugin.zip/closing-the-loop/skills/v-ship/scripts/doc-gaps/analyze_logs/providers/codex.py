"""Codex CLI provider for find-missing-documentation.

Contributed back from the v-memory memory_stats package (Visma AI Engineering,
2026), whose provider architecture was itself vendored from this skill's
analyze_logs package. Developed and verified against real Codex CLI 0.142.x
rollouts (2026-07-03). Token-usage accounting from the v-memory variant is
intentionally omitted here — this package's Event carries no usage fields and
documentation-gap analysis does not need it.

Reads rollout files at ~/.codex/sessions/<YYYY>/<MM>/<DD>/rollout-<ts>-<uuid>.jsonl
(CODEX_HOME overrides ~/.codex). One JSON object per line:

    {"timestamp": ISO, "type": T, "payload": {...}}

with T one of:
  session_meta   — payload.session_id, payload.cwd (repo filtering),
                   payload.cli_version, payload.originator
  turn_context   — payload.cwd per turn
  event_msg      — payload.type in {user_message, agent_message, token_count,
                   task_started, task_complete, web_search_end, ...};
                   user_message/agent_message carry payload.message
  response_item  — payload.type in {message, reasoning, function_call,
                   function_call_output, web_search_call, ...}; message has
                   role + content [{type: input_text|output_text, text}];
                   function_call has name/arguments/call_id; reasoning is
                   encrypted and skipped.

Defensive throughout — unknown event types are skipped, a malformed line never
crashes the scan. Re-verify field names after major Codex CLI upgrades.

Notes:
  - User turns come from event_msg/user_message. The same text also appears
    as response_item message role=user; those are typed "user_input_item" and
    not counted as agent starts (they are promoted to "user" only if a file
    has no user_message events at all, for older formats).
  - event_msg/agent_message duplicates the response_item assistant text, so
    it is skipped to keep segments compact.
  - Codex rollouts have no Task/delegation concept (v0.142.x), so segments
    are per user turn: detect_delegation and is_subagent_start return None.
  - ~/.codex/history.jsonl (cross-session prompt history) is deliberately
    ignored; sessions/ is the source of truth.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from ..events import Event, compact, dict_text

HOME = Path.home()

# Injected context blocks logged as user-role response items (environment
# context, user instructions / AGENTS.md) start with an XML-ish tag.
_INJECTED_PREFIX = "<"


def _codex_home() -> Path:
    return Path(os.environ.get("CODEX_HOME", HOME / ".codex"))


def _content_text(content: Any) -> str:
    if not isinstance(content, list):
        return dict_text(content)
    parts = []
    for item in content:
        if isinstance(item, dict) and isinstance(item.get("text"), str):
            parts.append(item["text"])
    return " ".join(parts)


class CodexProvider:
    name = "codex"

    def discover_sessions(self, limit: int) -> list[Path]:
        root = _codex_home() / "sessions"
        if not root.exists():
            return []
        paths = sorted(root.rglob("rollout-*.jsonl"))
        # rollout filenames embed the start timestamp, so name order is time
        # order; keep the `limit` most recent.
        return paths[-limit:] if limit < len(paths) else paths

    def load_events(self, sources: list[Path]) -> list[Event]:
        events: list[Event] = []
        for path in sources:
            events.extend(self._load_file(path))
        return events

    def _load_file(self, path: Path) -> list[Event]:
        events: list[Event] = []
        session = str(path)
        cwd = ""
        saw_user_message = False

        for line_no, line in enumerate(
            path.read_text(encoding="utf-8", errors="ignore").splitlines(), start=1
        ):
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue
            payload = record.get("payload")
            if not isinstance(payload, dict):
                continue
            rtype = str(record.get("type") or "")
            ts = str(record.get("timestamp") or "")

            if rtype in {"session_meta", "turn_context"}:
                if isinstance(payload.get("cwd"), str) and payload["cwd"]:
                    cwd = payload["cwd"]
                continue

            if rtype == "event_msg":
                etype = str(payload.get("type") or "")
                if etype == "user_message":
                    saw_user_message = True
                    events.append(
                        Event(
                            "codex", session, str(path), line_no, ts, "user",
                            compact(payload.get("message"), 1000), cwd=cwd,
                        )
                    )
                # agent_message duplicates response_item assistant text;
                # token_count / task_started / task_complete / web_search_end
                # and anything unknown: skipped.
                continue

            if rtype == "response_item":
                ptype = str(payload.get("type") or "")
                if ptype == "message":
                    role = str(payload.get("role") or "")
                    text = _content_text(payload.get("content"))
                    if role == "assistant":
                        events.append(
                            Event(
                                "codex", session, str(path), line_no, ts,
                                "assistant", compact(text), cwd=cwd,
                            )
                        )
                    elif role == "user":
                        if text.lstrip().startswith(_INJECTED_PREFIX):
                            continue  # injected environment/instructions block
                        events.append(
                            Event(
                                "codex", session, str(path), line_no, ts,
                                "user_input_item", compact(text, 1000), cwd=cwd,
                            )
                        )
                elif ptype == "function_call":
                    events.append(
                        Event(
                            "codex", session, str(path), line_no, ts,
                            "function_call",
                            compact(dict_text(payload)),
                            str(payload.get("name") or ""),
                            compact(payload.get("arguments"), 500),
                            "",
                            str(payload.get("call_id") or ""),
                            cwd=cwd,
                        )
                    )
                elif ptype == "function_call_output":
                    events.append(
                        Event(
                            "codex", session, str(path), line_no, ts,
                            "tool_result", compact(payload.get("output"), 500),
                            tool_call_id=str(payload.get("call_id") or ""),
                            cwd=cwd,
                        )
                    )
                elif ptype == "web_search_call":
                    events.append(
                        Event(
                            "codex", session, str(path), line_no, ts,
                            "web_search", compact(dict_text(payload.get("action"))),
                            "web_search",
                            compact(payload.get("action"), 500),
                            cwd=cwd,
                        )
                    )
                # reasoning (encrypted) and unknown item types: skipped.
                continue

            # Unknown top-level type: skipped, never crashes.

        # Older rollout formats may lack event_msg user_message; fall back to
        # the raw user-role response items so user turns aren't lost.
        if not saw_user_message:
            for e in events:
                if e.type == "user_input_item":
                    e.type = "user"
        return events

    def is_agent_start(self, e: Event) -> bool:
        return e.type == "user"

    def detect_delegation(self, e: Event) -> str | None:
        # Codex rollouts have no Task/delegation concept (v0.142.x).
        return None

    def is_subagent_start(self, e: Event) -> tuple[str, str] | None:
        return None

    def extract_session_id(self, session: str) -> str:
        return Path(session).stem
