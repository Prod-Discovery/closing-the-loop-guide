#!/usr/bin/env bash
# Run analyze_logs unit tests.
# Usage: bash skills/v-ship/scripts/doc-gaps/analyze_logs/tests/run.sh
set -e
cd "$(dirname "$0")/../.."  # cd to scripts/
python3 -m unittest discover -s analyze_logs/tests -v
