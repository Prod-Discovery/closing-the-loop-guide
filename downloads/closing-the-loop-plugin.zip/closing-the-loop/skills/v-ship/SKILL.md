---
name: v-ship
description: Use when landing work or keeping repo knowledge current — 'commit this', 'open a PR', 'address review comments', 'merge', 'cut a release', 'fix CI', 'set up or refresh AGENTS.md', 'capture this lesson', 'find doc gaps'. Packages commits and the PR, iterates review to a green merge, then closes the ticket, outcome, and lesson loops. Not for reviewing the change itself (v-challenge) or diagnosing a failing test (v-investigate).
license: Apache-2.0
metadata:
  author: "Doc-gap analysis contributed by Kent Karlsson (@vogonistic) and Uģis Bērziņš (@ugisberzins-visma)"
---

# Ship

**Is it with users, can we roll it back, did it work, and can the next
person carry on?**

## When to Use

- Work passed **v-challenge** and needs to land
- An open PR has comments, failing checks, or a stale base
- After a merge: release, ticket update, outcome follow-up, lessons
- Repo knowledge needs care — `AGENTS.md`, `.visma-skills/` settings, doc
  gaps: go straight to the matching reference; the Workflow below is for
  landing a change

## Workflow

**Outward actions need a yes.** Pushing, opening or commenting on a PR,
merging, writing to the tracker, and tagging a release happen only when the
user asked for that action in this task or approves it when asked.
The team's `.visma-skills/project.md` or `AGENTS.md` may pre-approve named
actions (for example, merging green dependency PRs); personal preferences
never do, and anything not named still needs a yes. When an
integration is missing, hand the user the exact text or command instead —
never skip the step silently. Called by a recipe or another skill's reference for one step: do that step, return the result to the caller, and let it continue.

### 1. Package

Not yet reviewed? Anything above low risk (see **v-challenge**) goes through
it from a fresh context before it is packaged — invoke **v-challenge** first.

Work on a branch off the default branch, named by the project's convention,
unless the project commits to the default branch directly. Where
`AGENTS.md` is silent on conventions, follow what recent merged PRs and
commit subjects on the default branch show. Never set or invent a git
identity; if a commit fails for lack of one, ask the user. One logical
change per commit, with a message that says why (`references/commit-pr.md`).
When the work lands through a PR, open it as a draft; its body links the
ticket instead of copying it, maps each acceptance criterion to its proof,
and states the risk and how to roll back. With no tracker to hold the
outcome follow-up (step 6), add its line to `.visma-skills/outcomes.md` now,
so it ships with the change. List any lines there already due.

### 2. Get to green

CI must pass. Retry a suspected flake once; a second failure is real. A
failing test or build: invoke **v-investigate**. A broken workflow or
environment: `references/ci.md`.

### 3. Iterate the review

Triage every comment: substantive, nit, question, out of scope, already
addressed. Fix substantive ones through **v-build**, reply to every thread,
and turn out-of-scope requests into follow-up tickets — a ballooning PR is a
slower PR. A material change re-runs **v-challenge**. Mark the PR ready only
when no blocking finding remains (`references/review-loop.md`).

### 4. Merge

Normal or high risk (per **v-challenge**): merge only after a human
approved — a required reviewer on the PR or, where none is required, the
user's explicit yes after reading the challenge report. Asking for the merge
up front is not that yes.

After the merge, confirm CI on the default branch. If the merge broke it,
open a revert right away, ask the user to approve it, and investigate
after.

### 5. Close the ticket loop

Update the ticket: what shipped, the PR, and any difference from the
acceptance criteria. Versioned releases follow `references/release.md`.

### 6. Close the outcome loop

Create a follow-up item holding the success signal from **v-scope** and the
date to check it — in the tracker, or the `.visma-skills/outcomes.md` line
added in step 1; no tracker never means no follow-up. Shipping is not
finished until it exists, unless the scope
recorded "criteria pass" as the signal. No signal recorded because the
flow began outside **v-scope**: propose one — for a bug, "the symptom does
not recur by <date>"; for a chore no user can see, "criteria pass" — and
ask the user. When
the date comes,
invoke **v-scope** for the outcome check.

### 7. Close the knowledge loop

Record only what the next agent or person would otherwise get wrong — a
non-obvious cause, an undocumented convention, a workaround — in `AGENTS.md`
or the docs (`references/learnings.md`). Every line there costs every future
session context, so whatever the code already shows stays out.

## References

| When | Read |
|---|---|
| Commit messages, splitting commits, the PR body | `references/commit-pr.md` |
| Iterating an open PR: comments, stale reviews, conflicts, the merge gate | `references/review-loop.md` |
| CI workflows or environments broken, flaky, or being set up or hardened | `references/ci.md` |
| Cutting a versioned release | `references/release.md` |
| The repo is on Azure Repos: PRs, review threads, merge and CI through the Azure DevOps MCP server (added by this bundle) | `references/azure-repos.md` |
| Capturing a lesson after a high-friction task | `references/learnings.md` |
| Creating or refreshing `AGENTS.md` / `CLAUDE.md` | `references/agent-context.md`, example in `references/agent-context-example.md` |
| Setting up `.visma-skills/`: team settings, specs, decisions, outcomes, personal notes | `references/project-settings.md` |
| Finding doc gaps from agent session logs | `references/doc-gaps.md` (contributed by Kent Karlsson and Uģis Bērziņš) |

## Make it yours

Before step 1, read the team's `.visma-skills/project.md` if it exists.
Precedence: the user's instruction for this task, then that file and
`AGENTS.md` (or `CLAUDE.md`), then your own
`.visma-skills/local/preferences.md` — which never relaxes an approval gate
— then this skill. The layout is in `references/project-settings.md`. This skill reads: branch and commit
conventions, merge strategy, who may merge, pre-approved actions, the
release process, where outcome follow-ups live (tracker, calendar), where
lessons go, and any team reference files to load, each with its condition.

## Output Contract

### Summary

One line: what shipped and where it stands — committed, PR open, merged,
released, or reverted.

### Detail

```markdown
**PR:** link — state
**Merge:** SHA — default-branch CI result
**Ticket:** link — state
**Outcome check:** follow-up link — signal — date
**Lessons:** where recorded, or "none worth keeping"
```

### Verification

CI on the merge commit, approvals, and branch protection satisfied.

### Follow-ups

Out-of-scope review requests filed, open threads, or "None".

## Quality Bar

It fails when someone reading only the PR and the ticket a month later could
not tell what shipped, why, and whether it worked.

## Anti-Patterns

**The stale-base merge.** Merging a branch whose checks ran against an old
base: the combination that lands was never tested. Integrate the base and
re-run CI first — and **v-challenge** if the integration changed behavior.

## Critical Rules

1. **Never bypass branch protection or required reviewers**, and never
   force-merge — the protection rules are the gate, not an obstacle.

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (`AskUserQuestion` in Claude Code and Cowork), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. Buttons mirror the listed options exactly — never add one that isn't an option.
- **Every path you just offered is a button.** If the message names ways forward in prose ("you could also iterate…", "or start a new run"), they all become buttons — never surface only a subset of them; with more than 4, use the lettered list so no option disappears.
- **Fall back to the list.** Without such a tool, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** Start each pause with one line placing the user in the loop — the phase this skill belongs to and the step within it, for example `Loop · Handover — shaping #6` or `Loop · Delivery — S-2 of 7`. Skip it when the skill runs standalone.
