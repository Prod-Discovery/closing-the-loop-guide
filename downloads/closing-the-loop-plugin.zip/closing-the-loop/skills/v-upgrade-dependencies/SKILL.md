---
name: v-upgrade-dependencies
description: Upgrade project dependencies safely — read release notes first, bump in dependency order, verify between steps, and separate mechanical version bumps from the code changes they force. Use when raising a dependency to a new version, applying a security advisory or CVE fix, clearing a backlog of outdated packages, resolving a transitive or lockfile conflict, or producing a dependency upgrade plan for a major version jump.
trigger: [upgrade dependencies, bump packages, update libraries, dependency upgrade plan, apply security patch, major version bump]
license: Apache-2.0
---

# Upgrade Dependencies

## Objective

Move dependencies to newer versions without breaking the build, weakening the
test gate, or silently changing runtime behavior. An upgrade is not "edit the
version number until it installs." The hard parts are not mechanical: ordering
decisions, the pin-vs-float policy, isolating a regression an upgrade
introduced, and judging how urgent a given upgrade actually is. This skill is
about those decisions.

## When to Use

- Raising a dependency to a new major, minor, or patch version
- Applying a security advisory or CVE fix to a vulnerable dependency
- Clearing a backlog of outdated packages flagged by an audit
- Resolving a transitive dependency conflict or a lockfile that won't converge
- Producing an upgrade plan for a major version jump before doing the work

Do not use this skill for adding a brand-new dependency (that is a design
choice — evaluate fit, license, and maintenance first), removing a dependency
(refactor work), or bumping a version purely to silence a tool without
intending to verify it.

## Context

Before changing anything, establish the ground you are standing on:

1. **Find the source of truth.** The manifest states intent (which versions
   are acceptable); the lockfile records the exact resolved graph that
   actually ships. Both matter, and they can disagree.
2. **Establish a green baseline.** Run the project's test / verify gate
   before touching any version. If the baseline is already red, stop and fix
   that first — you cannot attribute a post-upgrade failure to the upgrade if
   the suite was already failing.
3. **List what is being upgraded and why.** Current version, target version,
   and reason (security, feature, deprecation) per dependency — the reason
   drives urgency and ordering.
4. **Map the dependency order.** Plugins, adapters, and ecosystem packages
   must usually move *after* the core library they extend.

## Workflow

### 1. Read the Release Notes Before Bumping

Read the changelog, migration guide, and release notes for the span between
the current and target version **before** changing the version number — for a
multi-version jump, the notes for *every* major version in between, since
breaking changes accumulate. Look for: breaking changes (removed/renamed
APIs, changed defaults, dropped runtime support, stricter validation),
deprecations, required migration steps, and behavioral changes that are not
"breaking" by the maintainer's definition but change output, ordering, error
types, or performance.

Output a short list of expected impact sites in this codebase before you
touch the version. If the notes promise breaking changes and you find zero
impact sites, you have not looked hard enough.

### 2. Upgrade in Dependency Order, One Step at a Time

Apply upgrades in dependency order — foundational libraries before the things
that depend on them. For each step:

1. Bump exactly one dependency (and the transitive changes it pulls in).
2. Let the package manager resolve and update the lockfile.
3. Run the project's test / verify gate.
4. Only proceed once this one is green or its required adaptations are done.

### 3. Separate the Bump From the Adaptation

Keep two kinds of change in **distinct commits**: the mechanical bump (the
manifest version change and resulting lockfile delta, reviewable as
"version X → Y" and nothing else) and the code adaptation (the source edits
the new version *forces*). A reviewer reading a single commit that mixes a
lockfile diff with thirty source edits cannot tell which edits were mandatory
and which were opportunistic. If the adaptation is large, treat it as
ordinary feature work with the project's usual test discipline.

### 4. Apply the Pin-vs-Float Policy

Decide, per dependency class, whether to pin or float:

- **Pin (exact version) for applications and anything that ships.** The
  lockfile is the contract: the same graph builds the same way everywhere.
- **Allow a compatible range for libraries you publish.** A published library
  that hard-pins forces version conflicts onto its consumers. Express the
  widest range you can actually support and test.
- **Always commit the lockfile** for applications. The manifest may express a
  range; the lockfile pins the exact resolution.
- **Never float to "latest" implicitly.** Unpinned upgrades that resolve at
  install time are not reproducible and turn an unrelated CI run into a
  surprise upgrade.

State the policy you applied so a reviewer knows whether a range was
intentional or an oversight.

### 5. Handle Transitive and Lockfile Changes

Transitive shifts are the quiet source of regressions — nothing in the
manifest mentions them:

- **Read the lockfile diff, not just the manifest diff.** A one-line manifest
  change can move dozens of transitive versions; skim the delta for a
  transitive jumping a major, a package duplicated at two versions, or an
  unexpected resolution. A pinned direct dependency does not pin its
  transitive graph unless the lockfile is committed.
- **When the lockfile won't converge**, find the conflicting constraint
  rather than deleting the lockfile and regenerating blindly — regenerating
  from scratch erases intentional pins and can downgrade unrelated packages
  without telling you.

### 6. Judge Urgency: Security vs Feature

- **Security-driven upgrades** are time-sensitive: take the smallest version
  change that clears the advisory (often a patch on the current line) and
  ship it on its own, never coupled to a risky feature upgrade that could
  delay the fix.
- **Feature-driven upgrades** are discretionary — schedule them when there is
  time to absorb the migration guide.
- **Deprecation-driven upgrades** sit between: not urgent today, but a
  scheduled debt that gets more expensive the longer it waits.

When one dependency needs both a security patch *and* a feature jump, do the
security patch first as its own step.

### 7. Bisect a Regression Introduced by an Upgrade

When the gate goes red after an upgrade — or behavior breaks in a way the
gate did not catch — isolate the cause systematically:

1. **Confirm the baseline was green** before the upgrade; if not, the
   regression may predate your work.
2. **Reduce to the smallest failing change.** Revert all but one upgrade and
   re-run the gate; re-introduce one at a time until the failure reappears.
3. **Bisect the version range of the culprit** through intermediate versions
   between last good and first bad.
4. **Map the failing version back to its release notes** — a documented
   behavior change turns a mysterious failure into a missed migration step.
5. **Decide: adapt or hold.** Adapt the code (a distinct adaptation commit)
   or hold at the last good version and record why.

## Output Contract

### Summary

One or two lines stating which dependencies were upgraded, from which versions
to which, and the driving reason (security / feature / deprecation).

### Detail

- **Upgrades applied:** each dependency, old → new version, and the reason.
- **Release-note findings:** the breaking changes and migration steps that
  applied to this codebase, and the impact sites they touched.
- **Commit split:** which commit is the mechanical bump and which is the code
  adaptation, per dependency.
- **Pin-vs-float decisions:** what was pinned, what was given a range, and why.
- **Transitive / lockfile notes:** notable transitive shifts, duplicate
  versions resolved, or conflicts encountered.

### Verification

- The test / verify gate result on the green baseline, before any upgrade.
- The gate result after each upgrade step (between steps, not just at the end).
- If a regression was found and bisected: the culprit version and how it was
  isolated.

### Follow-ups

- Deprecations now visible that will force a future upgrade.
- Upgrades intentionally deferred and the reason (e.g. held at last good
  version pending a larger migration).
- "None" when the upgrade set is fully clean.

## Quality Bar

An upgrade meets the quality bar when:

- Release notes for the full version span were read before the version
  changed, and expected impact sites were identified up front.
- The gate ran on a green baseline first, and again after each upgrade step —
  never weakened to make a new version pass.
- The mechanical bump and the forced adaptation live in separate commits.
- The lockfile is committed for applications and the pin-vs-float policy is
  stated; transitive changes were reviewed via the lockfile diff.
- Security upgrades were isolated from discretionary feature upgrades.
- Any regression was bisected to a specific dependency and version, not
  patched over by reverting the whole batch.

## Anti-Patterns

**The blind bump.** Editing the version number, watching it install, and
declaring victory without reading the changelog or running the gate.
Installing is not working — a new major can install cleanly and break
behavior at runtime.

## Critical Rules

1. **One dependency per step, gate between steps.** Each step must be
   independently verifiable and revertible — this is what makes a later
   regression bisectable instead of a guessing game.

2. **Separate the bump from the adaptation.** The mechanical version change
   and the code it forces belong in distinct commits, always.

3. **Never nuke the lockfile.** Deleting and regenerating it to resolve a
   conflict discards every intentional pin and may move unrelated packages
   without anyone noticing. Find the conflicting constraint instead.
