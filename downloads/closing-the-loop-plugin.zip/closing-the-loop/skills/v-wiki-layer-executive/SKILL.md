---
name: v-wiki-layer-executive
description: Generate the executive-audience layer of a repository wiki — strategic shape, current state, and decisions worth surfacing — from a prepared AnalysisBundle. Use when the wiki orchestrator dispatches the executive layer, when an exec-readable repo summary is needed, or when porting the GitHub App's executive documentation prompt into a stage skill.
trigger: [executive wiki layer, exec summary of this repo, strategic repo shape, executive documentation layer, generate executive layer]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Executive

## Objective

Produce the executive-audience layer for a repository wiki: a short,
skim-first read that tells a non-engineering decision-maker what this
repo *is*, why it matters, what state it is in, and what they should
care about. The layer answers questions an exec actually asks —
"should I invest attention here?", "what bets does this represent?",
"what would I want to know before a budget review?" — using only what
the upstream `v-analyze-repo` skill captured.

This skill is one of the audience layers composed by the wiki
generation orchestrator. It always runs (executives are an
"always-emit" audience in the design); the orchestrator's
`format-output` step renders the structured content this skill
returns. This skill never writes prose directly to disk and never
emits framework-specific markup — output shape is a constrained AST
that the renderer turns into MDX.

## When to Use

- The wiki generation orchestrator dispatches the executive layer
  after `v-analyze-repo` has produced an `AnalysisBundle`
- A caller needs a structured, exec-grade summary of a repo for
  downstream rendering (a wiki, a portfolio review deck, a brief)
- An organization-level synthesis step needs each repo's executive
  layer as input

Do not use this skill when:

- No `AnalysisBundle` is available — invoke `v-analyze-repo` first
- The caller wants engineering, architecture, or overview content —
  those are sibling layer skills
- The caller wants free-form prose that bypasses the renderer; this
  skill produces a structured representation, not finished markup
- The repo is so empty (no source, no history, no manifests) that
  even an executive layer cannot be meaningfully grounded — emit a
  minimal `tldr` block plus a `gap` warning rather than padding

## Inputs

The skill is invoked with:

- `bundle` (required): the full `AnalysisBundle` object produced by
  `v-analyze-repo`. Treat its fields as the only ground truth. Do not
  re-read the repo to recover anything — if a field is missing, that
  is a signal, not a license to crawl.
- `options` (optional):
  - `maxSections`: cap on the number of sections to emit. Default 6.
  - `audienceHints`: free-form notes from the orchestrator about the
    reader (e.g. "portfolio review", "M&A diligence"). Used to nudge
    emphasis; never used to invent facts.

If `bundle` is missing or its `schemaVersion` does not match what this
skill understands, stop and report — do not proceed against an
inferred shape.

## Workflow

### 1. Ground the Layer in the Bundle

Before composing any content, walk the bundle and decide what is
actually true about this repo:

- What does the repo *do*? Use `repo.name`, frameworks, primary
  language, surfaces, and (if present) README-derived signals to
  form a one-sentence working description.
- Who interacts with it? Combine `signals.hasFrontend`,
  `signals.hasCustomerVisibleAPI`, and `signals.isInternalOnly` to
  classify the audience surface — customer-facing product, internal
  tool, infrastructure library, or unclear.
- Is it alive? Use `activity.commits`, the author count, and
  `activity.churnHeavyFiles` against the configured window to assess
  whether the repo is active, stagnant, or somewhere in between.
- Where does it sit in a portfolio? Frameworks plus surfaces plus
  signals usually place a repo as "product feature", "platform
  service", "internal tool", "library", or "infrastructure".

Anything you cannot ground — a claim about strategy, ROI, business
intent, or roadmap that the bundle does not support — does not enter
the layer. The bundle is the contract; speculation is a defect.

### 2. Decide What Sections This Repo Earns

Sections are not a checklist to fill. Decide which earn their place
based on what the bundle reveals:

| Section | Emit when… |
| --- | --- |
| `tldr` | Always — every executive layer leads with a 1–3 sentence summary |
| `strategic-shape` | The bundle places this repo somewhere a non-engineer would recognise (product, platform, internal tool, library, infra) |
| `current-state` | Activity data exists — emit an honest "alive / steady / stagnant / risky" read |
| `risks-and-decisions` | The bundle surfaces concrete risk signals (regulated data, security-sensitive code, license unknowns, deployment artefacts without ownership, signal conflicts) |
| `audience-and-reach` | Surfaces or frontend/API signals are strong enough to characterise who this repo touches |
| `what-to-watch` | Activity churn, signal conflicts, or warning codes suggest something an exec should keep an eye on |

A small or quiet repo may earn only `tldr` plus one other section.
That is correct. Padding an empty repo with strategic narrative is a
fabrication — see Anti-Patterns.

### 3. Compose Each Section From Bundle Facts

For each section that earns its place, write the content as a short,
skim-first block. Rules across all sections:

- **One claim per sentence.** Executives skim; compound sentences
  obscure the read.
- **Lead with the assertion, not the evidence.** "This is an internal
  CLI used by a small team" before "the bundle shows no public API
  surfaces and 4 distinct authors in the last 30 days."
- **Anchor every assertion to a bundle field** in the structured
  evidence list (see Output Contract). The renderer may or may not
  expose evidence to readers, but the structured trail must exist so
  reviewers can verify.
- **Length scales with importance.** A live customer-facing service
  earns more space than a dormant internal helper. Do not pad.

### 4. Mark Callouts Semantically

When a fact rises above prose level — a regulated-data flag, a
months-old most-recent commit, a license gap, a signal conflict —
emit it as a `callout` element with an explicit level. Callouts
exist so the renderer can highlight them; do not bury them in
paragraphs. Levels:

- `info` — orientation a reader should know but does not need to act on
- `note` — useful context that may shape a follow-up question
- `warn` — a concrete risk an exec should be aware of (regulated
  data, security-sensitive code with no recent review activity,
  unknown licenses on runtime dependencies, deployment artefacts
  without owner signal)
- `risk` — a hard problem the bundle is confident about (signal
  conflicts the analyser flagged, repos with deployment artefacts
  but zero recent activity)

Never emit `risk` without at least one bundle warning or evidence
entry pointing at the underlying signal.

### 5. Stay Inside the Audience Boundary

Executive content has a strict boundary that the renderer cannot
restore if you cross it. Hold the line:

- No tool, framework, or language names rendered as code identifiers.
  Use general terms — "built on a popular web framework", "the package
  manifest", "the deployment manifests" — and let the architecture
  layer name names.
- No code blocks. No file paths. No directory listings.
- No "the team should…" prescriptions. Surface the decision; do not
  pretend to make it.
- No invented business context. If the bundle does not say what this
  repo *is for*, say what it appears to *be* and stop.

### 6. Assemble the Layer

Emit a single object matching the Output Contract — a list of
section/callout elements plus metadata about what was emitted and
what was deliberately omitted. The orchestrator's `format-output`
step renders it; downstream synthesis agents consume the structured
content directly without re-parsing prose.

## Output Contract

The skill returns exactly one object in this shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "executive",
  "repo": {
    "name": "<bundle.repo.name>",
    "path": "<bundle.repo.path>"
  },
  "elements": [
    {
      "type": "section",
      "id": "tldr",
      "title": "<short heading>",
      "body": "<1–3 sentence plain-text paragraph>",
      "evidence": [
        { "field": "<dotted bundle path>", "note": "<why this grounds the section>" }
      ]
    },
    {
      "type": "callout",
      "level": "info | note | warn | risk",
      "title": "<short heading>",
      "body": "<plain-text content, no markup>",
      "evidence": [
        { "field": "<dotted bundle path>", "note": "<grounding>" }
      ]
    }
  ],
  "emitted": ["<section-or-callout id>"],
  "skipped": [
    { "id": "<section id>", "reason": "<why this section was not earned>" }
  ],
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle path>"] }
  ]
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  any change to the element vocabulary or required fields.
- `audience` is always the literal string `"executive"`. The
  orchestrator routes by this field.
- `elements` is an ordered list. Render order is emit order. The
  first element must be the `tldr` section.
- Each element's `id` is a stable kebab-case slug (e.g. `tldr`,
  `strategic-shape`, `regulated-data-flag`). IDs are unique within a
  layer.
- `body` is plain text. No markdown headings, no fenced code, no
  embedded markup. The renderer adds structure.
- `evidence` is required for every section and every `warn` or `risk`
  callout. `field` is a dotted path into the bundle
  (`signals.hasCustomerVisibleAPI`, `activity.commits`, etc.) — never
  a path into the repository filesystem.
- `emitted` lists every element id that was produced. `skipped`
  documents sections considered and intentionally not emitted, with
  a reason; this is how the orchestrator knows the absence is
  deliberate.
- `warnings` uses stable codes consistent with `v-analyze-repo`'s
  vocabulary plus layer-specific additions: `WARN_BUNDLE_INCOMPLETE`,
  `WARN_NO_ACTIVITY_DATA`, `WARN_NO_SURFACE_SIGNAL`,
  `WARN_SIGNAL_CONFLICT_PROPAGATED`, `WARN_AUDIENCE_BOUNDARY_TIGHT`
  (the bundle was so thin only `tldr` could be grounded).

The skill never writes files, never performs network calls, and never
reads from the repository directly. The bundle is the only input.

## Quality Bar

A layer meets the quality bar when:

- Every assertion in every `body` field is traceable to at least one
  `evidence.field` pointing into the bundle
- The `tldr` section is present, leads the `elements` list, and is at
  most three sentences
- Sections are present because the bundle earned them and absent
  because the bundle did not — `skipped` documents the second case

## Anti-Patterns

**The padded-empty-repo layer.** A repo with no surfaces, no recent
activity, and a single contributor produces a long executive layer
full of strategic narrative. Every paragraph is a fabrication. Emit
`tldr` plus a `WARN_AUDIENCE_BOUNDARY_TIGHT` warning and stop.

**The architecture-in-shorter-sentences layer.** Describing component
relationships, data flows, or framework choices in plain English and
calling it "executive". Architecture content belongs in the
architecture layer; the executive layer answers different questions
(state, reach, risk, decisions worth surfacing).

**The opinionated layer.** Telling the exec what they should
*decide* — "this repo should be sunset", "the team should invest in
testing." Surface the decision; do not make it. The exec is the
decider.

**The signal-conflict-laundering layer.** The bundle reports a
`WARN_SIGNAL_CONFLICT` and the layer silently picks a side, hiding
the conflict from the reader. Surface the conflict as a callout.

## Critical Rules

1. **The bundle is the only ground truth.** No re-reading the repo,
   no inferred business context, no industry priors. If it is not in
   the bundle, it is not in the layer.

2. **`tldr` is always emitted.** Even a layer reduced to a single
   sentence must have a `tldr` section. The orchestrator depends on
   it for navigation indices and synthesis.

3. **Audience boundary is hard.** No tool names, framework names,
   identifiers, or file paths in body text. The verifier rejects
   them at the skill level; the renderer cannot fix them
   downstream.

4. **Every assertion needs evidence.** Sections and `warn`/`risk`
   callouts must carry at least one `evidence.field` pointing to the
   bundle path that grounds them. Missing evidence is a quality-bar
   failure.

5. **Output is structured, not finished prose.** The skill returns
   the constrained AST defined in the Output Contract. The
   `format-output` step in the orchestrator handles MDX, callout
   components, and any markup; this skill never emits markup.

6. **Skipped sections are documented.** A repo too thin to support
   a section means the section is recorded in `skipped` with a
   reason. Silence reads as fabrication.

7. **Length tracks importance.** A live customer-facing service
   earns more space than a dormant internal library. Do not pad
   either; do not starve either. The bundle is the ruler.
