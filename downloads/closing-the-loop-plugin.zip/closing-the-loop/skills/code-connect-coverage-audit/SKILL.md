---
name: code-connect-coverage-audit
description: Audit Code Connect coverage for a team — what percentage of published Figma components have mappings in the codebase, what mappings are stale (referencing code files / components that no longer exist or have been renamed), and what's drifted (the Figma component has been updated more recently than the mapping file). **Framework-agnostic** — handles both first-class template-files (`.figma.ts` with `instance.*` API, used by React) AND HTML integration parser-files (`.figma.ts` with `figma.connect()` calls, used by Angular / Vue / Svelte / Lit / Web Components / HTML). Three-direction audit, one report. Pairs with `library-freshness-check` for Highway-tier teams that already have Code Connect set up. Read-only by design — produces a punch list, never modifies mappings. Pairs with the `schedule` skill for weekly automated runs. Use periodically (weekly or before a release), when components look like they're not picking up Figma updates, when joining a team and orienting on their Code Connect coverage, or whenever the user asks to "audit Code Connect", "check Code Connect coverage", "are our Code Connect mappings stale", "Code Connect drift report", "what percent of our Figma components are Code Connected", or "Code Connect health check".
trigger: [audit code connect, check code connect coverage, are our code connect mappings stale, code connect drift report, what percent of our figma components are code connected, code connect health check, code connect status, code connect audit]
license: Apache-2.0
---

# Code Connect Coverage Audit

## Objective

Code Connect is a contract between Figma and the codebase. Like any contract, it drifts. Designers add components, rename variants, deprecate things. Engineers rename files, restructure imports, deprecate components. Without a deliberate check, the coverage silently degrades — until a designer review surfaces that "Code Connect doesn't show the right snippet anymore for half the components."

This skill is the maintenance counterpart to `code-connect-setup` and `figma-code-connect`. It walks both sides, computes three drift directions, and produces a punch list aimed at engineers + designers. Run it weekly. Treat it as the team's Code Connect health check.

## When to Use

- **Weekly recurring check** — pair with the `schedule` skill
- Before a release
- When prototypes from `prototype-from-components` look like they're not using the latest Figma components
- When joining a team — orient on Code Connect coverage before touching anything else
- The user says: "audit Code Connect", "check Code Connect coverage", "are our Code Connect mappings stale", "Code Connect drift report", "what % of our Figma components are Code Connected"

Do NOT use when:
- Code Connect isn't set up yet — run `code-connect-setup` first
- The Figma MCP isn't available — this skill needs it
- The team only wants token drift — use `figma-tokens-extract` workflow / drift checks, not this

## Prerequisites

1. Figma MCP server connected
2. `figma.config.json` exists at the project root (created by `code-connect-setup`)
3. At least one `.figma.ts` mapping exists in the codebase (otherwise the report is just a list of unmapped components — use `code-connect-setup` for the first batch instead)
4. Figma file URL — auto-detected from existing `.figma.ts` files' `url=...` comments

## The three drift directions

| # | Drift class | What "behind" looks like |
|---|---|---|
| 1 | **Unmapped in code** | Figma has 47 published components, codebase has `.figma.ts` for 31. The other 16 are unmapped. |
| 2 | **Orphan mappings** | A `.figma.ts` file references a Figma node that no longer exists (renamed, deleted, or merged into another component). The mapping should be deleted or updated. |
| 3 | **Stale / drifted** | A `.figma.ts` file's `source=...` path points to a code file that has been renamed or removed. OR the Figma component's last-modified timestamp is significantly newer than the mapping file's — possible spec change that hasn't been picked up. |

## Workflow

### Step 1: Detect the parser mode

Read `figma.config.json` `parser` value first. This drives how the audit parses mapping files:

- `parser: "react"` → expect first-class template-files (`.figma.ts` with `instance.getString()` etc.; URL is in a `// url=` leading comment)
- `parser: "html"` → expect HTML integration parser-files (`.figma.ts` with `figma.connect("url", ...)`; URL is the first argument to `figma.connect()`)
- `parser: "swift"` / `"compose"` → native parsers; expect `.figma.swift` or `.figma.kt` files with their respective `figma.connect()`-equivalent calls
- `parser: "custom"` → roll-your-own; the audit can still walk files but can't reliably parse URLs without project-specific glue

If `figma.config.json` is missing or `parser` is unset, scan the codebase for both patterns and infer.

### Step 2: Load the codebase's Code Connect mappings

Walk the project for `*.figma.ts`, `*.figma.tsx`, `*.figma.swift`, and `*.figma.kt` files. **Both styles use the same file extensions for the web frameworks** (`.figma.ts`) — the difference is the file's *content* (leading-comment URL vs. `figma.connect()` first-arg URL), not the extension.

For each file, extract:

- **Figma URL** (and from it, fileKey + nodeId):
  - **First-class template-file style** — look for the `// url=...` leading comment
  - **`figma.connect()` parser-file style** — parse the first argument of the `figma.connect("url", ...)` call
- **Code component reference**:
  - First-class — `// source=...` and `// component=...` comments
  - `figma.connect()` — the second argument (import path) and the `example` function signature
- **Mapping file's last-modified timestamp** (from filesystem stat)

Build a unified map regardless of style:

```
mappings = {
  "12:34": {
    file: "src/figma/Button.figma.ts",
    style: "first-class" | "figma.connect",
    source: "src/components/Button.tsx" | "src/app/shared/button/button.component.ts",
    component: "Button" | "DsButtonComponent",
    modifiedAt: 2026-05-12
  },
  ...
}
```

Also confirm the detected `style` matches the `figma.config.json` `parser` — if `parser: "react"` but the file uses `figma.connect()`, that's a misconfiguration worth flagging.

### Step 3: Query Figma for published components

Use the Figma MCP `get_code_connect_suggestions` with `excludeMappingPrompt: false` to get every published component (mapped or not). For each:

- nodeId (e.g. `12:34`)
- name (e.g. `Button/Primary/Medium`)
- last-modified timestamp (if the MCP exposes it; otherwise via `get_metadata`)
- whether it's already Code Connected (mapped from Figma's perspective)

Build:

```
figma_components = {
  "12:34": { name: "Button/Primary/Medium", modifiedAt: 2026-06-08, isCodeConnected: true },
  "5102:1043": { name: "EmptyState", modifiedAt: 2026-06-01, isCodeConnected: false },
  ...
}
```

### Step 4: Compute the three drift classes

**Class 1 — Unmapped in code:**

```
unmapped = figma_components.keys() − mappings.keys()
```

Filter out any with `isCodeConnected: true` (Figma thinks they're mapped — likely a mapping in a path we didn't scan).

**Class 2 — Orphan mappings:**

```
orphans = mappings.keys() − figma_components.keys()
```

These are `.figma.ts` files referencing nodes that no longer exist in Figma. Could be deleted components or — more often — renamed components where the new component-set has a different nodeId.

For each orphan, attempt to detect a *rename* — search Figma for a component with a similar name to the mapping's `component=` field. If found with high similarity (variant structure match, name distance ≤ 3), flag as "likely rename: confirm and update nodeId".

**Class 3 — Stale / drifted:**

For each entry in `mappings`:

- Check the `source=` path exists in the codebase. If not, flag as "source file missing — code component renamed or removed".
- Check the `component=` name still exists in that file (parse exports). If not, flag as "code component name not found".
- Compare Figma's `modifiedAt` with the mapping file's `modifiedAt`. If Figma is more than 14 days newer, flag as "potential drift — Figma updated after mapping".

### Step 5: Render the report

```
# Code Connect Coverage Report — 2026-06-30
Figma file: tripletex-design-library (4WZWeGkM…)
Codebase: cristinaiftode/tripletex-component-library

📊 Coverage: 47/63 (75%)
Mappings on disk: 47 · Published Figma components: 63

## 1. Unmapped in code (16) — run figma-code-connect for each

| Component | Figma node | Suggested next step |
|---|---|---|
| Banner v2 | 4521:889 | figma-code-connect with this URL |
| EmptyState | 5102:1043 | figma-code-connect |
| KeyValuePair | 4990:2287 | figma-code-connect |
| Toast | 4711:1502 | figma-code-connect |
... 12 more ...

## 2. Orphan mappings (3)

| Mapping file | Likely cause | Suggested action |
|---|---|---|
| src/figma/Counter.figma.ts (was 12:34) | Likely rename: Figma now has `Counter/Filled` at 12:38 (95% match on variants) | Confirm with designer, update `url=` to 12:38 |
| src/figma/LegacyTag.figma.ts | Figma component deleted | Remove the .figma.ts file |
| src/figma/OldModal.figma.ts | No similar component in Figma | Designer review needed |

## 3. Stale / drifted (5)

### Source-file issues (2)
- src/figma/Input.figma.ts → source=src/components/Input.tsx — file exists, but component `Input` no longer exported (renamed to `TextInput`?). Update `source=` and `component=`.
- src/figma/Avatar.figma.ts → source=src/components/Avatar.tsx — FILE NOT FOUND. Component moved or removed.

### Figma-newer-than-mapping drift (3)
- src/figma/Button.figma.ts — Figma modified 2026-06-25; mapping last edited 2026-04-12. 74-day gap; review for spec change.
- src/figma/Tag.figma.ts — Figma modified 2026-06-20; mapping last edited 2026-05-30. 21-day gap; review.
- src/figma/Modal.figma.ts — Figma modified 2026-06-29; mapping last edited 2026-06-10. 19-day gap; review.

## Recommended next steps

1. Map the 16 unmapped components — use `figma-code-connect` per-component, or `code-connect-setup --batch` for a sprint.
2. Resolve the 3 orphans — confirm renames with designer, update `url=` references.
3. Triage the 5 drifted mappings — Figma may have added a new variant or changed a token. Re-running `figma-code-connect` on the same Figma node refreshes the template.

Full report saved to: ./code-connect-coverage-report-2026-06-30.md
```

### Step 6: Save the report

Default location: `./code-connect-coverage-report-YYYY-MM-DD.md`. `--no-save` suppresses.

If a previous report exists, compute the coverage delta (e.g. "75% (+3pp from last week)") and surface it in the summary.

### Step 7: Suggest scheduling

End with:

```
This check is most useful weekly. To run it every Monday morning:

  schedule "code-connect-coverage-audit" --cron "0 9 * * 1" --post-to slack

Or pair with `library-freshness-check` for a combined Figma-vs-code health report.
```

## Output

- **Always:** terminal-printed report with the freshness percentage + summary
- **By default:** full markdown report at `./code-connect-coverage-report-YYYY-MM-DD.md`
- **Never:** changes to `.figma.ts` files, `figma.config.json`, or any code component. This skill is read-only. Acting on the findings is the team's choice (often via `figma-code-connect` or manual edits).

## Common failure modes

- **Missing the `--no-save` semantics.** When run periodically (e.g. by `schedule`), the report file can pile up. Either rotate (`--keep-last 4`) or pipe to Slack only. Don't silently create 52 weekly reports in the repo root.
- **False-positive renames.** A `Toast` component and a `Banner` component might share Variables and look like a rename — they aren't. Require name distance ≤ 3 AND variant structure exact match before flagging as "likely rename".
- **Treating drift threshold too strictly.** A Figma component modified 1 day after the mapping is normal (designer tweaked padding by 2px). Use a 14-day threshold — anything shorter is noise.
- **Walking `node_modules` or vendor directories.** Restrict the `.figma.ts` walk to the project's own source tree (use `figma.config.json` `include` patterns if present).
- **Auto-updating mapping files.** Don't. Even an "obviously correct" rename should be confirmed by a human — Code Connect mappings are sensitive and a wrong update breaks downstream prototypes.

## Companion skills

- `code-connect-setup` — the bootstrap skill. Run it once; this audit thereafter.
- `figma-code-connect` — invoked manually for each fix (per-component mapping create or refresh).
- `library-freshness-check` — companion audit at the Figma-vs-tokens layer (from `cristinaiftode/ai-design-system-skills`). Pair both for a full health report.
- `discovery-component-mapper` — downstream consumer of the mappings. High coverage here = its Mode A path stays reliable.
- `schedule` — pair for weekly automated runs.
