---
name: closing-the-loop-setup
description: "One-time setup for the Closing the Loop plugin: choose the context-first or governed handover path and the default backlog shape, record Linear or Jira, choose tracker or Confluence for requirements, scaffold the Jira auth file (~/.netrc) with a placeholder you fill in, and verify the connection — without passing a credential through chat. Use when the user says 'set up closing the loop', 'configure my tracker', 'connect Jira/Linear/Confluence', or runs a tracker skill with no config yet."
license: Apache-2.0
---

# Closing the Loop — Setup

A one-time, credential-safe setup so every tracker-touching skill in this plugin knows **which tracker
your team uses** and **where the auth lives** — without you ever typing a secret into the chat.

It does six things:
1. Records whether the team uses the context-first or governed handover path, and the team's
   **default** backlog shape (a tie-breaker — the shape itself is decided per feature at handover).
2. Records your tracker choice + site in a small, **non-secret** config file at
   `~/.config/closing-the-loop/config.json`.
3. Records **where requirements live** — in the tracker itself, or as Confluence pages.
4. For Jira, scaffolds your `~/.netrc` auth file with a **placeholder** — you paste the real token
   yourself, in your editor, so it never enters the conversation.
5. Verifies the connection by checking an HTTP status code, never by reading the secret back.
6. On a re-run, shows what is already configured and lets you change just that (Step 0).

> **The secret is yours alone.** This skill writes placeholders and a pointer to the auth file. It
> never asks for, prints, logs, or stores your API token. If you ever find yourself about to paste a
> token into chat — stop; that's not how this works.

## What gets stored

`~/.config/closing-the-loop/config.json` (no secrets — only a pointer to the auth file). A
**`context-first`** config, which omits the governed-only handover mode and timing — this one also shows
the Confluence requirements surface, supported on this path only:

```json
{
  "version": 1,
  "tracker": "jira",
  "requirementsSurface": "confluence",
  "handoverPath": "context-first",
  "backlogMode": "epic",
  "jira": {
    "site": "<site>.atlassian.net",
    "email": "<your-atlassian-email>",
    "authMethod": "netrc",
    "authFile": "~/.netrc"
  },
  "confluence": {
    "spaceKey": "<SPACE>",
    "parentPageId": "<optional parent page id>",
    "authMethod": "netrc"
  },
  "linear": { "authMethod": "mcp" }
}
```

A **`governed`** config adds `handoverMode` and `backlogTiming`:

```json
{
  "version": 1,
  "tracker": "jira",
  "requirementsSurface": "jira",
  "handoverPath": "governed",
  "handoverMode": "standard",
  "backlogMode": "single-ticket",
  "backlogTiming": "post-gate",
  "jira": {
    "site": "<site>.atlassian.net",
    "email": "<your-atlassian-email>",
    "authMethod": "netrc",
    "authFile": "~/.netrc"
  },
  "linear": { "authMethod": "mcp" }
}
```

The token lives **only** in `~/.netrc` (or, if you choose env vars, in your shell) — never here.

> **Two keys, two questions.** `tracker` says **where delivery items live** (`jira` | `linear`);
> `requirementsSurface` says **where the PRD lives** (`jira` | `linear` | `confluence`). They are
> usually the same. When `requirementsSurface` is absent, every skill treats it as equal to `tracker`,
> so an existing config keeps working untouched. Confluence needs **no second credential** — it is the
> same site and the same `~/.netrc` entry as Jira.

## The four questions

**Show this table at the start of the run**, before asking anything. A first-time user cannot otherwise
tell how long the run is or which answers unlock follow-ups — questions 5a and 5b only exist for
governed teams, so most runs really are four questions long.

| # | Question | Key | Options | Asked when |
|---|---|---|---|---|
| 1 | Which tracker do you work in? | `tracker` | `jira` · `linear` | always (usually auto-detected) |
| 2 | Where does the PRD live? | `requirementsSurface` | `jira` · `confluence` | Jira teams only — Linear records `linear` |
| 3 | How does context cross into delivery? | `handoverPath` | `context-first` · `governed` | always |
| 4 | What should **most features** default to? | `backlogMode` | `single-ticket` · `epic` | always — the shaper recommends per feature and asks you to confirm; this is only the tie-breaker |
| 5a | Who implements the features? | `handoverMode` | `standard` · `strict` | `governed` only |
| 5b | When are stories projected? | `backlogTiming` | `post-gate` · `pre-gate` | `governed` only |

Every question has a working default, so "just pick the sensible one" is a valid answer to any of them.
Question 3 is the one that actually changes how the team works — spend the time there.

The full reference — trade-offs, the config schema with defaults, Jira auth detail, and troubleshooting —
is in [`docs/setup.md`](../../docs/setup.md). Point the user at it rather than restating it here.

## Workflow

### Step 0: Check for an existing config

Before anything else, read `~/.config/closing-the-loop/config.json`.

**If it does not exist**, this is a first run. Show [the four questions](#the-four-questions) and continue
to Step 1.

**If it does exist**, do not silently rediscover everything. Report the current settings — tracker,
`requirementsSurface`, `handoverPath`, `backlogMode` (default shape), and the governed keys when present, plus the auth
file path for Jira — and offer three choices:

1. **Show and stop** — the settings above are all they wanted (this is what "check my tracker connection"
   usually means). Offer to re-run the Step 6 verification against the existing config, then stop.
2. **Reconfigure** — walk the questions again, pre-filled with the current values so unchanged answers are
   one keystroke. Then continue from Step 1.
3. **Cancel** — change nothing.

Never print the contents of `~/.netrc` while reporting, and never rewrite an existing `~/.netrc` entry on a
reconfigure — Step 3 already handles that correctly.

**Reconfiguring `handoverPath` is worth a sentence of warning.** The path is also stamped as a marker on
each ticket, and that marker is what routes delivery. Changing the config does not retro-convert a feature
that already carries a governed package; that ticket needs its handover re-run. Say so plainly rather than
letting the user discover it later.

### Step 1: Detect what's connected, then confirm the tracker

Check, in order, what the session already has (same detection `discovery-create-tracker-issue` uses):
- **Linear** — a Linear MCP server, or a `LINEAR_API_KEY` in the environment.
- **Jira** — an Atlassian MCP server.

Tell the user what you found and confirm the choice. If both are connected, ask which the team works
with.

**If neither is connected, say so before going further.** This plugin ships no connectors, so nothing this
skill writes will make a tracker reachable — recording a choice against an absent connector produces a
config that looks correct and fails at the first real tracker write. Give the user the exact command for
the tracker they use:

```
/plugin install atlassian@claude-plugins-official
/plugin install linear@claude-plugins-official
```

(`claude-plugins-official` ships with Claude Code. On desktop/web it's the claude.ai connector settings
instead, and in Cowork **Customize → Connectors**.) Note that installing declares the server and they still
authorize it once — a tools-need-authentication state is connected-but-unauthorized, not broken.

Then offer both honest options rather than blocking outright:

1. **Connect first, then re-run this skill** — the better path if they're heading for the seam or delivery.
2. **Record the intended tracker now and proceed** — legitimate when they know which tracker the team uses
   and want the config and `~/.netrc` scaffolded ahead of connecting. Say plainly that Step 6 verification
   will not pass yet, and that the discovery lane (stages 0–6) needs no connector at all, so they can start
   there meanwhile.

Never imply the configuration is complete when the connector is missing.

### Step 1.4: Choose the requirements surface

Ask this **only when the tracker is Jira** — Confluence pairs with Jira on the same Atlassian site, so
a Linear team has nothing to choose here. Record `requirementsSurface: "linear"` and move on.

One plain question — where should the PRD live once discovery publishes it?

- **`jira`** (default) — the PRD is the issue description, exactly as today. Choose this unless the team
  already keeps product docs in Confluence.
- **`confluence`** — the PRD becomes a Confluence page the PM can keep editing, with the prototype
  attached. Delivery items still live in Jira. Choose this when requirements need to stay a living
  document, or when Briefs are long enough to bump the Jira description cap (32,000 characters).

Record the answer as `"requirementsSurface"`. When absent, every skill treats it as equal to `tracker`.

**Confluence is currently supported on the `context-first` path only.** If the team picks `confluence`
here and `governed` in Step 1.5, say so plainly, record both, and note that
`discovery-create-tracker-issue` will ask them to publish to Jira until governed Confluence support
lands. Do not silently rewrite either answer.

When the answer is `confluence`, resolve the destination now so the push does not have to:

- **Space.** List spaces with `getConfluenceSpaces` and ask which one discovery pages belong in (if the
  site has exactly one, use it and say so). Record its **key** as `confluence.spaceKey` — the page
  create tool accepts a key and resolves it, so no numeric id is needed.
- **Parent page (optional).** Ask whether discovery pages should nest under a specific page, e.g. a
  "Product discovery" parent. Record `confluence.parentPageId`. If skipped, omit the key — pages then
  parent to the space homepage.

### Step 1.5: Choose the handover path

Ask one plain question — how does the team want product/design/engineering context to cross into
delivery?

Present `context-first` first — it is the direction the project is heading and the better default for most
teams — while making clear both paths are complete and neither is degraded.

- **`context-first`** (recommended) — keep the feature ticket as the one live requirements surface, append a
  sourced Delivery Context that grounds the proposed change in the codebase, and continue into
  ordinary engineering planning without a handover-specific approval gate. Choose this for
  high-trust teams where product, design, and engineering already work together. It is also the **only**
  path that supports `requirementsSurface: confluence`.
  **What you give up:** the ratified artifact and the asynchronous approval record. Unresolved choices
  become ordinary planning decisions, so there is no written point where both sides said yes.
- **`governed`** — use the existing Engineering Brief, frozen PRD, mandatory review, and
  PM + Dev sign-off gate. Choose this when ambiguity is high, disciplines work asynchronously, or
  the team wants an explicit ratification point.
  **What you give up:** speed, and a single source of truth — the PRD freezes, so the Brief becomes the
  document that evolves. It also costs a review pass per change and a gate wait.

State both trade-offs, not just the descriptions — a team that picks `governed` because it *sounds* more
rigorous, without wanting the gate, will experience the gate as friction.

**Either way, say this once:** the shaping step reads live production code, so whoever runs the handover
needs the target repository open in Claude Code. A plain clone is enough. If the person configuring this
won't have a checkout, tell them the work splits cleanly — they can own discovery, publishing, and
confirming the story projection, with a teammate running the shaping step.

Record the answer as `"handoverPath"` in the config. When the key is **absent**, every skill falls back to
`governed` so that configs predating this choice keep working. That fallback is backward compatibility, not
a recommendation — always record an explicit answer here.

Both paths continue to Step 1.6 to choose the default backlog shape. If the answer is `context-first`,
skip Steps 1.7–1.8 after that choice. Do not write `handoverMode` or `backlogTiming`; those describe the
governed Brief/sign-off path. When reconfiguring an existing file from governed to context-first,
remove those two governed-only keys. If the answer is `governed`, ask both Step 1.7 and Step 1.8.

### Step 1.6: Choose the **default** backlog shape

Ask one plain question — what should **most features** default to?

- **`single-ticket`** (default) — the feature stays one ticket and one Delivery Context or Brief; one
  engineering session delivers one PR. Right for most features. **What you give up:** nothing you'd
  miss on a small feature — but a large one arrives as a single PR, with no sprintable units.
- **`epic`** — vertical stories with stable `S-n` ids and behavioral Gherkin, optionally projected as
  tracker children. Governed records the story map in the reviewed Engineering Brief (§6.3) and uses
  `create-backlog-from-brief`; context-first records it in the Delivery Context and uses
  `handover-project-stories` without adding a handover sign-off gate.
  **What it costs:** a projection pass, and the generated children are **read-only** — feedback goes on the
  parent, because a directly-edited story is overwritten on the next reconcile. Worth saying up front;
  teams reliably try to edit a story first.

**This is a default, not a decision.** `handover-shape-feature` (context-first) and
`discovery-handover-package` (governed) look at each feature's contract, recommend a shape, use this
value only to break ties, and ask you to confirm once per feature. The outcome is recorded on the
ticket, never written back here. Epic-default teams keep getting epic recommended when the evidence is
balanced. Heuristic: `${CLAUDE_PLUGIN_ROOT}/references/backlog-shape-decision.md`.

Record the answer as `"backlogMode"` in the config. When absent, every skill treats it as
`single-ticket`. Changing it later only changes the tie-breaker for future features; already-shaped
features keep the shape recorded on their ticket.

### Step 1.7: Choose the governed handover mode

Ask this only for `governed` — in day-to-day work, who implements the features?

- **`standard`** (default, recommended to start) — *a developer working with an AI copilot.* The
  handover produces a strong starting package; anything unresolved becomes an explicit question on the
  PM/Dev sign-off gate, and the dev can always just ask. Choose this unless you know otherwise.
- **`strict`** — *an autonomous coding agent with no human conversation.* The handover payload (Brief +
  frozen PRD + AGENTS block) must fully stand alone before the ticket is promoted; gaps block the
  handover instead of becoming questions.

Record the answer as `"handoverMode"` in the config. When the key is absent, every skill treats it as
`standard`.

### Step 1.8: Choose the governed backlog timing

Ask **whenever the path is governed** — when should stories be projected into the tracker?
Context-first has no governed gate timing. The value is meaningful only for features that end up
epic-shaped, but any feature can be shaped epic at handover (Step 1.6 is only the default), and
`prepare-amigo-session` no longer re-runs setup mid-feature to ask — so record it now.

- **`post-gate`** (default) — stories are created only after both PM + Dev sign-offs are Done. Choose
  this unless the team reviews the breakdown together before approving; it also defers the projector's
  token spend past the gate.
- **`pre-gate`** — stories are projected right after the mandatory brief review, **before** sign-off,
  so the team's refinement session (e.g. a three-amigos walkthrough) reviews real tracker stories and
  the sign-off then ratifies the Brief *and* the visible breakdown. Delivery stays blocked until both
  sign-offs are Done regardless.

Record the answer as `"backlogTiming"` in the config. When the key is absent, every skill treats it
as `post-gate`.

### Step 2 (Jira): resolve the site and email

- **Site.** If the Atlassian MCP is connected, call `getAccessibleAtlassianResources` and use the
  returned site URL (if more than one, ask which). Otherwise ask the user for their site — the
  `<site>` in `https://<site>.atlassian.net`.
- **Email.** Ask for the Atlassian account email used to log in. This is not a secret; it goes in both
  `~/.netrc` and the config.

### Step 3 (Jira): scaffold `~/.netrc` — placeholder only

`~/.netrc` is the auth file `curl --netrc` reads. Add an entry for the site **without overwriting**
anything already there:

1. If `~/.netrc` already has a `machine <site>.atlassian.net` line, leave it alone — report that an
   entry already exists and skip to Step 5 (verify). Detect it without printing the file's contents,
   e.g. `grep -q "machine <site>.atlassian.net" ~/.netrc`.
2. Otherwise append this block (create the file if absent):

   ```
   machine <site>.atlassian.net
     login <email>
     password REPLACE_WITH_CLASSIC_API_TOKEN
   ```

3. Lock the file down: `chmod 600 ~/.netrc`.

**Write the literal placeholder `REPLACE_WITH_CLASSIC_API_TOKEN`.** Never put a real token here, and
never ask the user to give you one.

### Step 4 (Jira): hand the secret step to the user

Tell the user to do this themselves, outside the chat:

1. Go to **id.atlassian.com → Security → API tokens** and create a token.
   **Create a classic (unscoped) token** — a *scoped* token is Bearer-only and fails basic auth with a
   confusing `401`.
2. Open `~/.netrc` in their editor and replace `REPLACE_WITH_CLASSIC_API_TOKEN` with the token.
3. Save. The token never leaves their machine.

### Step 5: Write the config

```bash
mkdir -p ~/.config/closing-the-loop
```

Write `~/.config/closing-the-loop/config.json` with `tracker`, `requirementsSurface`, `handoverPath`,
`backlogMode`, and for Jira the `site`, `email`, `authMethod: "netrc"`, `authFile: "~/.netrc"`. For
`governed`, also write `handoverMode` and `backlogTiming`. When the requirements surface
is `confluence`, also write the `confluence` block: `spaceKey`, `parentPageId` only if one was chosen,
and `authMethod` — `"netrc"` when a classic token is available, or `"mcp"` when attachment and labels
run connector-only (Step 6). No secret goes in this file.

### Step 6: Verify — by status code, never by reading the secret

After the user confirms they've pasted the token, check the connection without echoing any credential:

```bash
curl -s -o /dev/null -w "%{http_code}" --netrc \
  "https://<site>.atlassian.net/rest/api/3/myself"
```

- `200` — working. Optionally confirm identity by showing only the `displayName` from
  `/rest/api/3/myself` (never the token, never the file).
- `401` — the placeholder is still in `~/.netrc`, or a *scoped* token was used. Point the user back to
  Step 4.
- `403` — the account lacks access; `404` — wrong site. Surface readably.

**When `requirementsSurface` is `confluence`, check Confluence too** — same credential, same discipline,
status code only:

```bash
curl -s -o /dev/null -w "%{http_code}" --netrc \
  "https://<site>.atlassian.net/wiki/rest/api/user/current"
```

- `200` — the same token reaches Confluence; page publishing, prototype attachment, and labels all work.
- `401` — same causes as above (placeholder still in place, or a *scoped* token).
- `404` — Confluence is not provisioned on this site. Say so and offer to fall back to
  `requirementsSurface: "jira"`.

**When there is no classic token to check** — no `~/.netrc` entry, no env vars, or an environment that
has neither (Cowork is the case that matters) — do not report a failure. The token is optional for this
surface: it only buys prototype *attachment* and the convenience page label. Instead verify through the
connector: list spaces with `getConfluenceSpaces` and confirm the configured `spaceKey` is reachable.
Then record `confluence.authMethod: "mcp"` and tell the user plainly what they get:

- **works** — publishing the page, editing it, the marker block, and the whole handover chain;
- **falls back** — a prototype is linked, or handed to them to upload manually, rather than attached
  automatically; and no page label is applied. The marker block carries the path either way, so nothing
  downstream breaks.

Never treat a missing token as a setup failure on the Confluence surface. It is a capability difference,
not a broken configuration.

Never print the contents of `~/.netrc`.

### Step 2–6 (Linear): minimal

Linear needs no auth file — the connector (or `LINEAR_API_KEY`) carries auth.

- Record `tracker: "linear"` and `authMethod`: `"mcp"` if the MCP is connected, else `"env"`.
- If `"env"`, tell the user to set `LINEAR_API_KEY` in their own shell profile (never in chat).
- Verify via the MCP (read the viewer / list teams), or — for the env route — a whoami that reads the
  key from the environment without echoing it.
- Write the config (Step 5) and report.

### Step 7: Report

Three things, in this order.

**1. Show what was written.** Print the resulting config file contents verbatim. It holds no secrets — the
Security Rules below guarantee that — so showing it is safe, and it is the only way the user can confirm
the run recorded what they meant:

```json
{
  "version": 1,
  "tracker": "jira",
  "requirementsSurface": "confluence",
  "handoverPath": "context-first",
  "backlogMode": "epic",
  "jira": { "site": "...", "email": "...", "authMethod": "netrc", "authFile": "~/.netrc" },
  "confluence": { "spaceKey": "PROD", "authMethod": "netrc" }
}
```

Then state the config path, the auth file path (Jira), and the verification result — including the
Confluence check when it ran, and the capability difference when `confluence.authMethod` is `"mcp"`. Name
the Confluence space when one was chosen. **Never print `~/.netrc`.**

**2. Give exactly one next command**, derived from what was just recorded — not a menu:

| Recorded | Say next |
|---|---|
| `handoverPath: context-first` | `Create a handover from <KEY>` (runs `handover-shape-feature`) |
| `handoverPath: governed` | `Create a handover from <KEY>` (runs `handover-workflow`) |
| `governed` + `backlogTiming: pre-gate` | `Run prepare-amigo-session for <KEY>` (only useful for a feature that ends up epic-shaped) |
| No feature ticket yet | `Run the full discovery to prototype workflow` |
| Unsure which | `Close the loop on <KEY>` — the orchestrator detects where the feature is |

If the target repo has no `AGENTS.md` / `CLAUDE.md`, add one line recommending `v-setup-agent-context`
first — the bridge reads that context when it captures codebase constraints.

**3. Note that nothing else needs configuring.** The tracker and handover skills
(`discovery-create-tracker-issue`, `handover-shape-feature`, `handover-project-stories`,
`discovery-handover-package`, `handover-retrieval`, `handover-brief-review`,
`create-backlog-from-brief`) read this config automatically, so these choices are never asked again —
the one per-feature question left is the backlog shape, which the shaper confirms against the default.
Re-running this skill shows the current settings and offers to change them (Step 0). Full reference:
[`docs/setup.md`](../../docs/setup.md).

## Security Rules

- **Never** ask for, accept, print, log, or store an API token in the chat, the config file, or any
  artifact. If a token appears in the conversation, treat it as compromised and tell the user to rotate it.
- The skill writes **placeholders only**; the user fills the secret out-of-band in their editor.
- `chmod 600 ~/.netrc` so only the owner can read it.
- Verification asserts on the **HTTP status code**, not on file or credential contents.
- The config file holds non-secret values only (tracker, site, email, auth-file path).
- Never overwrite an existing `~/.netrc` entry — append only, and only when absent.

## Quality Bar

A run meets the bar when:
- The user saw the shape of the run before answering question one, and saw the resulting config after.
- An existing config was read first (Step 0) and either shown, changed deliberately, or left alone — never
  silently rediscovered from scratch.
- The user leaves with **one** next command, not a menu.
- The tracker choice and (for Jira) site + email are recorded in `~/.config/closing-the-loop/config.json`.
- The requirements surface is explicit, and for `confluence` the space key is recorded and reachable.
- The handover path and default backlog shape are explicit; handover mode and backlog timing are both
  present for `governed`, and only for `governed`.
- For Jira, `~/.netrc` has a `machine <site>.atlassian.net` entry with `chmod 600`, scaffolded with a
  placeholder the user replaced — and no existing entry was clobbered.
- The connection was verified by status code (`200`), with no credential ever shown.
- No secret was requested, printed, or stored anywhere by this skill.

It fails the bar if a token passed through the chat, if the config or any artifact contains a secret,
if an existing `~/.netrc` entry was overwritten, or if "done" was claimed without a successful verify.

## Triggers

| To... | Say... |
|-------|--------|
| Run first-time setup | "Set up Closing the Loop" / "Configure my tracker" |
| Connect Jira | "Set up Jira auth" / "Connect Jira" |
| Connect Linear | "Set up Linear" / "Connect Linear" |
| Publish requirements to Confluence | "Put our PRDs in Confluence" / "Use Confluence for requirements" |
| See the current configuration | "What's my Closing the Loop config?" / "Show my tracker setup" |
| Change one setting | "Switch us to context-first" / "Change our default backlog shape to epic" |
| Re-verify the connection | "Check my tracker connection" |
