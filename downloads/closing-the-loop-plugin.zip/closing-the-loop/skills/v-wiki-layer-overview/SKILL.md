---
name: v-wiki-layer-overview
description: Author the overview layer of a wiki — a plain-language description of what the repo is, who uses it, and what category it falls into — for someone meeting it for the first time. Use when the wiki orchestrator dispatches the overview audience layer, when generating the always-emit orientation page for a repo, or when a non-technical reader needs a single short answer to "what is this thing".
trigger: [wiki overview layer, plain-language repo summary, what is this repo, overview audience documentation, generate overview wiki page]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Overview

## Objective

Produce the overview layer of a generated wiki: a short, plain-language
orientation page that lets any reader — technical or not — answer "what
is this repo, who uses it, and what kind of thing is it" in under a
minute. The overview is the always-emit layer; every wiki run produces
one regardless of the audience-routing signals.

The overview is **descriptive**, not strategic. It tells the reader
what the repo *is*. It does not argue why it matters, what state it is
in, or what to do about it — that is the executive layer's job (see
"Overview vs. Executive" below).

## When to Use

- The wiki orchestrator dispatches the overview audience layer for a
  repo, working from an `AnalysisBundle` produced by `v-analyze-repo`
- A first-time reader needs a single short page that names the repo,
  describes it in plain language, and points them onward
- The user asks for an "overview", "plain-language summary", "what is
  this repo", or an orientation document

Do not use this skill when:

- The audience is leadership and the question is ROI, risk, or
  investment posture — that is the executive layer's territory
- The audience is engineers and the question is how the system fits
  together — that is the architecture layer
- The audience is contributors and the question is how to set up,
  build, test, or deploy — that is the engineering layer
- A free-form prose summary is wanted; this skill emits structured
  content for the orchestrator to render

## Setup check

Before proceeding, verify that an `AnalysisBundle` is available as
input — produced by the `v-analyze-repo` skill or supplied directly. If
no bundle is available, stop and instruct the caller to run
`v-analyze-repo` first. This skill never re-reads the repository to
recover bundle fields; that defeats the read-once contract.

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` matching `v-analyze-repo`'s
  output contract (`schemaVersion: "1.0"` at time of writing)
- `options` (optional):
  - `siblingRepos`: a list of `{ name, oneLineSummary }` for repos in
    the same wiki run, used to populate the landscape section. Omit
    when the repo is being documented in isolation.

If the bundle's `schemaVersion` is incompatible, stop and warn rather
than producing partial output against an unknown shape.

## Overview vs. Executive

Future contributors must keep these two layers distinct. They share an
audience (non-engineers) and a tone (plain language), but they answer
different questions and must not be conflated.

| Aspect | Overview (this skill) | Executive (sibling) |
|---|---|---|
| Question answered | What is it? | Why does it matter? |
| Mode | Descriptive | Strategic |
| Typical content | Category, users, plain-language description | ROI, state, risk, investment posture |
| Tone | Welcoming, neutral | Decision-supporting |
| Always emitted? | Yes | Yes |

If a sentence in the overview starts arguing for funding, justifying
existence, framing risk, or recommending action, it belongs in the
executive layer. Move it.

## Workflow

### 1. Read the bundle, not the repo

Work exclusively from `bundle`. The `v-analyze-repo` skill exists to
amortise repo reading across wiki layers; re-walking the tree here
duplicates work and risks drift between layers. The fields used most:

- `repo.name`, `repo.isMonorepo`
- `languages.primary`, `languages.secondary`
- `frameworks[]`
- `surfaces.*` (to determine category)
- `signals.hasFrontend`, `signals.hasCustomerVisibleAPI`,
  `signals.hasDeploymentArtifacts`, `signals.isPureInfra`,
  `signals.isInternalOnly`
- `dependencies.byEcosystem` (for category disambiguation only — never
  list dependencies in the overview)

### 2. Classify the category

Pick exactly one primary category from the controlled list below.
Categories are derived from signals plus surfaces; do not invent new
ones without a follow-up to refine the enum.

| Category | Primary evidence |
|---|---|
| Web application | `hasFrontend` true AND `hasCustomerVisibleAPI` or `hasDeploymentArtifacts` true |
| Backend service | `hasCustomerVisibleAPI` true AND `hasFrontend` false |
| CLI tool | A binary entry point in a manifest AND no `hasFrontend` AND no service surfaces |
| Library / SDK | `isPureInfra` true; published as a package; consumed by other code |
| Framework | `isPureInfra` true AND exposes extension points (plugin APIs, conventions) consumed by user code |
| Infrastructure / IaC | Predominantly deployment artefacts (Kubernetes, Terraform, Helm) with no application code |
| Documentation site | Static-site framework (Hugo, Jekyll, Docusaurus, etc.) and content directories dominate |
| Internal tooling | `isInternalOnly` true AND none of the above categories fit cleanly |
| Other | Nothing above fits; record why in a one-line note |

When two categories tie, pick the one closer to how the repo is
*reached* by its primary user — a service that ships a small CLI is
still a service.

### 3. Identify the audience

Express users in role-shaped phrases, not personas. The role names
should be inferable from the bundle's signals and surfaces, not
invented.

- "Engineers building X" — when the repo is a library, framework, or
  SDK consumed by other code
- "Operators running Y" — when deployment artefacts dominate
- "End users of Z" — when `hasFrontend` and `hasCustomerVisibleAPI`
  point to a customer product
- "Internal teams handling W" — when `isInternalOnly` is true
- "Contributors to the platform" — when the repo is part of a larger
  internal platform identified via siblings

If the bundle does not carry enough signal to name a role, say so —
"audience not determined from analysis" — rather than guessing.

### 4. Write the plain-language description

3–5 sentences. The description must be readable by a non-engineer.
Apply these constraints:

- Lead with what it does for whom, not what it is built with
- Use everyday words; if a technical term is unavoidable, gloss it in
  the same sentence
- No code blocks, no file paths, no command lines
- No version numbers, no dependency names, no framework names unless
  the framework defines the category (e.g. "a Next.js application" is
  acceptable shorthand only when it disambiguates)
- No ROI claims, no risk framing, no calls to action — those belong in
  the executive layer

If the bundle's evidence is too thin to write 3 confident sentences,
write fewer and add a note in the warnings section of the output —
silence is worse than admission.

### 5. Place it in the landscape (if siblings supplied)

When `options.siblingRepos` is present, add a short paragraph or list
that positions this repo against its siblings — "this is the X service
in a platform that also includes Y and Z". Use only the names and
one-line summaries supplied; do not invent relationships. If
`siblingRepos` is absent, omit the landscape section entirely rather
than producing a stub.

### 6. Stay short

The overview is bounded. Resist drift into architecture or
engineering. Concrete budgets:

- One-line summary: ≤ 25 words
- Plain-language description: 3–5 sentences, ≤ 120 words
- Audience: 1–3 role-shaped phrases
- Category: exactly one label, with one evidence sentence
- Landscape: ≤ 4 sentences, omitted when no siblings supplied

If you find yourself explaining how the system works internally, stop
and hand off to the architecture layer.

### 7. Emit structured content

Return a single object matching the Output Contract. The wiki
orchestrator's format-output step renders it; this skill never emits
MDX directly.

## Output Contract

The skill emits exactly one JSON object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "overview",
  "repo": {
    "name": "<bundle.repo.name>"
  },
  "title": "<repo name> — Overview",
  "oneLineSummary": "<repo name> is a <category> that <does what for whom>.",
  "category": {
    "label": "<one of the controlled categories>",
    "evidence": "<one sentence pointing at bundle fields that justify the label>"
  },
  "description": "<3–5 plain-language sentences>",
  "audienceRoles": [
    "<role-shaped phrase>"
  ],
  "landscape": {
    "siblings": [
      { "name": "<sibling repo name>", "relationship": "<one short phrase>" }
    ],
    "note": "<one paragraph, ≤ 4 sentences>"
  },
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>" }
  ]
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  contract changes.
- `audience` is always the literal string `"overview"`. Downstream
  rendering uses it to pick the layer template.
- `oneLineSummary` follows the `<name> is a <category> that <verb
  phrase>` pattern. The pattern is contractual — the wiki landing page
  composes these summaries across siblings and depends on the shape.
- `category.label` must be drawn from the controlled list in step 2.
  When `Other` is used, `category.evidence` must explain why no other
  label fit.
- `description` is plain prose, no markdown formatting beyond
  sentences. The orchestrator's format step adds any structural
  rendering.
- `audienceRoles` contains 1–3 role-shaped phrases. The empty list is
  a quality-bar failure; emit a `WARN_AUDIENCE_UNDETERMINED` warning
  and a single `"audience not determined from analysis"` placeholder
  rather than an empty array.
- `landscape` is omitted when `options.siblingRepos` is absent. When
  present, every `siblings[].name` must appear in the supplied
  `siblingRepos`; do not invent siblings.
- `warnings` uses the same code-prefixed shape as `v-analyze-repo`.
  Recognised codes for this skill:
  - `WARN_THIN_EVIDENCE` — bundle did not carry enough signal for a
    confident description
  - `WARN_CATEGORY_AMBIGUOUS` — two categories tied; record both in
    the message
  - `WARN_AUDIENCE_UNDETERMINED` — no role-shaped phrase could be
    derived from the bundle
  - `WARN_BUNDLE_VERSION_MISMATCH` — `bundle.schemaVersion` was newer
    or older than expected; the skill produced a best-effort output

## Quality Bar

An overview meets the quality bar when:

- A non-engineer reading the description understands what the repo is
  and who uses it without consulting any other layer
- The category label matches the bundle's signals — a `hasFrontend:
  false` repo is not labelled "Web application"
- The one-line summary follows the `<name> is a <category> that
  <verb>` pattern exactly
- Audience roles are role-shaped, not technology-shaped — "engineers
  building integrations", not "TypeScript developers"
- The output stays within the length budgets in step 6
- Every `warnings` entry is a real, actionable observation about the
  bundle, not boilerplate
- The output is self-contained: removing the architecture and
  engineering layers does not break the reader's understanding of
  what the repo is

## Anti-Patterns

**The architecture leak.** Drifting into "the frontend communicates
with the backend over a REST API and the backend writes to a Postgres
database." Plain-language readers do not need this; engineers reading
the architecture layer do.

**The dependency dump.** Listing the tech stack in the overview
("built with Next.js, Tailwind, Convex, and Stripe"). The overview
names the category, not the toolchain. Tech-stack inventory belongs
in the architecture or engineering layers.

**The persona invention.** Writing "ideal for forward-thinking
product teams" when the bundle says nothing about who uses the repo.
Audience roles must be inferable from the bundle; otherwise admit the
gap with `WARN_AUDIENCE_UNDETERMINED`.

## Critical Rules

1. **Always emit.** Unlike audience-routed layers, the overview is
   produced for every wiki run. If the bundle is sparse, emit a short
   overview with `WARN_THIN_EVIDENCE` rather than skipping the layer.

2. **Plain language is contractual.** The overview is the only layer
   guaranteed to be readable by non-engineers. Jargon, code, and
   dependency names break that guarantee.

3. **Stay descriptive.** Overview answers "what is it" and "who uses
   it". The moment the answer becomes "and why you should care", the
   sentence belongs in the executive layer.

4. **Read the bundle, not the repo.** The overview is derived
   exclusively from `bundle`. No file reads, no shell commands, no
   version-control queries — and never create or change files in the
   source repository; the layer's only output is its JSON.

5. **One category, controlled list.** Pick exactly one label from the
   controlled list in step 2. Disambiguation goes in
   `category.evidence`; novel labels require a `WARN_CATEGORY_AMBIGUOUS`
   note and a follow-up to refine the enum.

6. **Bounded length.** Honour the budgets in step 6. The overview is
   short by design; growth comes at the cost of layer separation.
