---
name: closing-the-loop-start
description: The front door of Closing the Loop — run a preparedness scan of the current environment (config, agent context, connectors, design system, codebase), show the whole loop's journey map, and route the user to their one next step. Ends with an explicit choice — guided from the beginning, jump to a specific point, fix what's missing first, or score the repo with the agent readiness report. Use on first contact with the plugin, at the start of a team pilot (the Week 0 readiness report), or whenever the user says "start closing the loop", "start CTL" (CTL is the accepted shorthand for Closing the Loop), "run the preparedness scan", "am I ready for closing the loop", "check my closing the loop setup", "readiness report", or "what's my next step".
trigger: [start closing the loop, start ctl, ctl start, run ctl, run the closing the loop preparedness scan, am i ready for closing the loop, check my closing the loop setup, closing the loop readiness, readiness report, week 0 readiness report, whats my next step in closing the loop, begin closing the loop]
license: Apache-2.0
---

# Closing the Loop — Start

The activation moment. A user who installed the plugin should not need to read the README
to know what to do next: this skill detects what they have, shows them the whole journey,
and hands them one concrete next step. Not every user is confident or outspoken — never
leave them at an open end. Every pause here finishes with a small set of labeled options.

Two audiences, one skill:

- **A first-time user** — "I installed this, now what?"
- **A team starting a pilot** — the Week 0 *preparedness scan*: one report saying whether
  this repo + this person are ready to run the loop.

## Workflow

### Step 1: Detect (silently)

Check, without asking the user anything yet:

1. **Config** — does `~/.config/closing-the-loop/config.json` exist? If yes, read the
   tracker, `handoverPath`, and backlog mode from it.
2. **Agent context** — does the current repo have `AGENTS.md` or `CLAUDE.md`?
3. **Connectors** — are tracker tools (Jira/Linear MCP) available in this session? Figma
   MCP? Is `gh` authenticated (`gh auth status`)?
4. **Codebase** — is the working directory a git repo? Is there a component library or
   design-system folder (a `components/`, `packages/ui`, `design-system/`, or a
   `DESIGN-SYSTEM.md`)? Don't deep-scan — a cheap look is enough; the real analysis is
   `component-readiness-scan`'s job. **If the folder holds several git repos** (or a
   `.code-workspace`), note it and plan to ask which repo is the frontend — never
   assume, and never treat the folder's *name* as an app to launch (a workspace named
   `CTL` once did exactly that). For several repos, also look for `repo-landscape.md`
   at the folder root — the team's map of every product repository, including ones not
   checked out (see `${CLAUDE_PLUGIN_ROOT}/references/multi-repo.md`).
5. **Customer/product context docs** — is there a product context file the discovery lane
   could use (`CUSTOMER_PROFILE.md`, `PRODUCT.md`, a strategy doc in `docs/`)? Optional —
   note presence, never require it.
6. **Duplicate plugins** — if the standalone discovery-engine plugin's skills are also
   installed, warn: it competes for the same trigger phrases and this bundle supersedes
   it. Recommend uninstalling it (see the README's *Before you install* section).
7. **Agent readiness report** — when the working directory is a git repo, look for an
   earlier run of `v-agent-readiness-report`: an `*-agent-readiness.html` under
   `.reviews/agent-readiness/` (its default output folder). Note its path and date, or
   that there is none. Never run the report here; it takes minutes and Step 4 offers it.
8. **Plugin version** — read the installed version from
   `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`, then fetch the latest released
   version with
   `curl -s --max-time 3 "https://prod-discovery.github.io/closing-the-loop-guide/downloads/version.json"`.
   Compare as semantic versions (0.2.10 is newer than 0.2.2, not older). If the fetch
   fails or times out — offline, proxy, firewall — skip this check entirely and never
   mention it: the scan must work without internet, and a missing version row is better
   than a scary false warning.

### Step 2: Report the readiness status

Show one compact checklist — ✅ / ⚠️ / ❌ per item — in this order: plugin version,
config, agent context, tracker connector, `gh`, Figma (mark "optional" plainly),
component library, repo landscape (only for a multi-repo folder), product context docs,
agent readiness report (only in a git repo).
One line each, plain language, no jargon.
Example line:
`❌ Tracker — no Jira/Linear connector in this session. Needed from the moment you publish a ticket; discovery works without it.`

The **plugin version** line (omit it entirely when the Step 1 fetch was skipped):

- Up to date → `✅ Plugin version — 0.2.3 (latest)`.
- Outdated → a ⚠️ line naming both versions, followed by the one update path that
  matches this install. Detect it: if the plugin's installed folder (or the marketplace
  folder it lives in) contains a `.git` directory, it was installed from the GitHub
  repo — tell them to run `claude plugin marketplace update closing-the-loop` then
  `claude plugin update closing-the-loop`, and restart. No `.git` means it came from
  the zip — tell them to re-download it from
  https://prod-discovery.github.io/closing-the-loop-guide/, replace the plugin folder,
  and restart. If unsure, show both paths, each labeled with who it's for. Never tell
  a zip user to run the update commands — without repo access they do nothing.

The **repo landscape** line (only when Step 1 found several repos or a `.code-workspace`;
omit it for a single repo whose product is not known to be larger):

- `repo-landscape.md` found → `✅ Repo landscape — <n> repos mapped; <m> not checked out here.`
- Several repos, no landscape file → `⚠️ Repo landscape — several repos here but no
  repo-landscape.md. Code-reading skills can't tell what they're missing without it — I can
  draft one from the checkouts for you to finish.` Offer the draft inside option C.
- Session started *inside* one repo of a multi-repo product (the landscape file or the user
  says so) → ⚠️ advising: start Closing the Loop from the folder that holds all relevant
  repos, not from inside one of them — the session cannot see outside its starting folder.

The **agent readiness report** line (omit it outside a git repo). It is never ❌: the
loop runs without it.

- Found → `✅ Agent readiness report — run on <date>: <path to the .html>`. Older than
  about a month, or older than the last change to `AGENTS.md` / `CLAUDE.md`, → ⚠️ and
  say a re-run shows what moved.
- Not found → `⚠️ Agent readiness report — not run yet. Option D scores this repo for
  coding agents and lists the fixes, each with a prompt you can paste.`

The two reports answer different questions, so say which is which in one line: this
checklist is *can this person and this session run the loop*; the agent readiness report
is *how well can agents work in this repo*.

When the user asked for the **preparedness scan** (Week 0), also write the checklist to
`closing-the-loop-readiness.md` in the working directory so the team has the report file.
It is the one file to share: after an agent readiness report exists (found in Step 1, or
run through option D), add a `## Repo readiness for agents` section to it with the
report's path, date, the preview level per area (labelled preview, as the report labels
it) and its top three actions.

### Step 3: Show the journey map (always, ~10 lines)

```
THE LOOP — from customer signal to shipped feature

  DISCOVER   Stages 0–3   Customer data → opportunities → scored choice → PRD
  PROTOTYPE  Stages 4–5   Scan YOUR components → build a clickable prototype from them
  VALIDATE   Stage 6      Experiment plan + usability test
  PUBLISH    —            One tracker ticket; its key is the handoff
  HAND OVER  Stage 7      Delivery Context (context-first) or Brief + sign-off (governed)
  BUILD      —            "Take <KEY> to a PR" — plan → code → test → review
  SHIP       —            Release, measure against the experiment plan, feed learnings back
```

### Step 4: Offer the choice (always end here)

```
What would you like to do?

A) Start from the beginning — I'll guide you stage by stage, starting with
   whatever the checklist says is missing.
B) Jump to a specific point — tell me what you already have:
   "I have customer data"   → discovery stage 1
   "I have a PRD"           → prototype (stage 4–5)
   "I have a prototype"     → experiment plan / create the ticket
   "I have a ticket <KEY>"  → handover
   "Take <KEY> to a PR"     → delivery
C) Just fix what's missing — I'll walk you through the ❌ items only, then stop.
D) Score this repo for coding agents — the agent readiness report: an HTML
   scorecard with evidence, and the fixes as prompts you can paste. Takes a
   few minutes; changes nothing in the repo.

Which would you prefer — A, B, C, or D?
```

When the environment can show choice buttons (such as the AskUserQuestion tool), the
buttons MUST mirror the lettered options exactly — one button per letter, labelled
"A — start from the beginning", "B — jump to a specific point", "C — fix what's missing",
"D — score this repo for agents" — and nothing else. Leave D out, in the text and the
buttons, when the working directory is not a git repo. Never add a button that isn't a lettered option; a repair action such
as reconnecting a connector belongs inside C, not beside it. If a button can't be offered,
the typed letter always works.

Route accordingly: missing config → `closing-the-loop-setup`; missing agent context →
`v-ship` ("set up AGENTS.md"); A → the master `closing-the-loop` orchestrator (or
`discovery-to-prototype-engine` when the user's starting point is customer data); B → the
matching lane skill; C → resolve the ❌ items one at a time, each ending with "fixed —
next is X. Continue? (yes/no)"; D → invoke **v-agent-readiness-report** on the current
repo with its default output folder and no questions the scan already answered (several
repos in the folder: ask which first). It adds the report to AIEA only when AIEA's MCP
server is connected and the user says yes. When it returns, give the report's path and
top three actions, update `closing-the-loop-readiness.md` if this was a Week 0 scan, and
ask the A/B/C question again — the report is a look, not a stop.

💬 Include this line once, near the end: *you can send us feedback at any moment — just
say "give feedback". A quick 1–5 rating plus an optional comment, completely anonymous.
You don't need to finish anything first.*

## What this skill is NOT

- Not the explainer — `closing-the-loop-getting-started` owns "what is this plugin".
  If the user only wants orientation, hand over to it.
- Not the deep component audit — that's `component-readiness-scan` (stage 4). Step 1's
  codebase look is a presence check only.
- Not the repo scorecard — that's `v-agent-readiness-report`. Step 1 only looks for an
  earlier run; option D runs it.
- Not setup — it detects and routes to `closing-the-loop-setup`; it never writes config
  itself.

## Output

The readiness checklist (plus `closing-the-loop-readiness.md` when run as the Week 0
scan, with the agent readiness section once that report exists), the journey map, and the
user's chosen route — ending with the next skill invoked or the explicit lettered question
still open. Never end with "let me know how to proceed."
