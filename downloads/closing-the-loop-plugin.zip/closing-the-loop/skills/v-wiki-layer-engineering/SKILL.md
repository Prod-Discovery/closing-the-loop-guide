---
name: v-wiki-layer-engineering
description: Produce structured engineering-audience wiki content from an AnalysisBundle — repo layout, languages and frameworks, dev setup, gotchas, contribution flow, dependencies of note. Use when the wiki orchestrator dispatches the engineering layer, when a new contributor needs first-PR documentation derived from a fresh analysis, when a reference-repo run needs the always-emit engineering content, or when a non-engineering caller needs the same shape of contributor-facing material.
trigger: [generate engineering wiki, write contributor docs, engineering layer, dev setup docs, first PR guide]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Engineering

## Objective

Produce the engineering-audience layer for a generated wiki: a structured
content tree, derived entirely from an `AnalysisBundle`, that lets a new
contributor open their first pull request without asking questions.

Engineering is an **always-emit** layer. Every repo gets engineering
documentation, because every repo has contributors. Depth scales with the
bundle's richness: a four-file utility library produces a short layer; an
engineering-heavy reference repo with monorepo dispatch, multiple languages,
and a real test harness produces a thicker one.

This skill is **content-only**. It does not render to the wiki output format
— the orchestrator's `format-output` step handles that. Emit a structured
tree the orchestrator can render, including step-shaped content marked
semantically so it can become a `<Steps>` block downstream.

## When to Use

- The wiki orchestrator (`v-generate-wiki`) dispatches the engineering layer
  after `v-analyze-repo` produces a bundle
- A reviewer wants a contributor-facing layer regenerated against a new
  bundle without re-running architecture / executive / marketing
- The user asks for "engineering docs", "contributor guide", "dev setup",
  or "first-PR documentation" derived from repo analysis
- A non-wiki caller wants the same shape of structured content (e.g. a
  CLAUDE.md or AGENTS.md generator) — the skill's output is reusable

Do not use this skill when:

- An `AnalysisBundle` is not available — invoke `v-analyze-repo` first
- The user wants an architectural deep-dive (component boundaries, data
  flows) — that is a different audience layer
- The user wants prose marketing copy or a strategic summary

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` matching the contract emitted by
  `v-analyze-repo`. The skill reads only the bundle — it must not re-walk the
  repository
- `options` (optional):
  - `depth`: `"terse" | "standard" | "thorough"`. Default `"standard"`.
    Terse compresses sections to single paragraphs; thorough expands
    gotchas and contribution flow when signals justify it
  - `topicLimit`: cap on distinct topics emitted. Default 8

If `bundle` is missing or its `schemaVersion` does not match a supported
range, stop and emit a warning entry — do not fabricate content.

## Workflow

### 1. Read the Bundle, Decide Topic Set

Topics are derived, not hand-curated. Walk the bundle once and decide which
sections this repo justifies:

- **Repo layout** — always emitted. Sourced from `fileStructure.topLevelDirs`
  plus monorepo markers in `repo.monorepoMarkers`
- **Languages and frameworks** — always emitted. Sourced from `languages`
  and `frameworks`. One paragraph each on the load-bearing entries; skip
  frameworks that appear only as transitive deps
- **Dev setup** — always emitted. Sourced from manifests (presence of a
  package manifest implies an install step), test directories, and any
  build artifacts under `surfaces.deploymentArtifacts` that imply a
  containerised local run
- **Gotchas** — emitted when concrete evidence exists. Sourced from
  `signals.evidence`, monorepo dispatch markers, environment-variable
  references in code (only if surfaced in the bundle), and `warnings`
- **Contribution flow** — emitted when `activity.authors` is non-empty
  and recent commits exist. Branching/PR conventions inferred from
  recurring patterns in the bundle's activity section
- **Dependencies of note** — emitted when `dependencies.byEcosystem`
  surfaces high-blast-radius entries (frameworks, runtime libraries, deps
  with unusual licenses, deps the bundle explicitly flagged via
  `WARN_LICENSE_UNKNOWN` or similar)

Skip a topic when its evidence is empty. A repo with no recent commits
gets no contribution-flow section. A pure-library repo with no deployment
artefacts gets no containerised-run paragraph in dev setup. Empty topics
are worse than missing topics.

### 2. Repo Layout — Describe, Don't Inventory

Anyone can list directory names. The value here is explaining what
*belongs* in each top-level directory, derived from the bundle's
per-language file counts and surface inventories:

- For each top-level directory with a meaningful file count (>1% of total
  or hand-flagged in the bundle), state what kind of content lives there
  in one sentence
- Mark monorepo dispatch points explicitly. If `repo.isMonorepo` is true,
  call out the workspace marker file and explain that changes in a
  package directory typically only need that package's checks
- Flag generated or vendored directories the bundle excluded — readers
  who don't know the convention will waste time reading them otherwise

Output as a layout list (semantic, not visual — the orchestrator chooses
the rendering). Each entry: `{ path, role, contributorNote }` where
`contributorNote` is the non-obvious bit a first-time PR author needs.

### 3. Languages and Frameworks — One Paragraph Each

For each entry in `languages.primary` and `languages.secondary`, write a
short paragraph covering:

- Where in the tree this language lives (cross-reference the layout
  section, don't repeat it)
- What version constraints the manifest pins to, if surfaced in the
  bundle
- Whether this language is tested, has a linter, or has a formatter
  configured — derived from the manifest, not assumed

For each framework in `frameworks`, do the same — one paragraph naming
the framework, its version (if known), and the load-bearing
responsibility it owns. Do not list frameworks the bundle classifies as
unused; the bundle has already filtered transitive-only matches.

When two languages share the same role (e.g. both `.ts` and `.tsx`), do
not write redundant paragraphs — fold them into one.

### 4. Dev Setup — Tool-Neutral Steps

This is the section most likely to attract banned vocabulary. Resist.
Describe each step in tool-neutral phrasing:

- "Clone the repository at the URL shown in the project manifest"
- "Install dependencies via the project's package manager — the lockfile
  in the repo root identifies which one"
- "Run the build command declared in the project manifest"
- "Run the test command the project declares — typically a script entry
  in the manifest or a target in the build configuration"
- "Run the development entry point — the manifest's start script, the
  framework's dev server command, or the documented entry point in the
  README"

Mark this content as step-shaped so the orchestrator renders it as a
`<Steps>` block. Each step gets `{ ordinal, action, note }` where `note`
captures the one-sentence "what could go wrong here" that the bundle
surfaced (missing env vars, required external services, monorepo
dispatch caveats).

If the bundle includes deployment artefacts implying a local container
run, add an alternative step path. If multiple package managers are
detected (a sign of partial migration), surface that as a gotcha rather
than picking one in the steps.

### 5. Gotchas — The Non-Obvious Catches

This is the highest-value section because it is the hardest to derive
from raw structure. Mine the bundle for everything that would surprise a
first-time contributor:

- **Monorepo dispatch rules.** If `isMonorepo` is true, explain which
  package's checks run for which path changes. If the bundle does not
  surface dispatch evidence (a workflow file under
  `surfaces.deploymentArtifacts`), say so — do not invent
- **Environment-variable dependencies.** Anything the bundle flags as
  required at boot (config keys, manifest tags, regulated-data evidence
  pointing at env names)
- **Generated artefacts.** Directories the bundle excluded from counts
  but a contributor might edit by accident (build outputs, generated
  clients, vendored deps)
- **Conflicting signals.** Any `WARN_SIGNAL_CONFLICT` or ambiguous
  framework detection — surface the conflict so the contributor knows
  the codebase is mid-migration or has competing conventions
- **License-unknown deps.** A contributor adding code that depends on a
  flagged dep should know the license status is unresolved before
  shipping

Every gotcha entry needs a path or bundle field as evidence. A gotcha
without evidence is a guess; cut it.

### 6. Contribution Flow — Conventions, Not Etiquette

Derive from `activity` and surfaces, not from generic open-source
boilerplate:

- **Branch naming.** If recent commits show a recurring prefix
  (`<author>/<ticket>`, `feat/`, `fix/`), state the convention. If no
  pattern is visible, say so — do not invent a convention
- **PR conventions.** If a workflow file under
  `surfaces.deploymentArtifacts` runs checks on PR open, name the gates
  the contributor needs to clear
- **Review expectations.** If `activity.authors` shows a small group of
  recurring committers, mention that reviews come from a known set —
  this is genuinely useful for first-time contributors
- **Commit message style.** If recent commits cluster around a
  conventional-commits style or a ticket-prefix style, surface it

Do not write etiquette ("be respectful", "engage constructively"). Code
of conduct content lives elsewhere; this section is operational.

### 7. Dependencies of Note — Selective, Not Exhaustive

The bundle's `dependencies.byEcosystem` lists everything. This section
covers only the load-bearing entries:

- Frameworks already covered above — cross-reference, don't restate
- Runtime libraries with unusual version pins (a comment in the
  manifest, a pinned major when the rest of the file uses ranges)
- Deps with unknown or non-permissive licenses (the bundle flags these
  via `WARN_LICENSE_UNKNOWN` and similar)
- Deps that own a high-blast-radius surface (auth, crypto, payment
  processing, data persistence) — a contributor changing code near
  these should know the dependency exists

Cap this section at roughly the top 10 entries. The full dependency
list lives in the bundle, not in the wiki.

### 8. Assemble the Structured Tree

Emit a single content tree matching the Output Contract. Each section is
optional except `repoLayout`, `languagesAndFrameworks`, and `devSetup`.
Mark step-shaped content semantically; mark callout-worthy gotchas
semantically — let the orchestrator decide rendering.

## Output Contract

The skill emits exactly one structured-content object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "engineering",
  "repo": { "name": "<basename>", "path": "<absolute path>" },
  "topics": [
    {
      "id": "repo-layout",
      "title": "Repo Layout",
      "kind": "layout",
      "entries": [
        { "path": "<dir>", "role": "<short label>", "contributorNote": "<non-obvious detail>" }
      ]
    },
    {
      "id": "languages-and-frameworks",
      "title": "Languages and Frameworks",
      "kind": "prose",
      "paragraphs": [
        { "subject": "<language or framework>", "body": "<one paragraph>" }
      ]
    },
    {
      "id": "dev-setup",
      "title": "Dev Setup",
      "kind": "steps",
      "steps": [
        { "ordinal": 1, "action": "<imperative tool-neutral sentence>", "note": "<gotcha or null>" }
      ],
      "alternatives": [
        { "label": "<alt path label>", "steps": [ { "ordinal": 1, "action": "<...>", "note": "<...>" } ] }
      ]
    },
    {
      "id": "gotchas",
      "title": "Gotchas",
      "kind": "callouts",
      "callouts": [
        { "severity": "warning | note | important", "title": "<short>", "body": "<one to three sentences>", "evidence": "<bundle path or field>" }
      ]
    },
    {
      "id": "contribution-flow",
      "title": "Contribution Flow",
      "kind": "prose",
      "paragraphs": [ { "subject": "<branch | PR | review | commit-style>", "body": "<...>" } ]
    },
    {
      "id": "dependencies-of-note",
      "title": "Dependencies of Note",
      "kind": "table",
      "rows": [
        { "name": "<dep>", "ecosystem": "<key>", "version": "<v>", "reason": "<why it's load-bearing>" }
      ]
    }
  ],
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle field>"] }
  ]
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  contract changes
- `topics` is ordered as listed above when emitted; the orchestrator may
  re-order at render time, but the skill's natural order is the
  suggested reading order
- `kind` values are stable: `layout`, `prose`, `steps`, `callouts`,
  `table`. The orchestrator's `format-output` step keys off these to
  pick the right rendering primitive (`<Steps>`, callout component,
  table, paragraph block)
- Every `entries[i].contributorNote` and every `callouts[i].body` must
  cite a concrete bundle field or path — no free-floating advice
- `warnings` mirrors the v-analyze-repo warning shape: code, message,
  optional evidence list. Use codes like `WARN_BUNDLE_INCOMPLETE`,
  `WARN_NO_ACTIVITY`, `WARN_AMBIGUOUS_PACKAGE_MANAGER`

## Quality Bar

The output meets the quality bar when:

- A new contributor reading the rendered output can clone, set up, run
  the test command, make a small change, and open a PR without asking
  questions of an existing maintainer
- Every required topic (`repo-layout`, `languages-and-frameworks`,
  `dev-setup`) is present and non-empty
- Gotchas are specific to evidence in the bundle, never generic
  ("tests can fail", "watch out for env vars")

## Anti-Patterns

**The directory inventory.** Listing every top-level directory and what
extension lives there. Anyone can derive that from the tree; the
engineering layer's value is the contributor-facing *interpretation* —
what kind of changes go where, what dispatch rules apply, what
generated content to leave alone.

**The hedge-phrase rewrite.** When the verifier flags a banned token,
the wrong fix is to add "(formerly known as X)" or "the tool sometimes
abbreviated X". The right fix is to rewrite the sentence around the
*role* the tool plays — "the project's package manager", "the project's
test command", "the project's lint configuration".

**The fabricated convention.** Writing "PRs follow conventional commits"
because that is what most projects do, when the bundle's
`activity.authors` shows no such pattern. If the bundle does not
surface a convention, say the convention is unestablished — do not
invent one.

**The undated activity claim.** Stating "this repo is actively
maintained" or "merges happen weekly" without sourcing the figure to
`activity.commits` and `activity.windowDays`. Either cite the window or
cut the claim.

## Critical Rules

1. **Read the bundle, not the repo.** The skill consumes
   `AnalysisBundle` and only that. Re-walking the tree defeats the
   amortisation rationale and risks producing content that disagrees
   with the bundle other layers consume.

2. **Tool-neutral, every sentence.** The verifier enforces the obvious
   cases. The author owns the rest. When in doubt, describe the
   *role* the tool plays in the project, not its name.

3. **Evidence or cut.** Every gotcha, every contribution-flow claim,
   every dependency-of-note entry must trace to a bundle field or
   path. Un-evidenced advice belongs in someone else's wiki.

4. **Step-shaped content gets marked.** Dev setup is a sequence. Mark
   it `kind: "steps"` so the orchestrator can render it as a
   first-class step primitive. Free-form prose loses the affordance.

5. **Always emit; depth scales.** Engineering is an always-emit layer
   per the wiki design. A thin bundle produces a thin layer — not a
   missing one, not a padded one. Honesty about scope is a feature.

6. **Engineering is not architecture.** Describe how to *work on* the
   system, not how the system is structured. When tempted to explain
   data flow or service boundaries, stop — that is a different layer.

7. **Cap the dependency list.** The full dependency tree lives in the
   bundle (and any future license-audit skill). The wiki carries
   curated, load-bearing entries — typically 10 or fewer.

8. **Surface bundle warnings as gotchas.** When the bundle's
   `warnings` array contains entries a contributor would trip on
   (`WARN_AMBIGUOUS_PACKAGE_MANAGER`, `WARN_FRAMEWORK_AMBIGUOUS`),
   forward them into the gotchas section. Do not silently filter them
   out — they exist precisely because something is non-obvious.
