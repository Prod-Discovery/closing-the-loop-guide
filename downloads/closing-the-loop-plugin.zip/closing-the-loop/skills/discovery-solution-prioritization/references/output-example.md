# Output Example

## Product Context (gathered first)

Before scoring, the following context was provided:

**Target Audience**: SMB bookkeepers and accountants in the Nordic region who manage finances for multiple small business clients. Key pain points include manual data entry, time-consuming reconciliation, and difficulty scaling their practice.

**Product & Market**: Cloud-based accounting and invoicing software for the Finnish SMB market, with expansion plans for Sweden and Norway.

**Key Business Goals**:
1. Increase MRR by 20% through feature-driven upgrades
2. Reduce churn in the SMB segment by improving daily workflow efficiency
3. Establish automation as a key differentiator vs. competitors

---

## Scored Opportunity Matrix

| # | Opportunity | Pain (1-10) | Market (1-10) | Feasibility (1-10) | Alignment (1-10) | Total | Confidence |
|---|-------------|-------------|---------------|-------------------|------------------|-------|------------|
| 1 | OCR invoice scanning | 9 | 7 | 8 | 9 | 33 | High |
| 2 | AI bank reconciliation | 8 | 8 | 6 | 8 | 30 | Medium |
| 3 | Onboarding wizard | 7 | 6 | 9 | 7 | 29 | High |
| 4 | Mobile feature expansion | 6 | 5 | 7 | 6 | 24 | Medium |
| 5 | Custom report builder | 5 | 4 | 5 | 5 | 19 | Low |

## Detailed Reasoning

**Opportunity 1: OCR Invoice Scanning**
- Pain: 9 — Strongest signal in data; 34% of detractors cite this, 180 tickets/month
- Market: 7 — Affects all invoice-processing users (~65% of base), but intensity varies by volume
- Feasibility: 8 — OCR tech mature, clear integration pattern, several vendor options
- Alignment: 9 — Directly supports "reduce manual work" OKR, flagship automation feature
- Overall confidence: High — Multiple data sources confirm, clear technical path

**Opportunity 2: AI Bank Reconciliation**
- Pain: 8 — #1 CES pain point, but some users have acceptable workarounds
- Market: 8 — Daily task for 67% of active users
- Feasibility: 6 — AI matching requires training data, accuracy thresholds need testing
- Alignment: 8 — Fits automation strategy, but not explicitly in current roadmap
- Overall confidence: Medium — Pain clear, feasibility assumptions need technical spike

**Opportunity 3: Onboarding Wizard**
- Pain: 7 — High drop-off (41%), but only affects new users once
- Market: 6 — All new customers, but limited ongoing impact
- Feasibility: 9 — Straightforward UX work, no backend complexity
- Alignment: 7 — Supports acquisition, but retention is current priority
- Overall confidence: High — Clear problem, known solution pattern

**Opportunity 4: Mobile Feature Expansion**
- Pain: 6 — Complaints increasing but still minority of feedback
- Market: 5 — ~30% use mobile, subset need advanced features
- Feasibility: 7 — Known development, but native mobile adds time
- Alignment: 6 — Nice-to-have, not strategic priority this year
- Overall confidence: Medium — Trend data suggests growing importance

**Opportunity 5: Custom Report Builder**
- Pain: 5 — Vocal minority, most users satisfied with defaults
- Market: 4 — Power users and accountants (~15% of base)
- Feasibility: 5 — Complex to build flexible reporting well
- Alignment: 5 — Not in current strategy, potential future differentiator
- Overall confidence: Low — Segment size uncertain, scope unclear

## Recommendation

Based on scoring: **Opportunity 1 (OCR Invoice Scanning)** has highest total (33) and highest confidence. Recommend taking forward to PRD.

Alternative: If feasibility concerns exist, **Opportunity 3 (Onboarding Wizard)** is lower risk with high confidence.
