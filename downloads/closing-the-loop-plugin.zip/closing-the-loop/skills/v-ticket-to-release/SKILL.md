---
name: v-ticket-to-release
description: Orchestrate full ticket-to-merged-code delivery — fetch ticket, investigate, implement, dual-review, open PR, address feedback, merge, and close — with codebase- and harness-agnostic fallbacks. Use when a Linear, Jira, or GitHub ticket is the entry point and the user wants the entire lifecycle through merge, when team policy requires PR-mediated landing, or whenever the request is "take this ticket and ship it".
trigger: [ticket to release, take this ticket, deliver linear issue, ship this jira, full ticket workflow]
license: Apache-2.0
---

# Ticket To Release

## Objective

Take a ticket reference and drive it all the way to merged code in `main`
with the ticket transitioned to its terminal state. The orchestrator
fetches ticket context, investigates (bug, feature, or chore), implements,
runs two complementary review passes — `v-review-changes` followed by the
mandatory `v-scored-code-review` — opens a draft PR, addresses review
feedback through `v-address-review`, merges once the protection-rule gate
is satisfied, verifies the post-merge state, closes the ticket, and
captures learnings.

The skill is codebase-agnostic and harness-agnostic. Missing integrations
(no PM tool, no MCP, no `gh` CLI) downgrade those phases to user-provided
context — they never fail-stop the workflow.

## When to Use

- A Linear, Jira, GitHub, or other tracker ticket is the entry point
- The user wants the full lifecycle from ticket to merged change
- The change is substantial enough to warrant a PR review cycle (not a
  trivial one-line fix)
- The team's process expects PR-mediated landing on `main`

Do not use this workflow for:

- Trivial fixes that bypass code review by team policy — just do the work
- Bug fixes when no ticket exists — use **v-fix-bug** directly
- Feature development without ticket tracking — use **v-develop-feature**
- Release preparation across many already-merged PRs — use
  **v-prepare-release**
- Repository onboarding — use **v-setup-agent-context**

The boundary: this skill assumes a ticket as the starting artifact and a
merged commit as the ending artifact. Anything outside that envelope
belongs in a different workflow.

## Context

Before entering the workflow, establish:

1. **Ticket reference.** A URL, ID, or natural-language reference (`VIS-123`,
   `linear.app/...`, `github.com/.../issues/45`). The reference shape tells
   you which integration to try first.

2. **Working tree state.** The tree must be clean and on a fresh branch off
   an updated default branch. If not, set that up before continuing — do
   not run the workflow on a dirty branch or a branch that has already
   diverged from `main` for unrelated reasons.

3. **Authorization scope.** This workflow culminates in a merge to `main`
   and a ticket-state transition. Confirm with the user — at invocation —
   how far the orchestrator is allowed to go autonomously. Default: stop
   before merging and ask for confirmation. Opt-in: explicit
   "auto-merge once gates pass" authorization.

4. **Project conventions.** Read `AGENTS.md` / `CLAUDE.md` / `CODEREVIEW.md`
   if present. They define the merge strategy (squash / rebase / merge),
   branch-naming, required reviewers, and any release-window constraints.
   **If no convention docs exist at root,** sample 3–5 recent merged PRs
   (`gh pr view <N>`) and ~20 commit subjects (`git log --pretty=format:'%s' main | head -20`)
   from the default branch — branch naming, commit prefix style, and PR
   body format are evidenced there even when undocumented.

## Tooling Note

This orchestrator uses several integration ladders. Map each to whatever
your environment provides; never fail-stop on a missing tool.

- **Ticket fetch & state transitions:** Linear MCP server > Jira MCP
  server > GitHub Issues via MCP or `gh issue view` > user-provided text.
- **PR creation, comments, status, merge:** GitHub MCP server > `gh` CLI
  (`gh pr create`, `gh pr view`, `gh pr merge`, `gh pr review`) >
  Bitbucket / Azure Repos / GitLab equivalents > user-provided actions.
- **CI status reads:** `gh run list` / `gh run view` > GitHub MCP > the
  harness's CI integration > the project's CI provider UI.
- **Adversarial-review isolation:** subagents or agent teams when the
  harness supports them; otherwise sequential phases in the same context.

When an integration is unavailable, ask the user for the data the phase
needs (paste the ticket, paste the comments, share the CI status). Skip
side-effect-only steps (state transitions, auto-merge) and surface them
as actions for the user to take manually.

## Workflow

The workflow proceeds through 13 phases (0–12). Each phase invokes its
stage skill where one applies, or runs inline glue (ticket fetch, PR
open, merge, ticket close). Stage skills are not re-taught here —
follow their own contracts.

### Phase 0: Fetch ticket

Goal: load the ticket into context as structured information.

- Try the ticket-fetch ladder (see Tooling Note) until one succeeds
- Extract: ticket type (bug / feature / chore), summary, full description,
  acceptance criteria (if present), labels, priority, related links,
  parent epic, attachments
- Record the ticket reference for later cross-linking with the PR

If no integration is available, ask the user for description and
acceptance criteria. Note in the eventual PR body that the ticket was
loaded from user-provided text rather than the tracker.

**Handover-ticket detection.** Route by explicit markers. Read
[`handover-shape-feature`'s delivery contract](../handover-shape-feature/references/delivery-contract.md)
before loading context-first work:

- `context-first-story` or `context-first-backlog-item` → walk to the
  context-first parent, compare the child stamp with the parent's current
  context hash, and load that child's `S-n` or `C-n` slice directly. A stale
  child invokes **handover-project-stories** reconciliation and stops before
  implementation.
- `context-first-handover` → split the description at `## Delivery Context`,
  load both halves in full, and check only evidence-index paths since the
  recorded base commit. Changed evidence invokes a targeted
  **handover-shape-feature** refresh, then reloads the ticket. Report
  `gate: not applicable`; unresolved items enter normal planning.
- `discovery-handover` → invoke **handover-retrieval**. It checks the PM
  + Dev sign-off gate and loads the approved Engineering Brief + AGENTS.md
  block. The Brief becomes the spec and the block is appended to
  `AGENTS.md`. Stop when the gate is not satisfied.

Both markers make the handover ambiguous and stop it at triage. No marker means
the ordinary ticket path: use the description as the spec.

Also confirm the working tree is on a fresh branch off the updated
default branch. Create the branch using the project's naming convention
(read from `AGENTS.md` if specified) — for example `<author>/<ticket-id>-<short-slug>`.
Then **mark the ticket in flight**: transition it into the project's first
in-flight state, chosen from the available transitions rather than an assumed
name, so started work does not read as untouched. Best-effort and never a
gate — with no tracker write path, say so and carry on.

**Gate:** Ticket type is known, description is in context, working tree
is on a fresh branch off updated `main`. For governed handover: sign-off
passed and the Brief + AGENTS block are loaded. For context-first: live
requirements + Delivery Context (or the projected child slice) are loaded and
freshness/context-hash checks passed.

### Phase 1: Triage — branch by ticket type

Goal: route the ticket into the right investigative sub-flow before
planning.

- **Bug:** invoke **v-debug-issue** to reproduce, isolate, and root-cause.
  The v-debug-issue output (failing test, root cause, blast radius) feeds
  Phase 2.
- **Feature with thin spec:** invoke **v-write-spec** to lock down
  requirements, acceptance criteria, and non-requirements before planning.
- **Feature with clear spec** (including a governed handover whose
  Engineering Brief is already the spec): proceed directly to Phase 2.
  Do not re-derive a governed Brief with **v-write-spec**.
- **Context-first feature:** judge clarity from the live requirements,
  acceptance behavior, and Delivery Context. Proceed to Phase 2 when
  they are decision-complete; otherwise use **v-write-spec** only as an
  engineering planning aid. It does not become a handover artifact and
  requires no PM/Dev sign-off.
- **Chore** (refactor, dependency bump, infra or config tweak, doc-only
  shipping change): proceed directly to Phase 2 — same as a clear-spec
  feature, but acknowledge chores typically have no acceptance
  criteria. Frame Phase 2 v-plan-work as "what changes, what doesn't" —
  the contract surfaces and behaviors that must stay stable — rather
  than "what does success look like". Treat that "what doesn't change"
  list as the chore's de facto acceptance criteria.
  **Dependency-upgrade or CVE tickets** route the implement phase
  (Phase 3) through invoke **v-upgrade-dependencies** instead of bare
  implementation.
  **Sub-classify chore as docs-only / template-only / config-only when
  no executable surface is touched.** Phase 4 (test), Phase 7 (docs),
  and Phase 8 (CI) have documented skips for this case — pre-collapse
  them at triage.

**Skip criteria:** The ticket already contains an explicit, unambiguous
acceptance criteria list and a clear root-cause hypothesis (rare). In
that case, document the assumption and proceed.

**Gate:** The work to be done is reduced to a known scope with explicit
acceptance criteria (or, for chores, an explicit "what doesn't change"
list), plus — for bugs — a reproducing failing test.

### Phase 2: Plan — invoke **v-plan-work**

Decompose the work into a decision-complete implementation plan, and
surface decisions that need the user's input before code starts.

**Gate:** The plan is detailed enough that an implementer would not
need to make significant architectural decisions while coding.

### Phase 3: Implement — invoke **v-implement-code**

Execute the plan with minimal-diff scoped changes. Stop when the plan
is fulfilled — extras belong in follow-up tickets.

**Conditional:** invoke **v-design-frontend** before v-implement-code if the
ticket touches user-facing UI and no design has been produced yet.

### Phase 4: Test — invoke **v-run-tdd**

Verify the implementation with red-green-refactor discipline.

- For bugs: the failing test from Phase 1 must now pass
- For features: every acceptance criterion has at least one test
- Existing tests still pass

**No-test-framework case:** If the repo has no traditional test
framework, `v-run-tdd`'s discovery ladder will surface the actual gate —
a verifier script, an integration check, a linter-style validator, or
no formal gate. Continue with whatever it identifies; treat that gate
as this repo's test command, and capture its output as the v-run-tdd
evidence. Do not fail-stop because a conventional test runner is
missing.

**Pure-docs / template / config PRs:** when no executable surface is
touched (per Phase 1's docs-only sub-bucket), the test gate is
rendering or parsing the artefact — that single observation is the
entire Phase 4 evidence. Skip the v-run-tdd discovery ladder.

**Loop-back condition:** If tests reveal implementation defects, return
to **Phase 3** to fix root causes. Do not patch tests to mask broken
behavior.

### Phase 5: First-pass review — invoke **v-review-changes**

Perform the structured, risk-first review of the diff, with findings
ranked by severity.

**Loop-back condition:** Major or Critical findings → return to
**Phase 3**. Suggestions can be deferred to follow-ups.

### Phase 6: Adversarial review — invoke **v-scored-code-review** (default, with one tiny-diff exception)

Run the scored Finder / Adversary / Judge pass. This phase is the
**default** in this workflow, unlike `v-develop-feature` and `v-fix-bug`
where it is optional. The full v-ticket-to-release scope warrants the
harder pass.

- Use subagents or agent teams if the harness supports them so role
  contexts stay separated
- Take the Judge's final scoreboard as the authoritative output

**Skip criteria (tiny-diff exception):** Skip the full Finder / Adversary
/ Judge pass only when ALL of the following hold:

- The diff is under 100 lines of net change
- Changes are scoped to a single section of a single file (or a single
  new file)
- No security or correctness boundary is touched (no auth, crypto,
  permissions, input validation, concurrency, persistence-layer logic,
  or public API contracts)

When the exception applies, run a single-pass self-skim instead — read
the diff once with two prompts in mind: "what hidden assumptions does
this rest on?" and "what edge case does this not check?". Record the
findings in the same shape as a Judge scoreboard so Phase 9's
ready-for-review gate has something to compare against. If any Major
or Critical concern surfaces in the self-skim, escalate to the full
Finder / Adversary / Judge pass — do not loop back to Phase 3 yet, as
the self-skim is not authoritative on its own.

**Loop-back condition:** Any Major or Critical issue surviving the Judge
pass → return to **Phase 3**. After remediation, re-run Phases 4 and 5
before re-entering Phase 6.

### Phase 7: Document — invoke **v-update-docs**

Update documentation affected by the change.

**Skip criteria:** Internal refactor with no user-visible or contract-
visible change.

### Phase 8: CI — invoke **v-manage-ci**

Confirm the change interacts correctly with CI: new tests run in CI, any
new jobs or build steps are wired up, and CI status will be readable on
the upcoming PR.

**Bundled-asset sync.** Check whether the change touches any
source-of-truth file that has a mirror the repo's CI keeps in sync
(bundled copies, generated snapshots, vendored duplicates), and update
the mirrors as part of this phase before pushing. CI will catch drift
after the fact, but landing the mirror update in the same PR avoids a
second review cycle.

**Skip criteria:** No CI configuration changes required, existing CI
already covers the new tests, and no source-of-truth file with bundled
mirrors was touched.

### Phase 9: Commit & open PR (draft)

Goal: produce a clean commit history and open a PR for review.

- invoke **v-prepare-commit** for commit grouping, messages, and PR title
  and description
- Open the PR as a **draft** using the best available tool (GitHub MCP,
  `gh pr create --draft`, or the host's equivalent)
- Cross-link ticket ↔ PR if PM integration is available: post the PR URL
  on the ticket; reference the ticket ID in the PR body
- Mark ready-for-review only if Phase 5 produced no Major/Critical
  findings AND Phase 6's Judge accepted no Major/Critical issues. If
  either still has open findings, leave the PR draft until they're
  resolved

**Mid-flow `main` drift.** If `main` has advanced since the Phase 0
branch-off, rebase or merge the base into the working branch and re-run
**Phase 4** (v-run-tdd) and **Phase 5** (v-review-changes) on the integrated
state. If those new commits touched CI configuration, also re-run
**Phase 8**. A PR opened on a stale base hides regressions until CI
catches them late.

**Gate:** PR exists, body answers what/how/risk/testing/follow-up
(per `v-prepare-commit`), draft state matches review cleanliness, and
the PR head is integrated with current `main`.

### Phase 10: Address review — invoke **v-address-review**

Iterate on the open PR until the merge gate is satisfied.

- Triage incoming comments (substantive / nit / question / out-of-scope /
  conflicting / already-addressed)
- Push fixes for substantive defects after re-running `v-implement-code`,
  `v-run-tdd`, and `v-review-changes`
- Reply to every thread; force-push only when intentional and re-request
  review explicitly
- Handle CI flake with at most one retry; escalate on the second failure
- Resolve base-branch conflicts by rebasing or merging and re-running
  Phases 4 and 5 before pushing

**Loop-back condition:** If review feedback reveals deep architectural
problems — not just localized defects — return to **Phase 2** to
re-plan. This is rare; most feedback fits inside `v-address-review`'s
own loop.

**Gate:** `v-address-review` returns `Ready to merge: yes` with the SHA
to merge.

### Phase 11: Merge

Goal: land the change on `main` under the project's protection rules.

- **Default behavior — confirm before merge.** Surface the merge SHA,
  the merge strategy implied by project conventions (squash / rebase /
  merge), and the branch-cleanup intent. Wait for the user's explicit
  go-ahead.
- **Opt-in auto-merge.** Only when the user authorized auto-merge at
  invocation time AND `v-address-review` confirmed the gate met AND CI
  is green on the merge SHA AND every required reviewer has approved
  AND branch protection is fully satisfied. Perform the merge using the
  project's strategy.
- Delete the head branch after a successful merge if the project's
  convention is to do so

Never override branch protection or force-merge.

**Gate:** The merge commit exists on `main`. The PR is in the merged
state. The head branch is deleted if convention requires it.

### Phase 12: Verify, close ticket, capture learnings

Goal: confirm the change actually landed cleanly and close the loop.

- Verify the merge commit landed on `main` with the expected SHA
- Wait for post-merge CI on `main` to complete; confirm green
- Transition the ticket to its terminal state — or to the next state if
  the project uses a non-terminal handoff (e.g. `In Review` → `QA` →
  `Done`). Record the merge commit SHA on the ticket
- invoke **v-capture-learning** to store any non-obvious lessons from this
  cycle (review-feedback patterns, tooling friction, scope shifts)

**Revert escape hatch:** If post-merge `main` CI fails, or smoke tests
expose a regression the PR loop missed, revert the merge commit, reopen
the ticket with the new findings, and return Phase 12 with a `reverted`
status. Do not silently leave broken code on `main`. The orchestrator
owns the consequences of the merge it requested.

**Gate:** Merge confirmed on `main`, post-merge CI green, ticket in its
correct downstream state, learnings captured.

## Output Contract

### Summary

- **Ticket:** <reference, title, type>
- **PR:** <repo#PR-number, URL>
- **Merge SHA:** <SHA on main>
- **Merged at:** <timestamp>
- **Final ticket state:** <state name and link>

### Detail

Phases run (one line each, per phase 0–12): integration / triage branch /
plan reference / commits / test result / v-review-changes findings /
Judge scoreboard / docs touched or skipped / CI changes or skipped / PR
URL and ready-state / v-address-review iterations / merge strategy and
SHA / post-merge CI and ticket transition.

### Verification

| Check | Status |
|---|---|
| Tests passing on PR head | <yes/no> |
| v-review-changes clean | <yes/no — open suggestions noted> |
| v-scored-code-review Judge: no Major/Critical | <yes/no> |
| PR opened draft, marked ready after reviews clean | <yes/no> |
| Required reviewers approved | <list> |
| Branch protection satisfied | <yes/no> |
| CI green on merge SHA | <yes/no> |
| Post-merge CI on main green | <yes/no> |
| Ticket transitioned to terminal/next state | <state> |
| Reverted | <no | yes — reason> |

### Follow-ups

- <issues filed for out-of-scope review feedback>
- <known limitations carried into the ticket close>
- "None" when the ticket closes fully clean

## Quality Bar

A run meets the bar when:

- The ticket reference was loaded into context (from a tracker or from
  the user) before any code was planned
- Bug tickets went through `v-debug-issue` before planning; ambiguous
  feature tickets went through `v-write-spec`
- `v-review-changes` ran, and `v-scored-code-review` ran (or its tiny-diff
  self-skim substitute, per Phase 6 skip criteria); the PR stayed draft
  until both came back clean
- `v-address-review` triaged comments before changing code; out-of-scope
  requests turned into follow-up issues, not scope creep
- The merge happened only after the protection-rule gate was met, and
  post-merge CI was verified before the ticket was closed
- A merge that broke `main` was reverted, not papered over

A run that violates any Critical Rule below fails the bar — most often
via a premature ready-for-review, a skipped adversarial pass with no
tiny-diff exemption, or a ticket closed before post-merge verification.

## Anti-Patterns

**The reviewer-pleaser scope expansion.** Implementing every review comment
regardless of scope. Push back on out-of-scope requests with a follow-up
issue — a ballooning PR is a slower PR.

**The bypassed triage.** Jumping straight to `v-plan-work` on a bug ticket
without `v-debug-issue`. Plans built without a known root cause produce
fixes that move the symptom rather than removing it.

## Critical Rules

1. **Adversarial review is the default in this workflow.** The Phase 6
   Skip criteria (tiny, single-section, non-boundary diffs) are the only
   legitimate exemption — and they substitute a self-skim, not nothing.
   Skipping the pass simply because `v-review-changes` came back clean is
   not in scope.

2. **PR opens as draft.** It only graduates to ready-for-review when
   both review phases came back without Major/Critical findings.

3. **Confirm before merge by default.** Auto-merge is opt-in per
   invocation, and only fires when every protection-rule condition is
   met. Never override the rule. "The gate passed" is not authorization —
   release windows, on-call and deploy coordination live outside CI.

4. **Out-of-scope review feedback becomes a follow-up issue, not a
   scope expansion.** The PR's goal was set when it was opened.

5. **Post-merge `main` failure triggers a revert.** A broken `main` is
   never an acceptable steady state. Revert the merge, reopen the
   ticket, hand back to triage.

6. **Codebase- and harness-agnostic.** Missing integrations skip side
   effects and ask the user; they do not fail-stop the workflow.

7. **The protection rule is the gate.** Approval count is a heuristic.
   Read CODEOWNERS, required-reviewer lists, required checks, and
   branch-protection policy — and gate on the rule.

8. **Bug tickets go through `v-debug-issue` before `v-plan-work`.** No fix
   is planned before the root cause is known.

9. **The orchestrator owns the consequences of the merge.** Verifying
   post-merge state, transitioning the ticket, and capturing learnings
   are part of the workflow — not optional cleanup.

10. **Route handovers by marker.** `discovery-handover` clears its
    sign-off gate and loads the Brief through `handover-retrieval`.
    `context-first-handover` or a generated context-first child loads the live
    requirements and Delivery Context directly from the parent contract and
    has no handover-specific sign-off. Both still pass the normal engineering
    plan and protection-rule gates.
