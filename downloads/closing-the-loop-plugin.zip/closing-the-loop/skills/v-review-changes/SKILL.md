---
name: v-review-changes
description: Perform risk-first code review with structured findings and severity ranking, including a security-depth pass for auth, input, dependency, and sensitive-data changes. Use when reviewing a pull request before merge, when self-reviewing local changes before committing, when assessing release risk, when reviewing a commit or commit range, when a security review or vulnerability check is needed, or whenever someone asks "does this look right?", "audit these changes", or "code review this".
trigger: [review this code, code review, check this pr, pre-merge review, audit these changes, security review, audit for vulnerabilities, scan for secrets, review auth implementation, security audit]
license: Apache-2.0
output_contract_schema: custom
metadata:
  requires:
    - AGENTS.md
---

# Review Changes

## Objective

Identify defects, risks, and gaps in changed code before it reaches users —
correctness errors, security vulnerabilities, missing tests, and
maintainability traps. Review is a read-only activity: the reviewer
inspects, analyzes, and reports, but never modifies the code being reviewed.

## Setup check

Before proceeding, verify `AGENTS.md` exists at the repo root. If missing,
stop and instruct the user to run the `v-setup-agent-context` skill first —
without it the review has no codified conventions or quality gates to anchor
findings against.

## When to Use

- Pull request or merge request review
- Pre-merge quality check on local changes, or a spot-check before committing
- Release-risk assessment for a set of changes
- Reviewing a specific commit or range of commits
- A security review, vulnerability check, or security audit is requested
- Any time someone asks "does this look right?"

Do not use this skill for writing or modifying code, running tests, or
planning work. A review produces findings and recommendations; acting on
them is a separate step, performed by a separate skill or agent.

## Context

### 1. Determine Review Scope

Identify which changes to review: staged changes (pre-commit check), unstaged
changes (broader "what's been changed" sweep), a specific commit, a commit
range (release assessment or branch comparison), or a full pull request diff.
If the scope is not specified, default to staged changes; if nothing is
staged, use unstaged changes. Always state what scope you reviewed so the
reader knows what was and was not covered.

### 2. Understand the Intent

Read the commit messages, PR description, or task context before evaluating
how the code was written. Knowing the stated goal and its constraints
prevents false findings — code that looks wrong in isolation may be correct
given constraints not visible in the diff.

### 3. Assess the Risk Surface

Spend review time proportional to risk:

- **High risk:** Authentication, authorization, data validation, financial
  calculations, encryption, session handling, database migrations, public
  API changes, dependency updates
- **Medium risk:** Business logic, state management, error handling, API
  integration, configuration changes with runtime impact
- **Low risk:** Documentation, logging, test additions (not modifications),
  comment updates, formatting

## Workflow

### 1. Structural Scan

Map the shape of the change before reading details: how many files, what
types (source, test, config, docs), how large a diff, concentrated in one
area or spread across modules. A change touching twenty files across five
modules carries more integration risk than two files in a single module.

### 2. Risk-First Deep Review

Review files in order of risk, not alphabetical or diff order:

**Priority 1 — Correctness:** Does the code do what the description says?
Logic errors, off-by-one mistakes, unhandled states, incorrect
transformations at boundaries (type conversions, null handling, encoding),
error paths that don't recover or fail safely, uncoordinated concurrent or
async operations.

**Priority 2 — Security and Data Safety:** Input validated before use, auth
checks present where needed, sensitive data not logged or exposed, queries
parameterized, template output escaped, access controls consistent with the
existing model. For changes touching authentication, authorization, input
handling, sensitive data, dependencies, or security-relevant configuration —
and before any production release — run the Security Depth pass below.

**Priority 3 — Test Adequacy:** Tests exist for the changed behavior and
cover the happy path, at least one edge case, and at least one error path.
Assertions target behavior, not implementation details. Modified tests do
not weaken coverage. Missing tests for new behavior is a finding, not an
afterthought.

**Priority 4 — Maintainability:** Readable to someone unfamiliar with the
change, names consistent with the codebase, complexity proportional to the
problem, project conventions followed.

### 3. Security Depth

When the change touches a trust boundary, think adversarially: for every
input point, "what happens if I send something unexpected?"; for every
access check, "what happens if I skip this?"; for every data flow, "where
could this leak?". Cover all six areas:

- **Injection:** queries parameterized, template output escaped, no
  unsanitized user input in shell commands, file paths, fetched URLs, or
  deserialization.
- **Authentication and authorization:** checks on every protected endpoint,
  enforced server-side (not UI-level hiding), tokens fully validated
  (signature, expiration, audience, issuer), secure session flags, no
  privilege-escalation paths, least privilege.
- **Secrets and sensitive-data handling:** no hardcoded credentials in
  source, configuration, fixtures, or comments; secrets loaded from
  environment or secret management; logs and errors sanitized of PII.
- **Dependency risk:** known CVEs in new or updated dependencies (consult
  vulnerability databases), maintenance status, lock files committed,
  dependency-confusion exposure.
- **Configuration:** CORS not wildcard, CSP and security headers present,
  TLS enforced, file-upload restrictions, no default credentials, CI secrets
  scoped and not leaked into logs.
- **Data exposure:** API responses filtered of sensitive fields, error
  messages free of internals (stack traces, queries, file paths), encryption
  at rest and in transit, debug endpoints disabled in production.

Rules for this pass:

- Every security finding must include an attack scenario — how it could
  actually be exploited — not just "this is bad."
- Severity reflects exploitability: rate by access required, complexity of
  exploitation, and impact. Map onto the standard scale below — exploitable
  now or trivially is Critical; exploitable with effort or a missing
  required control is Important; defense-in-depth hardening is a Suggestion.
  Hardcoded secrets are always Critical.
- Close the pass with an explicit verdict in the report summary: Ship /
  Ship with fixes / Block until resolved.
- Zero findings on a non-trivial auth/input/data change means the review
  failed, not passed — every such change yields at least observations.
  State what was checked, not just what was not found.

### 4. Cross-Cutting Concerns

After file-by-file review: interface consistency (changed signatures and
schemas match their usage across the codebase), migration completeness (a
pattern changed in one place is changed everywhere), configuration
alignment, and dependency impact on build size and compatibility.

### 5. Synthesize and Report

Compile findings into a structured report ordered by severity, in the Output
Contract format.

## Output Contract

Every review must produce findings in this format. If there are no findings,
explicitly state that and note residual risk.

```markdown
## Review Findings

**Scope:** [what was reviewed — staged changes, commit range, PR #N, etc.]
**Files reviewed:** [count]
**Risk assessment:** [low / medium / high — overall change risk]

### Critical
[findings that will cause bugs, data loss, or security issues if shipped]

- **[file:line]** — [description of the defect and its impact]

### Important
[findings that represent significant risk but may not cause immediate failure]

- **[file:line]** — [description and recommendation]

### Suggestions
[improvements that would make the code better but are not blocking]

- **[file:line]** — [suggestion]

### Test Coverage
- [assessment of whether changed behavior is adequately tested]
- [specific gaps, if any]

### Questions
- [anything unclear that needs author clarification]

### Summary
[2-3 sentence overall assessment: what's the risk level, what are the key
concerns, is this ready to merge or does it need changes?]
```

If there are no findings at any severity level, use:

```markdown
## Review Findings

**Scope:** [what was reviewed]
**Files reviewed:** [count]
**Risk assessment:** [level]

No defects or significant risks identified. [Note any residual risk from areas
that could not be fully assessed, such as integration behavior or production
load characteristics.]
```

## Quality Bar

A review meets the quality bar when:

- Every finding references a specific file and location and explains the
  actual risk — not just "this looks wrong"
- Findings are ordered by severity, and style nits are separated from
  substantive findings
- Security findings carry attack scenarios and actionable remediation, not
  guessed severity
- Test adequacy is assessed for all behavior changes
- The review scope is clearly stated, and the summary gives a clear
  merge/no-merge signal

## Anti-Patterns

**The style-only review.** Spending all review effort on naming and
formatting while missing a null pointer dereference in the same diff.
Correctness and security before aesthetics.

**The rubber stamp.** Approving changes without reading them because the
author is trusted or the change "looks small." Small changes in critical
paths cause the worst bugs.

**The checkbox audit.** Marking each security area "OK" without inspecting
the code. A security pass requires reading code paths, tracing data flows,
and thinking adversarially — not filling in a list.

## Critical Rules

1. **Review is read-only.** Never modify the code being reviewed. A reviewer
   who edits the code has become an author and can no longer objectively
   assess the change. Report findings — let someone else fix them.

2. **Risk drives depth.** Authentication logic gets more scrutiny than a log
   message format change. Not every line deserves equal attention.

3. **Be specific.** "This is wrong" is not a finding. "This comparison does
   not handle the null case, which will cause a runtime error when the field
   is optional" is a finding.

4. **Separate severity levels.** A critical correctness bug and a minor
   naming suggestion never appear at the same priority. The reader must be
   able to scan for blocking issues without wading through style feedback.

5. **Review the diff, not the codebase.** Findings reference changed code.
   The exception: a pre-existing defect that interacts with the change is
   in scope. Everything else pre-existing gets filed separately, not mixed
   into this review.
