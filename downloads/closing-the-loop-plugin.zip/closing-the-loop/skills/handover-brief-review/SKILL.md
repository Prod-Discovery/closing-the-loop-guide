---
name: handover-brief-review
description: "Governed-path review of the Engineering Brief (the ticket description) and ticket + sign-off comments, mandatory before the PM + Dev gate and on new comments. A consolidated reviewer plus two verifiers find and classify issues; the skill applies mechanical fixes into the versioned Brief and routes judgment items onto sign-off checklists. Never use for context-first-handover, which has no Brief or sign-off gate."
trigger: [review the brief, brief review, pre-gate review, stress-test the handover, fold comments into the brief]
license: Apache-2.0
metadata:
  requires: [Engineering Brief as the ticket description (from discovery-handover-package Step 7.0)]
---

# Handover Brief Review (Pre-Gate Review)

> **Path guard:** this skill belongs only to the governed path. If the ticket carries
> `context-first-handover` or the configured `handoverPath` is `context-first`, stop. Do not create a
> Brief or sign-off issues; refresh the ticket's Delivery Context through `handover-shape-feature`
> instead.

A **mandatory** scrutiny of the Engineering Brief that runs **after the handover package is compiled
(the Brief is now the ticket description) and before the human PM + Dev gate** — and in a **targeted,
cheap form whenever a new comment lands**. It runs one consolidated, read-only **Brief Reviewer**
(five concerns in one pass: feasibility, design/UX, customer evidence, risk/assumptions, legal/privacy)
plus two mechanical **verifiers** — the **Source-Fidelity Auditor** (with the sources in hand: did the
prototype's and reference's load-bearing content *arrive* in the Brief, and is every Brief-vs-PRD
divergence a *recorded* correction?) and the **Fresh-Eyes Probe** (with *only* the delivery payload —
Brief + frozen PRD + AGENTS block: could the coding agent build this without guessing?). Then it does two
bounded things: **applies the mechanical fixes and the groundable comment-changes into the Brief**, and
**routes the judgment calls and the ungroundable comments onto the two sign-off sub-issue checklists**.

> [!note] Bounded automation — the gate is still human
> The reviewer and verifiers are **read-only**; they find, classify, and propose. The skill (the
> orchestrator) makes the writes: a **mechanical fix or a grounded comment-change** is applied straight
> into the Brief/description (version-bumped, logged in `## Revision history`); a **judgment call or an
> ungroundable comment** becomes a **checklist item on the relevant sign-off sub-issue**. It writes
> **no comment of its own** and **no separate review document**. It **never moves a sub-issue to
> Done** — signing is the human's act — but if it applies a requirement-level change after a side has
> already signed, it **re-opens** that sub-issue so the change is re-ratified. The AI is triage; the
> PM and Dev at the gate are the review of record.

## Objective

Catch the defects that sink a handover — a Brief that silently dropped the sources' spec, dangling
references the coding agent can't resolve, infeasible flows, missing UI states, requirements unmoored
from evidence, privacy exposure — **and fold in the requirements and clarifications that arrive as
comments** — then resolve them the cheapest correct way: **apply the mechanical ones automatically**
so nobody hand-transcribes them, and **surface the real decisions on the gate** so the PM and Dev sign
a pre-scrutinised Brief against a short, ranked checklist. Every finding cites a Brief section.

## When to Use

- **Always**, once a handover package exists and the **Brief is the ticket description**
  (`discovery-handover-package` Step 7.0 has run) and the sign-off sub-issues exist —
  `handover-workflow` runs it at Step 2.5 before holding the gate. It is not optional.
- **Whenever a new comment appears** on the ticket or a sign-off sub-issue — as a **targeted fold**
  (see Token discipline), re-invoked by `handover-retrieval` before delivery.
- A Brief came back with **changes requested** and you re-scan before re-submitting (it re-applies
  fixes and reconciles the checklist items by key — no duplicates; see step 4).

Do not use this skill when:
- There is **no Brief / no description to review** — run `discovery-handover-package` first.
- You expect it to *approve* the handover — it never moves the gate; PM + Dev sign-off is unchanged.

## Token discipline (pay per change, not per event)

This is the most expensive step in the bridge; keep it priced to what changed:

- **Full pass** (all three agents) runs on the **first review of a Brief** only.
- **Re-review after edits:** every `## Revision history` row names the §s it changed; re-run only the
  agents whose lane covers a changed §** — Reviewer: any §; Auditor: spec-bearing §4/§6/§7/§8;
  Probe: every version bump (it is the cheapest agent — payload-only).
- **Comment events never fan out.** The orchestrator grounds the comment against the sources itself,
  or spawns **at most one** agent (the Reviewer, given only the sources relevant to that comment).
  A new comment is never a reason to re-run the full pass on an unchanged Brief.
- **Tailored inputs, mid-tier model.** Each agent receives only the inputs its definition names —
  never "everything, just in case". All three agents run on a mid-tier model (`model:` in their
  frontmatter); the orchestrator — the only writer — stays on the session model.

## Workflow

### 1. Locate the inputs
Read the **Engineering Brief = the ticket description** (the version-stamped state), the **AGENTS.md
context block**, plus, if present, the **brownfield reference**, the **validated prototype**, the
**archived PRD**, **and the comments** on the ticket and the two sign-off sub-issues (skip the
archived-PRD provenance comment as a *comment* — it is the Auditor's source). Read the **sign-off
sub-issue** keys from the manifest's `signoffIssues` (PM + Dev) — that is where judgment findings and
ungroundable comments will land. Decide from the trigger and the revision history **which agents this
run needs** (Token discipline above).

### 2. Run the pass — reviewer + verifiers, each with only its inputs
Run the agents this event needs **in parallel**, each read-only, each given exactly its input set:

| Agent | Input | Catches |
|---|---|---|
| [Brief Reviewer](./agents/brief-reviewer.agent.md) | Brief + brownfield reference + prototype (when present) + PRD | judgment defects across five concerns: feasibility, design/UX, customer evidence, risk/assumptions, legal/privacy |
| [Source-Fidelity Auditor](./agents/brief-source-fidelity-auditor.agent.md) | Brief + PRD + prototype + reference (each when present) | silent omissions from the **unloaded** sources (prototype/reference content that didn't arrive verbatim-or-stronger); references pointing outside the payload; **unrecorded contradictions** between Brief and frozen PRD |
| [Fresh-Eyes Probe](./agents/brief-fresh-eyes-probe.agent.md) | **ONLY** the delivery payload (Brief + frozen PRD + AGENTS.md block) | dangling references and build-blocking questions the coding agent would face; floods → a "not ready for handover" verdict |

**Story-map coverage (epic-shaped Briefs only — resolved by §6.3 presence, never config).** When the
Brief carries a §6.3 Story map, the Auditor
also count-checks the map itself: every §6.2 `AC-n` appears in **exactly one** slice (no orphans, no
duplicates), every slice names its §6.1 blocks and its demonstrable outcome (a prototype state, an
observable behaviour tied to one of its criteria, or an agentic state/transition), every §8 constraint is
either a chore row or named in a slice, and every cross-slice dependency is explicit. A coverage
defect whose fix is derivable from the Brief itself (an orphan criterion, a missing dependency edge)
is **mechanical**; one that encodes a scope or sizing call (split this slice? merge these?) is
**judgment**, routed to the Dev checklist. The Auditor also checks that the `> **Backlog shape:**`
header line (legacy label `Backlog mode:`) agrees with §6.3 presence, per
[`${CLAUDE_PLUGIN_ROOT}/references/backlog-shape-decision.md`](../../references/backlog-shape-decision.md): header says single-ticket but §6.3
is present → the header is wrong — **mechanical** (section presence wins); header says epic but no
§6.3 → ambiguous — **judgment**, routed to the Dev checklist, and nothing is projected until resolved.

The two verifiers cover each other's blind spots: the Auditor cannot notice a question no source ever
answered; the Probe cannot notice a confidently incomplete copy or a silent Brief-vs-PRD conflict. The
Probe's isolation is load-bearing — never hand it the prototype or the reference. **Permanent
regression examples** the verifiers must always catch: an abridged description ("full detail in the
attached §X" — KAN-12 v1.0), a partially copied enumeration from an unloaded source (the KAN-12 v1.1
shape: 4 of 14 labels embedded, the source cited for the rest), and a silent PRD correction (the Brief
diverges from the PRD with nothing recorded in §3/§8).

### 3. Each agent returns classified items
Per the shared [review rubric](./references/review-rubric.md), each finding or comment-derived item
carries: severity, the cited Brief section, the issue, a **proposed change**, and a **proposed class —
`mechanical`, `judgment`, or `needs-input`** (an ungroundable comment). Agents that find nothing return
`No issues found.` If the Probe returns its **flood verdict** (`NOT READY FOR HANDOVER`), what happens
depends on the handover mode (manifest `handoverMode`, default `standard`): in **`strict`** it blocks
promotion outright — the handover returns to discovery/PRD; in **`standard`** route the single verdict
as one judgment item on both sign-off checklists ("probe found N unanswerable questions — approve
anyway or return to discovery?") for the humans to decide. In neither mode is a flood translated into
a checklist wall.

### 4. Classify, then apply or route (this orchestrator — the only writer)
Take the union of findings and comment-derived items, de-duplicate, and decide each one's class
**conservatively**:

- **Mechanical** — exactly one correct change, no scope/value judgment (a missing disclaimer, an absent error-state criterion, an unstated format, an Auditor back-fill whose exact content exists in a source). **Apply it directly to the Brief (the ticket description)**, then bump the version in the status header and append one line to the Brief's `## Revision history` **naming the §s changed**, e.g. `v1.1 — §6.1: added the legal disclaimer to the CSV spec — handover-brief-review`. Keep the description and the version-stamped attachment in lockstep.
- **Judgment** — any decision, scope call, or external validation (which book-value rule, confirm the column set with an advisor, a metric choice). **Write it as a checklist item on the relevant sign-off sub-issue:** `feasibility` concern → the **Dev** sub-issue; `design` / `customer` / `risk` / `legal` / `fidelity`-judgment → the **PM** sub-issue (feasibility-flavoured fidelity items may go to Dev). The item must be ticked before that side can go Done — so the finding gates the sign-off.

When in doubt, classify as **judgment** — never auto-apply a change that encodes a decision.

**Fold in comments (ground-or-route).** A comment on the ticket or a sign-off task is a candidate change, handled by the same classes — but **only if it can be grounded** in the inputs (the Brief, the brownfield reference, the prototype/PRD):
- **Groundable + mechanical** (a clear factual fix — "the date format is DD.MM.YYYY") → apply to the Brief like any mechanical fix.
- **Groundable + a requirement/scope change** ("it also needs CSV") → draft the **sourced** Brief edit, apply it (new version, logged), and add a **confirm** checklist item on the owning sub-issue naming the change: `§6 updated from comment: CSV export added (v1.3) — confirm`.
- **Not groundable** — the comment references context the inputs do not contain (e.g. "match existing export styling" when no brownfield capture covers the existing exports) → **do not invent specifics.** Capture the requirement and route a **precise `needs-input` question** to the owning sub-issue, naming the missing context (and, where useful, recommend a `handover-codebase-discovery` pass to capture it). A comment you cannot ground is a signal the captured handover context has a gap.

**Apply-then-ratify (there is no "approve" button).** Approval is the reviewer moving their sign-off sub-issue to **Done** — there is nothing to hook on a ticked box. So the change goes into the Brief *here*, and the **Done-transition ratifies that version**; `handover-retrieval` loads only the ratified version, so an applied-but-unratified change never reaches delivery. **If a side had already signed** (its sub-issue was Done) and you apply a requirement-level change, **re-open that sub-issue** (transition it out of Done) with the confirm item, so the new version must be re-ratified. Re-opening only ever adds rigor — it is never a sign-off.

**Backlog staleness (once a backlog exists — manifest `backlog` block; post-gate by default, pre-gate
under `backlogTiming: pre-gate`).** If the manifest carries a `backlog` block — the stories already
exist — and an applied change touches a § that a story's slice cites (stories are stamped with the
Brief version they were cut from), add a confirm item to the **Dev** sub-issue naming the affected
story keys: `[fidelity · §6.3] Brief v<X> changed §<n>, cited by <S-key(s)> — refresh via
create-backlog-from-brief and confirm`. This review only flags stale stories; refreshing them is the
projector's job, never this skill's.

**Key every routed item** by its concern and cited Brief section (e.g. `[feasibility · §7]`,
`[fidelity · §6.1]`) so repeat runs are reconcilable rather than additive.

**Re-scan reconciliation (a Brief that came back with changes, or a new comment).** A re-scan reconciles the checklist by key — it is never append-only:
- **Still reproduces** — an open item with that key already exists: leave it, do **not** add a second copy.
- **New** — no item with that key exists: append it.
- **No longer reproduces** (a mechanical fix or human edit resolved it): **annotate** the existing item `(appears resolved in v<X> — confirm and tick)`. The review never ticks, closes, or deletes a checklist item — closing it is the reviewer's act; it only surfaces that it is now closable.

**The orchestrator performs the writes, not the subagents.** The reviewer and verifiers are read-only; this skill (the orchestrator) makes every tracker write — editing the Brief (the parent ticket description), **appending a checklist item** to a sign-off sub-issue's description, and **re-opening** a sub-issue when a post-sign-off requirement change lands. The concrete append and re-open tracker operations are documented in `discovery-handover-package`'s `signoff-subissue-template.md`.

### 5. Report the run (no comment, no separate document)
Summarise the run **in chat only**: which agents ran and why (trigger + §-diff), what was auto-applied
(with the new version), the judgment items and ungroundable comments routed to each sub-issue, **any
sub-issue re-opened**, and any flood verdict. The durable record already lives in its homes — the
Brief's `## Revision history` and the sub-issue checklists. Do not write a standalone review report and
do not post a comment.

## Bundled Review Agents

All three are **read-only** and `user-invocable: false`. They find and propose; they never write. Each
also evaluates the **comments routed to it** — grounding a comment against its sources and proposing
the edit, or returning `needs-input` when the context is absent.

| Agent | Role |
|---|---|
| [Brief Reviewer](./agents/brief-reviewer.agent.md) | consolidated judgment triage — five concerns in one pass, each finding tagged by concern for lane routing |
| [Source-Fidelity Auditor](./agents/brief-source-fidelity-auditor.agent.md) | mechanical verifier, auditor view — sources in hand, count-checks every enumeration/formula/constant into the Brief |
| [Fresh-Eyes Probe](./agents/brief-fresh-eyes-probe.agent.md) | mechanical verifier, consumer view — payload only, simulates the coding agent |

## Output Contract

### Summary
One line: the Brief reviewed (and its new version if bumped), which agents ran, the count of mechanical
fixes + grounded comment-changes applied, the count of judgment items + ungroundable comments routed to
each sub-issue, any sub-issues re-opened, and an overall **go / revise / not-ready** read (revise while
any routed item is open; not-ready on a flood verdict).

### Detail
The artifacts are **the existing homes, updated** — not new documents:
- The **Brief/description** with mechanical fixes and grounded comment-changes applied, version bumped, each logged in `## Revision history` with the §s changed.
- **Checklist items** on the PM and Dev sign-off sub-issues — one per judgment finding or ungroundable comment, **keyed by concern + Brief section** and cited to it. A re-scan reconciles by key: no duplicates, and items whose finding no longer reproduces are annotated (never ticked by the review).
- Any sign-off sub-issue **re-opened** because a requirement-level change landed after it had signed.
This skill writes no review report and no comment; review outputs are process — never committed to the production branch.

### Verification
Every agent that ran was read-only and received only its defined inputs (the Probe saw only the
delivery payload); no agent ran that the trigger + §-diff did not require; every applied change is
mechanical or a grounded comment-fix (no decision and no invented specifics auto-applied); every
judgment finding and ungroundable comment is a checklist item on the correct side; the description and
attachment are version-locked; **no sub-issue was moved to Done**; any post-sign-off requirement change
**re-opened** its sub-issue; **no comment was posted**.

### Follow-ups
Any judgment item or ungroundable comment still open on a sub-issue (these block the gate); a flood
verdict (blocks Step 7.0 promotion — the handover returns to discovery); any agent that returned
`partial`/`blocked`.

## Quality Bar

A run meets the bar when:
- Exactly the agents the trigger + §-diff required ran — a full pass on a first review, a targeted fold on a comment — each with only its defined inputs, and returned cited, classified items (or `No issues found.`).
- **Payload-containment was verified from both directions:** the Auditor count-checked the unloaded sources into the Brief (no silent omissions, no unrecorded PRD contradictions) and the Probe confirmed the payload answers its own questions (no dangling references) — or a flood became a single not-ready verdict, handled per the handover mode.
- Mechanical fixes and grounded comment-changes were applied to the Brief, version-bumped, and logged with the §s changed; nothing requiring a decision was auto-applied.
- Each comment was either **grounded into a sourced Brief change** or **routed as a precise `needs-input` question** — none invented.
- Judgment findings and ungroundable comments became checklist items on the correct sign-off sub-issue.
- A requirement-level change applied after a side had signed **re-opened** that sub-issue.
- On a re-scan, items were reconciled by key — no duplicate added for a still-open finding, and any resolved finding's item was annotated rather than left silently blocking.
- The run was reported in chat with no comment posted and no separate review document written.
- The review **never moved a sub-issue to Done** — signing stays the humans' act.

It fails the bar when:
- A decision, or an ungroundable comment's invented specifics, was auto-applied to the Brief.
- An agent wrote to anything, or the Probe was handed the sources (its isolation is the check).
- The full pass was re-run for an event that needed a targeted fold — burning the budget the gate depends on.
- A flood of gaps was routed as a checklist wall instead of a not-ready verdict.
- Findings or comments were dumped into a comment, or a standalone review report was produced.
- A requirement-level change was applied but the already-signed sub-issue was left Done (a stale approval).

## Anti-Patterns

**Re-running everything for every event.** A new comment on an unchanged Brief does not need the
reviewer re-reading a 42KB prototype. Ground the comment; spawn at most one targeted agent. The full
pass is for a new Brief version, not a new event.

**Auto-applying a decision.** "Just set COL-09 to X" when two readings exist is a judgment call, not a
mechanical fix. When in doubt, route it to the gate — never encode a decision into the Brief automatically.

**Inventing specifics for a comment you can't ground.** "Match existing export styling" with no captured
exports is `needs-input`, not a guess — route it as a precise question naming the missing context. A
confidently-wrong spec is worse than a routed question.

**Passing a Brief that points instead of states.** A Brief whose spec lives in "the PRD's column spec"
or "the prototype" fails silently at the gate: the engineering flow never loads those, so the
implementer builds blind. The Auditor back-fills it into §6.1 — verbatim from the source when
groundable (mechanical), else `needs-input`. The Brief must stand alone.

**Feeding the Probe the sources.** A fresh reader who has seen the PRD is not fresh — the dangling
references it exists to catch no longer dangle. Its input is the delivery payload, full stop.

**Translating a flood into a checklist.** Twenty routed needs-input items don't gate a sign-off; they
get rubber-stamped. Past the flood threshold, the finding is "this handover is not ready" — one
verdict, back to discovery.

**Leaving a stale approval.** Applying a requirement-level change but leaving the already-signed sub-issue
Done ships an unratified spec to the developer. Re-open the sub-issue so the new version is re-ratified.

**Comment-thread review.** Findings posted as comments are noise nobody acts on. Mechanical fixes and
grounded comment-changes go into the Brief; decisions and ungroundable comments go onto the sign-off
checklists where a human must tick them.

**A standalone review document.** A separate report duplicates the Brief and rots. The Brief's revision
history and the checklist items *are* the record, in the homes the gate already reads.

## Critical Rules

1. **Agents are read-only; the orchestrator is the only writer** — it makes three kinds of write: a mechanical or grounded-comment fix into the Brief, a checklist item onto a sign-off sub-issue, or re-opening a sub-issue whose signed version a change made stale.
2. **Pay per change, not per event.** Full pass on a first review; §-diff-selected agents on a revision; at most one targeted agent per comment. Each agent gets only its defined inputs; the Probe gets only the delivery payload.
3. **Mechanical means one correct change, no judgment.** Anything that encodes a decision, scope, or external validation is a judgment finding and is routed, never applied. An Auditor back-fill is mechanical only when the exact content exists in a source.
4. **Ground or route every comment.** Apply a comment to the Brief only when it can be grounded in the inputs; otherwise route a precise `needs-input` question — never invent specifics.
5. **Every applied change is logged** in the Brief's `## Revision history` with a version bump and the §s changed; description and attachment stay version-locked.
6. **Apply-then-ratify; never sign.** The review writes the Brief but never moves a sub-issue to Done — approval is the human's Done-transition, and `handover-retrieval` loads only the ratified version. A requirement-level change after sign-off **re-opens** the sub-issue.
7. **Judgment findings and ungroundable comments gate the sign-off** as checklist items, routed by side (Dev: feasibility; PM: design/customer/risk/legal) and **keyed by concern + Brief section** so a re-scan reconciles without duplicating or leaving stale blockers.
8. **A flood is a verdict, not a checklist.** Past the threshold, return "not ready for handover" — blocking promotion in `strict` mode, or routed as one approve-anyway-or-return decision for the humans in `standard` mode. Never bury the gate in items.
9. **No comment, no separate review document.** The record lives in the Brief and the sub-issues.
10. **Cite or drop.** A finding without a Brief section is dropped; no style nits.

## Triggers

| To run... | Say... |
|-----------|--------|
| The full pass on a new Brief | "Review the Engineering Brief for <feature>" / "Stress-test this handover before the gate" |
| As part of the bridge | (auto) `handover-workflow` Step 2.5 before the gate; re-invoked by `handover-retrieval` when a new comment appears (targeted fold) |
| Fold in a comment | "A comment landed on the ticket — fold it into the brief" |
| A re-scan after revisions | "Re-review the brief — changes were requested" |
