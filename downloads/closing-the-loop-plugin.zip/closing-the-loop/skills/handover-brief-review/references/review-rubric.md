# Brief Review Rubric (shared by the Brief Reviewer and the two verifiers)

Every agent uses this rubric so the synthesis step can merge and rank findings consistently.

## Severity scale

Severity is about **impact on the handover**, not effort to fix.

- **Critical** — would block implementation or send it down the wrong path (e.g. an infeasible core flow, a requirement that contradicts a hard constraint, undefined behaviour on the primary path).
- **Major** — would cause significant rework or a wrong outcome if it reached code (e.g. a missing error state on a key flow, a requirement with no acceptance criteria, unhandled PII).
- **Moderate** — a real gap that a competent implementer would have to stop and ask about (e.g. an ambiguous edge case, an unstated assumption, a missing breakpoint).
- **Minor** — worth noting but not blocking (e.g. a metric named but not sized, a secondary state left implicit).

The synthesis step maps severity to action: **Critical/Major → Must-fix**, **Moderate → Should-fix**, **Minor → Nice-to-have**.

## Finding format

Return each finding as a block:

```markdown
### <Short title>
- Severity: <Critical|Major|Moderate|Minor>
- Concern: <feasibility | design | customer | risk | legal | fidelity>
- Brief section: <the section / heading / line the finding is about>
- Finding: <what is wrong or missing and why it matters for implementation>
- Evidence: <a short quote from the brief, or "absent — section X does not cover Y">
- Suggested fix: <the specific addition or change to make>
- Class: <mechanical | judgment>  — your proposal; the orchestrator decides finally
```

## Classification — mechanical vs judgment

Tag each finding so the orchestrator can route it:
- **mechanical** — exactly one correct change, no scope or value judgment (a missing disclaimer to add, an absent error-state criterion, an unstated format). May be auto-applied into the Brief.
- **judgment** — the fix encodes a decision, a scope call, or needs external validation (which book-value rule, confirming a column set with an advisor, choosing a metric). Routed to a sign-off checklist; never auto-applied.

When unsure, propose **judgment**.

## Payload-containment (the payload must stand alone)

The engineering flow loads the **delivery payload** — the Brief, the **frozen PRD**, and the AGENTS.md block — never the prototype or the brownfield reference. So (`Concern: fidelity`):

- A load-bearing detail that lives only in the **prototype or the reference** (a spec, formula, enumeration, state, or output format *named but not stated* in the Brief) is a real defect — **Critical/Major** — and its home is §6.1. Citing the PRD is fine (it is in the payload).
- A place where the Brief **diverges from the PRD without a recorded correction** (§3/§8) is equally a defect: the precedence rule makes the Brief win, so a silent divergence misleads anyone reading both.

Owned by the two **verifiers**: the **Source-Fidelity Auditor** (silent omissions, weakened copies — count-check every enumeration — and unrecorded contradictions) and the **Fresh-Eyes Probe** (dangling references and unanswerable build questions from the consumer's side).

Classify by whether the detail can be recovered from the sources:
- **Groundable → mechanical back-fill.** The missing content exists in the prototype/reference → copy it **verbatim** into §6.1. There is exactly one correct change, so it is mechanical: the orchestrator applies it, version-bumps, and logs it. (An unrecorded PRD contradiction is usually **judgment** — someone must decide which document is right, then record it.)
- **Not groundable → needs-input.** The detail isn't in any source → route a precise `needs-input` question naming what's missing; never invent the spec.

**Flood rule:** more than 8 build-blocking `needs-input` items on one pass (or a missing §6.1 on a feature that plainly requires one) is not a checklist — it is a single verdict: **not ready for handover, return to discovery/PRD**. In `strict` mode this blocks Step 7.0 promotion; in `standard` mode it is routed as one approve-anyway-or-return decision for the humans.

## Discipline (all agents)

- **Cite or drop.** Every finding names a brief section and quotes the brief (or states precisely what is absent). No citation → do not report it.
- **No style nits.** Wording, formatting, and naming are out of scope. Report defects that would mislead or block implementation.
- **Stay in your role.** The Reviewer judges the content that is present; the Auditor checks fidelity against the sources; the Probe reports what the payload alone cannot answer. Don't do another agent's job.
- **Read-only.** Inspect and report. Never edit the brief or any file.
- **Default to fewer, real findings.** A short list of defensible findings beats a long list of maybes.

## Closing line

End every report with exactly one status line:

```text
STATUS: done | partial | blocked
```

- `done` — you reviewed the whole brief through your lens.
- `partial` — you reviewed part; name what you could not reach and why.
- `blocked` — you could not review (e.g. the brief was missing); say what you needed.
