---
name: v-debug-issue
description: Systematically diagnose and fix failures through evidence-based root cause analysis. Use when a test is failing for non-obvious reasons, when a runtime error or exception appears, when behavior has regressed, when a failure is intermittent or hard to reproduce, when performance has degraded without clear cause, or whenever the user says "debug", "investigate", "broken", "failing", or "why is this happening".
trigger: [investigate this failure, diagnose the regression, why is this broken, root cause this bug, debug the failing test]
license: Apache-2.0
---

# Debug Issue

## Objective

Diagnose failures through evidence-based investigation and fix the root
cause, not the symptom. A good debug cycle produces three things: a clear
explanation of why the failure occurred, a minimal fix that addresses the
actual cause, and a regression guard that prevents recurrence.

## When to Use

- A test is failing and the cause is not immediately obvious
- A runtime error or exception occurs in development or production
- Behavior has regressed, a failure is intermittent, or performance has
  degraded without clear cause
- An error message is misleading or does not point to the actual problem

Do not use this skill when the problem is obvious and the fix is trivial (a
typo, a missing import the error message names directly). Recognize when full
debugging methodology is overhead and just fix the obvious thing.

## Context

Before starting any investigation, establish what you know:

1. **Gather the failure signal.** Copy the exact error, stack trace, or
   unexpected output — not a paraphrase of it.

2. **Establish when it last worked.** Recent commits, dependency updates,
   configuration changes, and environment differences are the most common
   regression sources. Use version control history to narrow the window.

3. **Understand the expected behavior.** Read the relevant tests, specs, or
   docs — you cannot diagnose a deviation without knowing what "correct"
   looks like.

4. **Check for known issues** in issue trackers and commit messages.

   **Tooling note:** Use the strongest issue-tracker integration available —
   Linear MCP, Jira MCP, GitHub Issues MCP or `gh issue list/view`, harness
   equivalents for other hosts. If none is configured, ask the user to share
   prior incident links or move on; missing integration is not a fail-stop.

## Workflow

### 1. Reproduce the Failure

Without a reliable way to trigger the failure, you cannot verify that any fix
works.

- Run the exact failing command — same arguments, environment, and data —
  before modifying anything. Capture the full output to compare against
  after each change.
- If the failure is intermittent, identify the conditions that increase its
  likelihood (timing, concurrency, data volume, resource pressure) and try
  to make it reproducible.
- If you cannot reproduce, state that clearly and investigate from the
  available evidence (logs, traces, error reports) — do not pretend a
  non-reproducible failure is reproduced.

### 2. Form a Hypothesis

State what you think is causing the problem. Be specific:

- **Bad:** "Something is wrong with the data processing."
- **Good:** "The null check on line 47 does not account for empty strings, so
  the downstream parser receives an empty value and throws."

A good hypothesis is testable — it predicts what you should see if it is
correct, and what you should see if it is wrong. If you cannot state both
predictions, the hypothesis needs to be more specific. Write it down before
testing it — this prevents confirmation bias.

### 3. Gather Evidence

- Trace the code path from entry point to failure point — the cause is often
  upstream of the symptom.
- Add temporary diagnostic output at key decision points to observe actual
  runtime state; remove it after diagnosis.
- Compare working vs failing contexts — the difference between them is the
  clue.
- Check boundary conditions: nulls, empty collections, zero-length strings,
  maximum values, concurrent access, encoding.

### 4. Isolate the Root Cause

Narrow until you can point to the exact location and condition that causes
the failure: binary-search the execution path, minimize the reproduction
case, and distinguish root cause from symptom — the error message tells you
what happened; the root cause tells you why. When you believe you have found
it, predict what the fix should be. If you cannot predict the fix, you have
not found the root cause yet.

### 5. Apply the Minimal Fix

- Fix the cause, not the symptom. If a null value reaches a point that
  cannot handle it, fix where the null originates — not by adding a null
  check at every downstream usage.
- Avoid refactoring, renaming, reformatting, or "improving" adjacent code
  during a bug fix. Those changes obscure the actual fix and risk new issues
  — they are separate work.
- Handle the security dimension: validate external input at the boundary,
  keep sensitive information out of error messages and logs, fail safely.
- Verify the fix works for all inputs that reach the code path, not only the
  case that triggered the failure.

### 6. Add Regression Protection

If the bug could recur, add a test that fails without the fix and passes
with it. Test at the narrowest level that catches the issue, and name it so
the guarded scenario is clear without reading the body.

Skip regression tests when: the fix is a trivial typo, the issue is
environment-specific and not testable in the standard suite, or existing
tests already cover the exact scenario (they just were not being run).

### 7. Verify the Fix

Rerun the exact reproduction command and compare against the output captured
in step 1. Run the broader test suite for the affected module. If the fix
changes shared logic, check its other callers. Confirm the regression test
fails when the fix is reverted and passes when it is applied.

## Output Contract

Every debug session must produce these sections under `## Output Contract`:

### Summary

One sentence stating what failure was diagnosed and how it was fixed (or
"diagnosed but not fixed" with reason).

### Detail

The diagnosis-and-fix narrative:

- **Symptom:** [exact error or unexpected behavior observed]
- **Root Cause:** [specific explanation of why the failure occurs]
- **Evidence:** [what observations confirmed the diagnosis]
- **Change:** [what was changed and where]
- **Rationale:** [why this fix addresses the root cause]

### Verification

- [reproduction command and its output after the fix]
- [test suite results]
- [regression test added: yes/no with justification]

### Follow-ups

- [any related issues discovered but not fixed]
- [conditions that might trigger similar failures]
- "None" if the fix is fully self-contained and no related risk remains

## Quality Bar

A debug session meets the quality bar when:

- The root cause is identified and explained, not just the symptom
- The fix targets the cause, not a downstream effect
- Reproduction evidence exists for both the failure and the fix
- The broader test suite passes, and a regression test exists (or a clear
  reason why one is not needed)
- The diagnosis narrative is coherent from symptom to cause to fix
- No unrelated changes are mixed into the fix

## Anti-Patterns

**The suppression fix.** Wrapping the failing code in error handling, adding
a null check before the crash, or returning a default value where an error
should propagate. The underlying problem remains and will manifest
differently later.

**The timeout debug.** Spending hours in a single debugging direction without
progress. After three failed attempts at the same approach, stop. Write down
what you know for certain, what you have ruled out, and what you have not
tried. Often the act of writing this list reveals a fresh direction.

## Critical Rules

1. **Reproduce before fixing.** Never apply a fix to a problem you cannot
   reproduce. If reproduction is impossible, document that limitation and be
   explicit about the lower confidence.

2. **One change at a time.** Each debug iteration should change exactly one
   variable. Multiple simultaneous changes make it impossible to determine
   what actually worked.

3. **Evidence over intuition.** "I think" is a hypothesis. "I observed" is
   evidence. Verify hypotheses with observations before acting on them.

4. **Fix the root cause.** If you cannot explain why the failure occurred,
   you have not finished debugging.
