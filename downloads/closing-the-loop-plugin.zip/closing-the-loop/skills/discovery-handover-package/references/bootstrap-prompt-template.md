# Bootstrap Prompt Template

> **Purpose:** Pasted at the start of an engineering session (`v-scope`, then `v-build`) to initialise engineering with full discovery context.
>
> **Disciplines:**
> - Always invoke Plan Mode — the agent interviews before writing code
> - Reference a throwaway prototype as intent documentation, never as source code; reference a component prototype's source as the UI reference implementation, under the port rule
> - Use explicit import paths, never visual descriptions

---

## Template

```
You are starting a new feature development session for: **[Feature Name]**

---

## Discovery context

A validated prototype exists for this feature. [Throwaway prototype:] It is **intent documentation only** — do not copy code from it. Use it to understand the desired UX and interactions, then implement against the production codebase. [Component prototype:] Its source is the **UI reference implementation**, built from this product's own components. Open it for layout, component usage, and tokens. Port markup and styles; never its mock data, stand-ins, kit import paths, or hard-coded copy.

- **Engineering Brief:** `[path to handover/[feature]-brief.md]`
  Read this first. It contains the problem statement, user flows, acceptance criteria, hard constraints, risks, and open assumptions.

- **Prototype:** `[path or URL]`
  [Throwaway:] Intent documentation. Reference for UX and interactions, not for code.
  [Component prototype:] Source at `[repo · branch · commit · folder]`; its `prototype-pack.md` lists the files per screen and state.

- **AGENTS.md Discovery Context block:** Already appended to this repo's `AGENTS.md` under `## Discovery Context — [Feature Name]`. Read it — it carries non-inferable rationale that the code alone will not tell you.

---

## Production components

Use these import paths. Do not approximate from the prototype's component names.

| Prototype element | Production import |
|---|---|
| [Element] | `import { [Component] } from '[package]'` |
| [Element] | `import { [Component] } from '[package]'` |

---

## Hard constraints

These cannot be changed without coordinated effort:

- [Constraint]
- [Constraint]

---

## What is explicitly out of scope

Do not implement:

- [Out-of-scope item]
- [Out-of-scope item]

---

## Starting instruction

**Enter Plan Mode.**

Before writing any code:
1. Read the Engineering Brief and AGENTS.md Discovery Context block in full
2. Read the relevant existing module(s) in the codebase
3. Propose an implementation plan that respects the hard constraints above
4. Ask any clarifying questions before proceeding

Do not write code until the plan has been reviewed and confirmed.
```
