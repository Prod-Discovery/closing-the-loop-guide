# Bootstrap Prompt Template

> **Purpose:** Pasted at the start of a `v-develop-feature` session to initialise engineering with full discovery context.
>
> **Disciplines:**
> - Always invoke Plan Mode — the agent interviews before writing code
> - Reference the prototype as intent documentation, never as source code
> - Use explicit import paths, never visual descriptions

---

## Template

```
You are starting a new feature development session for: **[Feature Name]**

---

## Discovery context

A validated prototype exists for this feature. It is **intent documentation only** — do not copy code from it. Use it to understand the desired UX and interactions, then implement against the production codebase.

- **Engineering Brief:** `[path to handover/[feature]-brief.md]`
  Read this first. It contains the problem statement, user flows, acceptance criteria, hard constraints, risks, and open assumptions.

- **Prototype:** `[path or URL]`
  Intent documentation. Reference for UX and interactions, not for code.

- **AGENTS.md Discovery Context block:** Already appended to this repo's `AGENTS.md` under `## Discovery Context — [Feature Name]`. Read it — it carries non-inferable rationale that the code alone will not tell you.

---

## Production components

Use these import paths. Do not approximate from the prototype's component names.

| Prototype element | Production import |
|---|---|
| [Element] | `import { [Component] } from '[package]'` |
| [Element] | `import { [Component] } from '[package]'` |

---

## Hard constraints

These cannot be changed without coordinated effort:

- [Constraint]
- [Constraint]

---

## What is explicitly out of scope

Do not implement:

- [Out-of-scope item]
- [Out-of-scope item]

---

## Starting instruction

**Enter Plan Mode.**

Before writing any code:
1. Read the Engineering Brief and AGENTS.md Discovery Context block in full
2. Read the relevant existing module(s) in the codebase
3. Propose an implementation plan that respects the hard constraints above
4. Ask any clarifying questions before proceeding

Do not write code until the plan has been reviewed and confirmed.
```
