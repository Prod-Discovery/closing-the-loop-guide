# Engineering Brief — [Feature Name]

> **Purpose:** Input to the engineering `v-write-spec` skill
> **Discovery run completed:** [Date]
> **Feature type:** [Brownfield / Greenfield]
> **Target repo:** [repo name / URL]
> **Version:** v1.0 · **Source ticket:** [KEY — or "none (local)"]
> **Backlog shape:** epic | single-ticket (team default: <X>; chosen per feature)
> *(Approval status lives on the two sign-off sub-issues — the tracker is the record, never this header.)*

> **The delivery payload is this Brief + the frozen PRD + the AGENTS.md context block.** That is all
> the engineering flow loads — never the prototype or the brownfield reference. The PRD (attached,
> frozen at handover) carries the requirements; this Brief carries what the PRD does not: the
> interpretations, the **corrections to the PRD**, the codebase constraints, and the integration
> contracts. **Precedence: on any conflict, this Brief wins** — it is the reviewed arbitration layer,
> and every correction it makes is listed explicitly (§3/§8). Citing the PRD is legal ("columns per
> PRD §3.1" — it's in the payload); citing the prototype or the reference for load-bearing detail is
> a defect (they are not).
> **Litmus test:** could an implementer build this correctly from the payload alone? Enforcement
> depends on the configured handover mode — `strict` blocks promotion until true; `standard` routes
> the gaps as explicit questions to the sign-off gate — but the litmus test is the bar in both.
>
> **Brevity:** this is a scannable decision document, not a spec dump. Each section carries only what
> its consumer acts on; cite the frozen PRD precisely rather than duplicating it; a section with
> nothing new says so in one line (§6.1 models this). Load-bearing detail that exists only in the
> prototype or the brownfield reference is the exception — that must be stated in full, always.

---

## 1. Problem statement

[What user problem does this solve, and why does it matter? 3–5 sentences sourced from Stage 1 customer insights and Stage 2 solution prioritization.]

**Severity evidence:** [Pain level and sample size from Stage 1.1 — e.g. "Severity 8/10 across 34 NPS verbatims"]

---

## 2. Solution concept

[What we decided to build, and why this approach over alternatives. Sourced from Stage 2 solution exploration and Stage 3 PRD.]

**Agentic feature:** [Yes / No] — [if yes, brief description of the agent's role]

---

## 3. Open interpretations resolved by the brief author

> Every PRD line that was ambiguous, the interpretation chosen, the alternative reading, and a one-line rationale. The PM should override anything here that does not match intent **before** approval — disambiguations caught at the gate are free; the same disambiguations caught after implementation cost a rebuild.
>
> If the PRD was unambiguous, this table is empty. That itself is a signal — leave the table header in place with a single row reading "No interpretations needed."

| # | PRD said (verbatim, with §/page if useful) | Interpreted as | Alternative reading | Why this choice |
|---|---|---|---|---|
| 1 | [verbatim PRD line] | [the interpretation chosen by the brief author] | [the plausible reading not chosen] | [one-line rationale] |
| 2 | ... | ... | ... | ... |

---

## 4. User flows

[Key flows the prototype validated — or, on a declared no-prototype handover, the flows as the PRD
and acceptance criteria state them. Reference the prototype by path — intent documentation only, not
source.]

**Prototype reference:** `[path or URL]` — intent documentation only; do not copy code from this.
*(Omit this line on a declared no-prototype handover.)*

### Primary flow

1. [Step]
2. [Step]
3. [Step]

### Edge cases and alternate flows

- [Edge case and how it was handled in the prototype]

---

## 5. Success metrics

[From Stage 3 PRD. Measurable signals that tell us this feature is working.]

| Metric | Target | Measurement method |
|--------|--------|--------------------|
| [Metric] | [Threshold] | [How to measure] |

---

## 6. Functional specification & acceptance criteria

### 6.1 Functional specification (what the PRD does not say)

> The PRD is **in the delivery payload** (frozen, attached) — do not re-copy what it already states
> well; cite it ("columns per PRD §3.1"). This section carries the spec content the PRD does **not**:
>
> - **Corrections to the PRD** — *mandatory whenever discovery found one* (e.g. "PRD names
>   `global.de.php`; the grouping actually reads `report-balancesheet.global.de.php` — see §8").
>   An unlisted correction is a defect: the precedence rule says this Brief wins, so a silent
>   divergence misleads the implementer.
> - **Exact values the prototype confirmed** *(when a prototype exists — n/a on a declared
>   no-prototype handover)* — defaults, orderings, column order, every empty/loading/error state. The
>   prototype is NOT in the payload; a value only in its markup is a value engineering never sees.
> - **Data-shape and behavioural constraints from the brownfield reference** — also not in the
>   payload; state what matters here (and in §8), never point at the reference for load-bearing detail.
> - **Integration contracts** for new server-side methods (with §7).
> - **Agent-behavior contract (agentic features)** — triggers/conditions; tools + access mode; human
>   checkpoints; decision boundaries ("when NOT to act"); failure modes + fallbacks. *(The AGENTS.md
>   block carries non-inferable rationale + runtime state transitions; §6.1 carries the build spec.)*
>
> Never compress a formula, enumeration, or state machine that lives outside the payload into a
> one-line criterion — state it in full here.

If the PRD plus §4 and §6.2 genuinely cover everything (no corrections, no prototype-only values, no
codebase constraints), say so explicitly: `Nothing beyond the PRD, §4, and §6.2.` (An absent §6.1
signals the pass was skipped.)

### 6.2 Acceptance criteria

[From Stage 3 PRD. Conditions that must be true for the feature to be considered done. Each criterion
verifies something specified in §6.1 or a flow in §4 — it does not replace the spec. **Key every
criterion** (`AC-1`, `AC-2`, …) and tag it with the §4 flow it verifies — the keys are what §6.3, the
backlog stories, and the per-criterion tests reference. These keyed Given/When/Then criteria are the
feature's **test-scenario surface**: stories carry them verbatim, and delivery derives at least one
test per `AC-n`.]

- [ ] AC-1 `[flow: <§4 flow name>]` [Criterion]
- [ ] AC-2 `[flow: <§4 flow name>]` [Criterion]

### 6.3 Story map (implementation slices) — epic-shaped features only

[Present iff this feature was shaped epic (`discovery-handover-package` Step 3.5); omit the section
entirely for a single-ticket-shaped feature. Its presence is what every downstream skill reads as the
shape — the `Backlog shape:` header line above is the human statement. Vertical slices grouping the
§6.2 criteria by the §4 flow they verify — the task-breakdown output of the spec pass. Each slice must be independently shippable and **demonstrable**: name its
**demonstrable outcome** — the prototype state/screen that shows it done; on a declared no-prototype
handover, an observable behaviour tied to one of its criteria; for agentic features, slice by
state/transition of the §6.1 agent-behavior contract instead of by screen. Chores are prerequisite
work from §8 (migrations, seams) — never "watch out for X" risks, which stay in §10. This table is
what PM + Dev ratify at the gate; `create-backlog-from-brief` renders it into tickets verbatim and
never invents slices of its own.]

| Slice | Flow (§4) | Criteria (§6.2) | Spec carried (§6.1) | Demonstrable outcome | Depends on |
|-------|-----------|-----------------|---------------------|----------------------|------------|
| C1 [chore name] | — | — | [§8 constraint it clears] | — | — |
| S1 [story name] | [Primary flow steps 1–3] | AC-1, AC-2 | [the §6.1 blocks this slice needs] | [screen/state or observable behaviour] | C1 |
| S2 [story name] | [Alt flow A] | AC-3, AC-4 | [§6.1 blocks] | [screen/state or observable behaviour] | S1 |

[Coverage rule: every §6.2 `AC-n` appears in **exactly one** slice — no orphans, no duplicates. Every
§8 constraint is either a chore row or named in a slice's spec column. Every cross-slice dependency is
an explicit `Depends on` entry.]

---

## 7. Component decisions

[For each UI component used in the prototype — or, on a declared no-prototype handover, in the design
source (e.g. Figma) — the production import path. Source: Code Connect mapping, Claude Design bundle,
or manual mapping.]

| Element (prototype/design) | Production component | Import path | Source |
|----------------------------|---------------------|-------------|--------|
| [Element] | [ComponentName] | `[import path]` | [Code Connect / Claude Design / Manual] |

**For brownfield features that add new server-side methods** (controller actions, API handlers, service operations, background jobs): confirm the integration contract against existing analogues *in the same class* before the brief leaves this stage. This is what prevents the implementer from using a plausible-but-wrong return type, URL helper, or middleware pattern — bugs that look correct in isolation but break at the framework boundary.

| New method (type) | Existing analogue in the same class | Integration contract |
|---|---|---|
| [e.g. "AJAX dialog action `dialogFooAction()`"] | [`[file:line]` of the closest existing method of the same type] | [Return type + response envelope + auth pattern — e.g. "returns `JsonModel({status: 'ok', view: rendered_html})` — NOT raw `ViewModel`"] |
| [e.g. "file download action `downloadFooAction()`"] | [`[file:line]`] | [e.g. "generates URL via named route `app/default` with `[controller, action]` params — NOT via `fromRoute(null, …)`; sets `Content-Disposition: attachment` then `exit`"] |

Leave this table empty only if the feature adds no new server-side methods. Partial information is worse than none — if you cannot confirm the contract from a read analogue, leave the row blank and flag it for the Dev reviewer to confirm before approval.

---

## 8. Hard constraints

[Things engineering must not change without coordinated effort. For brownfield features, sourced from the `handover-codebase-discovery` output. For greenfield, sourced from architecture discussions or regulatory requirements.]

- [Constraint — e.g. "Must extend existing `user_preferences` table — no new backend service"]
- [Regulatory — e.g. "Data residency: subject to same rules as parent module per `config/compliance.yml`"]

---

## 9. Scope boundaries

[What is explicitly out of scope for this implementation. Sourced from Stage 2 prioritisation and Stage 3 PRD.]

**Not in scope:**
- [Item — e.g. "Bulk apply to other dashboards — deferred post-launch"]
- [Item]

---

## 10. Risks engineering should know about

[Anything discovery flagged that engineering would otherwise miss. For brownfield features, sourced from `handover-codebase-discovery` Known Risks section.]

| Risk | Why it matters | Suggested mitigation |
|------|----------------|----------------------|
| [Risk] | [Impact] | [Mitigation] |

---

## 11. Open assumptions

[What was not fully validated during discovery. Sourced from Stage 6 experiment plan results.]

- [Assumption — e.g. "Default 10-view limit — untested, revisit after launch based on usage data"]

---

## 12. Discovery context summary

[Brief summary of the discovery journey for engineering's awareness. 3–5 sentences.]

- **Customer signal:** [key pain points from Stage 1.1]
- **Competitive context:** [relevant gap from Stage 1.2]
- **What changed during prototyping:** [key iterations from Stage 6]
- **Experiment results:** [what was validated, what remains open]

---

## Sign-off *(no-tracker path only — delete this section when a tracker holds the sign-off sub-issues)*

> When there is no tracker, this section is the live sign-off surface (there is no separate Approval
> Record file). Open items routed by the handover land here as checklist boxes; each must be ticked
> before its side signs. With a tracker, sign-off lives on the two sub-issues and this section must
> not exist — a file can lie; the tracker state cannot.

- [ ] *(routed open items appear here, keyed `[concern · §]`)*

**PM sign-off:** name ____ · date ____
**Dev sign-off:** name ____ · date ____

---

## Revision history

> One row per version. The brief is created at v1.0; `handover-brief-review` mechanical fixes and human edits bump the version (in the header block above) and append a row here. **Each row names the §s it changed** (e.g. "§6.1: embedded the column derivations") — re-reviews use this to re-run only the agents whose lane covers a changed §. Keep this in lockstep with the version-stamped attachment and the ticket description.

| Version | Date | Change | By |
|---|---|---|---|
| v1.0 | [Date] | Initial brief from discovery handover | discovery-handover-package |
