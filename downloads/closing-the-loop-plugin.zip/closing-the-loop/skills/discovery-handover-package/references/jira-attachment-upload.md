# Jira attachment upload (REST API token)

How to attach handover artifacts to a **Jira** issue. Use this only on the Jira path of Step 7; the
Linear path uses the connector's 3-step signed-upload flow inline in `SKILL.md` and is unaffected.

## Why this exists

The Atlassian MCP server (`mcp.atlassian.com`) exposes **no attachment tool** — only comment, worklog,
issue, and search operations. The OAuth grant the MCP holds *does* include `write:jira-work` (which
covers attachments), so this is missing *tooling*, not missing *permission*. But the bearer token is
sealed in the OS keychain and never exposed to tool calls or the shell, and it auto-refreshes — so
reading or scraping it is unsupported and fragile. The symmetric fix (Linear hands artifacts over via
signed upload URLs) is to upload through the **Jira Cloud REST API with a user-provided Jira API
token**. This is gated on configuration: with no token, the package stays local-only (never fail, never
block).

## Configuration (two env vars, read at runtime, never printed)

| Var | What it is |
|-----|-----------|
| `JIRA_EMAIL` | The Atlassian account email used for basic auth. |
| `JIRA_API_TOKEN` | A Jira API token from id.atlassian.com → **Security → API tokens**. |

The token needs `write:jira-work`-equivalent permission — **any** normal user who can attach files to
the project qualifies. Both values are read from the environment at runtime. **Never** hardcode, echo,
log, or commit them; never write them to a file, the manifest, the ticket, or stdout. Reference them
only as the shell variables `$JIRA_EMAIL` / `$JIRA_API_TOKEN`.

> **Use a classic (unscoped) API token.** Basic auth needs a *classic* Atlassian API token. A newer
> **scoped** token is Bearer-only and fails basic auth with a confusing `401` — if you see `401` with
> credentials that look correct, this is almost always the cause. Create the token at
> id.atlassian.com → **Security → API tokens** without selecting scopes.

**Alternative: `~/.netrc` instead of env vars.** If you'd rather keep the credential off the process
environment, put it in `~/.netrc` and use `curl --netrc` (it reads the matching `machine` line) in
place of `-u`:

```
machine <site>.atlassian.net
login <your-atlassian-email>
password <classic-api-token>
```

`chmod 600 ~/.netrc` so only you can read it. Either mechanism works; pick one. The same credential
serves both upload and [download](./jira-attachment-download.md).

Running **`closing-the-loop-setup`** scaffolds the `~/.netrc` entry and records the site + auth method
in `~/.config/closing-the-loop/config.json`. When that config is present, take the `<site>` and auth
method (`--netrc` or the env vars) from it rather than re-detecting.

If neither the env vars nor a `~/.netrc` entry is configured, do **not** attempt the upload: leave the
artifacts local-only, set the manifest's `attachments` to `[]`, and say so in the Step 8 summary (with
how to enable it).

## The request

- **Endpoint:** `POST https://<site>.atlassian.net/rest/api/3/issue/{issueKey}/attachments`
  - Derive `<site>` from the source ticket URL captured in Step 1
    (`https://<site>.atlassian.net/browse/<KEY>` → `<site>`, e.g.
    `visma-product-discovery-test`). Use the **direct site host**. Do **not** use the
    `api.atlassian.com/ex/jira/{cloudId}` gateway form — that is the OAuth path; basic auth uses the
    direct site host.
- **Auth:** HTTP Basic — `JIRA_EMAIL : JIRA_API_TOKEN`.
- **Required header:** `X-Atlassian-Token: no-check` — Jira rejects the upload without it.
- **Body:** `multipart/form-data` with the field name **`file`**. The field is repeatable: pass several
  `-F "file=@..."` parts to attach several files in one request.
- **Response:** a JSON array of attachment objects (`id`, `filename`, `content` URL). Capture each
  `id` + `filename` for the manifest.

## Reference call

Read the token from the environment and reference it via the shell variable — never inline the secret:

```bash
curl -s -u "$JIRA_EMAIL:$JIRA_API_TOKEN" \
  -H "X-Atlassian-Token: no-check" \
  -F "file=@<feature>-brief-v<version>.md" \
  "https://<site>.atlassian.net/rest/api/3/issue/<KEY>/attachments"
```

With `~/.netrc` configured instead, swap `-u "$JIRA_EMAIL:$JIRA_API_TOKEN"` for `--netrc`:

```bash
curl -s --netrc \
  -H "X-Atlassian-Token: no-check" \
  -F "file=@<feature>-brief-v<version>.md" \
  "https://<site>.atlassian.net/rest/api/3/issue/<KEY>/attachments"
```

The whole payload can go in one request (the `file` field repeats):

```bash
curl -s -u "$JIRA_EMAIL:$JIRA_API_TOKEN" \
  -H "X-Atlassian-Token: no-check" \
  -F "file=@<feature>-brief-v<version>.md" \
  -F "file=@<feature>-agents-context-v<version>.md" \
  -F "file=@<feature>-prd-v1.0.md" \
  -F "file=@<feature>-manifest-v<version>.json" \
  "https://<site>.atlassian.net/rest/api/3/issue/<KEY>/attachments"
```

## Version stamping (accumulate, never overwrite)

Reuse the **Brief's header version** (it starts at `1.0`; the revision history bumps it) in each
uploaded filename — `[feature]-brief-v<version>.md`, `[feature]-agents-context-v<version>.md`, etc. Jira's
attachment API always *adds* a new attachment (it never replaces by name), so a re-run at a bumped
version accumulates a fresh, version-stamped set alongside the prior one — identical to the Linear
convention. Do not delete prior attachments.

## Manifest

For each attachment in the response, record one entry in the manifest's `attachments[]`:

```json
{ "artifact": "brief", "filename": "[feature]-brief-v1.0.md", "attachmentId": "<id>", "uploadedAt": "<ISO date>" }
```

Store the `attachmentId` and `filename` only — never any auth material.

## Failure handling (never abort the handover)

The upload is best-effort. On an HTTP error, surface a readable message and **continue** — the package
still completes locally and the manifest keeps `attachments` as `[]`.

| Status | Meaning | What to tell the user |
|--------|---------|-----------------------|
| `401` | Bad credentials | `JIRA_EMAIL` / `JIRA_API_TOKEN` is wrong or expired — regenerate the token. |
| `403` | No permission, or attachments disabled | The account can't attach to this project, or attachments are off for the instance. |
| `404` | Issue or site not found | Check `<site>` and `<KEY>` derived from the Step 1 URL. |
| `413` | File too large | Exceeds the instance attachment size limit — attach manually or raise the limit. |

In every case the artifacts remain local, `attachments` stays `[]`, and the Step 8 summary notes the
upload was attempted and why it didn't land. Do **not** stop the handover.
