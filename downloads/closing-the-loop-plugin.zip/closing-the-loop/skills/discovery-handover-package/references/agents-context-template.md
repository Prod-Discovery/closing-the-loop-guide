# AGENTS.md — Discovery Context block template

> **Discipline: Non-inferable content only.**
> Every line must be something a coding agent could not derive from reading the code.
>
> Test for inclusion: *if I removed this line, would the agent's behaviour change for the worse?* If no — the line isn't earning its place.
>
> **Cap: 30 lines.** Brevity is the discipline. Discovery rationale that doesn't fit here belongs in the Engineering Brief.

---

## Where this goes

Append the block below to the repo's `AGENTS.md`, under a heading like:

```markdown
## Discovery Context — [Feature Name] (YYYY-MM-DD)
```

Suggested placement: after general repo conventions, before any feature-specific blocks.

---

## Block template

```markdown
## Discovery Context — [Feature Name] (YYYY-MM-DD)

**What was validated:**
- [Specific finding from user testing — be concrete, with sample size if relevant]
- [...]

**Decisions and why:**
- [Component / pattern / interaction choice] — [reason rooted in user behaviour, not preference]
- [...]

**What changed during prototyping:**
- [What we tried, what didn't work, what replaced it]
- [...]

**Open assumptions** (still untested as of handover):
- [Assumption + why we couldn't test it yet]
- [...]
```

**For agentic features, add:**

```markdown
**Agent state transitions** (non-inferable):
- [State A] → [State B]: triggered by [event] — agent must [specific behavior], not [common mistake]
- [Why the transition logic is non-obvious from the code]
```

---

## What goes here vs. what doesn't

| Include (non-inferable) | Don't include (the agent can read this) |
|---|---|
| *"Drawer over modal — 6/8 testers reported context loss in modal"* | "We use Drawer for the create-view panel" |
| *"Default 10-view limit is an untested assumption — revisit after launch"* | "Saved views array max length is 10 in the schema" |
| *"Bulk apply deferred — low pain score in Stage 2 prioritisation"* | "This dashboard only — see dashboard-id filter" |
| *"Filter chips must render in insertion order — 4/5 testers tracked them visually"* | "FilterChip[] preserves insertion order" |

## Discipline checklist

- [ ] Under 30 lines?
- [ ] Every line earns its place? (delete test per line)
- [ ] No restatement of code?
- [ ] Reasons given, not just choices?
- [ ] Open assumptions called out?
- [ ] State transitions included if agentic?
