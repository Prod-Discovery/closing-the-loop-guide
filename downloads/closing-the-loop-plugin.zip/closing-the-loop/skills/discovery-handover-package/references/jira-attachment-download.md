# Jira attachment download (REST API token)

How to download an attachment's **bytes** from a **Jira** issue. The counterpart to
[`jira-attachment-upload.md`](./jira-attachment-upload.md); use it wherever a skill must *read back* a
file from a Jira ticket (the AGENTS.md block in `handover-retrieval`, a Jira-attached prototype in
`discovery-handover-package` Step 1 or `discovery-component-mapper`).

## Why this exists

The Atlassian MCP returns attachment **metadata only** (`id`, `filename`, `size`, `mimeType`) — never
the file contents. To get the bytes you must call the Jira Cloud REST API with the same basic-auth
credential the upload path uses. Linear is unaffected: its connector's get-attachment operation returns
the bytes directly, no token needed.

## Auth & config (same credential as upload)

Identical to [`jira-attachment-upload.md`](./jira-attachment-upload.md): HTTP Basic with `JIRA_EMAIL` +
`JIRA_API_TOKEN` (read from the environment, referenced only via the shell variables, never echoed or
written anywhere), **or** a `~/.netrc` entry with `curl --netrc`. The token must be a **classic
(unscoped)** Atlassian API token — a scoped/Bearer-only token fails basic auth with `401`.

When `~/.config/closing-the-loop/config.json` is present (written by `closing-the-loop-setup`), take the
`<site>` and auth method from it. If no credential is configured, do **not** fabricate the file: report
what couldn't be downloaded and ask the user to supply it (see *Gating* below).

## Step A — get the attachment id

- **From a local manifest:** the `attachmentId` is already recorded in `attachments[]` (written by the
  upload path) — use it directly, no round-trip.
- **Otherwise:** `getJiraIssue` with `fields` including `"attachment"` → read `attachment[].id`,
  `filename`, `size`, `mimeType`. (The MCP *can* read this metadata; it just can't return the bytes.)
  Match the right file by `filename` (and version stamp, e.g. `-v1.1`).

## Step B — download the bytes

```bash
mkdir -p <out-dir>
curl -u "$JIRA_EMAIL:$JIRA_API_TOKEN" --fail --show-error --silent -L \
  -o "<out-dir>/<id>-<safe-filename>" \
  "https://<site>.atlassian.net/rest/api/3/attachment/content/<id>"
```

With `~/.netrc` configured, swap `-u "$JIRA_EMAIL:$JIRA_API_TOKEN"` for `--netrc`.

- **`-L` is required.** `/rest/api/3/attachment/content/{id}` 302-redirects to a short-lived signed
  storage URL; without `-L` you capture the redirect, not the file.
- **No `X-Atlassian-Token` header** — only *uploads* are XSRF-checked; downloads are plain GETs.
- **Site host** comes from the ticket URL (`https://<site>.atlassian.net/browse/<KEY>` → `<site>`). Use
  the direct site host, **not** the `api.atlassian.com/ex/jira/{cloudId}` gateway (that is OAuth-only).
- `<safe-filename>`: the original filename with whitespace/shell metacharacters replaced by `_`,
  extension preserved. Reuse an already-downloaded path instead of re-fetching.

After download, **read the actual file** — never act on a prose summary of it.

## Failure modes (surface readably; never proceed on an unread file)

| Symptom | Cause | What to do |
|---------|-------|-----------|
| `401` | Missing/wrong creds, or a **scoped** token used for basic auth | Tell the user; use a classic unscoped token. |
| `403` | The account lacks access to the issue | Confirm the issue is visible to that account. |
| `404` | Wrong/stale attachment id (re-uploads change ids) | Re-fetch the issue's attachment metadata (Step A) and retry. |
| HTML body instead of a file | Auth redirected to a login page | Credential is misconfigured — surface to the user. |
| Empty file | Transient server issue | Retry once, then surface. |

## Gating & fallback

Download is credential-gated. When no token / `~/.netrc` is configured, or download fails:

- **`handover-retrieval`:** the **Engineering Brief is the ticket description** — read it with a plain
  get-issue, no download, so retrieval still works without a token. Only the **AGENTS.md block** needs a
  download; if it can't be fetched, report it as not-loaded and ask the user to supply the local file —
  do not fabricate it.
- **`discovery-handover-package` Step 1 / `discovery-component-mapper`:** fall back to the existing
  behaviour — ask the user to supply the prototype file or a working link, and mark every
  prototype-dependent section as unverified rather than proceeding on a file you could not read.

**Download only.** Creating, updating, or deleting attachments is the upload path's job, not this one.
