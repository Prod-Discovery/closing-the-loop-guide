# Sign-off sub-issues — templates and tracker operations

The handover crosses a **human approval gate**: PM and Dev review the package before any engineering skill runs. The *live* surface for that review is **two tracker sub-issues** under the source ticket — one for the PM, one for the lead Dev — not a file someone has to open, edit, and re-upload.

> **Done = sign-off.** Each sub-issue is assigned to the reviewer, carries their checklist, and *blocks* the parent feature ticket. Moving a sub-issue to a **Done-type state is the sign-off.** The gate is satisfied only when **both** are Done. Leaving a sub-issue open with a comment is how a reviewer **blocks**.

This file holds the two sub-issue templates and the tracker call sequence to create and read them. Linear and Jira are treated the same — both support assignable sub-issues with a Done-type state. **The sub-issues (and the tracker's own history of who moved them to Done, and when) are the durable record of the approval — nothing is stamped or re-uploaded on pass.**

---

## When this applies

- **Source is a tracker ticket (Linear or Jira):** create the two sub-issues (below). They are the source of truth for the gate.
- **No tracker (local stage files only):** sub-issues are not possible. Fall back to the Brief's `## Sign-off` section as the sign-off surface, signed in-file (see `engineering-brief-template.md`). Everything below is skipped.

---

## Sub-issue 1 — PM sign-off

- **Parent:** the source feature ticket (e.g. `PRO-5`)
- **Title:** `✋ PM sign-off — [Feature Name]`
- **Assignee:** the PM (resolved in Step 2; unassigned + @mention if unknown)
- **Label:** `handover-signoff`
- **Relation:** *blocks* the parent feature ticket
- **Description:**

```markdown
You own the **value** side of this handover: scope, semantics, success metrics.
The discovery skills assembled the Engineering Brief — you confirm it matches what the user actually needs.

**Before signing:** resolve every routed open item in this checklist — including any Open interpretations, missing inputs, assumptions, or brief-review findings routed to PM. Implementation waits on those.

Review the Engineering Brief (attached to the parent, or `handover/[feature]-brief.md`) and tick each box:

- [ ] **Problem statement** reflects the real user need *(Brief §1)*
- [ ] **Open interpretations** reviewed — every disambiguation matches my intent *(Brief §3 — this is where the most expensive bugs hide when missed)*
- [ ] **Acceptance criteria** are testable and complete *(Brief §6)*
- [ ] **Scope boundaries** are correct — nothing important is missing from the exclusion list *(Brief §9)*
- [ ] **Success metrics** are measurable with available data *(Brief §5)*
- [ ] **Story map slices match customer value** — each slice is something a user would recognise as shipped *(Brief §6.3 — epic-shaped features only, i.e. §6.3 present; omit this box for a single-ticket-shaped feature)*
- [ ] **Amigo walkthrough held** — product, design, development, and testing perspectives walked the projected story set together; identified gaps are incorporated into the Brief or routed as checklist items *(§6.3 present + team `backlogTiming: pre-gate` only; omit this box otherwise)*

_**Routed to you:** design / value / scope / customer / risk / legal / metric open items and brief-review findings are appended below as individual boxes, keyed `[lens · Brief §]`._

**To sign off:** tick every box — fixed and routed — then move this issue to **Done**. That is your approval.
**To block:** leave this issue open and comment what needs to change. The handover will be revised and re-circulated.
```

## Sub-issue 2 — Dev sign-off

- **Parent:** the source feature ticket (e.g. `PRO-5`)
- **Title:** `✋ Dev sign-off — [Feature Name]`
- **Assignee:** the lead Dev (resolved in Step 2; unassigned + @mention if unknown)
- **Label:** `handover-signoff`
- **Relation:** *blocks* the parent feature ticket
- **Description:**

```markdown
You own the **feasibility** side of this handover: technical constraints, risks, phasing.
You confirm the brownfield context matches reality and the proposed build is achievable.

**Before signing:** resolve every routed open item in this checklist — including any feasibility, data, engineering, dependency, or brief-review findings routed to Dev. Implementation waits on those.

Review the Engineering Brief (attached to the parent, or `handover/[feature]-brief.md`) and the brownfield reference (if present) and tick each box:

- [ ] **Hard constraints** in the brief are sourced from real code *(Brief §8)*
- [ ] **Surface conventions** in the brownfield reference match how the codebase does these things today *(`[module]-reference.md` § Surface Conventions, if present)*
- [ ] **Risks** called out are acceptable, or have a mitigation *(Brief §10)*
- [ ] **Phasing** is achievable — each phase has a working slice
- [ ] **No missing dependencies** — every external service, library, or access required is already in place
- [ ] **Story map sizing + order are right** — each slice is buildable alone, every cross-slice dependency is explicit and correctly ordered *(Brief §6.3 — epic-shaped features only, i.e. §6.3 present; omit this box for a single-ticket-shaped feature)*

_**Routed to you:** feasibility / data / engineering / dependency open items and brief-review findings are appended below as individual boxes, keyed `[lens · Brief §]`._

**To sign off:** tick every box — fixed and routed — then move this issue to **Done**. That is your approval.
**To block:** leave this issue open and comment what needs to change. The handover will be revised and re-circulated.
```

---

## Tracker operations

### Resolve assignees

Map the PM and lead Dev (name or email, collected in Step 2) to a tracker user id:
- **Linear:** `list_users` → match on name/email → `assigneeId`.
- **Jira:** the user-search operation → `accountId`.

If a person can't be resolved, create the sub-issue **unassigned**, @mention them in a comment, and flag it in the Step 8 summary so a human assigns it. If the person has **no tracker account at all** (an @mention cannot resolve either), write the assignment note into the sub-issue description itself — e.g. *"PM is <name> — no account on this site; assign manually"* — so the gap is visible where the reviewer will look. Never block package creation on a missing assignee.

### Create the sub-issues

- **Linear:** `save_issue` for each — `parentId` = the source issue's **id** (the UUID returned by `get_issue`, not the `PRO-5` key), `title`, `description`, `assigneeId`, `labelIds` (the `handover-signoff` label — create it once via `create_issue_label` if absent), `teamId` (inherit the parent's team). Add a *blocks* relation to the parent.
- **Jira, single-ticket-shaped feature (no Brief §6.3):** create a **Sub-task** issue type under the source key in the same project (`cloudId`), with `assignee` set, in the parent's project. Add a *blocks* link to the parent.
- **Jira, epic-shaped feature (Brief §6.3 present):** the source ticket was already converted to **Epic** by the Step 7 preflight (before this step). Create each sign-off as a **standard child issue (Task type)** with `parent` = the Epic — never a Sub-task: converting a parent with Sub-tasks attached succeeds silently and **orphans them** (verified on the staging instance), and Sub-tasks are not reliable children of Epic-level issues. Same `assignee`, label, and *blocks* link as above.
- **Jira checklist rendering (both shapes, pilot-verified):** create the sign-off description through the **REST v3 API as ADF**, with the checklist as `taskList`/`taskItem` nodes — a v2/wiki-markup description renders `- [ ]` lines as dead text, not tickable boxes. ADF `taskItem` state (`TODO`/`DONE`) is also machine-readable, which is what makes the gate's unticked-box scan reliable on Jira (see KNOWN-ISSUES, "Sign-off checklist scan").

Capture each created sub-issue's `key` (or `identifier`) and `url`. These go into the manifest's `signoffIssues` block.

### Read the gate (both Done?)

- **Linear:** `list_issues({ parentId })`, or `get_issue` per sub-issue, then `get_issue_status` / `list_issue_statuses` — the gate passes when **both** sign-off sub-issues sit in a state whose `type === "completed"`.
- **Jira:** `getJiraIssue` per sign-off issue (Sub-task or Task-type child) — the gate passes when both have `fields.status.statusCategory.key === "done"`. **Do not pass `responseContentFormat: "adf"` hoping to read `taskItem` state — the MCP accepts the parameter and ignores it, always returning markdown** (verified 2026-08-04; see `KNOWN-ISSUES.md`). The checklist scan is therefore a text scan that must match both the `- [ ]` and the escaped `\[ \]` form; `handover-retrieval` Step 3 owns it.

If either is not Done, the gate is **not** satisfied: surface the current state of both sub-issues and stop.

### Append a checklist item, or re-open a sub-issue (post-creation writes)

A sub-issue's **checklist lives in its description** (markdown `- [ ]` lines). To **append a routed item** — an open item in Step 7, or a `handover-brief-review` finding later — edit the description and add a box, keyed `[lens · Brief §]`, leaving the existing ticked/unticked boxes intact:
- **Linear:** `save_issue` with the updated `description`.
- **Jira:** fetch the description as **ADF** (v3 get-issue), append `taskItem` nodes to the existing `taskList` (or add a new `taskList` under a short paragraph naming the source, e.g. "Brief-review findings — routed to you"), and PUT it back. Never string-edit an ADF document as text — it corrupts the structure.

To **re-open a signed-off sub-issue** — the path `handover-brief-review` takes when a requirement-level change lands after a side has signed — move it **out of** the Done-type state, back to an active one. This forces re-ratification; it is the opposite of signing, never a sign-off:
- **Linear:** `save_issue` with a non-completed `stateId` (a Backlog / Todo / In-Progress-type state).
- **Jira:** transition the sign-off issue to an open status (e.g. `To Do` / `In Progress`).

---

## On pass: proceed — nothing is stamped

When both sub-issues are Done, the gate is satisfied and the flow proceeds. **No record is stamped,
written, or re-uploaded**: the sub-issues themselves — their Done state, assignees, completion
timestamps, and comment history, all kept by the tracker — are the durable record of who authorised
the build and when. Anything we copied out of them would only duplicate that state and go stale the
moment a sub-issue is re-opened.
