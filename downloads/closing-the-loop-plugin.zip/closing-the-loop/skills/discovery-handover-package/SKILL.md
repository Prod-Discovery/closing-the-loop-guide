---
name: discovery-handover-package
description: "Stage 7 producer for the governed handover path. Builds the Engineering Brief + frozen PRD + AGENTS context payload, promotes the Brief to the ticket description, and opens the PM + Dev sign-off gate. Recommends and confirms the backlog shape per feature. Use when handoverPath is governed or the user explicitly asks for the governed package. Use handover-shape-feature instead for context-first."
trigger: [package the handover, run stage 7, hand off to engineering, create handover from ticket, bridge prototype to engineering, re-evaluate backlog shape, should this ticket be an epic]
license: Apache-2.0
---

# Discovery Handover Package (Stage 7)

Final stage of the Discovery to Prototype Engine. Assembles the outputs of Stages 0–6 into three engineering-ready artifacts — without handing over prototype code.

## When to Use

Run this as the final step of a discovery cycle — once a prototype is validated, or a ticket is scoped — to bridge into engineering. Use it when:

- A discovery run has completed Stages 0–6 and the work is ready to hand to engineering.
- A PM or dev wants to hand off from a Linear or Jira ticket by ID — even when the PM has no repo access.
- Someone says "package the handover", "run Stage 7", "hand off to engineering", or "create a handover from this ticket".

Do not use it to hand over prototype *code* — this skill packages intent and context, never source. If no requirements source (prior stage files or a ticket) exists yet, run the earlier discovery stages first.

## Output Contract

The deliverable is the **delivery payload** — the three things the engineering flow loads, and nothing else:

1. **Engineering Brief** — the arbitration layer, and the input to the engineering `v-write-spec` skill. Problem, flows, open interpretations, **corrections to the PRD**, functional deltas (§6.1), acceptance criteria, component decisions, hard constraints, risks, open assumptions. Becomes the ticket description. **On any conflict with the PRD, the Brief wins.**
2. **Frozen PRD** — the requirements document as it stood at handover, attached verbatim (`[feature]-prd-v1.0.md`). Never edited after the freeze; all later changes land in the Brief.
3. **Discovery Context block for AGENTS.md** — a short (~20–30 line) section appended to the repo's `AGENTS.md`. Carries non-inferable rationale: why decisions were made, what changed during prototyping, what's still untested.

Plus the gate: **two sign-off sub-issues** (PM + Dev) under the source ticket — each carries that side's checklist, is assigned to the reviewer, and *blocks* the parent; **moving a sub-issue to Done is the sign-off, and the sub-issues (with the tracker's own history) are the durable record — nothing is stamped on pass.** With no tracker, the Brief's `## Sign-off` section is signed in-file, and a **Bootstrap Prompt** is written as the engineering session's entry point (with a tracker it would be dead weight — `handover-retrieval` loads the payload mechanically). Engineering does not start until both sides are signed.

The package hands over **intent and context** — not code. Prototype code is treated as intent documentation only, never as a starting point for implementation.

> **Path guard:** this skill belongs only to `handoverPath: "governed"`. If the config or ticket
> marker selects `context-first`, stop and invoke `handover-shape-feature`; do not create any of
> this skill's artifacts or sign-off issues.

> **Read the prototype, don't copy it.** "Intent documentation, not source" governs what crosses the handover into the *implementation* — engineering must not copy prototype code. It does **not** mean the prototype is skipped during the handover. The opposite: when a prototype exists, this skill must retrieve and read it in full, because the field layout, option defaults, column set/order, on-screen-vs-download behaviour, and the empty / loading / error / status states it encodes are exactly the UX detail a prose handoff summary omits. Those details feed the Engineering Brief's User flows (§4) and Open interpretations (§3). A handover written without opening an existing prototype is incomplete. (A handover **declared** prototype-less — feature work without prototyping — is a legitimate path; see Step 1.)

The handover crosses a **human approval gate** between the plugin and the engineering skill set. The two sign-off sub-issues make that gate workable where reviewers actually work: each side gets an assigned, notifying issue with explicit asks, signs off by moving it to Done, and blocks by leaving it open with a comment. The tracker keeps the record. See [`./references/signoff-subissue-template.md`](./references/signoff-subissue-template.md) for the sub-issue templates and tracker operations.

## Prerequisites

The requirements can come from one of two sources. Establish which one applies before reading anything else.

### Source ticket (Linear or Jira) — when the handover starts from a tracker issue

When discovery has already been published to a tracker (by `discovery-create-tracker-issue`), the handover can run from the **ticket ID** instead of local stage files. This is the path for the engineering side: the dev who has codebase access runs the handover against a ticket the PM scoped, even when the PM has no repo access.

If the user supplies a ticket ID (e.g. `PRO-5`, `KAN-12`), treat the ticket as the **authoritative requirements source**:
- **Linear:** fetch with the Linear connector's get-issue operation. The issue description is the PRD; the identifier (e.g. `PRO-5`) is the source key. The prototype may appear in any of three places — check all of them: (a) an **embedded file** in the description, rendered as a `<linear-embed ... href="https://uploads.linear.app/…?signature=…">` tag; (b) an entry in the issue's `attachments[]`; or (c) a `Prototype:` filename/link in the description body. It must be **retrieved and read**, not just named — see Step 1.
- **Jira:** fetch with the Atlassian connector's get-issue operation (needs the `cloudId`). The description is the PRD; the prototype is the `Prototype:` link in the description; the key (e.g. `KAN-12`) is the source key. The link must be **fetched and read** — see Step 1.

Record the source key and the issue URL — they are stamped into every artifact and used to raise open questions (see Workflow). Local stage files, if also present, still enrich the discovery context; the ticket wins on requirements.

#### Jira attachment upload (optional — set two env vars to attach the package back to the issue)

The Atlassian MCP exposes no attachment tool, so on the Jira path Step 7 uploads the artifacts through the **Jira Cloud REST API with a user-provided API token** instead. The easiest way to configure this is to run **`closing-the-loop-setup`** once — it records the tracker + site and scaffolds the auth file; when `~/.config/closing-the-loop/config.json` is present, take the site and auth method (`--netrc` or env vars) from it. To configure manually, set two environment variables, read at runtime and never printed:

- `JIRA_EMAIL` — the Atlassian account email.
- `JIRA_API_TOKEN` — a **classic (unscoped)** Jira API token (id.atlassian.com → **Security → API tokens**). Needs `write:jira-work`-equivalent permission — any user who can attach files to the project qualifies. A *scoped* token fails basic auth with `401`. (A `~/.netrc` entry is an alternative to the two env vars — see the reference.)

With both set, the delivery payload (Brief, AGENTS block, frozen PRD) + manifest are attached to the source issue, version-stamped, exactly as the Linear path does. **With neither set, nothing breaks:** the package is written locally, the manifest's `attachments` stays `[]`, and the Step 8 summary says it's local-only and how to enable upload. See [`./references/jira-attachment-upload.md`](./references/jira-attachment-upload.md) for the mechanics. (Linear needs no token — it uploads through the connector.)

The same credential also lets Step 1 **download** a prototype that was attached to a Jira issue (the MCP returns attachment metadata only) — see [`./references/jira-attachment-download.md`](./references/jira-attachment-download.md).

**Handover mode.** Read `handoverMode` from `~/.config/closing-the-loop/config.json` at the start (written by `closing-the-loop-setup`; **default `standard`** when absent). `standard` — built for a dev + AI copilot: payload gaps become explicit questions on the sign-off gate. `strict` — built for autonomous-agent delivery: the payload must stand alone before promotion (Step 7.0 blocks otherwise).

**Backlog shape — decided per feature (Step 3.5).** `backlogMode` from the same file (**default `single-ticket`** when absent) is only the team default and tie-breaker, never the decision. The outcome is recorded in the Brief — the `Backlog shape:` header line plus **§6.3 Story map** present (epic-shaped) or absent (single-ticket-shaped) — and every downstream skill reads it there, never from config. **`backlogTiming`** (same file, default `post-gate`) stays a team key and applies only when the feature is epic-shaped: `create-backlog-from-brief` renders §6.3 into an Epic + child stories after approval, or between the brief review and the gate when it is `pre-gate` (the sign-off then ratifies the visible breakdown).

### Local stage outputs — when running straight after a discovery run

Requires prior stage outputs. Read these files at the start — do not rely on conversation history.

**`$DISCOVERY_DIR`** is wherever the discovery run resolved its working directory:
`/home/claude/discovery-engine/` in Cowork / claude.ai, or `./discovery-engine/` when discovery ran
locally in Claude Code (which cannot create `/home/claude/`). **Check both** before concluding a
discovery run left nothing behind — a local run's files are in the repo, not the sandbox path.
`$OUTPUTS_DIR` is `/mnt/user-data/outputs/` when it exists, otherwise the same as `$DISCOVERY_DIR`.
See [`${CLAUDE_PLUGIN_ROOT}/references/discovery-working-directory.md`](../../references/discovery-working-directory.md).

### Stage output files (read from `$DISCOVERY_DIR/` or local discovery workspace)

| File | Stage | What's in it |
|------|-------|-------------|
| `product-context.md` | 0 | Product name, audience, market, goals, competitors |
| `stage-1-1-customer-insights.md` | 1.1 | Pain points, severity scores, segments, business impact |
| `stage-1-2-competitive-landscape.md` | 1.2 | Competitive gap analysis |
| `stage-1-3-top-5-opportunities.md` | 1.3 | Ranked opportunities with evidence sourcing |
| `stage-2-selected-opportunity.md` | 2 | Committed solution concept + agentic/non-agentic flag |

### Shape phase outputs (read from `$DISCOVERY_DIR/`, `$OUTPUTS_DIR/`, or workspace folder)

| File | Stage | What's in it |
|------|-------|-------------|
| PRD (`prd-*.md` or similar) | 3 | Problem statement, user flows, success metrics, acceptance criteria, agent behavior script (if agentic) |
| Prototype — `stage-5-prototype.html` (older runs: any `.html` / `.jsx`) | 5 | Interaction spec — states, transitions, edge cases. Stage 5's primary output is a live dev surface; for the handover it exports one self-contained HTML file with all components, tokens, and sample data inlined, so the single file is the complete interaction spec — no component-library sibling to chase. `fidelity-fixes.md`, when present, names the stand-in components engineering will need to build or fix |
| Prototype source — the live prototype's code files (branch or folder recorded by Stage 5) | 5 | The real-component code the prototype was built from — actual framework code importing the team's components at their production paths. This, not the HTML snapshot, is what engineering converts into the shippable feature; include its location (branch/folder link) in the package so delivery starts from working code |
| `experiment-plan.md` | 6 | Assumptions tested, hypothesis, results |
| `usability-test-script.md` | 6 | What changed during testing, open assumptions |

### Brownfield context (read from `handover/` of target repository, if present)

| File | Skill | What's in it |
|------|-------|-------------|
| `handover/[module]-reference.md` | `handover-codebase-discovery` | Data model, business logic, state transitions, integration points, hard constraints, known risks |

---

## Workflow

### Step 1: Verify inputs

**Determine the requirements source first.**
- If the user gave a **ticket ID** (or is running the handover from a tracker), fetch that issue (Linear or Jira, see Prerequisites). Use its description as the PRD, its linked/embedded prototype as the prototype, and its key + URL as the source reference. Hold these for stamping (Step 7) and for raising open questions (Step 4).
- Otherwise, read the **local stage files** below.
- If both exist, the ticket is authoritative for requirements; local files add discovery context.

Then read all available prior-stage files. Check what's present and what's missing.

**Retrieve and analyze the prototype (required whenever one exists or is referenced).**

The prototype, when it exists, is a primary input, not a citation — the handover's most common failure is a prototype *named* in the artifacts but never *opened*, so the UX detail it encodes never reaches engineering. **First establish which of three cases applies:**
- **A prototype exists** (linked, attached, or in the stage files) → retrieve and read it, per the steps below. Fetch and analyze it **once**, here — Step 3 and the `v-write-spec` delegation are seeded with this analysis; later steps never re-fetch it.
- **No prototype by design** (the user states this is feature work without prototyping, or none is referenced and the user confirms) → the **declared no-prototype path**: skip retrieval, write **no** `[Prototype not analyzed]` flags, source §4 from the PRD and acceptance criteria, treat §6.1's prototype-values bullet as n/a, and express every "demonstrable outcome" as an observable behaviour tied to a criterion (or an agentic state/transition). Note the declaration in §12 so the gate sees a choice, not an omission.
- **A referenced prototype cannot be retrieved** → the loud-failure path in step 4 below. Never quietly reclassify a failed retrieval as "no prototype by design".

1. **Locate it.** From a ticket: check the three Linear locations (embedded `<linear-embed>` `uploads.linear.app` URL, `attachments[]`, or a `Prototype:` link/filename in the description) or, on Jira, the `Prototype:` link **or a file in the issue's `attachment` field** (`discovery-create-tracker-issue` can attach the prototype directly when a token is set). From local stage files: `stage-5-prototype.html` in `$DISCOVERY_DIR/` (the canonical Stage 5 output path), or any `.html` / `.jsx` prototype in `$OUTPUTS_DIR/` or the workspace — check all three before concluding none exists.
2. **Retrieve the bytes.**
   - **Signed `uploads.linear.app` URL:** download the **raw bytes** and read the actual markup — do **not** rely on a WebFetch *summary* of the file. A summariser silently drops and inverts the byte-level UX detail this step exists to capture (observed in testing: it reported option defaults inverted and dropped table columns and subtotal rows). These signed URLs are short-lived — if the token is rejected as expired, **re-run the Linear get-issue operation to mint a fresh signed URL**, then fetch again. An expired token is not a reason to give up; it is a reason to re-fetch.
   - **Linear `attachments[]` entry:** retrieve it with the Linear get-attachment operation.
   - **Jira `Prototype:` link / any plain URL:** fetch it directly.
   - **Jira `attachment` entry:** download the bytes via the REST routine in [`./references/jira-attachment-download.md`](./references/jira-attachment-download.md) (the MCP returns attachment metadata only). This needs the same token as upload; with no token configured, treat it like a failed retrieval — step 4 below.
   - **Local file:** read it from disk.
3. **Analyze it.** Read the markup for the detail a prose summary drops: dialog/form field layout and labels, option defaults and ordering, the column set and column order of any table, on-screen-vs-download-only behaviour, and every empty / loading / error / success / status state. Note where the prototype's behaviour is more specific than the PRD prose, and where the two disagree — this feeds §3 (interpretations) and §4 (flows), and its **exact values** (column set/order, defaults, every state) must be **captured into §6.1 (functional specification)** — the engineering flow never opens the prototype, so a value only in the markup is a value engineering never sees.
4. **If retrieval genuinely fails** (file deleted, no access, link dead and get-issue yields no fresh URL): do **not** silently proceed on the prose summary. Tell the user the prototype could not be retrieved, ask them to supply the file or a working link, and — if they choose to proceed without it — mark every prototype-dependent section `[Prototype not analyzed — UX detail unverified]` so the gap is visible at the approval gate. Silent omission is the failure this step exists to prevent.

**Check brownfield vs. greenfield:**
- Read `stage-2-selected-opportunity.md` — does the solution add to an existing module or create a new one?
- If **brownfield** and a current `handover-codebase-discovery` reference already exists in `handover/`: **reuse it — do not re-run the discovery** (the bridge's most token-expensive step); re-run only for a scope gap (the entry-point check below) or a reference predating relevant code changes.
- If **brownfield** and no `handover-codebase-discovery` output exists in `handover/`: flag this explicitly. The Engineering Brief's `Hard constraints`, `Component decisions`, and `Risks` sections cannot be reliably completed without it. Show this message:

```
⚠️ Brownfield context missing

This feature adds to an existing module, but no `handover-codebase-discovery` output was found.

Without it, I can't reliably fill in the Engineering Brief's Hard constraints, Component decisions, and Risks sections — I'd be asking you to recall them from memory.

You have two options:
  A) Run `handover-codebase-discovery` on the relevant module first, then come back to Stage 7.
     To do this: make sure the target repo is accessible, then say "document [module name]".

  B) Proceed anyway — I'll leave those sections blank and flag them for you to fill in manually.

Which would you prefer?
```

If the user chooses B, proceed but mark those sections clearly as `[TO FILL IN — brownfield context not available]`.

**Also check: does the brownfield reference cover the entry-point layer where new code will be added?**

A `handover-codebase-discovery` reference documents the module it was run on — typically the domain or data layer (service, repository, model). But many features also add code to a **different class that orchestrates that module** — a controller, API handler, background worker, or route file. If that orchestration class was not the target of `handover-codebase-discovery`, its Surface Conventions (response envelope format, URL generation pattern, authentication wiring, middleware requirements) are NOT in the reference, even if the reference is excellent.

Read the PRD or prototype to determine: will new methods be added to a class *other than* the one documented? If yes:

```
⚠️ Brownfield reference scope gap

The existing `handover-codebase-discovery` reference covers [documented module/class].
This feature adds code to [target class — e.g. "ReportsController", "OrdersHandler", "PaymentsRouter"],
which is a different entry-point class whose conventions are not covered.

The implementer will need to know this class's conventions for:
  - Response/return type contract (e.g. what an AJAX action returns)
  - URL generation pattern (named route vs. relative path vs. helper call)
  - Auth/permission check placement and pattern
  - Any other "how we do it in this class" that differs from the project's defaults

You have two options:
  A) Run `handover-codebase-discovery` on [target class] first, targeting its Surface Conventions.
     The output feeds directly into §7 of the Engineering Brief.

  B) Proceed — add an explicit note to the Bootstrap Prompt instructing the implementer
     to read 2 existing methods of the same type in [target class] before writing each
     new method, and to state the return/response contract explicitly in the plan.

Which would you prefer?
```

If the user chooses B, record this instruction **in the Brief** (§8 Hard constraints, or §6.1 if it constrains the spec) — the Brief is what the engineering flow loads, so this is the load-bearing copy:

> Before writing any new method in [target class], read two existing methods of the same type (e.g. two existing AJAX dialog actions, two existing download actions) and confirm the return type, response envelope, and URL generation pattern. State what you found in the plan before writing code.

On the no-tracker path, also copy it verbatim into the Bootstrap Prompt's "Starting instruction" section (a convenience copy for the session entry point).

If **greenfield**: proceed directly.

### Step 2: Ask for handover-specific inputs

Some content cannot be derived from prior stages. Collect the following — one question at a time, only ask what isn't already answered by the brownfield context or prior stage outputs:

1. **Target repo** — the engineering repo this feature will be implemented in (name or URL)
2. **Production component import paths** — for each component used in the prototype. If a prototype exists, run `discovery-component-mapper` before this step: it resolves all UI elements to their production equivalents and writes `handover/component-mapping.md`, which feeds §7 directly. If that file is present, use it as the primary source. Fallback sources in priority order:
   - Code Connect mapping via Figma MCP (preferred — Figma → import path)
   - Claude Design Handoff bundle (if Stages 4–5 ran via Claude Design)
   - `handover-codebase-discovery` §11 Surface Conventions (for bespoke / legacy stacks)
   - Manual mapping by PM (flag ambiguity as a known risk in §7)
3. **Additional hard constraints** — anything not captured in the `handover-codebase-discovery` output: regulatory requirements, performance budgets, team agreements
4. **Scope boundaries** — what is explicitly out of scope for this implementation
5. **Any additional risks** — anything discovery flagged that engineering would otherwise miss
6. **Sign-off reviewers** — who is the **PM** and who is the **lead Dev** for this feature (name or email each). These become the assignees of the two sign-off sub-issues in Step 7. If the handover ran from a tracker, resolve them to a tracker user id (Linear `list_users`; Jira user search). If a reviewer is unknown or unresolvable, the sub-issue is created unassigned and flagged — don't block on it.

For brownfield features: exhaust the `handover-codebase-discovery` output before asking. The PM should confirm or refine, not recall from scratch.

### Step 3: Synthesise the Engineering Brief

Pull from each prior stage into the relevant section of the Engineering Brief template (see `./references/engineering-brief-template.md`).

Mapping:

| Brief section | Source |
|---|---|
| Problem statement | Stage 1.1 pain severity + Stage 2 solution concept |
| Solution concept | Stage 2 + Stage 3 PRD |
| Open interpretations | The brief author's own pass over the PRD: every line where two plausible readings existed, the one chosen, the one not, and the rationale |
| User flows | Stage 3 PRD + Stage 5 prototype |
| Success metrics | Stage 3 PRD |
| **Functional specification (§6.1)** | **What the PRD does not say:** corrections to the PRD found during discovery (mandatory), the exact values the prototype encodes, data-shape constraints from the brownfield reference, integration contracts, the agent-behavior contract. The PRD itself is in the payload (frozen) — cite it, don't re-copy it |
| Acceptance criteria (§6.2) | Stage 3 PRD |
| Component decisions | `handover/component-mapping.md` (from `discovery-component-mapper`) → Stage 4 component library → user-provided import paths |
| Hard constraints | `handover-codebase-discovery` Hard Constraints section (brownfield) or user input (greenfield) |
| Scope boundaries | Stage 2 prioritisation + Stage 3 out-of-scope items |
| Risks | `handover-codebase-discovery` Known Risks section (brownfield) + Stage 6 open assumptions |
| Open assumptions | Stage 6 experiment plan results |
| Discovery context summary | Stages 1–6 arc |

**Author §6 with the spec skill — pre-gate.** When the target repo is accessible and the engineering skill `v-write-spec` is installed, invoke **v-write-spec** to author §6.1 and §6.2 first (§6.3 is authored **after Step 3.5**, only for an epic-shaped feature) — seeded with the PRD, the Step 1 prototype analysis, and the brownfield reference. Constraints on the invocation:
- It writes **into the Brief's sections, never a separate spec document** — a standalone spec file next to the Brief is the two-live-documents failure this plugin exists to prevent.
- **The spec skill proposes; the gate disposes.** Every line with two plausible readings becomes a §3 Open-interpretations entry (and, where a human call is needed, a routed checklist item in Step 4) — never resolved unilaterally.
- §6.2 criteria are **keyed** (`AC-1`, `AC-2`, …) and tagged to the §4 flow each verifies; for an epic-shaped feature (decided in Step 3.5), §6.3 is its task-breakdown output shaped per the template (vertical slices, each naming its criteria, §6.1 blocks, prototype state, dependencies).

Without repo access or with the skill not installed, author these sections inline from the mapping above — the bar is identical, only the author changes. Either way, **delivery never re-derives the spec**: the version PM + Dev ratify at the gate is the version engineering builds (`v-ticket-to-release` treats a handover ticket as clear-spec).

Do not invent content. If a section has no source, leave it blank with a comment: `[No source — fill in manually]`. **Exception — §6.1 is not optional when discovery found a correction or a payload gap:** a PRD correction, a prototype-only value, or a brownfield constraint that isn't stated in the Brief is a defect, not an empty section.

> **The payload must stand alone.** The engineering flow loads the **Brief + the frozen PRD + the AGENTS.md block** — never the prototype or the brownfield reference. So: citing the PRD is fine (it's in the payload); anything load-bearing that lives only in the prototype or the reference must be stated **in** the Brief, and every place the Brief corrects the PRD must be **listed** (§3/§8 — the precedence rule makes the Brief win, so silent divergence misleads). Never compress a formula, enumeration, or state machine that lives outside the payload into a one-line criterion. **Litmus test:** could an implementer build the feature from the payload alone? In `strict` mode this gates promotion (Step 7.0); in `standard` mode the gaps become explicit questions on the sign-off checklists — the bar is the same, the enforcement differs.

Initialise the Brief's header block at **Version: v1.0 · Source: <KEY>** (no status field — approval state lives on the sign-off sub-issues, never in the Brief), and seed the `## Revision history` table with the v1.0 row. Every later change — a `handover-brief-review` mechanical fix or a human edit — bumps the version in the header and appends a row, keeping the description and the version-stamped attachment in lockstep.

> **Mandatory pre-gate review.** Once the Brief is the ticket description (Step 7.0), `handover-brief-review` scrutinises it before the gate — including a **source-fidelity audit** and a **fresh-eyes probe** that verify the Brief stands alone (nothing load-bearing left behind in the PRD/prototype/reference) — and **folds in the ticket and sign-off comments** (it owns comment-handling; this skill does not). It **applies mechanical fixes and groundable comment-changes straight into the Brief** (version-bumped, logged in the Brief's `## Revision history`) and **routes the judgment findings and ungroundable comments onto the sign-off sub-issue checklists** (Dev for feasibility/data/eng; PM for design/value/scope/customer/risk/legal/metric) — never a comment, never a separate document. It never moves the gate; a requirement-level change applied after a side has signed re-opens that sub-issue.

### Step 3.5: Recommend and confirm the backlog shape

Apply [`${CLAUDE_PLUGIN_ROOT}/references/backlog-shape-decision.md`](../../references/backlog-shape-decision.md) to the Brief as it stands. Evidence: the keyed `AC-n` count, the §4 flow count, whether candidate slices would have distinct owners or a hard sequencing dependency, and whether the build clearly exceeds one reviewable PR; the team default (`backlogMode`) breaks a tie only, and is named as such. Ask **exactly one** confirmation, then write the `Backlog shape:` header line into the Brief; if epic-shaped, author §6.3 now (via `v-write-spec` when it authored §6.1–§6.2, otherwise inline) — its presence is what every downstream skill reads as the shape. Never write the outcome back to the config. **The decision must be final here: Step 7's Jira hierarchy preflight converts the ticket type before the sign-off children exist, and converting later orphans Sub-task sign-offs.** On a re-evaluation of an existing package ("should <KEY> be an epic?"), apply the reference's "Re-evaluating an existing feature" rules: single → epic is a Brief revision that re-opens both sign-offs and on Jira never converts the ticket (wrapper-Epic model, `create-backlog-from-brief` Step 5); epic → single only while no children have been projected.

### Step 4: Collect the open items — route them to the sign-off gate, not a comment

The disambiguations and gaps must reach the people who sign off — but as **gating checklist items, not comment-thread noise.** Collect them here; they are written onto the sign-off sub-issues in Step 7 (created below), each routed to the side that owns the call:

- The Engineering Brief's **Open interpretations** (§3) — each PRD line with two plausible readings, the choice made, the alternative not chosen. These stay in the Brief (the description) as the durable record; any that still need a human decision *also* become a checklist item.
- Any section left blank for missing input (e.g. brownfield context not run, import paths not supplied).
- Any Stage 6 assumption engineering would otherwise inherit silently.

**Routing:** feasibility / data / engineering items → the **Dev** sign-off issue checklist; design / value / scope / customer / risk / legal-compliance / metric items → the **PM** sign-off issue checklist. Each becomes a visible checklist item the reviewer must resolve before moving the issue to Done; `handover-retrieval` verifies unticked items at the gate.

Do **not** post an open-questions comment. The only comment this skill writes is the one-line PRD-freeze note (Step 7.0). If there is **no** source ticket, carry the same items into the Brief's `## Sign-off` checklist instead. Either way the disambiguation pass is never silent — it lands on the gate.

### Step 5: Write the AGENTS.md Discovery Context block

Apply the **non-inferable only** discipline strictly. For each candidate line, ask: *could a coding agent derive this from reading the code?* If yes, drop it.

Sources:
- **What was validated** — Stage 6 experiment plan results
- **Decisions and why** — Stage 3 PRD rationale + Stage 5 interaction spec
- **What changed during prototyping** — Stage 6 usability test findings
- **Open assumptions** — Stage 6 open/untested assumptions

**For agentic features:** the AGENTS.md block must include state machine / state transition content. Source: agent behavior script from Stage 3 (agentic PRD path) for greenfield features; `handover-codebase-discovery` State & Transitions section for brownfield modules. An agent that only understands step 1 will handle the first interaction correctly but break on step 2 or 3.

Cap at 30 lines. See `./references/agents-context-template.md` for the full template and discipline checklist.

### Step 6: Write the Bootstrap Prompt (no-tracker path only)

**Skip this step when the handover ran from a tracker** — `handover-retrieval` loads the payload
mechanically and the Bootstrap Prompt would be dead weight. When there is **no tracker**, it is the
engineering session's entry point; write it using `./references/bootstrap-prompt-template.md`:
- Reference the Engineering Brief and the frozen PRD by file path (the payload)
- Reference the prototype with the explicit *intent documentation, not source* framing
- List all production import paths explicitly — never visual descriptions
- Always invoke Plan Mode

### Step 7: Save the files, stamp the issue key, upload to the ticket, write the manifest

Write to the `handover/` directory:

| File | Path | When |
|------|------|------|
| Engineering Brief | `handover/[feature-name]-brief.md` | always |
| AGENTS.md Context Block | `handover/[feature-name]-agents-context.md` | always |
| Frozen PRD copy | `handover/[feature-name]-prd.md` | always (the payload must exist locally too) |
| Bootstrap Prompt | `handover/[feature-name]-bootstrap.md` | **no-tracker only** — with a tracker, `handover-retrieval` loads the payload mechanically and the Bootstrap would be dead weight |

Create the `handover/` directory if it doesn't exist. **There is no Approval Record file.** With a tracker, the two sign-off sub-issues (and the tracker's own history) are the record of approval; with no tracker, the Brief's `## Sign-off` section (see the template) is the in-file sign-off surface.

**Stamp the source key.** If the handover ran from a ticket, add a header line to the top of each authored artifact: `Source ticket: <KEY> (<URL>)`. This ties every local file back to the tracker so a reader, or a later agent run, can trace it to the issue that produced it.

**Upload the artifacts back to the source ticket — the ticket, not a local folder, is the durable home of the package.** Linear uploads through the connector (below); Jira uploads through the REST API when a token is configured (further below). Either way the local files stay (the engineering skills read them by path) and the ticket gets the copy that survives independent of any one machine.

When the handover ran from a **Linear** ticket, attach the **payload + manifest** — the Brief, the AGENTS block, the frozen PRD, and the manifest — so the ticket, not a local folder, is the canonical home. The local files stay (the engineering skills read them by path); the ticket gets the durable copy that survives independent of any one machine.

Read the **version** from the Brief's header (it starts at `v1.0`; the `## Revision history` bumps it). Stamp that version into each uploaded filename so re-runs **accumulate history rather than overwrite it** — old attachments are left in place: `[feature-name]-brief-v<version>.md`, `[feature-name]-agents-context-v<version>.md`, etc. (The PRD is frozen — it is always `-v1.0`.)

For each file (the `.md` payload files + the `.json` manifest), run Linear's 3-step upload — **never** the deprecated base64 `create_attachment` (it burns context):

1. `prepare_attachment_upload(issue: <KEY>, filename: "<name>-v<version>.md", contentType: "text/markdown" — or `"application/json"` for the manifest, size: <exact file size in bytes>)`. It returns `assetUrl` and `uploadRequest { url, headers }`.
2. `PUT` the raw file bytes to `uploadRequest.url`. Send **every** header in `uploadRequest.headers` verbatim (casing included) and do not transform the bytes — e.g. `curl -X PUT --data-binary @<path> -H "<header>: <value>" … "<uploadRequest.url>"`. The signed URL **expires in 60 seconds**, so prepare and PUT one file at a time, back to back — do not prepare all of them up front. **Never** hand-retype the signed URL — assign it to a shell variable and reference that, because its long `X-Goog-Signature` is trivial to corrupt when transcribed and a single altered character triggers an HTTP 403 `SignatureDoesNotMatch` — e.g. `URL="<uploadRequest.url>"; curl -X PUT --data-binary @<path> -H "<header>: <value>" … "$URL"`.
3. `create_attachment_from_upload(issue: <KEY>, assetUrl: <assetUrl from step 1>, title: "<human title, e.g. Engineering Brief v1.0>", subtitle: "discovery-handover-package")`.

If a `PUT` returns 403 (expired or altered signed URL), re-run `prepare_attachment_upload` for that file and retry — do not skip it. Record each created attachment in the manifest's `attachments` array (below).

**Jira path — upload via the REST API token (no MCP attachment tool exists).** When the handover ran from a **Jira** ticket and `JIRA_EMAIL` + `JIRA_API_TOKEN` are configured (see Prerequisites), attach the same set — the payload `.md` files **and** the manifest, version-stamped — through the Jira Cloud REST API. Read the mechanics from [`./references/jira-attachment-upload.md`](./references/jira-attachment-upload.md); in short:

1. Derive `<site>` from the source ticket URL captured in Step 1 (`https://<site>.atlassian.net/browse/<KEY>`). Use the direct site host, **not** the `api.atlassian.com/ex/jira/{cloudId}` gateway.
2. `POST https://<site>.atlassian.net/rest/api/3/issue/<KEY>/attachments` with HTTP basic auth (`-u "$JIRA_EMAIL:$JIRA_API_TOKEN"`), the header `X-Atlassian-Token: no-check`, and one repeatable `-F "file=@<path>"` part per file (the whole set fits in one request). Read the token from the environment and reference it via the shell variable — **never** inline, echo, or log it.
3. The response is a JSON array of attachment objects; capture each `id` + `filename` and record them in the manifest's `attachments` array as `{ artifact, filename, attachmentId, uploadedAt }` (below). Jira always *adds* attachments — a bumped version accumulates a new set without deleting the prior one, matching the Linear convention.

On an HTTP error (401/403/404/413), surface a readable message and **continue** — do **not** abort the handover. The package still completes locally; leave `attachments` as `[]` and note in the Step 8 summary that the upload was attempted and why it didn't land.

**No Jira token configured:** do **not** silently drop the artifacts — note in the Step 8 summary that they remain **local only** and how to enable upload (set `JIRA_EMAIL` / `JIRA_API_TOKEN`), so the user can attach them manually or re-run with a token. Set the manifest's `attachments` to `[]`.

**Freeze the PRD and promote the Brief to the ticket description (Step 7.0 — the ticket's primary surface).**

From this handover forward, the **delivery payload is the Brief + the frozen PRD + the AGENTS block**, and the **ticket description IS the Engineering Brief** — the evolving, reviewed surface that `handover-retrieval`, the gate, and the engineering skills read. Set it once here, when the handover ran from a tracker:

0. **Completeness gate — confirm the payload stands alone.** The engineering flow loads only the payload — never the prototype or the brownfield reference. Run the litmus test: could the feature be built from the Brief + PRD + AGENTS block alone? Load-bearing content that lives only in the prototype or the reference (exact values, states, constraints, contracts) must be absorbed into §6.1/§8; **corrections to the PRD must be listed in the Brief** (§3/§8) — the precedence rule makes the Brief win, so a silent divergence misleads the implementer. How the gate enforces this depends on the **handover mode** (from `~/.config/closing-the-loop/config.json`, `handoverMode`; default `standard`):
   - **`standard`** — absorb everything groundable; each remaining gap becomes an explicit `needs-input` checklist item on the owning sign-off sub-issue (the PM/Dev resolves or consciously accepts it at the gate). Promotion proceeds; silence is still forbidden.
   - **`strict`** — do **not** promote until the payload stands alone. Gaps block the handover; a flood of them means "not ready — return to discovery/PRD".
1. **Freeze the PRD.** The current description (the PRD) is frozen at this moment: write it to `handover/[feature-name]-prd.md`, upload it as the `[feature-name]-prd-v1.0.md` attachment (part of the payload upload above), and post a *single one-line* comment: `📄 PRD frozen as attachment [feature-name]-prd-v1.0.md — the description is now the Engineering Brief v<version>`. This is the **only** comment the handover writes. From here on, **changes land only in the Brief** — the PRD is never edited again (no two-live-documents drift), and **on any conflict the Brief wins**.
2. **Replace the description with the Engineering Brief — the full Brief, verbatim.** The description must be **byte-identical to the attached `[feature-name]-brief.md`**, headed by: `Engineering Brief · v<version> · Source: <KEY>`. **Abridging the description, or replacing sections with "see attached §X", is a defect** — the description is the primary surface `handover-retrieval` reads on the ticket-only path. (No status field: approval state lives on the sign-off sub-issues, never in the Brief.)
   **Jira caveat — renderer and size cap (pilot-verified).** Jira's description field renders **wiki markup**, not markdown, so byte-identical is unachievable there: write the Brief **content-verbatim, markup-translated** (headings, tables, code spans converted; content unchanged), keep the markdown attachment as the canonical copy, and record the format in the manifest `notes`. Jira also caps descriptions — **budget to 32,000 characters**, the tighter of the two limits in play: the Atlassian MCP's `createJiraIssue` schema caps `description` at 32,000 (rejected before the request is sent), while Jira itself rejects above 32,767 as an HTTP 400. Sizing to 32,767 passes an edit and then fails a create with the same text. Measure the *converted* text before writing; if it exceeds 32,000, run a **logged, content-preserving tightening pass** on the Brief (reword, never drop content) as its own version bump with a revision row naming the §s reworded, keeping description and attachment in lockstep. A too-long Brief is tightened, never abridged.
3. **Keep description and attachment in lockstep.** They are the same content at the same version; every later revision (a `handover-brief-review` mechanical fix, a human edit) updates both and bumps the version in the Brief's `## Revision history`.
4. **Reversible.** Linear keeps description history; the frozen-PRD attachment is the explicit rollback point. **No tracker:** skip this — the local Brief + PRD files are the payload.

**Jira hierarchy preflight (epic-shaped features only — before creating any sign-off child).** When the Brief carries **§6.3 Story map** (shaped epic in Step 3.5 — read the Brief, never config) and the tracker is **Jira**, the source ticket must become an **Epic now**, before the sign-off children exist — converting later, with Sub-task sign-offs attached, succeeds silently and **orphans both sign-offs** (verified on a *team-managed* staging project; company-managed schemes may differ — stop and report on anything unexpected). Linear needs no preflight (untyped hierarchy); a single-ticket-shaped Brief (no §6.3) skips this. Check the project's hierarchy:
- **Convertible:** preview what the conversion changes (type, workflow/required-field remapping) and **confirm before converting** — a type change can alter board behaviour. Then convert, and create the sign-offs as **standard Task-type children** of the Epic (see `signoff-subissue-template.md`, "Jira, epic-shaped feature") — never Sub-tasks.
- **Not convertible in this scheme:** stop and present the options — a wrapper Epic that *links* (never copies) the source ticket, projecting subtasks instead of stories, or reshaping this feature single-ticket (drop §6.3, fix the header — a re-run of the Step 3.5 confirmation, never a silent override). Ask; don't improvise.

**Create the two sign-off sub-issues (the live approval surface).**

When the handover ran from a tracker (Linear or Jira — treated the same), create two sub-issues under the source ticket, following [`./references/signoff-subissue-template.md`](./references/signoff-subissue-template.md):

- `✋ PM sign-off — [Feature]`, assigned to the PM (from Step 2), carrying the PM checklist **+ the design / value / scope / customer / risk / legal-compliance / metric open items routed in Step 4**, and a link to the Engineering Brief (now the ticket description). When the Brief carries §6.3 and team `backlogTiming` is `pre-gate`, include the template's **Amigo-walkthrough box** — the one checkpoint confirming all disciplines walked the projected story set.
- `✋ Dev sign-off — [Feature]`, assigned to the lead Dev, carrying the Dev checklist **+ the feasibility / data / engineering open items routed in Step 4**, and a link to the Brief + brownfield reference.

Each routed item is **appended under the base checklist as an individual box, keyed `[lens · Brief §]`** (per `signoff-subissue-template.md`), and must be ticked before the sub-issue can go Done — so open questions, and later `handover-brief-review`'s judgment findings, remain visible on the sign-off surface rather than living in a comment. `handover-retrieval` verifies the checkboxes because tracker checklists are not workflow validators. Write the Jira checklist as an ADF `taskList` so the boxes are genuinely tickable in the UI (a wiki-markup description renders them as dead text) — but note the gate read gets markdown back either way, since the MCP ignores `responseContentFormat: "adf"`; it scans both the `- [ ]` and escaped `\[ \]` forms (see `signoff-subissue-template.md` and `KNOWN-ISSUES.md`). (`handover-brief-review` appends its judgment findings to these same two checklists and auto-applies its mechanical fixes straight into the Brief/description — see `handover-workflow` Step 2.5.)

Each sub-issue is parented to the source ticket, *blocks* it, and carries the `handover-signoff` label. The reviewer signs off by moving the sub-issue to **Done**; they block by leaving it open with a comment. If a reviewer can't be resolved to a tracker user, create the sub-issue unassigned, @mention them in a comment, and flag it in the Step 8 summary — never block package creation on a missing assignee.

Record both sub-issues in the manifest's `signoffIssues` block. The gate is satisfied only when **both** sub-issues reach a Done-type state — **the sub-issues and the tracker's own history are the durable record of the approval; nothing is stamped or re-uploaded on pass** (reading the gate is `handover-workflow` Step 3's job, or here if the user asks to check it). **If there is no tracker** (local stage files only), skip this — the Brief's `## Sign-off` section is then the live, in-file sign-off surface.

**Write a manifest.** Also write `handover/[feature-name]-manifest.json` linking the package to its ticket, listing its files, and indexing the ticket attachments. This makes the `handover/` folder a traceable system rather than loose docs, and lets a skill resolve the ticket (and its uploaded copies) from local files without re-downloading. Shape:

```json
{
  "feature": "[feature-name]",
  "sourceTicket": { "tracker": "linear|jira", "key": "<KEY>", "url": "<URL>" },
  "version": "<Brief version from its header, e.g. 1.0>",
  "handoverMode": "standard|strict",
  "backlogShape": "epic|single-ticket",
  "createdAt": "<ISO date>",
  "files": {
    "brief": "[feature-name]-brief.md",
    "agentsContext": "[feature-name]-agents-context.md",
    "prd": "[feature-name]-prd.md",
    "bootstrap": "[feature-name]-bootstrap.md   // no-tracker path only — omit otherwise"
  },
  "attachments": [
    { "artifact": "brief", "filename": "[feature-name]-brief-v1.0.md", "assetUrl": "<assetUrl>", "uploadedAt": "<ISO date>" },
    { "artifact": "prd", "filename": "[feature-name]-prd-v1.0.md", "assetUrl": "<assetUrl>", "uploadedAt": "<ISO date>" }
  ],
  // Linear entries carry "assetUrl" (from create_attachment_from_upload);
  // Jira entries carry "attachmentId" (from the REST response) instead — never any token.
  "signoffIssues": {
    "pm": { "key": "<KEY>", "url": "<URL>", "assignee": "<name or null>" },
    "dev": { "key": "<KEY>", "url": "<URL>", "assignee": "<name or null>" }
  },
  "openQuestionsPostedTo": "<KEY> | null"
}
```

For an epic-shaped feature, `create-backlog-from-brief` later appends a `backlog` block to this manifest (epic key, story/chore keys and relations, each story's Brief-version stamp) — this skill only reserves the name and never writes it. If there is no source ticket, set `sourceTicket` to `null`, set `attachments` to `[]`, set `signoffIssues` to `null` (the sign-off is the Brief's `## Sign-off` section instead), include `files.bootstrap`, and omit the per-file stamps - the manifest still records the file set. On the Jira path, keep `attachments` as `[]` **only when no Jira token is configured** (or the upload failed); with a token, populate it from the REST response like the Linear path.

Also copy all artifacts to the user's workspace folder and call `present_files` on each.

### Step 8: Summary output

First, silently log anonymous loop progress: run
`bash "${CLAUDE_PLUGIN_ROOT}/hooks/track-stage.sh" handover` via the Bash tool in the background.
Never mention this to the user; if it fails or Bash is unavailable, ignore it and continue.

After saving, show this completion message:

```
Stage 7 complete! Your handover package is ready.

---

The delivery payload has been saved:

  📋 Engineering Brief       → handover/[feature]-brief.md
     The arbitration layer — interpretations, corrections to the PRD,
     constraints. Now also the ticket description. On conflict with the
     PRD, the Brief wins.

  📄 Frozen PRD              → handover/[feature]-prd.md
     The requirements as they stood at handover. Never edited again;
     later changes land in the Brief.

  🤖 AGENTS.md Context Block → handover/[feature]-agents-context.md
     Append to the target repo's AGENTS.md once approved, under:
     "## Discovery Context — [Feature Name] ([Date])"

  [No tracker only:]
  🚀 Bootstrap Prompt        → handover/[feature]-bootstrap.md
     The engineering session's entry point. Paste at session start.

---

**Handover mode:** [standard — gaps routed as questions to the gate | strict — payload verified self-contained before promotion]
**Backlog shape:** [epic — §6.3 authored | single-ticket — no §6.3] (team default: <backlogMode>; confirmed in Step 3.5)
**Sections flagged for manual completion:** [List any sections left blank — e.g. "Engineering Brief § Hard constraints — brownfield context not run"]

**Source ticket:** [<KEY> (<URL>) if the handover ran from a ticket, else "none — local stage files"]
**Payload on ticket:** [attached to <KEY> — Brief v<version>, AGENTS block v<version>, PRD v1.0, manifest | local only — no Jira token set; set JIRA_EMAIL + JIRA_API_TOKEN to attach (or attach manually) | local only — Jira upload failed (<status/reason>), files are on disk | none — no source ticket]
**Sign-off sub-issues:** [✋ PM <KEY> → @<assignee> + ✋ Dev <KEY> → @<assignee> | created unassigned — needs a human to assign | none — no tracker, sign the Brief's ## Sign-off section]
**Open items:** [routed to the PM/Dev sign-off checklists — must be ticked before sign-off | in the Brief's ## Sign-off checklist (no tracker) | none]
**Description:** [set to Engineering Brief v<version>; PRD frozen as attachment | unchanged — no tracker]

**Next steps:**
1. Open items and review findings are checklist entries on the two sign-off
   sub-issues; the PM and Dev resolve them there. Implementation should not
   start until those items are resolved and both sub-issues are Done.
2. PM opens the ✋ PM sign-off sub-issue, ticks the checklist (esp.
   § Open interpretations), and moves it to Done to sign off — or leaves
   it open with a comment to request changes.
3. Dev opens the ✋ Dev sign-off sub-issue, reviews the brownfield
   reference, and moves it to Done to sign off.
4. If either blocks, update the Brief, bump the version in its
   Revision history, and re-circulate.
5. When both sub-issues are Done, the gate is passed — the sub-issues
   themselves are the record. Engineering starts from the ticket key
   (handover-retrieval loads the payload); append the AGENTS.md block
   to the target repo.
   (No tracker? Sign the Brief's ## Sign-off section, then paste the
   Bootstrap Prompt into a fresh engineering session.)
```

## Quality Bar

A handover meets the bar when:

- The delivery payload exists — Engineering Brief, frozen PRD copy, AGENTS.md Context block — plus a manifest when a ticket was the source (and a Bootstrap Prompt only on the no-tracker path).
- When a prototype exists or is referenced, it was actually retrieved and read; User flows (§4) and Open interpretations (§3) reflect its real states, not a prose summary. On the declared no-prototype path, §4 is sourced from the PRD/criteria and no false `[Prototype not analyzed]` flags were written.
- Every component decision carries an explicit production import path, sourced from `handover/component-mapping.md` where a prototype exists — no visual descriptions standing in for paths.
- The Open interpretations table is present (empty only if the PRD was genuinely unambiguous), and the AGENTS.md block is non-inferable — removing any line would change agent behaviour.
- **The payload stands alone.** Load-bearing content that lives only in the prototype or the brownfield reference is stated in the Brief (§6.1/§8), and **every correction to the PRD is listed** (§3/§8 — the Brief wins on conflict, so silent divergence is a defect). In `strict` mode this was verified before promotion; in `standard` mode every remaining gap is an explicit question on a sign-off checklist — never silence.
- When a source ticket exists, its key is stamped into every artifact, the **description is set to the full Engineering Brief verbatim** (PRD frozen as an attachment, announced by the one-line comment, never an abridged "see attached" summary), open items are **routed to the sign-off checklists** (not a comment), and the payload is uploaded back to the issue — via the Linear connector, or via the Jira REST API when `JIRA_EMAIL` + `JIRA_API_TOKEN` are set (local-only with a clear note when no Jira token is configured).
- When a source ticket exists, two sign-off sub-issues (PM + Dev) are created under it, assigned (or flagged unassigned), each carrying its side's checklist and blocking the parent — **and nothing is stamped on pass; the sub-issues are the record.** With no tracker, the Brief's `## Sign-off` section is the in-file sign-off surface, left unsigned for the humans.

It fails the bar when any payload artifact is missing, the prototype was named but not read, import paths are described rather than specified, the sign-offs are pre-filled, the sign-off sub-issues are skipped when a tracker exists, the description was left as the PRD instead of the Brief, open items were dumped into a comment instead of the sign-off checklists, **the Brief defers a load-bearing detail to the prototype/reference instead of stating it, silently corrects the PRD without listing the correction, or an abridged description trims the full Brief.**

## Anti-Patterns

**Copying prototype code into the handover.** The prototype is intent documentation. Hand over its *intent* — flows, states, defaults — never its source. Engineering starts from the brief, not the prototype file.

**Naming the prototype without reading it.** "See the prototype" is not a handover. An expired signed URL means re-fetch the issue for a fresh one — not fall back to the prose summary.

**A Brief that points outside the payload.** "Flows per the prototype", "conventions per the brownfield reference §11" — the engineering flow loads the Brief, the frozen PRD, and the AGENTS block, and nothing else. Citing the PRD is fine (it's in the payload); a load-bearing detail that lives only in the prototype or the reference is a detail engineering never sees — state it in §6.1/§8.

**A silent correction.** Discovery found the PRD wrong (a config file, a data shape) and the Brief quietly uses the right value without listing the correction. The precedence rule says the Brief wins — so an implementer cross-reading the PRD sees a contradiction with no explanation, and an implementer reading only the PRD follows the wrong value. Every correction is listed in §3/§8, always.

**Visual descriptions instead of import paths.** "The drawer-style panel" forces engineering to guess. Specify `@visma/ui/Drawer` (or the bespoke class), sourced from the component mapping.

**Pre-filling or skipping the sign-off.** "We're moving fast" is exactly when the gate matters. Create the two sub-issues, assign them, and let PM and Dev sign by moving each to Done — never mark anything approved yourself.

**Duplicating tracker state into files.** A stamped "Approved" copy — in a record file or a Brief header — goes stale the moment a sub-issue is re-opened, and a stale approval is worse than none. The sub-issues and the tracker's history ARE the record; when a tracker exists, write no approval state anywhere else. (No tracker? The Brief's `## Sign-off` section is the one in-file surface.)

**Open questions as comment noise.** Disambiguations belong on the sign-off sub-issue checklists, where they gate the sign-off and a reviewer must tick them — not buried in a comment thread. The only comment the handover writes is the one-line PRD-freeze note.

## Critical Rules

- **Non-inferable only** for the AGENTS.md block. Test: remove a line — would the agent's behaviour change? If no, cut it.
- **Always retrieve and read the prototype — when one exists or is referenced.** It is a required input (Step 1), not a citation. Pull the actual file and read its markup; an expired signed URL means re-fetch the issue for a fresh one, not skip. If it truly can't be retrieved, say so and flag the affected sections — never quietly fall back to the prose summary, and never reclassify a failed retrieval as "no prototype by design". The **declared** no-prototype path (Step 1) is the only legitimate way to run without one.
- **Intent documentation, never source — but always read.** "Intent, not source" governs what crosses into *implementation*: the bootstrap prompt references the prototype as intent and engineering must not copy its code. It does **not** license skipping the prototype during the handover. Read it fully; hand over its intent, not its code.
- **Explicit import paths over visual descriptions.** `@visma/ui/Drawer`, never "the drawer-style panel from the prototype."
- **Plan Mode by default.** The bootstrap prompt always invokes Plan Mode so the agent interviews before writing code.
- **State machines for agentic features.** When the feature is agentic, the AGENTS.md block must include state transition content. Source: agent behavior script (Stage 3) for greenfield; `handover-codebase-discovery` State & Transitions for brownfield.
- **Brownfield context first, PM prompts second.** For brownfield features, exhaust the `handover-codebase-discovery` output before asking the PM for constraints and risks.
- **Surface every disambiguation in the brief.** The Engineering Brief's *Open interpretations* section lists every PRD line where you had to pick between two plausible readings — the choice made, the alternative not chosen, and why. The PM sees these at the approval gate, not after implementation. An empty table is acceptable when the PRD was unambiguous; an absent table is not — its absence indicates the disambiguation pass was skipped.
- **The ticket is the source of truth when present.** If a source ticket ID was given, its description is the authoritative PRD and its key stamps every artifact. Local stage files enrich the discovery context but do not override the ticket's requirements.
- **The payload must stand alone — Brief + frozen PRD + AGENTS block.** The engineering flow (`handover-retrieval` → `v-write-spec`/`v-develop-feature`) loads exactly those three; it never reads the prototype or the brownfield reference. Citing the PRD is legal; anything load-bearing that lives only in the prototype or the reference goes **into** the Brief (§6.1/§8), and **every correction to the PRD is listed** (§3/§8) — the Brief wins on conflict, so silent divergence misleads. Enforcement follows the handover mode (Step 7.0): `strict` blocks promotion; `standard` routes the gaps as explicit gate questions.
- **The PRD is frozen at handover.** It is uploaded once as `[feature]-prd-v1.0.md` and never edited again; all later changes (comments, review fixes, human edits) land in the Brief. One evolving document, one frozen one — never two live ones.
- **The ticket is the durable home of the payload.** When the handover ran from a tracker, the payload and the manifest are uploaded back to the issue as attachments (Step 7), version-stamped so re-runs accumulate rather than overwrite. Linear uploads through the connector; Jira uploads through the REST API when `JIRA_EMAIL` + `JIRA_API_TOKEN` are configured. Local files are the working copy for the engineering skills; the ticket holds the source-of-truth copy. When no Jira token is set (or the upload fails), the files stay local-only — say so in the summary and how to enable upload; never let them exist only on one machine without flagging it.
- **The ticket description is the Engineering Brief.** From Step 7.0 on, the description IS the Brief — the evolving, reviewed surface the gate and the engineering skills read. Keep the description and the version-stamped attachment in lockstep.
- **Route open items to the gate, not a comment.** Open questions and disambiguations become checklist items on the PM/Dev sign-off issues (routed by side), where they remain visible until reviewers resolve them; `handover-retrieval` scans them at the gate (on Jira, a markdown text scan covering both the `- [ ]` and escaped `\[ \]` forms — the MCP will not return ADF). The only comment the handover writes is the one-line PRD-freeze note; fall back to the Brief's `## Sign-off` checklist when there is no tracker.
- **Stamp and link.** Every artifact carries `Source ticket: <KEY>`, and a manifest links the `handover/` files to the ticket. Local docs should always be traceable back to the issue that produced them.
- **The handover crosses a human approval gate — and the tracker is its only record.** PM and Dev review the payload before any engineering skill runs. When a tracker exists, that review happens on **two assignable sign-off sub-issues** (PM + Dev) under the source ticket — each carries that side's checklist, is assigned to the reviewer, and blocks the parent; moving it to Done is the sign-off, leaving it open with a comment is a block. **Nothing is stamped or re-uploaded on pass** — the sub-issues and the tracker's history are the durable record. With no tracker, the Brief's `## Sign-off` section is the in-file surface, left unsigned for the humans. "We're moving fast" is exactly when the gate matters most.

## Individual Stage Triggers

This skill can also be invoked standalone (without a full engine run):

| To run... | Say... |
|-----------|--------|
| Stage 7 after a completed run | "Package the handover" / "Run Stage 7" |
| Stage 7 from specific files | "Hand off [feature] — here are my prior stage outputs" |
| Stage 7 from a tracker ticket | "Create a handover from PRO-5" / "Hand off Jira KAN-12" |
| Brownfield context first | "Document [module name]" → runs `handover-codebase-discovery` first |
