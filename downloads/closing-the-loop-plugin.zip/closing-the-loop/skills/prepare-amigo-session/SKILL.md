---
name: prepare-amigo-session
description: "Prepare a governed-path feature for a pre-approval three-amigos walkthrough: assemble or reuse the handover package, review the Engineering Brief, project its provisional story map, produce an in-chat Product/Dev/Test session pack, and stop before sign-off or delivery. Never use for context-first-handover; that path handles collaboration in ordinary engineering planning."
---

# Prepare Amigo Session

> **Path guard:** this skill belongs only to `handoverPath: "governed"`. If the ticket carries
> `context-first-handover` or setup selects context-first, stop without creating a Brief, sign-off
> issue, or governed projected backlog. Use the live Delivery Context in the team's normal planning
> session, or `handover-project-stories` when the context-first feature is epic-shaped.

Prepare the existing handover artifacts and real tracker stories for a focused Product/Dev/Test
conversation. Own the preparation sequence directly; do not delegate the whole run to
`handover-workflow`. Reuse the skills that own each artifact and mutation.

This skill ends at a **ready-to-run session pack**. Never approve the handover, move sign-off issues
to Done, load the delivery payload, plan implementation, or write code.

## Preconditions

- Require a Linear/Jira tracker connection and one live source ticket. A local PRD is accepted as an
  input, but publish it first through `discovery-create-tracker-issue` after the user confirms the
  tracker destination and prototype/no-prototype choice. A CSV is not a usable Amigo surface.
- Read `backlogTiming` from `~/.config/closing-the-loop/config.json`; this path requires `pre-gate`.
  If it is `post-gate` (the default), say so and offer `closing-the-loop-setup` to change the team
  choice with confirmation; do not silently rewrite config.
- **Shape is per feature, read from the Brief — never from config.** When a package exists, the
  Brief must carry `### 6.3 Story map` (header `Backlog shape: epic`). If it does not, the feature
  was shaped single-ticket at handover: say so and **stop** — there is no story set to walk, and
  setup is never re-run for shape. The revision route (`discovery-handover-package` Step 3.5 on the
  existing Brief) can add §6.3, re-opening both sign-offs; on Jira that reshape uses the wrapper-Epic
  model in `create-backlog-from-brief`, never a ticket conversion. When no package exists,
  `discovery-handover-package` Step 3.5 recommends and confirms the shape; if single-ticket is
  confirmed, stop after packaging.
- Require the PM and lead Dev identities needed by `discovery-handover-package`. If they cannot be
  resolved to tracker users, keep the package skill's unassigned-plus-mention behavior and surface it
  as an unresolved item.

## Workflow

### Step 1: Resolve one authoritative source ticket

For a ticket key, fetch the ticket and use it as the requirements source. For a local PRD, invoke
`discovery-create-tracker-issue`; retain the resulting ticket key and URL for every later step. If
neither input contains enough requirements to publish or package, stop and name the missing source.

Check whether the ticket already carries `discovery-handover` and a current manifest/package:

- **No usable package:** invoke `discovery-handover-package` on the source ticket. Let it own Jira's
  Epic hierarchy preflight, Brief/PRD/AGENTS artifacts, description promotion, manifest, sign-off
  issues, and open-item routing.
- **Package exists:** reuse it. Do not recreate the package or sign-off issues. Resolve its current
  Brief version, manifest, and PM/Dev sign-off keys.

Never create a BDD document, TDD document, meeting document, or second requirements surface. The
frozen PRD expresses business intent; the Engineering Brief expresses the build contract; Brief
§6.2 and §6.3 are the acceptance-scenario and story surfaces.

### Step 2: Review the current Brief (mandatory)

Invoke `handover-brief-review` on the latest Brief version. This is mandatory even when the package
already existed. Let that skill apply groundable/mechanical fixes, fold unreflected parent/sign-off
comments, route judgment calls to the appropriate sign-off checklist, bump the Brief version when
needed, and re-open a signed side for requirement-level change.

Record the reviewed Brief version. Do not continue if the review blocks, if §6.3 is absent (the
feature was shaped single-ticket — see Preconditions), or if review findings leave the Brief unfit
for projection.

### Step 3: Project or reconcile the provisional backlog

Invoke `create-backlog-from-brief` directly and pass all three facts that license its pre-gate path:

1. caller = `prepare-amigo-session`;
2. `handover-brief-review` completed in this run;
3. reviewed Brief version = the current version.

Let the projector own its mechanical coverage checks, dry-run tree, user confirmation, creation,
relations, retry safety, and manifest update. Do not invent or repair a slice in this orchestrator.
If the backlog already exists, reconcile it against the reviewed Brief instead of duplicating it.

Invoke `handover-retrieval` with `mode: gate-status` to report the live PM/Dev states and checklist
visibility. An open gate is expected here: record it and continue preparing the session pack. This
inspection mode must not load the delivery payload or turn the open gate into a caller failure.

### Step 4: Build the Amigo Session Pack in chat

Render the pack in the response only; do not save or attach another document. Base every item on the
live ticket, reviewed Brief, projector report, and sign-off checklists.

Use this structure:

```markdown
# Amigo Session Pack — <KEY>: <feature>

## Ready state
- Brief: v<version>, mandatory review complete
- Backlog: <epic URL>, <N> stories + <M> chores reconciled
- Gate: PM <key/status>; Dev <key/status> (expected to be open)
- Session objective: ratify or change the Brief and projected breakdown; do not approve during prep

## Walkthrough order
1. <chore key/link> — <constraint cleared> — no AC — <dependencies> *(chores first)*
2. <story key/link> — <demonstrable outcome> — <AC keys> — <dependencies>
...

## Acceptance-scenario coverage
| AC | Given/When/Then summary | Story | Flow | Question or gap |
|---|---|---|---|---|

## Product prompts
- Does each scenario express recognizable user value and the intended business rule?
- Are success, failure, empty, boundary, and permission outcomes correct?
- Are scope exclusions, terminology, and success measures explicit?

## Development prompts
- Can each story be built independently from its in-body §6.1 slice?
- Are contracts, data behavior, dependencies, migration work, and ordering explicit?
- Which assumptions or sizing risks require a Brief change before sign-off?

## Testing prompts
- Is every AC observable and testable through its Given/When/Then examples?
- Which negative, boundary, state-transition, recovery, and regression cases are missing?
- What evidence will show the behavior works, including non-UI or no-prototype outcomes?

## Unresolved before sign-off
- <owner> — <source: Brief section, review finding, or sign-off checkbox> — <decision needed>

## Readiness caveats
- <stale version, missing participant/input, blocked dependency, unreadable Jira checklist, or None>

## Agenda
1. Reconfirm goal, scope, and recording convention — 5 min
2. Walk chores first, then stories and ACs in dependency order — <timebox>
3. Resolve Product/Dev/Test questions and assign remaining decisions — <timebox>
4. Recap Brief changes, stale stories, and sign-off next steps — 5 min

## Recording convention
- Treat generated chore and story bodies as read-only projections.
- Put feedback and decisions on the parent ticket or the relevant PM/Dev sign-off issue.
- Let `handover-brief-review` fold accepted changes into the Brief; let the projector reconcile stories.

## Resume after the human session
After comments and checklist decisions are recorded, run:
“Resume the handover workflow for <KEY> after the Amigo session.”
That run folds comments, reconciles changed stories, checks both sign-offs, and still stops if the
gate is not clean.
```

Do not assign `AUTO`, `MANUAL`, or `CODE` classifications. The pilot first validates whether the
conversation and existing keyed criteria are sufficient.

### Step 5: Hard stop

After emitting the pack, stop. State explicitly:

- the session is prepared, not approved;
- participants must hold the walkthrough and record outcomes in the tracker;
- projected stories are read-only and undeliverable while the gate is open;
- no engineering delivery action ran.

Do not wait for the meeting, poll for sign-off, move either sign-off issue, reconcile hypothetical
changes, or continue into `handover-workflow` in the same run.

## Output Contract

### Summary

Name the source ticket, reviewed Brief version, backlog count, and that preparation stopped before
approval.

### Detail

Emit the complete in-chat Amigo Session Pack with linked chores/stories, AC coverage, role prompts,
unresolved items, readiness caveats, agenda, recording convention, and the exact resume instruction.

### Verification

Confirm the Brief is epic-shaped (§6.3 present) and team `backlogTiming` is `pre-gate`, mandatory
review on the current Brief, projector coverage and
dry-run confirmation, live gate inspection, and zero delivery actions.

### Follow-ups

List only decisions or access/assignee gaps that humans must resolve before clean sign-off. Use
`None` when there are none beyond holding the session.

## Critical Rules

- **Prepare, then stop.** Never sign off, load for delivery, plan implementation, or write code.
- **Use existing sources.** PRD + Brief + tracker stories are enough; create no BDD/TDD/session file.
- **Review before projection.** The current Brief must pass `handover-brief-review` in this run.
- **Project, never plan.** `create-backlog-from-brief` renders §6.3; this skill never invents slices.
- **Keep generated items read-only.** Feedback belongs on the parent/sign-off issues and returns
  through the Brief-review/reconcile path.
- **Treat an open gate as expected.** Inspect it with `handover-retrieval`'s `gate-status` mode; do not
  load artifacts or abort session-pack preparation merely because approval has not happened yet.
