---
name: v-prepare-commit
description: Prepare clean, well-scoped commits and pull requests with structured messages, verification evidence, and clear change narratives. Use when staging and committing completed work, when opening a pull request, when writing or improving commit messages, when cleaning up commit history before merge, when scoping what belongs in a commit versus a separate one, or whenever the user says "commit this", "open a PR", or "package these changes for review".
trigger: [commit this, prepare a pr, write commit messages, clean up commits, prepare changes for review]
license: Apache-2.0
---

# Prepare Commit

## Objective

Package code changes into commits and pull requests that are easy to review,
safe to merge, and useful as historical records. A good commit tells a future
reader what changed, why, and how to verify it. A good pull request gives a
reviewer everything needed to assess risk and correctness without follow-up
questions.

## When to Use

- Staging and committing completed work
- Preparing a pull request for review
- Writing or improving commit messages, or cleaning history before merge
- Scoping what belongs in a commit versus what should be separate
- Drafting changelog entries or release notes for behavior changes

Do not use this skill for writing application code, reviewing someone else's
changes, or deploying. This skill packages finished work for version control;
the work itself is done by other skills.

## Workflow

### 1. Scope the Change

A commit is one logical change. Keep together: an implementation change and
its tests, a rename and all its call sites, a configuration change and the
code that depends on it. Separate: an unrelated formatting fix found along
the way, a refactoring that enables a feature (it precedes the feature
commit), a dependency update and the code changes that use it, a bug fix
discovered while implementing something else.

The test: "If this commit were reverted, would everything still make sense?"
If reverting would leave the codebase broken because unrelated changes were
mixed in, the scope is wrong.

**Exclude from the branch entirely — not just from this commit:**

- Process artifacts: discovery trails, handover packages, specs, plans,
  review write-ups, session logs, prototype files, design-system dumps.
  These belong on the ticket or in untracked local directories, not in the
  production repository. Real documentation that ships with the change
  (README, API docs, runbooks) is not a process artifact — commit it.
- `.gitignore` edits whose purpose is to force process artifacts into the
  repo (e.g. un-ignoring a `handover/` directory). Changing the ignore rules
  to smuggle in working files inverts their purpose.

### 2. Run Pre-Commit Verification

Before committing:

- Run the project's test command, linter, formatter, and type checker
- Search the diff for common mistakes: debug statements, commented-out code,
  hardcoded values that should be configuration, secrets or credentials
- Review every file in the staging area — each change intentional and
  related to the stated purpose, no unexpected tool-generated files or
  editor artifacts

Do not commit changes that fail verification. Fix the issues first.

### 3. Write the Commit Message

Subject line: imperative mood, under 72 characters, specific to the change —
"Fix null pointer in user search when query is empty", not "Fix bug". Follow
the project's convention if one exists. Add a body when the subject alone
can't carry the why: the reason for the change, non-obvious decisions or
tradeoffs, side effects, migration requirements, related issues.

### 4. Clean Commit History (When Needed)

Before review, the history should tell a coherent story: squash fixup commits
into the commits they correct, reorder so enabling changes precede the
features they enable, split commits that do unrelated things. Rewrite only
within the bounds of Critical Rule 2.

### 5. Prepare the Pull Request

**Tooling note:** Use the strongest PR-creation integration your environment
supports — GitHub MCP server or `gh` CLI for GitHub repos (`gh pr create
--draft` for draft PRs), Bitbucket / Azure Repos / GitLab equivalents for
those hosts. If no integration is available, produce the title and
description text and ask the user to open the PR. Never fail-stop the flow
on a missing integration.

Give the PR a clear, specific title and a description following the template
in the Output Contract, plus reviewer guidance: which files need careful
review, a suggested review order for large diffs, known limitations upfront.

If the project's tracker auto-links PRs (e.g. Linear: a `Closes <ticket-id>`
line transitions the issue on merge), include the closing line in the PR body.

### 6. Record Release Notes

When a commit changes user-visible behavior, write a changelog entry from the
user's perspective, classify the change (feature, bug fix, breaking change,
deprecation, performance), and include migration instructions for breaking
changes.

## Output Contract

A completed v-prepare-commit pass produces these sections under `## Output Contract`:

### Summary

One sentence stating what was committed (commit count and headline subject) and
whether a PR was opened.

### Detail

The substantive output covers commits and the PR description:

**Commits**

- Imperative subject line, under 72 characters, specific to the change
- Body explains why when the subject isn't self-evident
- Each commit is a single logical change that can be understood in isolation
- No commits contain debug artifacts, secrets, or unrelated changes

**PR description** (when a PR is being opened):

```markdown
## What

[1-2 sentence summary of what this PR does and why]

## How

[Brief description of the approach — key files changed, design decisions]

## Risk

[What could go wrong, what areas to review carefully]

## Testing

[How this was verified — commands run, tests added, manual checks performed]

## Follow-up

[Anything deferred to a future change, or "None"]
```

### Verification

- Test suite passes on the committed changes
- Linter and type checker produce no new warnings
- No secrets, tokens, or credentials in the diff
- Commit messages are specific and follow project conventions

### Follow-ups

- [release-note or changelog entries still to write]
- [follow-up commits intentionally deferred]
- "None" when the commit/PR is fully ready

## Quality Bar

Commits and pull requests meet the quality bar when:

- A reviewer can understand the change from the commit message and PR
  description without reading the code first
- The diff contains no accidental changes, debug output, or secrets
- Verification was performed before committing, not after
- The history reads as an intentional sequence of logical changes, each
  revertable on its own
- The PR description gives the reviewer a roadmap for assessing the change

## Anti-Patterns

**The empty description.** A pull request with no description forces
reviewers to reconstruct the intent from the diff alone. The five minutes
saved by the author costs ten minutes per reviewer.

**The "address feedback" commit.** A commit whose message gives no indication
of what actually changed. Review responses are regular commits — each gets a
specific, descriptive message.

**The process-artifact dump.** A feature branch that arrives with the
discovery docs, handover package, prototype JSX, or a design-system snapshot
committed alongside the code — sometimes via a `.gitignore` edit to let them
in. Reviewers must wade through thousands of lines of pilot exhaust to find
the change, and the artifacts rot in the repo. The ticket is their durable
home; the branch carries the change.

## Critical Rules

1. **Never commit secrets.** No API keys, tokens, passwords, private keys, or
   credentials — not in code, configuration, comments, or test fixtures.
   Check the diff before every commit. If a secret is accidentally committed,
   treat it as compromised immediately — rotate the credential, don't just
   remove it from the repository.

2. **Never rewrite trunk or shared history.** Do not amend, rebase, or
   force-push mainline history or commits others are building on. One
   carve-out: a PR branch under active review may be force-pushed following
   v-address-review's protocol — name what changed and re-request review
   after. Clean your own unpushed commits freely.

3. **Verify before committing.** A commit that breaks the build is a broken
   promise to every other developer on the project.

4. **Write for the future reader.** The commit message is documentation for
   someone who wasn't present when the change was made. Explain why, not just
   what — the diff already shows the what.

5. **No process artifacts on the branch.** Discovery, handover, spec, plan,
   and review documents — and prototypes — never get committed to a
   production branch, and `.gitignore` is never edited to let them in. They
   live on the ticket or stay untracked. Documentation that ships with the
   change (README, API docs) is part of the change and does get committed.
