---
name: prototype-fidelity-report
description: After a prototype is built, tell the user in plain language which pieces are their REAL components and which are stand-ins, why, and what their team must fix to make each reusable — plus a visual-match check against the Figma frame when one was the source. Auto-runs when chained from prototype-from-components, so non-technical users don't have to know to ask. Also on demand — "why aren't these our components?", "what's not real in this prototype?", "component fidelity report", "does the prototype match the design".
trigger: [why aren't these our components, whats not real in this prototype, component fidelity report, why is this component invented, which components are real, prototype fidelity, does the prototype match the design]
license: Apache-2.0
---

# Prototype Fidelity Report

Someone non-technical will look at their prototype and think *"that's not our button"*
— but won't know to ask why. This skill says it for them, automatically, and turns it
into a fix-list their engineers can act on. Its job is honesty + a to-do list.

## When it runs

- **Automatically** — `prototype-from-components` invokes it after every build/refine.
  It should appear *with* the prototype, unprompted.
- **On demand** — when anyone asks why a component isn't theirs, or whether the
  prototype matches the design.

## Workflow

### 1. Find the stand-ins

Read the prototype file(s) just written. Collect every inline flag:

```
/* SUBSTITUTE — not <TheirLib>'s real <ComponentName>: <reason>. Fix: <pattern> */
```

Cross-check against `component-inventory.md` (from the scan) for the reason/verdict if
the inline note is thin. Count real components used vs. stand-ins.

### 2. Write the plain-language message (always show this)

Lead with the win, then the honest note. Keep it human — no jargon:

> ✅ **Your prototype is ready** — open it at [link].
> **9 of 11 components are your real ones.** 2 are stand-ins, so they won't look
> exactly like your product:
> - **DatePicker** — your real one pulls data from the app, so it can't run on its own
>   in a prototype yet.
> - **Chart** — there isn't a reusable Chart component in your codebase, so this is a
>   placeholder built from your buttons and tokens.
> None of this is a mistake in the prototype — it's a signal about which components are
> ready to reuse and which need a small fix. The list of fixes is below.

### 3. Visual-match check (only when a Figma source exists)

If the prototype was built from a Figma frame (the builder passes the reference along),
run a visual comparison:

1. Render the prototype on its live surface and capture a screenshot (browser tools or
   the preview MCP).
2. Fetch the Figma frame's export image (`get_screenshot` on the node).
3. Compare side by side and report differences a designer would care about — layout
   shifts, wrong colours/spacing, missing elements — each tied to its cause when
   possible ("the header is a stand-in, which is why the nav looks different").

Add one line to the message: *"Visual check: the prototype matches the Figma design
except [the differences]"* — or *"…matches the design"* when it does. When the
prototype came from a text brief only, **skip this section silently** — there is
nothing to compare against.

### 4. Write the fix-list (the audit)

For each stand-in, one line a developer can act on, using the five patterns from
`component-readiness-scan` / `component-remediation`:

- **Decouple** — it couples to app state/router/data; take those as props instead.
- **Promote** — it lives only in the app, not as a reusable component; move it into
  the shared library.
- **Extract** — it's trapped inside another component; pull it out and export it.
- **Extend** — it exists but is missing what the screen needs; add that capability.
- **Build** — it doesn't exist yet; build it as a reusable component.

Format as a short checklist, e.g.:

```
To make these reusable (for your engineers):
- [ ] DatePicker — decouple from the app data store; accept `value` / `onChange` props.
- [ ] Chart — build a reusable <Chart> in the component library (or wrap your chart lib).
```

### 5. Keep the tone right

- Plain language first, technical detail second.
- Frame stand-ins as **information, not failure** — "here's what's ready and what
  needs a small fix," never "the prototype is broken."
- If **everything** is real (no stand-ins), say so and celebrate it:
  *"✅ Every component in this prototype is your real one — nothing was substituted."*

## Output

A short, plain-language fidelity note shown with the prototype — including the visual
check when a Figma source exists — plus a developer fix-list. Append the fix-list to a
running `fidelity-fixes.md` so a session produces one consolidated "what to make
AI-readable" list for the team. That list is also useful input to
`discovery-component-mapper` and the Stage 7 handover: it names exactly which
components engineering will need to touch.
