---
name: prototype-fidelity-report
description: After a prototype is built, tell the user in plain language which pieces are their REAL components and which are stand-ins, why, and what their team must fix to make each reusable — plus a visual-match check against the Figma frame when one was the source, and a backend delta sketch telling the team early what the backend must provide (exists / extend / new) for what the prototype fakes. Auto-runs when chained from prototype-from-components, so non-technical users don't have to know to ask. Also on demand — "why aren't these our components?", "what's not real in this prototype?", "component fidelity report", "does the prototype match the design", "what does the backend need for this".
trigger: [why aren't these our components, whats not real in this prototype, component fidelity report, why is this component invented, which components are real, prototype fidelity, does the prototype match the design, what does the backend need, backend delta, how big is the backend change]
license: Apache-2.0
---

# Prototype Fidelity Report

Someone non-technical will look at their prototype and think *"that's not our button"*
— but won't know to ask why. This skill says it for them, automatically, and turns it
into a fix-list their engineers can act on. Its job is honesty + a to-do list.

## When it runs

- **Automatically** — `prototype-from-components` invokes it after every build/refine.
  It should appear *with* the prototype, unprompted.
- **On demand** — when anyone asks why a component isn't theirs, or whether the
  prototype matches the design.

## Workflow

### 1. Find the stand-ins

Read the prototype file(s) just written. Collect every inline flag:

```
/* SUBSTITUTE — not <TheirLib>'s real <ComponentName>: <reason>. Fix: <pattern> */
```

Cross-check against `component-inventory.md` (from the scan) for the reason/verdict if
the inline note is thin. Count real components used vs. stand-ins.

### 2. Write the plain-language message (always show this)

**The counting rule.** Counts are always given from the reuse side — *"X of Y pieces are your real
components; Z are stand-ins built from your own tokens"* — never as a bare tally of what was made
(*"7 new components"* reads as *"the AI invented 7 things we now have to build and maintain"*, which
is the opposite of what a stand-in means). The words **"invented"**, **"created from scratch"**, and
**"new component" as a count** never appear in this message; the term is **stand-in**, and a
stand-in is a finding about the team's component library, not new scope. When the build log or the
export legend used counter vocabulary ("new components: 7", "extensions: 3"), translate it
explicitly: *"where the build notes say 'new component', read 'stand-in'"*. When the log claims
something no flag in the source backs (an "extension" with no extended component), say so and ask
the builder — never invent a mapping to make the numbers agree.

**The lifecycle sentence.** Every report carries this, verbatim or near-verbatim, right after the
counts: *"Prototype code is a reference, not shipped code — at handover everything is rebuilt on
your production codebase. Stand-ins cost nothing extra; they tell you which components your
library is missing."*

Lead with the win, then the honest note. Keep it human — no jargon:

> ✅ **Your prototype is ready** — open it at [link].
> **9 of 11 components are your real ones.** 2 are stand-ins, so they won't look
> exactly like your product:
> - **DatePicker** — your real one pulls data from the app, so it can't run on its own
>   in a prototype yet.
> - **Chart** — there isn't a reusable Chart component in your codebase, so this is a
>   placeholder built from your buttons and tokens.
> None of this is a mistake in the prototype — it's a signal about which components are
> ready to reuse and which need a small fix. The list of fixes is below.
> Prototype code is a reference, not shipped code — at handover everything is rebuilt
> on your production codebase. Stand-ins cost nothing extra; they tell you which
> components your library is missing.

### 3. Visual-match check (only when a Figma source exists)

If the prototype was built from a Figma frame (the builder passes the reference along),
run a visual comparison:

1. Render the prototype on its live surface and capture a screenshot (browser tools or
   the preview MCP).
2. Fetch the Figma frame's export image (`get_screenshot` on the node).
3. Compare side by side and report differences a designer would care about — layout
   shifts, wrong colours/spacing, missing elements — each tied to its cause when
   possible ("the header is a stand-in, which is why the nav looks different").

Add one line to the message: *"Visual check: the prototype matches the Figma design
except [the differences]"* — or *"…matches the design"* when it does. When the
prototype came from a text brief only, **skip this section silently** — there is
nothing to compare against.

### 4. Write the fix-list (the audit)

For each stand-in, one line a developer can act on, using the five patterns from
`component-readiness-scan` / `component-remediation`:

- **Decouple** — it couples to app state/router/data; take those as props instead.
- **Promote** — it lives only in the app, not as a reusable component; move it into
  the shared library.
- **Extract** — it's trapped inside another component; pull it out and export it.
- **Extend** — it exists but is missing what the screen needs; add that capability.
- **Build** — it doesn't exist yet; build it as a reusable component.

Format as a short checklist, e.g.:

```
To make these reusable (for your engineers):
- [ ] DatePicker — decouple from the app data store; accept `value` / `onChange` props.
- [ ] Chart — build a reusable <Chart> in the component library (or wrap your chart lib).
```

### 5. Backend delta sketch (always, after every build/refine)

The stand-in list covers the frontend; this covers the half that decides feasibility. Every mock in
the prototype — faked state, faked data, a faked action — is a backend requirement in disguise, and
the trio's go/no-go deserves to see it **while the prototype can still change**, not at handover.

1. **Enumerate what the prototype fakes.** Read the mock layer (the prototype's state/mock service
   and flagged fake actions): the entities and fields it invents, the operations it pretends
   succeed, the state transitions it simulates. Include needs the template clearly implies but the
   mock layer skips (a picker needs its list of options), marked *implied by the template*.
2. **Classify each against the real backend — cheaply.** Use the backend repositories in the
   working view (see [`${CLAUDE_PLUGIN_ROOT}/references/multi-repo.md`](../../references/multi-repo.md)):
   targeted lookups only — does an endpoint, field, or state like this exist? Never a deep read.
   - **exists** — the backend already provides it; delivery wires it up;
   - **extend** — an existing record, endpoint, or state machine needs a field, value, or case;
   - **new** — nothing provides it: a new record, endpoint, flow, or integration.
   When the backend repos are not in the working view, still list every need and mark the whole
   sketch `unverified — backend not visible from here`, naming the repos the landscape says to
   check. Never guess a classification. What the visible repos **do** prove still gets reported —
   a feature flag that ships off, a hard limit, an existing state — as short bullets under the
   table, each with its `file:line`: partial visibility hides the backend, not these.
3. **Show it as a short table** in the same message, after the component note:

   ```
   Backend delta sketch (what the backend must provide for this prototype):
   | Prototype fakes            | Backend today                       | Delta  |
   |----------------------------|-------------------------------------|--------|
   | comments[] on an invoice   | no comment record in shop-api       | new    |
   | "put on hold" action       | invoice state machine, no Hold case | extend |
   | current user as author     | auth context already exposes it     | exists |
   ```

4. **Label it honestly, every time:** *a feasibility sketch from targeted lookups, not a scope
   commitment — the verified change map comes from the handover (`handover-shape-feature`).* The
   sketch informs the go/no-go; it never replaces shaping, and it must not slow the build loop —
   when a refine changes no mocks, say "backend delta unchanged" and move on.

Append the sketch to `fidelity-fixes.md` next to the fix-list, so the consolidated file carries
both halves of the delta.

### 6. Keep the tone right

- Plain language first, technical detail second.
- Frame stand-ins as **information, not failure** — "here's what's ready and what
  needs a small fix," never "the prototype is broken."
- Never alarm with arithmetic: counts are reuse-first (step 2's counting rule), and the
  lifecycle sentence always explains what a stand-in costs (nothing) and signals (a
  library gap).
- If **everything** is real (no stand-ins), say so and celebrate it:
  *"✅ Every component in this prototype is your real one — nothing was substituted."*

## Output

A short, plain-language fidelity note shown with the prototype — including the visual
check when a Figma source exists and the backend delta sketch — plus a developer
fix-list. Append the fix-list and the sketch to a running `fidelity-fixes.md` so a
session produces one consolidated "what to make AI-readable" list for the team. That
list is also useful input to `discovery-component-mapper` and the Stage 7 handover: it
names exactly which components engineering will need to touch, and the sketch gives
`handover-shape-feature` its first map of where the backend delta lives.

### Sharing the report

This report is written for people who weren't in the session — a PM, a designer, the
engineers who'll build the missing components. When an artifact-publishing tool is
available (`Artifact` in Claude Code), offer — never do it silently — to publish the
report as a private page the user can share with their team: the real-vs-stand-in list,
the fix-list, and the backend delta table, in that order. The page link travels better
than terminal scrollback. Without such a tool, the saved markdown file (presented as a
downloadable card where `present_files` exists) is the share path.

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (`AskUserQuestion` in Claude Code and Cowork), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. Buttons mirror the listed options exactly — never add one that isn't an option.
- **Every path you just offered is a button.** If the message names ways forward in prose ("you could also iterate…", "or start a new run"), they all become buttons — never surface only a subset of them; with more than 4, use the lettered list so no option disappears.
- **Fall back to the list.** Without such a tool, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** Start each pause with one line placing the user in the loop — the phase this skill belongs to and the step within it, for example `Loop · Handover — shaping #6` or `Loop · Delivery — S-2 of 7`. Skip it when the skill runs standalone.
