---
name: v-wiki-layer-marketing
description: Author the marketing-audience layer of a wiki — positioning angle, killer features in customer language, terminology guide, and what is safe to say externally — from an AnalysisBundle. Use when the wiki orchestrator dispatches the marketing layer for a customer-facing repo, when a brief or one-pager opener needs grounding in real surfaces, or when a marketer needs a starting draft they can take to a customer conversation without re-engineering the language.
trigger: [wiki marketing layer, generate marketing copy, customer-language repo summary, positioning angle, marketing audience documentation]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Marketing

## Objective

Produce the marketing-audience layer for a generated wiki: a short,
customer-language read that tells a marketer how to talk about this
repo to a buyer, prospect, or peer. The layer answers questions
marketing actually has — "what do we call this externally?", "what
would a customer say they liked about it?", "what's safe to put on a
slide?" — using only what `v-analyze-repo` captured.

This is the **most novel** of the audience layers. There is no
existing prompt to port; engineering-led teams rarely write this
content, so the failure mode is real. The default impulse — list every
public surface as a "feature" — is wrong. Marketing wants the 3–5
things a customer would mention to a peer when describing this
product, not the 47 endpoints.

This skill is **content-only**. The orchestrator's `format-output`
step renders the structured tree to MDX (or the plain-Markdown
fallback). This skill never emits MDX directly.

## When to Use

- The wiki orchestrator (`v-generate-wiki`) dispatches the marketing
  layer and the bundle's `signals.isInternalOnly === false`
- A marketer needs a customer-language draft they can take into a
  brief, one-pager, or sales-enablement asset without first having an
  engineer translate the README
- A non-wiki caller wants the same shape of structured marketing
  content (e.g. a website-copy generator, a launch-brief drafter)

Do not use this skill when:

- An `AnalysisBundle` is not available — invoke `v-analyze-repo` first
- `signals.isInternalOnly === true` — emit the skip object documented
  below; an internal-only repo has no external marketing surface and
  forcing a layer on it produces fluff
- The user wants engineering depth, architecture detail, or strategic
  framing — those are sibling layers
- The user wants a finished, channel-specific asset (a tweet, a press
  release, a paid-ad headline) — this layer is a draft substrate, not
  finished copy

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` matching the contract
  emitted by `v-analyze-repo`. The bundle is the only ground truth — do
  not re-walk the repo, do not enrich from public-internet sources,
  do not infer category from the repo name alone
- `options` (optional):
  - `audienceHints`: free-form notes from the orchestrator about the
    reader (e.g. "launch brief", "partner one-pager"). Used to nudge
    emphasis; never used to invent features
  - `maxKillerFeatures`: cap on the killer-features list. Default 5;
    do not exceed 7 even when surfaces are abundant

If `bundle` is missing or `bundle.schemaVersion` does not match a
supported range, stop and emit a warning entry — do not fabricate
marketing copy from a partial bundle.

## Skip Rule

**This is a signal-gated layer.** Before any other work, check
`bundle.signals.isInternalOnly`. If `true`, return immediately with:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "marketing",
  "repo": { "name": "<bundle.repo.name>", "path": "<bundle.repo.path>" },
  "skipped": {
    "reason": "internal-only repo; no external marketing surface"
  },
  "warnings": []
}
```

The orchestrator's routing table also enforces this at dispatch time,
but the skill must enforce it defensively — a caller passing an
explicit override could otherwise force this layer onto an internal
CLI and ship invented positioning.

## Workflow

### 1. Read the Bundle, Read the Surfaces

Walk the bundle once and ground the layer in what is actually
externally visible:

- `repo.name`, `frameworks`, `languages.primary` — the basic shape
- `surfaces.customerFacingAPI` — every public API entry, with its
  evidence path. These are the *only* surfaces marketing can
  legitimately reference
- `signals.hasFrontend`, `signals.hasCustomerVisibleAPI` — together
  they say whether this is a UI product, an API product, or both
- `signals.hasRegulatedDataReferences` — if true, "compliance" or
  "regulated data" is a legitimate positioning angle; if false, do
  not invent one
- `signals.isPureInfra` — if true, the audience is developers /
  builders, not end users. Adjust positioning language accordingly

If `surfaces.customerFacingAPI` is empty but the layer is being
asked to run anyway, that is a signal mismatch. Emit
`WARN_NO_EXTERNAL_SURFACE` and produce a thin layer (positioning
statement + customer-language summary only) rather than padding.

### 2. Draft the Positioning Statement

One to three sentences that a marketer could read aloud on a customer
call without flinching. The statement must answer:

- Who is it for (in their words, not "users of the platform")
- What does it let them do (the outcome, not the mechanism)
- Why is that worth their attention (the differentiator, when the
  bundle supports one — otherwise omit, do not invent)

Constraints:

- No tool, framework, or language names. "Built on a modern web
  stack" is acceptable shorthand only when the stack defines the
  category from the customer's perspective (rare)
- No internal codenames, no project numbers, no team names
- No "leverage" / "synergy" / "best-in-class" — corporate-vague is
  worse than admit-the-gap
- Lead with the outcome, not the mechanism. "Lets finance teams close
  the books a week earlier" before "an automated reconciliation
  service"

If the bundle's surfaces do not support a confident positioning
statement, emit two sentences instead of three and add
`WARN_POSITIONING_THIN`. Silence is worse than admission.

### 3. Pick 3–5 Killer Features (Not 47 Endpoints)

A killer feature is something a customer would mention to a peer
when describing this product — not a technical capability, not an
endpoint, not an integration. The litmus test: rephrase each entry
as "the thing I liked is that it lets me…" and check whether a
non-engineer would naturally finish that sentence.

For each killer feature, capture:

- `name`: a customer-language label (3–6 words). Not the codename,
  not the route, not the package name
- `userBenefit`: one sentence in the customer's voice — what
  outcome they get, not what the system does
- `evidence`: the surface entry or signal in the bundle that grounds
  the claim. A killer feature without bundle evidence is a
  fabrication; cut it
- `cautions`: optional one-line note when the feature has a known
  external-messaging risk (e.g. compliance scope, regional
  availability, beta surface). Empty when none

Bound the list. Five entries is the working ceiling; seven is the
hard cap. A long list dilutes the signal — the reader cannot tell
which two features actually matter. Cluster minor variants under
their parent feature.

If the bundle surfaces fewer than three load-bearing externally-visible
capabilities, emit what you have honestly and add
`WARN_FEATURES_THIN`. Do not pad to three by promoting an internal
helper to "feature".

### 4. Build the Terminology Guide

This is the section that earns the layer its keep. Engineering
language leaks into marketing copy by default; the terminology guide
exists to give the reader a one-glance translation table they can
keep open while writing.

For each term that matters, capture:

- `internalTerm`: what the codebase / engineering team calls it —
  taken verbatim from a manifest, route, or surface evidence
- `externalTerm`: the customer-language phrase a marketer should use
  instead. If a good external term does not exist yet, mark it
  `null` and add a `WARN_TERM_NEEDS_NAMING` warning so the marketer
  knows this is a real gap, not an oversight
- `usage`: one sentence on how to phrase it in a sentence. This is
  the difference between "the X feature" and showing the reader
  *how* to phrase it ("describe it as the way teams stay in sync
  without scheduling a meeting")
- `avoid`: optional list of phrasings to avoid — the in-house jargon
  that would tip a customer off that they are reading engineering
  copy

Aim for 4–8 entries. Fewer than four means you have not looked hard
enough at the surfaces; more than eight is documentation, not a
guide.

### 5. Decide What's Safe to Say Externally — and What's Not

Marketing copy that leaks an internal abstraction is a real risk —
roadmap pre-announcement, scope creep, contractual commitments the
product cannot keep. This section makes the boundary explicit.

Capture two parallel lists:

- `safeToSay`: 3–6 short statements grounded in
  `surfaces.customerFacingAPI` evidence, signals, or established
  external messaging the bundle surfaces (a public README excerpt,
  a documented webhook contract). Each entry: `{ statement,
  evidence }`
- `notSafeToSay`: 3–6 internal abstractions, codenames, in-flight
  surfaces, or implementation choices that should *not* leak into
  customer messaging. Each entry: `{ statement, reason }` where
  `reason` cites the bundle field that makes this internal
  (`signals.isInternalOnly` adjacency, `surfaces.internal`
  membership, churn-heavy file with no public surface)

The `notSafeToSay` list is the higher-leverage half. A marketer who
knows what *not* to say avoids the easiest mistakes; the
positioning statement and killer features are starting points, but
the don't-say list is a guardrail.

### 6. Write the Customer-Language Summary

One paragraph (3–5 sentences) that could open a brief or one-pager.
This is the single piece of free-form prose in the layer; it must:

- Read in the customer's voice — they would say this back to you
  unprompted if it landed right
- Use the external terms from §4, not the internal ones
- Stay inside the safe-to-say boundary from §5
- Avoid the corporate-vague vocabulary the positioning statement
  also avoids
- Build on the positioning statement rather than repeating it
- End with one concrete next-step framing — "teams using it for X
  typically start by Y", "the natural first integration is Z" —
  when the bundle supports one. Omit when it does not, do not invent

If the summary cannot be written without crossing into invention,
emit a shorter paragraph and add `WARN_SUMMARY_THIN`. Honest brevity
beats padded prose.

### 7. Assemble the Structured Tree

Emit a single content tree matching the Output Contract. The
orchestrator's `format-output` step renders it. Do not emit MDX,
fenced JSX components, or finished marketing copy formatted for a
specific channel.

## Output Contract

The skill emits exactly one JSON object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "marketing",
  "repo": {
    "name": "<bundle.repo.name>",
    "path": "<bundle.repo.path>"
  },
  "positioning": {
    "statement": "<1-3 sentences in customer language>",
    "evidence": [
      { "field": "<dotted bundle path>", "note": "<why this grounds the statement>" }
    ]
  },
  "killerFeatures": [
    {
      "name": "<3-6 word customer-language label>",
      "userBenefit": "<one sentence in customer voice>",
      "evidence": "<repo-relative path or surface entry>",
      "cautions": "<one-line external-messaging risk or null>"
    }
  ],
  "terminologyGuide": [
    {
      "internalTerm": "<as it appears in the codebase>",
      "externalTerm": "<customer-language phrase or null>",
      "usage": "<one sentence on how to phrase it>",
      "avoid": ["<in-house phrasing to avoid>"]
    }
  ],
  "externalMessagingBoundary": {
    "safeToSay": [
      { "statement": "<short>", "evidence": "<bundle field or path>" }
    ],
    "notSafeToSay": [
      { "statement": "<short>", "reason": "<bundle field that makes this internal>" }
    ]
  },
  "customerLanguageSummary": "<3-5 sentence paragraph in customer voice>",
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle field>"] }
  ]
}
```

When the skip rule fires, the skill emits the abbreviated object
documented in the Skip Rule section and nothing else — no
`positioning`, no `killerFeatures`, no other fields.

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  contract changes
- `audience` is always the literal string `"marketing"`. The
  orchestrator routes by this field
- `positioning.evidence`, `killerFeatures[].evidence`, and every
  `externalMessagingBoundary.*[].evidence` / `.reason` must reference
  a bundle field or a path that exists in the bundle's
  `fileStructure` or one of its surface entries. Never fabricate a
  path
- `terminologyGuide[].externalTerm` is `null` when no good external
  term has been agreed on yet — pair with a
  `WARN_TERM_NEEDS_NAMING` warning so the gap is visible
- `customerLanguageSummary` is plain text. No markdown beyond
  sentences. The renderer adds any structural rendering
- `warnings` mirrors the v-analyze-repo warning shape. Stable codes for
  this layer: `WARN_NO_EXTERNAL_SURFACE`, `WARN_POSITIONING_THIN`,
  `WARN_FEATURES_THIN`, `WARN_TERM_NEEDS_NAMING`,
  `WARN_SUMMARY_THIN`, `WARN_BUNDLE_VERSION_MISMATCH`

## Quality Bar

The output meets the quality bar when:

- A customer marketing manager could lift the positioning statement
  and customer-language summary verbatim into a brief without first
  asking an engineer what any phrase means
- Killer features pass the litmus test: each one rephrases naturally
  as "the thing I liked is that it lets me…" with a non-engineer
  finishing the sentence
- The terminology guide actually helps avoid jargon — the `usage`
  field shows *how* to phrase it, not just that the word exists
- Length tracks the bundle: a thin surfaces inventory produces a
  short layer with thin-evidence warnings; a substantive product
  produces a richer layer

## Anti-Patterns

**The endpoint inventory.** Listing every entry in
`surfaces.customerFacingAPI` as a killer feature. Customers do not
talk about "the GET /v1/widgets endpoint" — they talk about "being
able to pull our widget data into our own dashboards". The litmus
test cuts this; apply it.

**The codename leak.** Letting an internal codename, project
number, or team name into the positioning statement or summary
because the bundle's evidence string contained one. The terminology
guide exists to translate; use it on the layer's own output.

**The roadmap pre-announcement.** Surfacing an in-flight surface
(churn-heavy file, signal-conflicted feature, file present but not
yet in `surfaces.customerFacingAPI`) as a killer feature. The
`notSafeToSay` list exists precisely to keep these out of customer
messaging.

**The invented audience.** Writing "ideal for forward-thinking
fintech leaders" when the bundle says nothing about who uses the
repo. Audience phrasing must be inferable from `signals` and
`surfaces`; otherwise admit the gap.

**The architecture-in-marketing-voice layer.** Translating "the
service exposes a REST API backed by Postgres" into "a modern
cloud-native data platform with industry-standard interfaces" and
calling it marketing. The architecture layer owns the substrate;
this layer owns the customer's voice — a fluffy paraphrase serves
neither audience.

**The exhaustive terminology guide.** Listing every term in the
codebase. The guide is curated — 4–8 entries that a marketer would
realistically encounter when writing a brief — not a glossary.

## Critical Rules

1. **The skip rule is non-negotiable.** When
   `signals.isInternalOnly === true`, emit the skip object and
   nothing else. The orchestrator's routing table is the first line
   of defence; this skill is the second. A forced layer on an
   internal repo is a fabrication.

2. **Customer language, every sentence.** The litmus test for every
   `body`, `statement`, `userBenefit`, and `summary` field: would a
   customer marketing manager use this verbatim? If not, rewrite.

3. **Evidence or cut.** Every killer feature, every safe-to-say
   entry, every not-safe-to-say entry traces to a bundle field or
   surface path. Un-evidenced claims belong in someone else's draft.

4. **Bound the killer-features list.** Three to five is the working
   range, seven is the hard cap. A long list dilutes the signal —
   marketing wants what a customer would mention to a peer, not the
   surface inventory.

5. **The `notSafeToSay` list earns its keep.** This is the
   highest-leverage half of the boundary section. Silence reads as
   restraint to a casual reader and as fabrication to a careful
   one — populate it whenever the bundle surfaces internal
   abstractions or in-flight surfaces.

6. **Read the bundle, not the repo.** The marketing layer consumes
   `AnalysisBundle` and only that. Re-walking the tree breaks the
   read-once contract and risks producing claims that disagree with
   the sibling layers other readers consume.

7. **Output is structured content, never finished copy.** The
   `format-output` step in the orchestrator handles MDX rendering;
   this skill emits a structured tree. Channel-specific copy
   (tweets, headlines, press releases) is a downstream concern, not
   this layer's output.
