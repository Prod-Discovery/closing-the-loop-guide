# Output Template — Stage 1.3 Opportunity Framing (internal merge)

Exact format for the Stage 1.3 output written to `$DISCOVERY_DIR/stage-1-3-top-5-opportunities.md`. Stage 2 parses this file — keep the structure intact.

```markdown
# Top 5 Opportunities

Generated: [date] · Inputs: [stage-1-1 file ✓/✗] [stage-1-2 file ✓/✗]
[If an input was missing: "Note: produced from customer data only — competitive validation missing." or vice versa]

## Summary Table

| Rank | Opportunity | Evidence | Business Impact | Rationale |
|------|------------|----------|-----------------|-----------|
| 1 | [Short name] | Validated | High | [One-liner: why this is #1] |
| 2 | [Short name] | Validated | High | [One-liner] |
| 3 | [Short name] | Customer-driven | Medium | [One-liner] |
| 4 | [Short name] | Customer-driven | Medium | [One-liner] |
| 5 | [Short name] | Market-driven | Medium | [One-liner] |

## Detailed Rationale

### 1. [Opportunity name]
[2–4 sentences. Trace to specific evidence: severity score and segment from 1.1; gap type and signal strength from 1.2. State why it outranks the ones below it.]

**Sources:** 1.1 pattern #[n] (severity [x]) · 1.2 gap: [which gap, signal strength]

### 2. [Opportunity name]
[Same structure — repeat for each of the 5.]

## Honourable Mentions
[Strong signals that didn't make the Top 5, one line each with the reason for exclusion. Write "None" if there are none.]

## Confidence Flags
[Any Top 5 entry resting on single-source evidence, contradictions between 1.1 and 1.2, or stale data. Write "None" if clean.]
```

## Rules

- **Evidence labels** must be exactly `Validated`, `Customer-driven`, or `Market-driven` — Stage 2 relies on them.
- **Composition:** lean toward Validated and Customer-driven; max 1–2 Market-driven, and only with Strong signal.
- **Fewer than 5 strong candidates:** output fewer — never pad. Adjust the table.
- **More than 5:** the extras go to Honourable Mentions as "strong runners-up."
- Rationale must reference the input files, not conversation memory.
