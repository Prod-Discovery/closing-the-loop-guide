---
name: handover-workflow
description: "Governed-path orchestrator for the discovery-to-delivery bridge. Takes a Linear/Jira ticket or local PRD, builds and reviews an Engineering Brief package, holds at the PM + Dev approval gate, then hands off to engineering; for epic-shaped features (Brief carries §6.3) it can project the ratified story map. Use when handoverPath is governed or the user explicitly asks for the governed handover. Use handover-shape-feature for the context-first path."
---

# Handover Workflow (Discovery to Delivery Orchestrator)

One command that drives a scoped feature across the discovery/engineering seam: from a ticket (or PRD) to a validated, approved handover, and then into implementation and a PR. It sequences skills that already exist - it adds ordering, the approval gate, and the hand-off, not new behaviour.

This skill owns only `handoverPath: "governed"`. When the config or ticket marker selects
`context-first`, invoke `handover-shape-feature` instead; never add this skill's Brief/sign-off
machinery to that path.

> [!note] Spans two packages and reaches into engineering's lane
> This orchestrator calls `discovery-handover-package` (this plugin — which itself invokes `v-write-spec` during Brief authoring when available) and then the engineering delivery skills `v-develop-feature` / `v-ticket-to-release` (the Visma engineering skills package, owned by the engineering side). Those engineering skills are a separate dependency. If they are not installed, the workflow stops at the approved handover (and, for an epic-shaped feature, the provisioned backlog) and hands the brief over for a manual engineering start. The engineering portion is for the engineering lead to confirm.

## What this produces

- A complete, approved **delivery payload** (Engineering Brief + frozen PRD + AGENTS.md Context block, plus manifest and two sign-off sub-issues) via `discovery-handover-package`.
- **Epic-shaped features only (the Brief carries §6.3):** an **implementation backlog** — the source ticket as the Epic, child stories + blocking chores projected from the Brief's §6.3 Story map — via `create-backlog-from-brief`. Projected **after the gate by default** (`backlogTiming: post-gate`), or **between the brief review and the gate hold** (`pre-gate`) so the team's refinement session walks real tracker stories that the sign-off then ratifies.
- After the approval gate: an **implementation** produced by the engineering skills from that package, ending in a **pull request** for review (one PR per story when epic-shaped).
- One thread of traceability: the source ticket key stamped through the artifacts and referenced on the PR(s).

## When to run it

Best run in **Claude Code, inside the target repository**, because the engineering half needs codebase access. The discovery half (the handover package) can run anywhere, but the implementation hand-off assumes the repo is present.

## Prerequisites

- A **source ticket ID** (Linear or Jira) or a local PRD - the input to `discovery-handover-package`.
- For the implementation hand-off: the engineering skills (`v-write-spec`, `v-develop-feature`) available, and the target repo accessible.
- `handoverPath` is `governed`, or the user explicitly selected the governed path for this run.

## Amigo session preparation is a separate skill

When the ask is **"prepare <KEY> for an Amigo session"** (or any pre-approval refinement-session
preparation), do not run the full bridge — invoke **`prepare-amigo-session`**. It owns the bounded
sequence (package if missing → mandatory review → pre-gate projection → in-chat session pack) and
hard-stops before the gate. After the session, the team returns here: "Resume the handover workflow
for <KEY>" reconciles comments and gate state and continues from Step 3.

## Workflow

### Step 1: Resolve the input

Take the ticket ID (preferred) or the local PRD path. Pass it straight to `discovery-handover-package` as the requirements source. Do not re-derive requirements here - that is the handover package's job.

### Step 2: Run the handover package

Invoke **discovery-handover-package**. It produces the artifacts, **promotes the Brief to the ticket description**, routes any open questions onto the PM/Dev sign-off sub-issue checklists, stamps the source key into each artifact, and writes the manifest. Let it own that work; this orchestrator does not duplicate it.

### Step 2.5: Pre-gate brief review (mandatory)

Before holding at the gate, invoke **handover-brief-review** — a required step, not an optional one. It pressure-tests the Engineering Brief with a consolidated read-only reviewer (feasibility, design, customer-voice, risk, legal in one pass) plus two mechanical verifiers — a **source-fidelity audit** (did every enumeration/formula from the PRD, prototype, and reference arrive in the Brief?) and a **fresh-eyes probe** (could the coding agent build from the Brief alone?) — **and folds in the comments on the ticket and the sign-off sub-issues**. The full pass runs once per Brief version; a new comment triggers only a targeted fold, never a full re-run. It **applies mechanical fixes and groundable comment-changes into the Brief** (version-bumped, logged in its revision history) and **routes judgment findings and ungroundable comments onto the PM/Dev sign-off sub-issue checklists** — so PM and Dev sign off on a brief whose machine-findable defects are already fixed and whose real decisions sit on their checklists. It is **non-waiving**: it never moves a sub-issue to Done, writes no comment, and produces no separate document; a requirement-level change applied after a side has signed re-opens that sub-issue. _(Draft — that brief-review is mandatory here, and its placement in the bridge, is pending engineering-lead sign-off.)_

### Step 2.7: Project the provisional backlog (Brief carries §6.3 + `backlogTiming: pre-gate` only)

When the Brief carries `### 6.3 Story map` (the feature was shaped epic at `discovery-handover-package` Step 3.5 — read the Brief, never config) **and** the team's `backlogTiming` is `pre-gate` (`~/.config/closing-the-loop/config.json`; default `post-gate`), invoke **create-backlog-from-brief** now — after the mandatory Step 2.5 review, before the gate hold. Pass it the fact that the brief review completed **in this run** on the current Brief version — that sequence is what licenses projecting before sign-off (the skill refuses standalone pre-gate invocations for exactly this reason). It runs its coverage checks and dry-run confirm as always, projects the stories with *blocks* relations from both sign-off issues, and records the manifest `backlog` block.

The stories are **provisional**: visible for the team's walkthrough, undeliverable until the gate passes (`handover-retrieval` blocks every story's delivery through the walk-up). In `post-gate` timing, skip this step — Step 3.5 projects after the gate as before. A Brief without §6.3 was shaped single-ticket — skip this step and Step 3.5.

### Step 3: Hold at the approval gate (hard stop)

This is the human-in-the-loop gate, and it is not optional. Do not proceed to implementation until **both PM and Dev sign-off sub-issues are Done — with no unticked checklist items remaining.** Open questions and disambiguations are routed checklist items *on* those sub-issues (by `discovery-handover-package` Step 4, plus `handover-brief-review`'s judgment findings); the convention is that a reviewer ticks every item before Done, and the gate read verifies it — `handover-retrieval` scans both descriptions for unticked `- [ ]` items and treats Done-with-unticked-items as a gate that is not clean.

**Read the sign-off from the two sub-issues, not from a file.** `discovery-handover-package` created an `✋ PM sign-off` and an `✋ Dev sign-off` sub-issue under the source ticket (their keys are in the manifest's `signoffIssues`). The gate passes only when **both** sit in a Done-type state:
- **Linear:** `get_issue` (or `list_issues({ parentId })`) per sub-issue → state `type === "completed"`.
- **Jira:** `get_issue` per sign-off issue (Sub-task on a single-ticket-shaped feature; Task-type
  Epic child on an epic-shaped one) → `fields.status.statusCategory.key === "done"`.

If either is not Done, surface the current state of both sub-issues (assignee, status, any "changes requested" comment) and stop. **On pass, proceed — nothing is stamped or re-uploaded.** The sub-issues themselves (their Done state, assignees, completion timestamps, comment history — all kept by the tracker) are the durable record of the approval; any copy we wrote would only go stale the moment a sub-issue is re-opened. (See `discovery-handover-package`'s `signoff-subissue-template.md`.)

**No tracker (local PRD, no sub-issues):** fall back to the Brief's `## Sign-off` section — proceed only when both sides are signed in-file.

The detect → locate → gate-read reader is owned by `handover-retrieval`: invoke **handover-retrieval** to perform it rather than re-implementing the mechanic here (the detail above documents what it does). It is the *required* path when this orchestrator is entered on a bare ticket key whose package already exists on the ticket — i.e. Step 2 was skipped because the package was produced on a prior run. Before reading the gate, `handover-retrieval` checks for comments not yet reflected in the Brief and, if any, re-invokes `handover-brief-review` to fold them in or route them — so the gate is always read against a Brief that reflects the latest comments (a post-sign-off requirement change re-opens its sub-issue).

**The team walkthrough happens during this hold (pre-gate timing).** When Step 2.7 projected provisional stories, the team's refinement session — e.g. a three-amigos walkthrough — happens now, in the tracker, over the Epic's stories. It is a human forum, not a skill step. Its outcomes land through the existing machinery: ticked or added checklist items and comments on the sign-off sub-issues, or Brief revisions via the comment fold (`handover-brief-review`). A requirement-level change re-opens any signed side; a change touching a Brief section that a story cites flags that story stale for the Step 3.5 reconcile. Stories themselves are read-only projections — feedback goes on the parent ticket or the sign-off issues, never into story bodies.

Proceed only when sign-off is present, or when the user explicitly asks for a dry run that halts before any code is written. "Move fast" is exactly when this gate matters most.

### Step 3.5: Provision or reconcile the backlog (epic-shaped features only — the Brief carries §6.3)

**Post-gate timing (default):** when the Brief carries §6.3 and team `backlogTiming` is `post-gate`, invoke **create-backlog-from-brief** once the gate has passed. It re-verifies the gate, projects the Brief's ratified §6.3 Story map into the backlog — the **source ticket becomes the Epic**, stories + blocking chores are rendered verbatim — runs its coverage checks, and records the criteria↔story matrix in the manifest. It never invents a slice; a Brief without §6.3 was shaped single-ticket at handover, not an epic awaiting a breakdown.

**Pre-gate timing:** the backlog already exists (Step 2.7); this step is a **reconcile pass**. Compare the Brief's current version against the manifest's `backlog.briefVersion`: identical → confirm the expected slice children exist and report "backlog already current at v<x>"; newer (the gate changed the Brief) → re-run **create-backlog-from-brief**, whose reconcile path refreshes and re-stamps changed stories by slice id. Usually a no-op — `handover-brief-review`'s staleness rule puts a refresh-confirm item on the Dev checklist, so the Dev cannot have signed with stale stories unaddressed.

A Brief without §6.3 was shaped single-ticket — skip this step; the source ticket itself is the unit of delivery.

### Step 4: Hand off to engineering

Once approved, start the engineering chain from the package, never from scratch. **The Brief is already the implementation spec** — its §6 was authored at handover time (by `v-write-spec` where available, per `discovery-handover-package` Step 3) and ratified at the gate. No engineering step re-derives it: `v-ticket-to-release` Phase 1 treats a handover ticket as clear-spec, and re-specifying post-gate would fork what the humans signed.

**Single-ticket-shaped feature (no §6.3):**
- Begin a `v-develop-feature` session seeded with the **delivery payload** — the Engineering Brief, the frozen PRD, and the AGENTS.md Context block — loaded via `handover-retrieval` (which already read them at the approved version during the gate check). Precedence: on any conflict, the Brief wins over the PRD. Run in Plan Mode first, so the plan is reviewed before code is written.
- If the engineering package exposes a single entry skill (for example a v-ticket-to-release orchestrator), invoke that with the source ticket instead and let it own the engineering sequence.

**Epic-shaped feature (Brief carries §6.3):** invoke **handover-deliver-epic** with the Epic key. It owns the ordered one-child-at-a-time walk over the backlog provisioned at Step 2.7 or Step 3.5 — enumerating the children, deriving the order, driving one delivery run per child, and closing the Epic out. Pass only the key: the Brief is already the spec, and each run re-checks the gate for itself, which is what makes a mid-epic Brief change block the *next* story. If the walker is unavailable, deliver the children by hand through the single-ticket route above, one at a time in the order the projector reported.

### Step 5: Review, close out, report

When implementation opens a PR, check it back against the Engineering Brief and the ticket's success criteria - the same source of truth, end to end.

**Epic close-out (epic-shaped features):** `handover-deliver-epic` has already verified the delivered children against the Brief's §6.2 criteria and §5 success metrics and closed the Epic. What remains here is the optional release-preparation pass (e.g. `v-prepare-release`) over the merged story PRs — it runs once, at this level, never per child.

Then report the chain: source ticket key, handover artifacts, backlog keys (when epic-shaped), and the PR link(s).

## Output Contract

### Summary
A one-line status of the run: the source ticket, whether the approval gate passed, and the resulting PR (or the stopping point if it halted at the gate).

### Detail
References (paths and links) to the handover artifacts and manifest from `discovery-handover-package`, and the PR from the engineering chain. This skill produces no document of its own; it points at the artifacts the composed skills produced.

### Verification
Confirm the approval gate was satisfied before any implementation ran, and that the PR traces to the same source ticket key carried through the handover artifacts.

### Follow-ups
Anything the run left open: unanswered ticket questions, a blocked approval, or a PR awaiting review. `"None"` if the chain completed cleanly.

## Quality Bar

- **Never skip the approval gate.** Implementation must not begin until both sign-off sub-issues are Done — their routed checklist items (open questions included) ticked first — (or, with no tracker, the Brief's `## Sign-off` section is signed by both sides). A hands-off run that writes code before sign-off is a defect, not a feature.
- **Project, never invent, the backlog.** For an epic-shaped feature the backlog exists only from the Brief's §6.3 Story map — after the gate by default, or pre-gate (Step 2.7) for tracker-based refinement, in which case the gate still blocks every story's delivery and Step 3.5 reconciles any Brief drift. Delivering that backlog is delegated to `handover-deliver-epic`, which owns the walk and its rules.
- **Orchestrate, do not re-implement.** Each step delegates to the skill that owns it. This skill only sequences them, enforces the gate, and passes context forward.
- **One source of truth, end to end.** The ticket and its key thread through the handover and the PR. Do not fork requirements into a second document at any step.
- **Degrade gracefully.** If the engineering skills are not available, stop at the approved handover and hand the brief over for a manual start rather than failing.

## Triggers

| To run... | Say... |
|-----------|--------|
| The full bridge from a ticket | "Run the handover workflow for PRO-5" / "Take KAN-12 to a PR" |
| Through to the approval gate only | "Run the handover workflow but stop at approval" |
| Prepare a pre-gate Amigo session | "Prepare KAN-12 for an Amigo session" — delegated to `prepare-amigo-session`, which stops before the gate |
| From a local PRD | "Run the handover workflow on this PRD" |
