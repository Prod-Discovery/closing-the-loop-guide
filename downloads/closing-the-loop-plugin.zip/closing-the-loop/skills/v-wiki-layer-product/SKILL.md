---
name: v-wiki-layer-product
description: Generate the product-audience layer of a generated wiki — the user problem this repo solves, the user-visible primitives it exposes, where it sits on a roadmap, audience reach, and known user-facing gaps — from an AnalysisBundle. Use when the wiki orchestrator dispatches the product layer for a non-pure-infra repo, when a PM asks "what does this repo do for our users?", or when a product brief needs grounding in a fresh repo analysis.
trigger: [generate product wiki, write product layer, product audience documentation, what does this repo do for users, user-visible primitives summary]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Product

## Objective

Produce the product-audience layer for a generated wiki: a structured
content tree that answers the question a product manager actually asks
when they meet a repo for the first time — *what does this do for our
users?* The layer names the user problem the repo addresses, the
user-visible primitives the repo exposes, where the repo appears to
sit on a roadmap (stable / growing / sunset), and any user-facing gaps
the bundle surfaces honestly.

The product layer is **signal-gated**. It only emits when the repo has
end users — a UI, a customer-facing API, a documented product
surface. Pure-infra repos (libraries, frameworks, SDKs, internal dev
tools with no end users) skip the layer entirely; generating product
content for them produces fluff at best and fabrication at worst.

This skill is **content-only**. The orchestrator's `format-output`
step renders the structured content; this skill never emits MDX,
markdown, or any framework-specific markup directly.

## When to Use

- The wiki orchestrator (`v-generate-wiki`) dispatches the product
  layer after `v-analyze-repo` has produced an `AnalysisBundle`, and
  `signals.isPureInfra` is `false`
- A product manager or product-engineering lead needs a structured,
  user-language description of what a repo delivers without reading
  code
- A portfolio or roadmap synthesis step needs each repo's
  user-visible shape as input

Do not use this skill when:

- `signals.isPureInfra === true` — the layer must be skipped per the
  orchestrator's routing rules (see Skip Rule below)
- No `AnalysisBundle` is available — invoke `v-analyze-repo` first
- The caller wants engineering, architecture, or executive content —
  those are sibling layer skills with different audiences and
  different boundaries
- The caller wants free-form prose ready for a marketing page —
  that's a different audience (`marketing`) and a different skill

## Setup check

Before proceeding, verify that an `AnalysisBundle` is available — the
sole input. This skill never re-reads the repository. If no bundle
is available, stop and instruct the caller to run `v-analyze-repo`
first.

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` matching `v-analyze-repo`'s
  output contract (`schemaVersion: "1.0"` at time of writing). The
  bundle is the only ground truth — every assertion in the layer
  must trace back to a bundle field
- `options` (optional):
  - `audienceHints`: free-form notes from the orchestrator about the
    reader (e.g. "portfolio review", "roadmap planning"). Used to
    nudge emphasis; never used to invent facts
  - `maxPrimitives`: cap on user-visible primitives surfaced.
    Default 8 — beyond that, the layer becomes a feature dump

If `bundle` is missing or its `schemaVersion` does not match a
supported range, stop and emit a `WARN_BUNDLE_VERSION_MISMATCH`
warning rather than producing partial output.

## Skip Rule

The product layer is signal-gated on `bundle.signals.isPureInfra`:

- If `signals.isPureInfra === true`, emit a minimal output containing
  only the `skipped` block with reason `"pure infra; no user-facing
  primitives"` and stop. Do **not** invent primitives, audiences, or
  roadmap claims for a library, framework, SDK, or internal dev tool

The orchestrator independently applies the same skip rule before
dispatching this skill, so an `isPureInfra: true` invocation
generally indicates a caller override. Honour it: emit the
`skipped` block and exit cleanly. The orchestrator records the
skip in its manifest; the layer's job is to refuse politely.

## Product vs. Sibling Layers

The product layer is the easiest to drift, because every adjacent
layer has overlapping inputs. Hold the boundary:

| Layer | Question answered | Tone |
|---|---|---|
| Product (this skill) | What does it do for our users? | User-language, concrete |
| Executive | Should I invest attention here? | Decision-supporting |
| Marketing | Why should a buyer care? | Persuasive, pitch-shaped |
| Overview | What is this thing? | Welcoming, neutral |

If a sentence drifts toward strategic framing ("represents a
high-leverage investment"), it belongs in the executive layer. If
it drifts toward pitch language ("delight your customers"), it
belongs in marketing. If it drifts toward category-only orientation
("this is a web application"), it belongs in overview. The product
layer answers, in user terms, what the user can *do* because this
repo exists.

## Workflow

### 1. Read the Bundle, Apply the Skip Rule

Walk the bundle once. Confirm `schemaVersion`. Check
`signals.isPureInfra` — if true, emit the skip block and stop; if
false, proceed.

The bundle fields the layer leans on most:

- `repo.name` — the subject of the layer
- `signals.hasFrontend`, `signals.hasCustomerVisibleAPI`,
  `signals.isInternalOnly` — establish whether users are external
  customers, internal staff, or both
- `surfaces.customerFacingAPI`, `surfaces.internal` — concrete
  evidence for user-visible primitives
- `frameworks` — used only to disambiguate the kind of user surface
  (UI framework implies dashboard-shaped primitives; API framework
  implies integration-shaped primitives). Frameworks themselves are
  *not* primitives and never appear in body text
- `activity.*` — the substrate for the roadmap-position read
- `dependencies.byEcosystem` — used only when a dependency is a
  load-bearing user-facing concept (a payment processor implies a
  "payments" primitive that should be named for the user)
- `warnings` — anything propagated from the analyser that affects
  user-facing claims

### 2. Name the User Problem

Open with a one-line product summary: in plain user language, what
problem this repo solves for the people who interact with it. The
shape: *"<repo name> lets <audience> <user-recognisable outcome>."*

Constraints:

- Lead with the user, not the technology
- Use everyday verbs the user would recognise — "track", "submit",
  "approve", "publish", "reconcile" — not engineering verbs
- No tool, framework, or library names
- If signals are too thin for a confident one-liner, write the most
  defensible version and add `WARN_PRODUCT_THIN_EVIDENCE`

If `audience` is genuinely undetermined (no surfaces, sparse
signals), do not invent one — say "audience not determined from
analysis" and warn.

### 3. Inventory User-Visible Primitives

A *primitive* is a concept the user touches — a dashboard, a report,
a workflow, an integration, a notification, an export, a webhook
contract. Internal abstractions (services, repositories, event
buses, internal RPCs) are not primitives, even when they have
distinguished names in the codebase.

Derive primitives from `surfaces` and `frameworks`, not from
imagined product flows:

| Primitive shape | Primary evidence |
|---|---|
| Dashboard / UI screen | `hasFrontend === true` plus a UI framework |
| Public API / integration | Entry in `surfaces.customerFacingAPI` |
| Webhook contract | `surfaces.customerFacingAPI` with `kind: webhook` |
| Internal tool screen | `isInternalOnly === true` with a UI framework |
| Scheduled job / report | Worker/scheduler in `surfaces.internal` plus user-visible output |
| Export / data download | Documented data-export route in `surfaces` |

For each primitive, capture `name` (a user-language label —
`"Customer dashboard"`, never a code identifier), `userValue` (one
sentence in user terms), and `evidence` (a dotted bundle path that
grounds the primitive).

Cap at `maxPrimitives` (default 8). Truncations record
`WARN_PRODUCT_PRIMITIVES_TRUNCATED`. Fewer than 1 primitive when
`isPureInfra` is false is a quality-bar failure — emit
`WARN_PRODUCT_NO_VISIBLE_PRIMITIVES` and surface it honestly.

### 4. Read the Roadmap Position from Activity

The bundle's `activity` section is the only honest source for a
roadmap-position claim. Map activity into one of three positions:

| Position | Heuristic |
|---|---|
| `stable` | Steady commit cadence within `windowDays`, no large feature churn |
| `growing` | Higher-than-baseline commit volume; new authors; churn in feature-shaped directories |
| `sunset` | Near-zero commits; small author count; churn limited to dependency bumps |

If `activity` is empty or `windowDays` is missing, record
`position: "unknown"` plus `WARN_PRODUCT_NO_ACTIVITY_DATA`. The
roadmap claim is a probabilistic read on the bundle, not a stated
company strategy — phrase it that way and let the reader infer.

Output: a `roadmapPosition` block with `{ position, note, evidence }`
where `note` is one sentence in PM-readable terms ("the repo has
shipped roughly N changes from M contributors over the last
<windowDays> days") and `evidence` is the dotted path into `activity`.

### 5. Characterise Audience Reach

Reach answers "who uses this, and how broadly?" — derived from
surfaces and signals, not invented:

- **External customers**: `hasCustomerVisibleAPI` or `hasFrontend`
  is true and `isInternalOnly` is false
- **Internal staff**: `isInternalOnly` is true and a UI or
  internal-API surface exists
- **Both**: surfaces include a public API and an internal admin /
  back-office UI
- **Undetermined**: surfaces are empty but the repo is not pure
  infra (raise `WARN_PRODUCT_REACH_UNCERTAIN`)

Output: an `audienceReach` block with `{ groups, note, evidence }`
where `groups` is drawn from `["external customers", "internal
staff", "partners and integrators", "operators", "undetermined"]`.
Use only role-shaped phrases — never specific personas, never
invented buyer-segments.

### 6. Surface User-Facing Gaps Honestly

A gap is something the bundle reveals that a PM should know about
the *user-facing* side of the repo. Sources:

- Bundle `warnings` that affect user-facing surfaces
  (`WARN_FRAMEWORK_AMBIGUOUS` on a UI framework, signal conflicts
  involving `hasFrontend` or `hasCustomerVisibleAPI`)
- A documented integration in `surfaces.customerFacingAPI` with no
  recent activity in `activity.churnHeavyFiles` — implies a stale
  primitive
- `dependencies.byEcosystem` entries flagged
  `WARN_LICENSE_UNKNOWN` that gate a user-visible primitive (a
  payment SDK, an analytics library) — material for product because
  it constrains user-facing decisions

Do not invent gaps. "Missing a mobile app" is a gap only if the
bundle surfaces evidence; speculation outside the bundle is a
defect.

Each gap captures `{ summary, evidence }`. Cap at 6.

### 7. Mark Callouts Semantically

When a gap or signal rises above prose level — a stale integration,
a signal conflict on `hasFrontend`, a license-unknown dependency in
a payment-shaped primitive — emit it as a `callout` element with a
level (`info`, `note`, `warn`). The renderer turns these into
`<Callout>` components or quoted-fallback blocks per the
format-output contract. Never emit `warn` without bundle-grounded
evidence.

### 8. Stay Inside the Audience Boundary

Product content has a strict boundary the renderer cannot restore:

- No tool, framework, or library names as code identifiers in body
  text. ("Built on a popular dashboard framework" — the architecture
  layer names the framework)
- No code blocks, file paths, or dependency version pins
- No engineering process language (CI, tests, deployment) —
  engineering territory
- No strategic prescription ("the team should sunset this") —
  surface the position, do not make the call
- No invented user research, personas, or buyer journeys

If the layer reads like architecture-with-shorter-sentences, the
boundary has slipped. The product layer answers the user's
question, not the engineer's.

### 9. Assemble the Structured Tree

Emit a single object matching the Output Contract — product
summary, primitives, roadmap position, audience reach, gaps, plus
optional callouts and structured warnings. A thin bundle produces a
thin layer, not a padded one.

## Output Contract

The skill returns exactly one JSON object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "product",
  "repo": { "name": "<bundle.repo.name>", "path": "<bundle.repo.path>" },
  "skipped": null,
  "productSummary": {
    "oneLine": "<<repo name> lets <audience> <user-language outcome>.>",
    "audience": "<role-shaped phrase>",
    "evidence": [{ "field": "<dotted bundle path>", "note": "<grounding>" }]
  },
  "primitives": [
    {
      "name": "<user-language label>",
      "userValue": "<one sentence in user terms>",
      "evidence": [{ "field": "<dotted bundle path>", "note": "<grounding>" }]
    }
  ],
  "roadmapPosition": {
    "position": "stable | growing | sunset | unknown",
    "note": "<one sentence in PM-readable terms>",
    "evidence": [{ "field": "<dotted bundle path>", "note": "<grounding>" }]
  },
  "audienceReach": {
    "groups": ["<role-shaped phrase>"],
    "note": "<one short sentence>",
    "evidence": [{ "field": "<dotted bundle path>", "note": "<grounding>" }]
  },
  "gaps": [
    {
      "summary": "<one sentence describing a user-facing gap>",
      "evidence": [{ "field": "<dotted bundle path>", "note": "<grounding>" }]
    }
  ],
  "callouts": [
    {
      "level": "info | note | warn",
      "title": "<short>",
      "body": "<plain text, no markup>",
      "evidence": [{ "field": "<dotted bundle path>", "note": "<grounding>" }]
    }
  ],
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle field>"] }
  ]
}
```

When the skip rule fires, the output collapses to:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "product",
  "repo": { "name": "<...>", "path": "<...>" },
  "skipped": { "reason": "pure infra; no user-facing primitives" },
  "warnings": []
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump
  on contract changes
- `audience` is always the literal string `"product"`. The
  orchestrator routes by this field
- `skipped` is `null` when the layer emits content; an object with a
  `reason` string when the skip rule fires. The two cases are
  mutually exclusive
- Every `evidence.field` is a dotted path into the bundle
  (`signals.hasFrontend`, `surfaces.customerFacingAPI[0]`,
  `activity.commits`) — never a path into the repository filesystem
- `productSummary.oneLine` follows the `<repo name> lets <audience>
  <outcome>.` shape. The shape is contractual — wiki landing pages
  compose these one-liners across siblings and depend on it
- `primitives[].name` is user-language, never a code identifier
- `roadmapPosition.position` is drawn from the controlled enum
  `stable | growing | sunset | unknown`. Novel values require a
  contract bump, not ad-hoc additions
- `audienceReach.groups` items come from the controlled list in
  step 5; `"undetermined"` pairs with a
  `WARN_PRODUCT_REACH_UNCERTAIN` warning
- `warnings` uses stable codes: `WARN_BUNDLE_INCOMPLETE`,
  `WARN_BUNDLE_VERSION_MISMATCH`, `WARN_PRODUCT_THIN_EVIDENCE`,
  `WARN_PRODUCT_NO_VISIBLE_PRIMITIVES`,
  `WARN_PRODUCT_PRIMITIVES_TRUNCATED`,
  `WARN_PRODUCT_NO_ACTIVITY_DATA`,
  `WARN_PRODUCT_REACH_UNCERTAIN`,
  `WARN_PRODUCT_SIGNAL_CONFLICT_PROPAGATED`

The skill never writes files, never performs network calls, and
never reads from the repository directly. The bundle is the only
input.

## Quality Bar

The output meets the quality bar when:

- A product manager reading the rendered output understands what
  user problem the repo solves, what users touch, and roughly where
  it sits on a roadmap — without consulting any other layer
- Primitives are user-language labels (`"Customer dashboard"`, not
  `"DashboardController"`)
- Roadmap position is grounded in `activity` data, not invented from
  repo name or framework choice
- Length scales with repo importance; neither padded nor starved

## Anti-Patterns

**The fabricated primitive.** Naming a "Reports module" because the
repo has a `reports/` directory, when no surface evidence shows the
reports are user-visible. A primitive without bundle evidence in
`surfaces`, a UI framework, or a documented user-facing route is a
guess; cut it.

**The invented persona.** Writing "ideal for forward-thinking
finance teams" when the bundle shows no audience evidence. Audience
must be inferable from `signals` and `surfaces`; otherwise emit
`WARN_PRODUCT_REACH_UNCERTAIN` and admit the gap.

**The prescriptive roadmap.** Recommending "this repo should be
sunset" or "the team should invest in mobile". Surface the
roadmap-position read; never make the call. The PM is the decider.

**The signal-conflict-laundering layer.** The bundle reports a
`WARN_SIGNAL_CONFLICT` on `hasFrontend` and the layer silently
picks a side. Surface the conflict via a `warn` callout plus a
`WARN_PRODUCT_SIGNAL_CONFLICT_PROPAGATED` entry — the reader must
know the user-facing read is contested.

## Critical Rules

1. **Honour the skip rule.** When `signals.isPureInfra === true`,
   emit only the `skipped` block. No invented primitives, no
   speculative audiences, no roadmap claims.

2. **The bundle is the only ground truth.** No re-reading the repo,
   no inferred user research, no buyer-segment priors. If it is not
   in the bundle, it is not in the layer.

3. **User language, not engineering language.** Primitives,
   audiences, summaries, and gaps speak the user's vocabulary.
   Engineering nouns and verbs belong in architecture and
   engineering layers.

4. **Every assertion needs evidence.** Sections, primitives, gaps,
   and `warn` callouts each carry at least one `evidence.field`
   pointing to the bundle path that grounds them.

5. **Roadmap position is probabilistic, not declarative.** The
   `position` value is a read on `activity` data, not a stated
   strategy. Phrase the `note` so the reader sees the inference.

6. **Output is structured, not finished prose.** The skill returns
   the constrained AST defined in the Output Contract; the
   `format-output` step handles MDX and any markup.

7. **Skipped or thin is acceptable; padded is not.** Brevity is
   correct here when the bundle is thin.
