---
name: v-wiki-layer-support
description: Generate the support / customer-success-audience layer of a repository wiki — common customer-visible failure modes, sequenced diagnostic steps, escalation paths, and a debugging quick-reference — from an AnalysisBundle. Use when the wiki orchestrator dispatches the support layer, when a customer-success team needs structured triage material derived from repo analysis, or when a support-readiness review needs a layer extracted alongside the other audience layers.
trigger: [generate support wiki, support layer, customer-success documentation, triage runbook from repo, support audience layer]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Support

## Objective

Produce the support-audience layer for a generated wiki: a structured
content tree, derived entirely from an `AnalysisBundle`, that lets a
support agent fielding a customer ticket recognise the failure mode,
walk a diagnostic sequence, and decide when to escalate — without
reading code.

The reader is a support agent or customer-success rep, not an engineer.
They know the product from the customer's side. They want to answer
"what is the customer seeing", "what can I try", and "when do I stop
trying and route this to engineering". That is a narrower lens than
engineering's debugging view; resist drifting into it.

This skill is **content-only**. It does not render to the wiki output
format — the orchestrator's `format-output` step handles that. Emit a
structured tree that the orchestrator can render, with step-shaped
diagnostic content marked semantically so it can become a `<Steps>`
block downstream.

## When to Use

- The wiki orchestrator (`v-generate-wiki`) dispatches the support layer
  after `v-analyze-repo` has produced a bundle and the routing signal
  said the layer should run
- A support-readiness review needs the layer regenerated against a
  new bundle without re-running other audience layers
- A non-wiki caller wants the same shape of structured triage
  content (e.g. a runbook generator) — the output is reusable

Do not use this skill when:

- An `AnalysisBundle` is not available — invoke `v-analyze-repo` first
- The reader is an engineer wanting a debugging deep-dive — that is
  the engineering layer's territory
- The reader is an executive wanting strategic framing — that is
  the executive layer's
- The output should be free-form prose; this skill emits structured
  content for the orchestrator to render

## Setup check

Verify that an `AnalysisBundle` is available as input — produced by
the `v-analyze-repo` skill or supplied directly. If no bundle is
available, stop and instruct the caller to run `v-analyze-repo` first.
This skill never re-reads the repository.

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` matching the contract
  emitted by `v-analyze-repo`. The skill reads only the bundle — it must
  not re-walk the repository
- `options` (optional):
  - `depth`: `"terse" | "standard" | "thorough"`. Default
    `"standard"`. Terse compresses each failure mode to one diagnostic
    pass; thorough expands escalation criteria when the bundle
    surfaces multiple distinct surfaces
  - `failureModeLimit`: cap on distinct failure modes emitted.
    Default 6; truncations are recorded under `warnings`

If `bundle` is missing or its `schemaVersion` does not match a
supported range, stop and emit a warning entry — do not fabricate
content.

## Skip Rule

This is a **signal-gated** layer. If
`bundle.signals.hasCustomerVisibleAPI` is `false`, emit only:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "support",
  "repo": { "name": "<bundle.repo.name>", "path": "<bundle.repo.path>" },
  "skipped": { "reason": "no customer-visible API surface" },
  "warnings": []
}
```

The orchestrator records the skip in its manifest. There is no value
in a support layer for a repo customers cannot reach — invented
errors and escalation paths would be the only content available, and
both are defects.

When the bundle carries a `WARN_SIGNAL_CONFLICT` on
`hasCustomerVisibleAPI`, default to running the layer (more
inclusive) and forward the warning into `warnings` — a support
reviewer needs to know the signal was ambiguous.

## Workflow

### 1. Read the Bundle, Decide Whether the Layer Runs

Apply the skip rule first. If the layer skips, emit the skip envelope
and stop — do not draft topics speculatively.

If it runs, walk the bundle once and pull the fields a support
audience cares about:

- `surfaces.customerFacingAPI` — every entry is a place a customer
  can hit. Each one is a candidate failure-mode source
- `surfaces.deploymentArtifacts` — informs where logs and observable
  state live; only what the bundle exposes, never inferred
- `signals.hasRegulatedDataReferences` — when true, escalation
  policy is stricter and known limitations may include
  data-handling caveats
- `signals.hasSecuritySensitiveCode` — auth / credential errors are
  a likely failure mode worth surfacing
- `dependencies.byEcosystem` — only when a load-bearing external
  integration (payment, identity, email) is named explicitly; that
  becomes a known failure surface ("upstream provider degraded")
- `warnings` — schema gaps or signal conflicts the support reader
  should know about (the bundle's read of the system was partial)

### 2. Decide the Failure-Mode Set

Failure modes are derived, not invented. Each one needs at least one
of:

- An explicit error string the bundle exposes (an OpenAPI `4xx` /
  `5xx` schema, a documented webhook failure response, a public
  route that returns a known status text)
- A surface entry whose evidence file the bundle references and
  whose nature implies a recognisable customer experience (a public
  webhook receiver implies "we did not receive your event" tickets)
- A signal the bundle flags that maps to a customer-visible class
  of issue (regulated-data signal → "we cannot show this data in
  this region"; security-sensitive code → "you are signed out
  unexpectedly")

Cap the set at `options.failureModeLimit` (default 6). Truncations go
into `warnings` with `WARN_SUPPORT_FAILURE_MODES_TRUNCATED`. If the
bundle surfaces fewer than two failure modes, emit what you have and
record `WARN_SUPPORT_THIN_EVIDENCE` — do not pad with generic
"something went wrong" entries.

### 3. Capture the Customer-Visible Error

For each failure mode, the first piece of structured content is the
customer-visible error itself. Capture:

- `errorText`: the exact user-facing message text when the bundle
  exposes it (an OpenAPI `description`, a documented error code
  string, a public route's documented response). When the bundle
  does not expose verbatim text, capture the *kind* of error
  ("a 4xx response with no body", "a webhook timeout"); never
  invent a sentence in quotes
- `where`: where the customer encounters it — the customer-facing
  surface name, not an internal path
- `evidence`: a bundle field or repo-relative path that proves the
  error exists. A failure mode without evidence is a guess; cut it

This is the support layer's load-bearing claim. Get it right or
remove the failure mode entirely.

### 4. Author the Diagnostic Steps

Diagnostic steps are sequenced, not a checklist. Mark them
`kind: "steps"` so the orchestrator renders them as a `<Steps>` block
per the locked 4-component palette. Each step records:

- `ordinal`: 1-based step number
- `action`: imperative, in support's language — "ask the customer
  for the request ID shown in the error", "confirm the customer's
  region matches their account region", "check whether the customer
  is hitting a documented rate limit"
- `expectedSignal`: what a successful step looks like — "the
  customer reports the request succeeded on retry", "the request ID
  is present and well-formed". This is what tells support to stop
  and resolve, vs. continue to the next step
- `escalateOn`: what a step's failure means — when does this step
  not yielding a result imply the ticket leaves support's hands

Steps must be doable without code-reading. "Open the handler at
`src/handlers/foo.ts` and check the auth path" is engineering's
view, not support's. The right shape is "confirm the customer signed
in within the last hour" or "ask the customer to retry after
clearing their session". Anything that requires reading source goes
in the escalation path, not the diagnostic steps.

Cap the step count at roughly 5 per failure mode. If a failure mode
genuinely needs more, it probably belongs to engineering already —
record `WARN_SUPPORT_STEPS_OVERFLOWED` and emit the first 5.

### 5. Define the Escalation Path

Every failure mode has an escalation path even if support can
usually resolve it. The escalation entry records:

- `trigger`: the concrete condition under which this becomes
  engineering's problem — "two diagnostic passes did not yield a
  resolution", "the failure correlates with a deployment window",
  "the customer's tenant is in a regulated-data region and cannot
  share the payload"
- `route`: where the ticket goes next. Use roles, not names —
  "L2 engineering on-call", "the team that owns the customer-facing
  API surface", "security on-call" (when
  `hasSecuritySensitiveCode` is true and the failure touches auth).
  Do not name individuals; the bundle does not carry on-call
  rotations and inventing them is a defect
- `evidenceForHandover`: the artefacts support should attach to the
  escalation — "the request ID from step N", "the customer's
  account ID", "the timestamp range". Concrete fields, not
  "all available information"

The bundle's `surfaces` set informs `route`. A failure mode rooted
in `surfaces.customerFacingAPI` typically routes to the team owning
that surface; a failure rooted in `surfaces.deploymentArtifacts`
typically routes to whoever runs the system (the devops layer's
audience, when present). Cross-reference but do not duplicate.

### 6. Compose the Debugging Quick-Reference

Separate from the per-failure-mode content, emit a short
quick-reference section the support reader can scan during a live
ticket. Sections to consider — emit only when the bundle supports
them:

- **Where state lives, at a high level.** When the bundle's
  `surfaces` and `dependencies` collectively name an external
  service (payment, identity, email, primary database), record
  that "customer X's data is held by Y" — without naming an
  internal table or path. Support needs to know which third-party
  to contact, not which row to query
- **What "healthy" looks like.** When a customer-facing surface
  has a documented success response (an OpenAPI 2xx schema, a
  webhook ack contract), record the support-visible signal of a
  healthy interaction — "the customer's dashboard shows the
  event timestamp updating", "the API response includes a
  `requestId`"
- **What support cannot see.** Be explicit about state that is
  not customer-visible and therefore not support-visible — "the
  internal processing queue is not visible from the customer
  dashboard; if a ticket implies it, escalate"

If none of these can be grounded in the bundle, omit the section
entirely. Do not pad with generic advice.

### 7. Surface Known Limitations

Emit this section only when the bundle explicitly signals a
"won't fix" or a "by design" boundary the customer might mistake
for a bug. Sources:

- `signals.hasRegulatedDataReferences` true plus a customer-facing
  surface — record the regional / regulatory limit support should
  state up front
- `WARN_LICENSE_UNKNOWN` on a load-bearing dependency that touches
  the customer surface — typically irrelevant to support, but
  occasionally surfaces as "we cannot ship this feature in
  jurisdiction X" caveats
- An explicit deprecation or sunset note in a manifest description
  the bundle exposes

This section is small or absent. An entry not grounded in the bundle
is a fabrication, not a feature.

### 8. Assemble the Structured Tree

Emit one structured-content object matching the Output Contract.
Mark step-shaped content and callout-worthy escalation triggers
semantically (`severity: "important"` is appropriate when the
trigger involves regulated data or security-sensitive code).

## Output Contract

The skill emits exactly one structured-content object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "support",
  "repo": {
    "name": "<bundle.repo.name>",
    "path": "<bundle.repo.path>"
  },
  "skipped": {
    "reason": "<short reason>"
  },
  "topics": [
    {
      "id": "failure-mode-<slug>",
      "title": "<short customer-shaped name>",
      "kind": "failureMode",
      "customerVisibleError": {
        "errorText": "<verbatim string or null>",
        "kindOfError": "<short shape when text is null>",
        "where": "<customer-facing surface name>",
        "evidence": "<bundle field or repo-relative path>"
      },
      "diagnosticSteps": {
        "kind": "steps",
        "steps": [
          {
            "ordinal": 1,
            "action": "<imperative support-language sentence>",
            "expectedSignal": "<what tells support the step worked>",
            "escalateOn": "<what failing this step means>"
          }
        ]
      },
      "escalation": {
        "trigger": "<concrete condition>",
        "route": "<role-shaped target>",
        "evidenceForHandover": ["<concrete artefact>"]
      }
    },
    {
      "id": "debugging-quick-reference",
      "title": "Debugging Quick-Reference",
      "kind": "callouts",
      "callouts": [
        { "severity": "note | important", "title": "<short>", "body": "<one to three sentences>", "evidence": "<bundle field or path>" }
      ]
    },
    {
      "id": "known-limitations",
      "title": "Known Limitations",
      "kind": "callouts",
      "callouts": [
        { "severity": "note", "title": "<short>", "body": "<by-design constraint, customer-language>", "evidence": "<bundle field or path>" }
      ]
    }
  ],
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle field>"] }
  ]
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  contract changes
- `audience` is the literal `"support"`. The orchestrator routes by
  this field
- `skipped` is present *only* when the layer skips per the skip rule.
  When `skipped` is present, the skip envelope is the entire output —
  `topics` is omitted. When the layer runs, `skipped` is omitted
  entirely — its absence carries meaning
- `topics` is ordered: failure modes first (in the order the bundle
  surfaces justify), then `debugging-quick-reference`, then
  `known-limitations`. The orchestrator may re-order at render
  time, but the natural order is the suggested reading order
- `kind` values are stable: `failureMode`, `callouts`, with nested
  `kind: "steps"` for diagnostic-step blocks. The orchestrator's
  `format-output` step keys off these to pick the right rendering
  primitive (`<Steps>`, `<Callout>`, paragraph block)
- `customerVisibleError.errorText` is the verbatim user-facing
  string when the bundle exposes it; `null` otherwise. Never invent
  a quoted error message
- Every `evidence` field references a bundle field or repo-relative
  path that exists in the bundle's `fileStructure` or `surfaces`
  entries. Never fabricate a path
- `warnings` mirrors the v-analyze-repo warning shape. Stable codes
  for this layer: `WARN_SUPPORT_THIN_EVIDENCE`,
  `WARN_SUPPORT_FAILURE_MODES_TRUNCATED`,
  `WARN_SUPPORT_STEPS_OVERFLOWED`,
  `WARN_SUPPORT_SIGNAL_CONFLICT_PROPAGATED`,
  `WARN_BUNDLE_INCOMPLETE`

## Quality Bar

The output meets the quality bar when:

- Escalation paths are concrete: each one names a role-shaped route,
  a triggering condition, and the artefacts to hand over
- Length scales with the bundle: a thin customer-facing surface
  produces a short layer, a rich one produces a thicker layer; no
  padding either way
- No generic advice ("check the logs", "verify the network") appears
  without grounding in a bundle-named log location or surface

## Anti-Patterns

**The known-limitation invented from priors.** Adding "this product
does not work in low-bandwidth environments" because most products
have caveats. The bundle either signals a regulated-data,
sunset-notice, or license-gap limitation, or the section is empty.

**The duplicated devops content.** Restating deployment topology,
log aggregation, or monitoring stack in the support layer because
the bundle's `surfaces.deploymentArtifacts` looked rich. The devops
layer covers that. The support layer cross-references at most;
support readers do not run the system.

## Critical Rules

1. **Read the bundle, not the repo.** The skill consumes
   `AnalysisBundle` and only that. Re-walking the tree defeats the
   read-once contract and risks producing failure modes the other
   layers cannot corroborate.

2. **Skip when the signal says skip.** No customer-visible API means
   no support layer. The skip envelope is the entire output.

3. **Evidence or cut.** Every failure mode, every diagnostic step's
   `escalateOn`, every escalation route must trace to a bundle
   field or repo-relative path. Un-evidenced support content is
   fabrication, and fabrication in support content reaches
   customers.

4. **Step-shaped content gets marked.** Diagnostic steps are
   sequenced. Mark them `kind: "steps"` so the orchestrator can
   render them as a first-class `<Steps>` block. Free-form prose
   loses the affordance.

5. **Support's lens, not engineering's.** Diagnostic steps are
   doable from the customer's view. The moment a step requires
   opening source, it is engineering's job — that is what
   escalation is for.

6. **Roles, not names.** Escalation routes are role-shaped. The
   bundle does not carry on-call rotations; do not invent them.

7. **Verbatim error text or none.** `errorText` is either a string
   that appears in the bundle or `null`. There is no in-between.

8. **Output is structured content, never MDX.** The format-output
   step renders this layer's output to MDX. Emitting MDX directly
   here breaks the audience-skill / format-step seam.
