---
name: v-wiki-layer-devops
description: Generate the devops/SRE-audience wiki layer — deployment topology, monitoring surfaces, oncall runbook, incident response, shared-infra dependencies, scale notes — from an AnalysisBundle. Use when the wiki orchestrator dispatches the devops layer, when an SRE needs the 3am-page view of a repo, or when an audience-layered design document needs the operational lens that engineering and architecture layers deliberately do not cover.
trigger: [generate devops wiki, write devops layer, sre runbook layer, oncall documentation, devops audience layer, port devops wiki layer]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — DevOps

## Objective

Produce the devops-audience layer for a generated wiki: the page an
SRE opens when the system pages them at 3am. It answers where this
runs, what's wired up to watch it, what to do when it breaks, and
what shared infrastructure it leans on.

The reader is on-call. They want a runbook with enough context to
mitigate the page and an honest list of what's *not* wired up, so
they stop looking for monitoring that doesn't exist. Contributor
guidance, architectural maps, and strategic framing belong to the
sibling layers.

This is a **signal-gated** layer. It emits only when the bundle
surfaces deployment artefacts; a library or pure-source repo gets a
`skipped` marker, not a synthetic devops page.

## When to Use

- The wiki orchestrator (`v-generate-wiki`) dispatches the devops layer
  after `v-analyze-repo` produces a bundle and
  `signals.hasDeploymentArtifacts` is true
- An SRE needs the operational view of a repo — deployment, oncall,
  blast radius — derived from a fresh analysis
- A platform team needs the shared-infra dependency view across
  several repos for capacity or migration planning

Do not use this skill when an `AnalysisBundle` is not available
(invoke `v-analyze-repo` first); when
`signals.hasDeploymentArtifacts` is false (emit the `skipped` shape
and stop); when the reader needs setup or contribution patterns
(engineering layer); or when the reader needs component boundaries
or data flows (architecture layer — which covers topology from a
*design* lens; this layer covers it from an *operational* lens).

## Setup check

Verify an `AnalysisBundle` is available — produced by `v-analyze-repo`
or supplied directly. If absent, stop and instruct the caller to run
`v-analyze-repo` first. This skill never re-reads the repository; that
breaks the read-once contract the wiki layers share.

## Inputs

- `bundle` (required): an `AnalysisBundle` matching `v-analyze-repo`'s
  output contract (`schemaVersion: "1.0"`). Load-bearing fields for
  this layer: `surfaces.deploymentArtifacts`,
  `signals.hasDeploymentArtifacts`,
  `signals.evidence.hasDeploymentArtifacts`, `dependencies`,
  `frameworks`, `activity`
- `options` (optional):
  - `maxRunbookEntries`: cap on common-failure runbook entries
    (default 6). Truncations record `WARN_DEVOPS_RUNBOOK_TRUNCATED`
  - `maxDependencies`: cap on shared-infra entries (default 8).
    Truncations record `WARN_DEVOPS_DEPS_TRUNCATED`

If `bundle` is missing or `bundle.schemaVersion` is incompatible,
stop and emit a warning rather than partial output against an unknown
shape.

## Skip Rule (Hard)

If `bundle.signals.hasDeploymentArtifacts` is `false`, emit exactly:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "devops",
  "repo": { "name": "<bundle.repo.name>", "path": "<bundle.repo.path>" },
  "skipped": {
    "reason": "no deployment artifacts; not deployed infrastructure",
    "evidence": ["signals.hasDeploymentArtifacts"]
  },
  "warnings": []
}
```

No empty sections, no apologetic prose. The orchestrator's index page
surfaces the skip reason; this layer's job here is to be honest and
brief.

## Workflow

### 1. Read the Bundle, Not the Repo

Every fact must trace to a bundle field or a single spot-verification
of a file the bundle pointed at (e.g. opening a deployment manifest
the bundle listed to confirm a port number). Re-walking the tree
defeats the cost-saving rationale shared with sibling wiki layers. If
a fact you want to assert is not in the bundle and cannot be
confirmed by opening a file the bundle already references, leave it
out and add a `WARN_DEVOPS_INSUFFICIENT_EVIDENCE` warning.

### 2. Apply the Skip Rule

Check `bundle.signals.hasDeploymentArtifacts` first, per **Skip Rule
(Hard)** above. Everything below runs only when the signal is true.

### 3. Frame the Operational Summary

Write 2–3 sentences from an SRE lens:

- Where this runs at a high level — container, serverless function,
  static hosting, scheduled job, long-running worker
- How it is deployed — automated on merge, tag-driven, manual
- Whether anything else of note shares its blast radius

Use `surfaces.deploymentArtifacts[].kind` and surrounding evidence
notes as the substrate. Resist naming the orchestrator, hosting
provider, or CI vendor by tool name — describe the *role*
("container orchestrator", "serverless platform",
"continuous-deployment workflow"). The deeper rule is that the layer
should read the same whether the platform is one orchestrator or
another.

### 4. Capture Deployment Topology (Operational Lens)

The architecture layer covers topology from a design lens. The
devops layer covers it from an operational lens — what an SRE needs
to find the running thing, restart it, scale it, or roll it back.
For each entry capture: `kind` (container, serverless,
static-hosting, scheduled-job, long-running-worker, queue-consumer,
cron, other); `evidence` (a repo-relative path); `triggerNote` (one
sentence on what causes a deploy here — merge-to-default, tag push,
manual workflow, continuous-deployment workflow); and
`recoveryNote` (one sentence on the obvious recovery path if
discoverable, else `null` — do not invent rollback stories).

Mark a `Diagram`-shaped node when more than one runtime target or
shared service is present. Single-target deployments with no shared
services skip the diagram; prose is clearer.

### 5. Inventory Monitoring + Observability Surfaces

Emit only what `surfaces` and `dependencies` actually prove. For each
surface capture: `kind` (logs, metrics, traces, healthcheck,
alert-rule, dashboard, uptime-probe, error-tracker); `evidence` (a
repo-relative path from `surfaces.deploymentArtifacts` or
`signals.evidence.hasDeploymentArtifacts`); and `note` (one sentence
on what it watches and where it reports).

If the bundle surfaces a deployment artefact but no observability
surface, say so via a `gaps` entry — "no metrics surface detected;
logs presumed available via the platform's default sink". Inventing
a metrics story because the manifest looks orchestrator-shaped is a
fabrication.

### 6. Author the Oncall Runbook (Steps-shaped)

The highest-leverage section. For each common failure mode capture:
`symptom` (what the page or alert looks like); `diagnostic` (1–3
short steps — check logs at $surface, check metrics at $surface,
check upstream dependency $name); `mitigation` (1–2 short steps for
the most likely safe action — restart, redeploy last-known-good,
drain traffic, fall back to cache); and `escalation` (who to notify
if mitigation does not resolve, *only* when the bundle surfaces
evidence — CODEOWNERS, runbook reference in a manifest,
`oncall-team` label; otherwise `null` plus
`WARN_DEVOPS_NO_ESCALATION_PATH`).

Failure modes to consider, gated by bundle evidence: container or
serverless cold start / crash (when deployment artefacts include
containers or serverless manifests); upstream dependency outage
(one entry per shared-infra dependency from §8); migration or
startup failure (when the bundle surfaces database-driver
dependencies or migration directories); webhook or queue backlog
(when surfaces include webhook or queue endpoints); capacity or
scaling event (when manifests surface autoscaling config or
worker-count parameters).

Cap at `options.maxRunbookEntries` (default 6); record truncations
as `WARN_DEVOPS_RUNBOOK_TRUNCATED`. If the bundle genuinely supports
zero failure modes (rare), emit zero entries plus
`WARN_DEVOPS_NO_FAILURE_MODES`. Padding empty runbooks with generic
SRE wisdom is a defect. Mark each entry `kind: "steps"` so the
orchestrator's format-output step renders it as a `<Steps>` MDX
block with an ordered-list fallback.

### 7. Sketch Incident Response

Severity ladder and recovery posture only when deployment artefacts
justify it. Emit:

- `severityLadder`: 2–4 entries mapping observable signals (error
  rate, latency, total outage) to a severity label, *only* when an
  alert-rule artefact surfaces or a dashboard manifest references
  thresholds. Otherwise omit the ladder entirely
- `recoveryPaths`: rollback, redeploy, manual-traffic-drain,
  failover-to-secondary — one entry per path the deployment
  artefacts actually expose. Cite evidence

If the bundle shows a Dockerfile but no alerting, dashboarding, or
rollback workflow, omit the entire `incidentResponse` section and
record `WARN_DEVOPS_INCIDENT_SPARSE`. Don't over-specify on a
sparse-deployment repo.

### 8. List Shared-Infra Dependencies

What this system needs to *be running* in order for itself to
function. Source from `dependencies.byEcosystem` plus
`surfaces.customerFacingAPI` / `internal` entries that imply
outbound calls. For each: `name` (the external system as the bundle
surfaces it — data store, identity provider, message broker, object
store, third-party API); `interface` (http, sdk, database driver,
queue, file); `criticality` (load-bearing, soft-dependency,
optional — derived from hot-path evidence); `blastRadius` (one
sentence on what fails when degraded — "all reads fail", "writes
degrade to local buffer", "auth checks short-circuit", "background
sync stops; foreground unaffected"); and `evidence` (a path or
manifest entry).

Cap at `options.maxDependencies` (default 8); truncations record
`WARN_DEVOPS_DEPS_TRUNCATED`. Overlap with the architecture layer's
integration-points section is expected; the lens is different.

### 9. Note Resource and Scale Considerations

A short list (2–4 entries) of when this system needs SRE attention.
Source from `activity` (churn-heavy files near the request path),
deployment-artefact parameters (autoscaler bounds, worker counts,
scheduled-job frequency), and `WARN_*` codes that bear on capacity.
Each entry: `trigger` (peak-hour traffic, large payload,
scheduled-job window, dependency timeout cascade); `currentPosture`
(autoscaling bounds, retry policy, circuit-breaker presence — cite
evidence); `watchPoint` (the surface or metric to watch).

If the bundle surfaces a deployment artefact but offers no signal on
scale, say so honestly: "resource limits not surfaced in deployment
artefacts; capacity posture unclear from bundle". More useful than a
fabricated "runs comfortably under load" line.

### 10. Mark Diagrams and Steps Semantically

Diagrams emit as structured marks, not MDX:

```jsonc
{ "type": "diagram", "format": "mermaid", "source": "graph TD;\n  CD[Continuous deploy] --> App;\n  App --> DB[(data store)]" }
```

Steps emit with `kind: "steps"`:

```jsonc
{ "kind": "steps", "title": "Container crash loop", "steps": [ { "ordinal": 1, "action": "<diagnostic>", "note": "<surface to check>" } ] }
```

Rules: `format` is `"mermaid"` for v1 — the only renderer the
format-output step targets. `source` is the diagram body, ready to
drop inside a fenced mermaid block (no fence in the source itself).
Keep node labels short and tool-neutral ("data store",
"queue broker", "identity provider") — long or branded labels make
diagrams unreadable and leak vendor names. A two-stage runbook
("restart, watch the logs") needs no Steps shape — emit a single
short string; Steps earns its keep on three-or-more-step procedures.
The format-output step's plain-Markdown fallback wraps diagram
source in a fenced mermaid block and renders Steps as an ordered
list.

### 11. Assemble the Structured Output

Emit a single JSON object matching the Output Contract. Sections
that found nothing of substance emit empty collections plus an
explanatory `warnings` entry. The skip case emits the abbreviated
shape from §2.

## Output Contract

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "devops",
  "repo": { "name": "<basename>", "path": "<absolute path>" },
  "operationalSummary": "<2-3 sentence operational shape>",
  "deploymentTopology": {
    "targets": [
      { "kind": "<container|serverless|static-hosting|scheduled-job|long-running-worker|queue-consumer|cron|other>", "evidence": "<path>", "triggerNote": "<short>", "recoveryNote": "<short or null>" }
    ],
    "sharedServices": [
      { "kind": "<data-store|cache|queue|object-store|other>", "name": "<short label>", "evidence": "<path>" }
    ],
    "diagram": {
      "type": "diagram",
      "format": "mermaid",
      "source": "<mermaid graph TD>"
    }
  },
  "monitoring": {
    "surfaces": [
      { "kind": "<logs|metrics|traces|healthcheck|alert-rule|dashboard|uptime-probe|error-tracker>", "evidence": "<path>", "note": "<short>" }
    ],
    "gaps": [
      { "missing": "<surface kind>", "note": "<one sentence on the honest absence>" }
    ]
  },
  "runbook": [
    {
      "kind": "steps",
      "title": "<failure mode>",
      "symptom": "<short>",
      "steps": [
        { "ordinal": 1, "phase": "diagnostic|mitigation|escalation", "action": "<imperative tool-neutral sentence>", "note": "<surface or evidence or null>" }
      ],
      "escalation": "<short or null>"
    }
  ],
  "incidentResponse": {
    "severityLadder": [
      { "severity": "<short label>", "trigger": "<observable signal>", "evidence": "<path>" }
    ],
    "recoveryPaths": [
      { "kind": "rollback|redeploy|drain-traffic|failover", "note": "<short>", "evidence": "<path>" }
    ]
  },
  "sharedInfraDependencies": [
    {
      "name": "<external system label>",
      "interface": "http|sdk|database|queue|file",
      "criticality": "load-bearing|soft-dependency|optional",
      "blastRadius": "<one sentence>",
      "evidence": "<path or manifest entry>"
    }
  ],
  "scaleNotes": [
    { "trigger": "<operational condition>", "currentPosture": "<short>", "watchPoint": "<surface or metric>", "evidence": "<path or null>" }
  ],
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle field or path>"] }
  ]
}
```

When the skip rule fires, emit instead the exact skip envelope
defined in **Skip Rule (Hard)** above — nothing else.

Field-level rules:

- `schemaVersion` is fixed at `"1.0"`. Bump on contract changes
- `audience` is the literal `"devops"` — the orchestrator routes
  by this field
- The full shape and the `skipped` shape are mutually exclusive
- `incidentResponse` is omitted entirely when the bundle does not
  surface alerting or recovery artefacts
  (`WARN_DEVOPS_INCIDENT_SPARSE` records this). Do not emit as
  `null` or empty object — absence carries meaning
- `runbook[i]` carries `kind: "steps"` so format-output renders it
  as `<Steps>` with the ordered-list fallback. Single-action items
  use a one-element `steps` array
- `deploymentTopology.diagram` is omitted when there is one target
  and no shared services — prose is clearer
- Every `evidence` value points to a path that exists in the
  bundle's `fileStructure`, `surfaces`, or `dependencies` evidence.
  Never fabricate a path
- Stable warning codes for this layer:
  `WARN_DEVOPS_INSUFFICIENT_EVIDENCE`,
  `WARN_DEVOPS_INCIDENT_SPARSE`,
  `WARN_DEVOPS_NO_ESCALATION_PATH`,
  `WARN_DEVOPS_NO_FAILURE_MODES`,
  `WARN_DEVOPS_RUNBOOK_TRUNCATED`,
  `WARN_DEVOPS_DEPS_TRUNCATED`,
  `WARN_BUNDLE_VERSION_MISMATCH`

## Quality Bar

Meets the bar when:

- Every target, monitoring surface, dependency, and runbook
  diagnostic step traces to a path or manifest entry an SRE can open
- Runbook entries use `kind: "steps"` with at least one diagnostic
  step and at least one mitigation step per failure mode
- Topology diagrams are emitted via the structured `diagram` mark,
  parse as valid mermaid, and use short tool-neutral node labels
- Monitoring gaps are surfaced explicitly when present — the layer
  reads honestly on a sparse-deployment repo
- Length scales with deployment richness

## Anti-Patterns

**The aspirational runbook.** Diagnostic steps that reference
dashboards, alert channels, or escalation paths the bundle does not
surface. An SRE at 3am hits a dead link and loses minutes. If the
bundle does not show the dashboard, the runbook says "check the
platform's default log surface" or records
`WARN_DEVOPS_NO_ESCALATION_PATH`.

**The padded sparse-deployment layer.** A bundle with one Dockerfile
and no monitoring produces five sections of generic SRE content. The
honest output is one short topology entry, a
`WARN_DEVOPS_INCIDENT_SPARSE`, and a thin runbook covering container
crash loop. Brevity is honesty.

## Critical Rules

1. **The skip rule is hard.** When
   `bundle.signals.hasDeploymentArtifacts` is false, emit the
   abbreviated `skipped` shape and stop. No empty sections, no
   apologetic prose.

2. **The bundle is the input.** Do not re-walk the repo, re-detect
   frameworks, or re-enumerate dependencies. If the bundle is
   wrong, `v-analyze-repo` is where to fix it.

3. **Every fact has evidence.** Targets, monitoring surfaces,
   dependencies, runbook diagnostics, and recovery paths all carry
   an `evidence` field. An SRE must be able to open one file and
   verify the claim.

4. **Tool-neutral throughout.** Describe the *role* a platform
   plays — "container orchestrator", "continuous-deployment
   workflow", "identity provider" — never the brand. The deeper
   rule: diagrams, runbook steps, and dependency labels read the
   same across vendor migrations. (The architecture layer may name
   products where they disambiguate; this layer does not.)

5. **Runbook content gets the Steps shape.** Multi-step diagnostic
   and mitigation procedures are emitted with `kind: "steps"` so
   the orchestrator's format-output step renders them as a first-
   class primitive. Free-form prose loses the affordance.

6. **Topology gets the Diagram shape — when it earns it.** Multi-
   target or topology-with-services emits a small mermaid `graph
   TD` via the structured `diagram` mark. Single-target,
   no-service deployments skip the diagram.

7. **Gaps are surfaced, not papered over.** When the bundle shows
   deployment artefacts but no monitoring or alerting surfaces,
   say so via a `gaps` entry or `WARN_DEVOPS_INCIDENT_SPARSE`.

8. **Stay in the operational lane.** The devops layer is the
   3am-page lens — deployment, monitoring, runbook, blast radius.
   When a sentence describes how to contribute or design intent,
   stop — those belong in the engineering and architecture layers.

9. **Output is structured content, never MDX.** The format-output
   step renders this layer to MDX. Emitting MDX directly here
   breaks the audience-skill / format-step seam.
