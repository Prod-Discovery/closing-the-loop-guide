---
name: discovery-getting-started
description: "Quick-start orientation for the discovery lane — the Discovery to Prototype Engine, stages 0-6. Use when the user says 'getting started with discovery', 'what does the discovery engine do', 'how do I run discovery', or 'explain the discovery stages'. Covers the six stages, what each needs as input, and the exact phrase to begin. For plugin-wide orientation across all three lanes ('what is this plugin', 'where do I start'), use closing-the-loop-getting-started instead."
license: Apache-2.0
---

# Getting Started with the Discovery to Prototype Engine

You've just installed a workflow engine that takes you from raw customer feedback to a testable interactive prototype — in hours instead of weeks. This guide helps you understand what you have and how to start using it.

## What This Engine Does

The Discovery to Prototype Engine is a 6-stage workflow for product managers and designers. You feed it customer data and product context, and it guides you through:

1. **Understanding your landscape** — analyzing customer pain points and competitor gaps
2. **Picking the right opportunity** — scoring and prioritizing what to build
3. **Defining what to build** — writing a product requirements document
4. **Building a realistic prototype** — scanning your team's component library (any stack) and building an interactive prototype from your own components
5. **Planning how to test it** — creating an experiment plan and usability test script

Each stage has a checkpoint where you review the output and decide whether to continue, adjust, or stop. You're always in control.

## How to Start

**Option A — Run the full workflow from the beginning:**

Say this:

> "Run the full discovery to prototype workflow"

The engine will guide you step by step. It starts by asking about your product, then walks you through each stage. You don't need to have everything ready — it tells you what it needs at each step.

**Option B — Jump to a specific stage:**

If you already have some outputs (e.g., you have a PRD and just want a prototype), say:

> "Jump to Stage 5" or "I already have a PRD, generate a prototype"

The engine will ask you for whatever that stage needs as input.

## Slash Commands — Your Shortcut Menu

Any time you want to run a stage or action, type **`/`** (forward slash) in the chat. A dropdown menu will appear listing all available skills from the engine. Select one and it runs immediately — no need to remember exact phrases.

This is especially useful when you want to:
- **Repeat a stage** you've already run (e.g., re-run competitive analysis with new competitors)
- **Run a single stage** without starting the full workflow
- **See everything that's available** — the slash menu shows all installed skills at a glance

Think of it as the engine's command palette. The full workflow and quick commands below still work — slash commands are just a faster way to get to the same things.

## What You'll Need

You don't need all of this upfront — the engine asks for what it needs at each stage:

| What | When | Examples |
|------|------|---------|
| Product context | Stage 0 (first thing) | A strategy doc, pitch deck, or just answers to a few questions about your product |
| Customer data | Stage 1 | CSV exports of NPS scores, support tickets, customer feedback |
| Competitor names | Stage 1 | 2–4 competitor names — the engine researches them using public sources |
| Component library or design system | Stage 4 | Clone your team's component library repo locally and run in Claude Code — Stage 4 scans it (any stack: Angular, React, Vue, Svelte, …), classifies every component, and writes the inventory the prototype builds from. Connecting Figma adds a design-vs-code gap check. No library? The engine can still prototype with generic components — it just won't look like your product. |

## The Stages at a Glance

```
SENSE — Understand the landscape
  Stage 0    Set up product context
  Stage 1.1  Analyze customer data
  Stage 1.2  Research competitors
  Stage 1.3  Merge into Top 5 Opportunities (automatic)
  Stage 2    Score, pick an opportunity, and commit to a solution direction

SHAPE — Build the response
  Stage 3    Write the PRD (product requirements)
  Stage 4    Scan your component library for prototype-readiness (any stack)
  Stage 5    Build an interactive prototype from your own components
  Stage 6    Create an experiment plan and usability test script
```

## Quick Commands

| Say this... | To do this... |
|-------------|---------------|
| "Run the full discovery to prototype workflow" | Start from the beginning |
| "Jump to Stage [N]" | Start at a specific stage |
| "Analyze this customer data" | Run Stage 1.1 only |
| "Research competitors" | Run Stage 1.2 only |
| "Score these opportunities" | Run Stage 2 only |
| "Create a PRD for [opportunity]" | Run Stage 3 only |
| "Scan our component library" or "Is our library prototype-ready" | Run Stage 4 only |
| "Build a prototype with our components" | Run Stage 5 only |
| "Create test plan" | Run Stage 6 only |

## Tips for Your First Run

- **Start with "Run the full discovery to prototype workflow"** — even if you don't finish all 6 stages, the engine saves outputs at every stage so you can pick up later.
- **Upload a strategy doc or pitch deck early** — this is the fastest way to give the engine product context. It extracts what it needs and asks about gaps.
- **Take checkpoints seriously** — corrections in Stage 1 save hours of rework in Stages 4–6.
- **You can stop at any stage** — say "stop here" and your progress is saved.

## Sending Us Feedback

At any point — mid-workflow, after finishing, or even after two minutes of poking around — type **"feedback on discovery"**. You'll be asked for a 1–5 rating and an optional comment. It's **completely anonymous** (no name, no email, no project details) and goes straight to the team building this engine. Every piece of feedback directly shapes what we improve next, so don't wait until you've finished a workflow — first impressions are just as valuable.

(Feedback about the *engineering delivery* skills or the handover bridge goes somewhere else — a different maintainer team — so say **"feedback on the delivery skills"** for that. A bare "give feedback" will just ask you which one you meant.)

## Ready?

Say **"Run the full discovery to prototype workflow"** to begin, or ask me anything about how a specific stage works.
