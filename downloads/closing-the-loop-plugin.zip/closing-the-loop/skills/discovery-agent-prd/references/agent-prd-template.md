# Agent PRD Template

Template for Step 2 of the Agent PRD skill. Extends the standard PRD structure with the confirmed Agent Behavior Script and agent-specific use cases, metrics, and risks.

---

## The PRD Generation Prompt

This is the core prompt used to generate the agentic PRD in Step 2. Fill in from the confirmed behavior script and product context:

```
Context:
- Confirmed agent behavior script: [from Step 1]
- Selected opportunity: [from Stage 2]
- Product context: [from Stage 0]

Create a concise PRD for this agentic solution.

The PRD must include:
1. Feature name (2-5 words)
2. Problem statement (who, what problem, when/where, impact, current state)
3. Proposed solution (concept, what agent handles vs user controls, capabilities, out of scope)
4. Agent Behavior Script (embed the confirmed script exactly as approved — do not modify)
5. Target segments (primary, secondary, excluded)
6. Use cases as: trigger → agent action → user experience → outcome
   Include at least one escalation scenario and one failure recovery scenario
7. Success metrics including agent-specific KPIs:
   - Agent accuracy (correct actions / total actions)
   - Agent utilization (completed actions / total triggers)
   - Escalation rate (escalations / total actions)
   - User override rate (corrections / total agent actions)
   - Time saved per user
8. Dependencies & risks including:
   - Trust risk (user doesn't trust agent)
   - Accuracy risk (agent makes wrong decision)
   - Degradation risk (performance drops over time)
   - Key assumptions that become testable hypotheses for Stage 6

Stay high-level. Focus on "what" not "how." Include scope boundaries.
Each assumption becomes a test hypothesis for the experiment plan.
```

---

## Template

### [Feature Name]

---

#### Problem Statement

**Who**: [Specific user segment with characteristics]

**Problem**: [1-2 sentences describing the core pain point]

**Context**: [When/where this problem occurs in the user journey]

**Impact**: [Why this matters — quantify if possible]

**Current state**: [How users handle this today, workarounds]

---

#### Proposed Solution

**Concept**: [1-2 sentence description including the agentic nature]

**What the agent handles autonomously**:
- [Autonomous capability 1]
- [Autonomous capability 2]

**What the user controls**:
- [User-driven action 1]
- [User-driven action 2]

**Key capabilities**:
- [Capability 1]
- [Capability 2]
- [Capability 3]

**Out of scope** (for this iteration):
- [Explicitly excluded feature/capability]
- [Another excluded item]

---

#### Agent Behavior Script

> Embed the confirmed behavior script from Step 1 here.
> Copy it exactly as the user confirmed — do not modify.

[Full behavior script: identity, goal, triggers, tools, human checkpoints, evaluation]

---

#### Target Segments

**Primary**: [Must-serve segment]
- Characteristics: [qualifying traits]
- Size: [estimate if known]

**Secondary**: [Nice-to-serve segment]
- Characteristics: [qualifying traits]

**Excluded**: [Who this is NOT for]
- [Excluded segment and why]

---

#### Use Cases

| # | Trigger | Agent Action | User Experience | Outcome |
|---|---------|-------------|----------------|---------|
| 1 | [Event/condition] | [Agent acts autonomously] | [User sees notification/result] | [Value delivered] |
| 2 | [Event/condition] | [Agent acts autonomously] | [User sees notification/result] | [Value delivered] |
| 3 | [Event/condition] | [Agent escalates to user] | [User decides / provides input] | [Resolved with human judgment] |
| 4 | [Agent encounters error] | [Agent falls back safely] | [User takes manual control or retries] | [Graceful degradation] |

**Mandatory:** Include at least one escalation scenario (agent asks user) and one failure recovery scenario (agent handles an error gracefully). These are critical for building user trust and feed directly into the Stage 6 experiment plan.

---

#### Success Metrics

| Metric | Current State | Target | Measurement Method |
|--------|---------------|--------|-------------------|
| [Primary user outcome metric] | [baseline] | [goal] | [how to measure] |
| [Secondary user metric] | [baseline] | [goal] | [how to measure] |
| Agent accuracy | N/A | >[target %] | Correct actions / total actions |
| Agent utilization | N/A | >[target %] | Completed actions / total triggers |
| Escalation rate | N/A | <[target %] | Escalations / total actions |
| User override rate | N/A | <[target %] | User corrections / total agent actions |
| Time saved per user | [current time on task] | [target reduction] | Before/after analytics |

---

#### Dependencies & Risks

| Type | Description | Mitigation |
|------|-------------|------------|
| Dependency | [System/data the agent needs to function] | [Fallback if unavailable] |
| Risk | Agent makes incorrect decision | Confidence thresholds + user review flow + undo capability |
| Risk | User doesn't trust agent actions | Transparency in agent reasoning + gradual autonomy rollout |
| Risk | Agent performance degrades over time | Monitoring dashboard + accuracy alerts + periodic review |
| Assumption | [About agent behavior — e.g., "accuracy >95% is achievable"] | [Validate in Stage 6 experiment plan] |
| Assumption | [About user acceptance — e.g., "users will trust auto-categorization"] | [Validate in Stage 6 usability test] |

---

## Writing Guidelines

- **Agent behavior is the core section.** The behavior script is what makes this PRD different from a standard one. It must be complete and unambiguous.
- **Use cases should show the agent-user interaction.** Not just what the agent does, but what the user experiences at each step — the "dance" between agent and human.
- **Success metrics must include agent-specific KPIs.** Accuracy, utilization, escalation rate, and override rate are mandatory. Without these, there's no way to measure whether the agent is actually working.
- **Risks must address trust and transparency.** Users interacting with an agent have fundamentally different concerns than users of a traditional feature.
- **Assumptions become experiment hypotheses.** Every assumption in this PRD feeds directly into Stage 6's experiment plan and usability test script. Write them as specific, falsifiable statements.
