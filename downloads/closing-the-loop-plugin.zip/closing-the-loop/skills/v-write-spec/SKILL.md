---
name: v-write-spec
description: Write structured specifications that drive agent implementation — requirements, acceptance criteria, constraints, and task breakdowns — before any code is written. Use when defining a feature or system before implementation, when acceptance criteria need to be explicit and verifiable, when multiple agents or people will work from a shared understanding, when starting a spec-driven workflow, or whenever jumping to code would produce ambiguous or untestable results.
trigger: [write a spec, specify this feature, define requirements, create acceptance criteria, spec-driven development]
license: Apache-2.0
output_contract_schema: custom
---

# Write Spec

## Objective

Produce a specification that is complete enough for an agent or engineer to
implement without guesswork, and precise enough to verify when implementation
is done. A good spec answers three questions: what are we building, what does
done look like, and what are we explicitly not building.

## When to Use

- A feature, change, or system needs to be defined before implementation
- Multiple people or agents will work from the same understanding of what
  to build
- Acceptance criteria need to be explicit and verifiable
- You are starting a spec-driven development workflow

Do not write a spec when the change is trivial, when the task is already
fully specified in an existing spec or issue, or when writing the spec would
take longer than doing the work.

## Workflow

### 1. Capture Requirements

Clarify the user's intent to concrete outcomes (not feature labels), read
the code, data models, and UI the spec will affect, and write each
requirement as a behavior statement:

- "When a user submits a search query, the system returns matching results
  within 200ms" — NOT "The search should be fast"

Each requirement must be independent (understandable on its own), testable
(clear pass/fail criterion), unambiguous (one interpretation), and bounded
(explicit scope limits). Capture what the system does, who triggers it, when
it applies, and what success looks like.

### 2. Define Acceptance Criteria

For each requirement, write criteria that an automated test or manual
verification can check:

```
Given: [precondition — the state of the system before the action]
When:  [action — what the actor does]
Then:  [outcome — what the system does in response, observable and measurable]
```

If you cannot write a test for a criterion, it is too vague. Assert on
behavior, not implementation ("returns JSON with status 200", not "uses the
framework's response helper"). Cover the edges: happy path, error path,
empty state, boundary values, authorization failures.

### 3. Document Constraints and Non-Requirements

Constraints limit how the implementation can be done — performance budgets,
compatibility, security, regulatory requirements — and need specific
thresholds, not vague qualifiers. Non-requirements prevent scope creep:
features explicitly excluded, quality attributes deferred, edge cases
acknowledged but not addressed now.

### 4. Resolve Ambiguities

For each requirement, ask whether two engineers could interpret it
differently, whether implicit assumptions should be explicit, and whether it
conflicts with existing behavior. State each ambiguity found and record the
resolution and rationale. If the resolution requires a decision from someone
else, mark it as blocked and move on — do not guess.

### 5. Break Down Into Tasks (Optional)

For complex specs, decompose into implementation tasks: each small enough for
a single agent context window, ordered by dependency, independently
verifiable, and linked to the requirements it implements. Task breakdown
follows the same risk-first ordering as v-plan-work — the most uncertain
tasks go first.

Before handing the spec to an implementer, check it against the Quality Bar.
Blocked open questions are acceptable; silent gaps are not.

## Output Contract

Every spec must include these sections:

```markdown
# [Feature/Change Name]

## Overview
[2-3 sentences: what this is, why it matters, who it's for]

## Requirements

### REQ-1: [Requirement title]
[Behavior statement]

**Acceptance criteria:**
- Given [precondition], when [action], then [outcome]
- Given [precondition], when [action], then [outcome]

### REQ-2: [Requirement title]
...

## Constraints
- [Performance, compatibility, security, or regulatory constraint]
- [Constraint with specific threshold or boundary]

## Non-Requirements (Explicit Exclusions)
- [Feature or behavior explicitly NOT included in this work]
- [Edge case acknowledged but deferred]

## Assumptions
- [Something believed true but not verified — if wrong, the spec changes]

## Open Questions (if any)
- [ ] [Question that blocks a requirement — with who needs to answer it]

## Tasks (if breaking down into implementation units)
1. [Task title] — implements REQ-1, REQ-2
2. [Task title] — implements REQ-3
...
```

Gated pipelines (e.g. v-ship-feature) may require additional spec sections —
users & stakeholders, user journeys, success metrics — carried as extra H2s
extending this same contract.

See ./references/example-spec.md for a worked example applying this contract.

## Quality Bar

A spec meets the quality bar when:

- Every requirement has at least one testable acceptance criterion
- An implementer can build the feature without asking clarifying questions
- Constraints have specific thresholds and non-requirements draw explicit
  scope boundaries
- Ambiguities are resolved with documented rationale, or explicitly marked
  as blocked and assigned
- Requirements trace to a user need, not to implementation convenience

The defining failure: the spec is a restatement of the user's request with no
added precision.

## Anti-Patterns

**The wish list spec.** A bullet list of features with no acceptance
criteria, no constraints, and no exclusions. Agents will interpret each
bullet differently every time.

**The spec novel.** A 20-page document that no one reads. If a spec is too
long, the feature is too big — break it into smaller specs.

**The living spec that never ships.** Continuously refining the spec instead
of declaring it ready for implementation. A spec needs to be specific enough
to implement and verify, not perfect.

## Critical Rules

1. **Behavior over implementation.** Specs define what the system should do,
   not how to build it. Exception: when the implementation approach is itself
   a requirement (e.g., "must use the existing auth middleware").

2. **Explicit exclusions are not optional.** Scope without boundaries expands
   until the work is unshippable. Name what you are not building and which
   edge cases you are deferring.

3. **Assumptions are first-class.** List them. Making assumptions visible
   lets you validate them early and adapt when they break.

4. **Specs are versioned artifacts.** When requirements change, update the
   spec. A stale spec is worse than no spec — it actively misleads.

5. **Proportional depth.** A one-endpoint API addition needs a one-page spec;
   a payment system rewrite needs a thorough one. Match depth to the risk and
   complexity of the work.
