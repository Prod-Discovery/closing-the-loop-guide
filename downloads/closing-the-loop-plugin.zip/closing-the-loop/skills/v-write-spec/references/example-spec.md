# Example Specification: User Search Feature

## Overview
Add search functionality to the user management page, allowing administrators
to find users by name, email, or role. This reduces time spent scrolling
through paginated user lists in organizations with 100+ users.

## Requirements

### REQ-1: Search by text query
When an administrator enters a search query in the search field, the system
returns users whose name or email contains the query string (case-insensitive
partial match).

**Acceptance criteria:**
- Given a query "jan", when searching, then users named "Janet" and
  "jan.doe@example.com" both appear in results
- Given a query with no matches, when searching, then an empty state is
  shown with the message "No users match your search"
- Given an empty query, when searching, then all users are shown (default
  state)

### REQ-2: Filter by role
When an administrator selects a role filter, the system returns only users
with that role. Filters combine with text search (AND logic).

**Acceptance criteria:**
- Given role filter "Admin" is selected, when viewing results, then only
  users with the Admin role appear
- Given role filter "Admin" and query "jan", when viewing results, then only
  Admin users matching "jan" appear
- Given no role filter selected, when viewing results, then users of all
  roles appear

### REQ-3: Search performance
Search results return within 200ms for organizations with up to 10,000 users.

**Acceptance criteria:**
- Given an organization with 10,000 users, when a search query is submitted,
  then results are returned to the client within 200ms (server response time)

## Constraints
- Search must use the existing database — no new search infrastructure
  (e.g., no Elasticsearch) in this iteration
- The search endpoint must require admin authentication
- Results must respect existing data access controls (org-scoped queries)
- Maximum 50 results per page with cursor-based pagination

## Non-Requirements (Explicit Exclusions)
- Full-text search across all user fields (only name, email, role)
- Search history or saved searches
- Export of search results
- Real-time search-as-you-type (search triggers on explicit submit or
  300ms debounce)
- Fuzzy matching or typo tolerance

## Assumptions
- The users table has indexes on name and email columns (verify before
  implementation)
- The existing pagination component supports filter parameters
- Admin authentication middleware is already applied to the user management
  routes

## Open Questions
- [ ] Should search results include deactivated users? (Ask: product owner)
