# Confluence page publishing (MCP + REST API token)

How to publish a discovery PRD as a **Confluence page**, attach a prototype to it, and mark it with the
handover path. Use this on the Confluence surface of Step 1–3; the Linear and Jira issue routes are
unaffected.

Everything below was verified against a live Cloud site on **2026-08-05**. Where a claim is
counter-intuitive, the observed error is quoted — those are the traps.

## Split of responsibilities

| Operation | Route | Why |
|---|---|---|
| Create page, update page, read page | **Atlassian MCP** | `createConfluencePage` / `updateConfluencePage` / `getConfluencePage` |
| Attach the prototype | **REST + classic token** | the MCP exposes no Confluence attachment tool |
| Apply a page label | **REST + classic token** | the MCP exposes no Confluence label tool |

Same root cause as Jira's missing attachment tool (see `KNOWN-ISSUES.md`): missing *tooling*, not
missing *permission*. Same credential, same `~/.netrc` entry, same site host — Confluence needs **no
second credential**. `closing-the-loop-setup` already scaffolded it.

## Credentials

Identical to [jira-attachment-upload.md](../../discovery-handover-package/references/jira-attachment-upload.md):
`curl --netrc` against `machine <site>.atlassian.net`, or `-u "$JIRA_EMAIL:$JIRA_API_TOKEN"`.

> **Use a classic (unscoped) API token.** A *scoped* token is Bearer-only and fails basic auth with a
> confusing `401`.

Read the token from the environment or `~/.netrc` and reference it only as a shell variable. **Never**
inline, echo, log, or commit it, and never write it to a page, a config file, or stdout.

When neither is configured, do not attempt the REST calls: publish the page through the MCP, put the
prototype in as a **link**, carry the marker in the **page body** (which needs no credential at all),
and say so in the report. Never hard-fail.

> [!note] Cowork has no classic token, by design
> Connector OAuth tokens never enter the Cowork sandbox, and `~/.netrc` is not part of that
> environment, so the REST half of this reference is simply unavailable there. That is a capability
> difference, not a misconfiguration — **do not report it as a setup failure.**
>
> What still works in Cowork is most of it: creating, reading, and updating the page through the
> Atlassian connector, and the marker block — which is the page body, so it needs no credential. That
> means the whole downstream handover chain routes normally. What you lose is *automatically* attaching
> the prototype (link it, or hand the file to the user to upload through **Insert → Files and images**)
> and the convenience page label (the body block was always the source of truth anyway).
>
> This is why Confluence is the most Cowork-portable of the three surfaces: its routing layer never
> needed a credential in the first place.

Reachability check — status code only, never reading the secret back:

```bash
curl -s -o /dev/null -w "%{http_code}" --netrc \
  "https://<site>.atlassian.net/wiki/rest/api/user/current"
```

`200` means the same token that works for Jira also reaches Confluence. `404` usually means Confluence
is not provisioned on the site.

## Creating the page

Use `createConfluencePage` with `contentFormat: "markdown"` so the PRD renders as written.

- **`spaceId` accepts a space *key*** (e.g. `MST`) and resolves it to the numeric id. No lookup step.
- Omitting `parentId` parents the page to the **space homepage**.
- Markdown converts cleanly: headings, tables, blockquotes, code fences, and lists all survive.

> [!important] Create with `status: "current"`. Never create a draft and publish it later.
> `updateConfluencePage` always sends the next version number, but Confluence requires version 1 when
> publishing a draft for the first time, so the transition fails:
> `"Version number must be 1 when publishing a page for the first time. Provided version: [2]"` (400).
> There is no MCP path from draft to published. A draft also cannot receive attachments (below).

## The round-trip rule — write markdown, read and update HTML

This is the rule that protects a PM's edits, so it is not optional.

**Reading a page as `markdown` is lossy, silently.** Verified on a realistic requirements page:

| Authored | Read back as `markdown` | Read back as `html` |
|---|---|---|
| `panel-warning` holding *"Legal reviewed the reminder wording — do not change the template copy"* | an ordinary paragraph — **the warning severity is gone** | panel preserved, severity intact |
| `decision-list` item `data-state="DECIDED"`: *"Cap a batch at 50 invoices"* | an ordinary paragraph — **indistinguishable from prose** | decision list preserved, state intact |
| `task-list` with an unticked item | `- [ ]` text | task list preserved, with `data-local-id` |
| table, blockquote, headings, code fences | preserved | preserved |

Note what the two examples are: a **constraint** and a **decision** — exactly the load-bearing content
this plugin exists to carry. Flattened, they read as background prose, and writing that markdown back
destroys them permanently.

Two consequences:

1. **Any update to a page a human may have edited must fetch as `html`, splice, and write `html`.** A
   markdown round trip would silently convert a PM's panel into a plain paragraph and destroy the
   distinction. `html` is documented round-trip safe; preserve existing `data-local-id` attributes on
   fetched nodes and omit them on new ones.
2. The task-list flattening is **the same dead-text trap** `KNOWN-ISSUES.md` records for Jira's ADF
   flattening: once flattened, an unticked box is indistinguishable from literal text that was never
   tickable. Never build a gate check on checkboxes read out of a Confluence page as markdown.

Reading as `markdown` is fine when you only need the prose — e.g. treating the page as requirements
text. It is **not** fine as the read half of a write.

> [!warning] Do not verify page content against `body.storage` over REST.
> Confluence's *storage* format is a third representation, and it is **not** what you wrote. Verified on
> the same page: a `data-type="panel-warning"` div comes back as
> `<ac:structured-macro ac:name="note">` (the severity is normalised away), and an absolute page URL
> becomes `<ac:link><ri:page ri:content-title="…"/></ac:link>` — a *title* reference, not an id one.
> Both render correctly and both read back correctly as `html`; only the storage projection differs.
> Assert on a `getConfluencePage` read with `contentFormat: "html"`. Checking `body.storage` with curl
> will make a perfectly good round trip look broken.

## Attaching the prototype

- **Endpoint:** `POST https://<site>.atlassian.net/wiki/rest/api/content/{pageId}/child/attachment`
  (REST **v1** — the v2 API is read-only for attachments). Use the direct site host, never the
  `api.atlassian.com/ex/confluence/{cloudId}` gateway.
- **Required header:** `X-Atlassian-Token: no-check`.
- **Body:** `multipart/form-data`, field name **`file`**, repeatable for several files.
- **Response:** `{"results":[{"id":"att<numeric>","title":"<filename>", ...}]}`. Capture `id` + `title`.

```bash
curl -s --netrc \
  -H "X-Atlassian-Token: no-check" \
  -F "file=@<packaged prototype path>" \
  "https://<site>.atlassian.net/wiki/rest/api/content/<pageId>/child/attachment"
```

> [!warning] The page must already be published.
> Attaching to a draft fails with `404` and this message:
> `No content found with id : ContentId{id=...} and status [current], there is a content object with
> status : draft`. This is the second reason to create with `status: "current"`.

**Packaging.** Reuse `scripts/package_prototype.sh` unchanged. Its 10 MB default exists because that is
Linear's free-tier *native* attachment cap — it does not apply here, so pass a higher `max_mb` (the
site's own upload limit governs; Confluence Cloud's default is far more generous). A `status=too_big`
result under the Linear ceiling is usually perfectly attachable to a page.

**Prefer a hosted link anyway.** A live prototype URL carries design context an engineer can pull. On a
page, render it as an inline card — `<a href="URL" data-card-appearance="inline">Prototype</a>` — which
is strictly nicer than Jira's `Prototype: <url>` description line.

## Applying the path marker

**The page body block is the marker and the source of truth.** The first line of the page, before the
PRD:

```
> **Closing the Loop** · path: `context-first` · surface: `confluence` · delivery: `KAN-42`
```

Use `none` for `delivery` when no tracker issue was created. `handover-shape-feature` later appends a
fifth key, `context: <sub-page URL>`, pointing at the Delivery Context sub-page. The full key table is
in the skill's "Confluence marker block" section — keep the two in step if either changes.

The body block needs no credential, survives page edits, travels with the page, and is findable by CQL
text search. Downstream skills route on it.

**Additionally**, when the token is configured, apply a real Confluence label as a convenience for
human browsing and CQL `label =` queries:

```bash
curl -s --netrc -X POST -H "Content-Type: application/json" \
  -d '[{"prefix":"global","name":"context-first-handover"}]' \
  "https://<site>.atlassian.net/wiki/rest/api/content/<pageId>/label"
```

Returns `200` with the applied label. Unlike attachments, this **does** work on a draft. The label is a
convenience mirror — if it is missing or stale, the body block still decides. Never route on the label
alone.

## Failure handling (never abort the publish)

The REST calls are best-effort. On an HTTP error, surface a readable message and **continue** — the page
already exists and carries the PRD and the marker.

| Status | Meaning | What to tell the user |
|--------|---------|-----------------------|
| `401` | Bad credentials | Token wrong, expired, or *scoped* rather than classic — regenerate it. |
| `403` | No permission | The account cannot attach or label in this space. |
| `404` | Page not found — **or the page is a draft** | Check `<pageId>`; if the page was created as a draft, publish it (recreate with `status: "current"`). |
| `413` | File too large | Exceeds the site upload limit — link the prototype instead. |

In every case the page stands, the marker is in the body, and the report states what did not land and
why.

## Cleanup (for test runs only)

Deleting needs the status the content is actually in — a plain `DELETE` targets `current` and returns
`404` for a draft:

```bash
curl -s --netrc -X DELETE "https://<site>.atlassian.net/wiki/rest/api/content/<pageId>"                  # → trash
curl -s --netrc -X DELETE "https://<site>.atlassian.net/wiki/rest/api/content/<pageId>?status=trashed"    # purge
curl -s --netrc -X DELETE "https://<site>.atlassian.net/wiki/rest/api/content/<pageId>?status=draft"      # a draft
```

Never delete a page a user created. This is for cleaning up verification artifacts you made yourself.
