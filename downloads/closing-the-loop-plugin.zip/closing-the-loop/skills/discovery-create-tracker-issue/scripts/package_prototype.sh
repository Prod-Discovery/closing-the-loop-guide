#!/usr/bin/env bash
#
# package_prototype.sh — prepare a prototype for attachment to a tracker issue.
#
# Behaviour (mirrors the skill's prototype-handling rule):
#   - A single file is returned as-is. Never zip a lone file.
#   - A folder (or multiple files) is zipped.
#       * If the zip is under MAX_MB, attach it as-is. Do not clean.
#       * If the zip is MAX_MB or larger, re-zip excluding build/dependency
#         directories (node_modules, .git, dist, build, .next, coverage), then
#         use the cleaned zip.
#       * If even the cleaned zip is MAX_MB or larger, report too_big so the
#         skill can fall back to asking for a hosted link.
#
# MAX_MB defaults to 10. 10 MB is the smallest attachment cap across the
# trackers we target (Linear free = 10 MB; GitHub Issues = 25 MB general files;
# Jira Cloud ~1 GB). Staying under 10 MB fits all of them.
#
# Usage:
#   package_prototype.sh <prototype_path> [output_dir] [max_mb]
#
# Output: key=value lines on stdout —
#   status=nopack|ok|too_big
#   path=<absolute path to the file to attach>   (omitted when status=too_big)
#   size_mb=<size of that file, 1 decimal>
#   cleaned=true|false
#
set -euo pipefail

SRC="${1:?usage: package_prototype.sh <prototype_path> [output_dir] [max_mb]}"
OUT_DIR="${2:-$(mktemp -d)}"
MAX_MB="${3:-10}"

if [ ! -e "$SRC" ]; then
  echo "error=path_not_found" >&2
  exit 1
fi

mkdir -p "$OUT_DIR"

# Resolve absolute paths (works for files and dirs).
abspath() { (cd "$(dirname "$1")" >/dev/null 2>&1 && printf '%s/%s' "$(pwd)" "$(basename "$1")"); }

size_mb() {
  # bytes -> MB with one decimal, portable across GNU/BSD stat.
  local bytes
  bytes=$(wc -c < "$1")
  awk -v b="$bytes" 'BEGIN { printf "%.1f", b / 1048576 }'
}

# Threshold in bytes for integer comparison.
MAX_BYTES=$(awk -v m="$MAX_MB" 'BEGIN { printf "%d", m * 1048576 }')

# --- Single file: attach as-is -------------------------------------------------
if [ -f "$SRC" ]; then
  ABS=$(abspath "$SRC")
  echo "status=nopack"
  echo "path=$ABS"
  echo "size_mb=$(size_mb "$ABS")"
  echo "cleaned=false"
  exit 0
fi

# --- Folder: zip, measure, clean if needed ------------------------------------
BASE=$(basename "$SRC")
FULL_ZIP="$OUT_DIR/${BASE}.zip"
CLEAN_ZIP="$OUT_DIR/${BASE}-clean.zip"

# Zip the whole folder first (faithful to "decide based on the zip size").
( cd "$SRC" && zip -r -q "$FULL_ZIP" . )

FULL_BYTES=$(wc -c < "$FULL_ZIP")
if [ "$FULL_BYTES" -lt "$MAX_BYTES" ]; then
  echo "status=ok"
  echo "path=$FULL_ZIP"
  echo "size_mb=$(size_mb "$FULL_ZIP")"
  echo "cleaned=false"
  exit 0
fi

# Too big: re-zip excluding build/dependency directories.
( cd "$SRC" && zip -r -q "$CLEAN_ZIP" . \
    -x '*/node_modules/*' 'node_modules/*' \
       '*/.git/*' '.git/*' \
       '*/dist/*' 'dist/*' \
       '*/build/*' 'build/*' \
       '*/.next/*' '.next/*' \
       '*/coverage/*' 'coverage/*' )
rm -f "$FULL_ZIP"

CLEAN_BYTES=$(wc -c < "$CLEAN_ZIP")
if [ "$CLEAN_BYTES" -lt "$MAX_BYTES" ]; then
  echo "status=ok"
  echo "path=$CLEAN_ZIP"
  echo "size_mb=$(size_mb "$CLEAN_ZIP")"
  echo "cleaned=true"
  exit 0
fi

# Still too big after cleaning: caller should fall back to a hosted link.
echo "status=too_big"
echo "size_mb=$(size_mb "$CLEAN_ZIP")"
echo "cleaned=true"
exit 0
