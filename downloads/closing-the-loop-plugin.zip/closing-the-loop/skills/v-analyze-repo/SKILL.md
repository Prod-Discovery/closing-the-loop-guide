---
name: v-analyze-repo
description: Produce a structured AnalysisBundle for a repository — file structure, languages, dependencies, surfaces, activity, and audience-routing signals — that downstream skills consume without re-reading the repo. Use when generating a wiki, or when a downstream skill needs a repo profile without re-scanning the codebase.
trigger: [analyze this repo, summarize this codebase, build the analysis bundle, profile this repository, prepare repo analysis for wiki]
license: Apache-2.0
output_contract_schema: custom
---

# Analyze Repo

## Objective

Read a repository once and emit an `AnalysisBundle` — a structured,
JSON-shaped summary of what the repo *is*, what it *contains*, what it
*exposes*, and which audience-routing signals apply. Downstream skills
(wiki layer skills, security audits, dependency-upgrade plans) consume
the bundle directly. They must not re-read the repo to recover any
field that belongs in the bundle.

The bundle is the contract. Its shape is fixed; its semantics are
documented here. If you cannot determine a field with confidence,
emit it as `null` (or the empty form for collections) and add a note
to `bundle.warnings` — never guess.

## When to Use

- Wiki generation orchestrator needs shared repo understanding before
  dispatching audience-layer skills
- A reusable analysis pass is needed for security audits, dependency
  upgrade plans, design-system extraction, or similar derived skills
- The user asks to "analyze this repo", "summarize the codebase",
  "build the analysis bundle", or otherwise produce a structured repo
  profile that other tooling will consume
- Multiple downstream consumers would otherwise each re-read the same
  repository

Do not use this skill when:

- The user wants a free-form natural-language summary (this skill emits
  a structured bundle, not prose)
- The work is a single targeted query against the repo ("which file
  defines `X`?") — read the file directly
- A previous bundle exists and is still fresh; reuse it rather than
  regenerating

## Inputs

The skill is invoked with:

- `repoPath` (required): absolute path to a checked-out repository on
  the local filesystem
- `options` (optional):
  - `since`: ISO date for "recent activity" window. Default: 30 days
    ago.
  - `maxDeps`: cap on dependencies enumerated in the bundle. Default:
    no cap; recommended sanity limit 500. Truncations are recorded in
    `bundle.warnings`.
  - `includeLockfiles`: whether to read lockfiles for resolved versions
    when manifests pin ranges. Default: true.

If `repoPath` is missing or not a directory, stop and report — do not
proceed against an empty filesystem.

## Workflow

### 1. Establish Repo Shape

Before reading content, map the structure:

- List top-level directories and a count of files within each (recurse
  but bound the depth — do not enumerate dependency caches, version
  control internals, or build output directories such as `dist` or
  `build`)
- Detect monorepo signals: workspace configuration in the root
  manifest, multiple package manifests under sibling top-level
  directories (`packages/*`, `apps/*`, `services/*`), or a
  workspace-marker file at the root (e.g. `nx.json`, `turbo.json`,
  workspace YAML, `lerna.json`, or analogous)
- Count files per language using extension heuristics; record the
  total file count and the per-language breakdown

### 2. Identify Languages and Frameworks

From file extensions, manifest contents, and a small set of
fingerprint files, determine:

- **Primary language**: largest by file count among source files
  (exclude generated and vendored)
- **Secondary languages**: any language with at least 5% of source
  files, sorted by share
- **Frameworks**: detect by manifest dependency entries *and*
  fingerprint files. Examples to recognise (non-exhaustive): Next.js,
  React, Vue, Svelte, Convex, Express, Fastify, NestJS, Django, FastAPI,
  Flask, Spring Boot, Rails, .NET, Go HTTP routers (chi, gin, echo).
  Record each as `{ name, version, evidence }` where `evidence`
  references the manifest entry or fingerprint file path.

If a framework appears only as a transitive dep with no usage signal,
do not list it. Frameworks are listed when the repo *uses* them, not
merely when they are reachable.

### 3. Enumerate Dependencies

For each manifest the repo contains — `package.json`, `pyproject.toml`,
`go.mod`, `pom.xml`, and any other ecosystem manifest you encounter —
flatten direct dependencies into uniform records:

```
{
  name: string,
  version: string,        // resolved from a lockfile when available, else from the manifest range
  license: string | null, // best-effort from registry metadata or local install metadata
  ecosystem: string       // see ecosystem-key list below
}
```

**Ecosystem keys are language-runtime style**, tool-neutral across the
build systems each runtime supports. The full enum:

- `node` — `package.json` and the lockfiles its package managers produce
- `python` — `pyproject.toml`, `requirements*.txt`, `setup.py`
- `go` — `go.mod`
- `jvm` — `pom.xml` and other JVM build manifests
- `dotnet` — `*.csproj`, `packages.config`
- `ruby` — `Gemfile`
- `rust` — the Rust crate manifest
- `other` — anything not listed above

Notes:

- Group results by ecosystem. A monorepo may have several manifests of
  the same kind; deduplicate by `(name, ecosystem)` keeping the
  highest pinned version.
- Distinguish runtime, dev, peer, and optional dependencies in
  `bundle.dependencies.byKind` if the manifest separates them. Most
  ecosystems mark optional deps explicitly (`optionalDependencies`
  in node manifests, extras in Python projects, `<optional>` in JVM
  POMs) — preserve that distinction; license-audit cares about
  required and optional with different urgency.
- License resolution is best-effort. If unknown, set `license: null`
  rather than guessing.

### 4. Inventory Surfaces

A "surface" is a way the repo is reached from outside its own code.
Categorise into:

- **Customer-facing API**: public OpenAPI / Swagger specs; HTTP
  handlers under `/api/*`, `/v1/*`, or framework-specific public
  router roots; webhook endpoints documented as public; gRPC services
  published in `.proto` files.
- **Internal surfaces**: admin endpoints, internal RPCs,
  service-to-service handlers, CLI entry points consumed by other
  internal repos.
- **Deployment artifacts**: `Dockerfile`, container compose files,
  Kubernetes manifests, Helm charts, infrastructure-as-code
  (`*.tf`, `*.bicep`, `serverless.yml`), and CI deployment workflows
  under `.github/workflows/` that push to a runtime environment.

For each surface, record `{ kind, path, evidence }`. Do not classify a
handler as customer-facing without evidence — a public route prefix,
an OpenAPI entry, or a documented webhook contract.

### 5. Sample Recent Activity

From the repo's version control history, within the configured `since`
window:

- `commits`: count of commits in the window
- `authors`: deduplicated commit authors (name + email) with commit
  counts
- `churnHeavyFiles`: top N (default 10) files by lines changed in the
  window, each as `{ path, additions, deletions, commits }`

If the directory is not a working git tree, skip this section and
record a warning. Do not fabricate activity data.

### 6. Detect Signals

Compute the seven booleans the orchestrator and downstream skills use
to route audience layers. Each must be derived from concrete evidence
already gathered above; record the supporting evidence inline.

| Signal | True when… |
| --- | --- |
| `hasFrontend` | See rule below |
| `hasCustomerVisibleAPI` | At least one entry exists in `surfaces.customerFacingAPI` with credible evidence (OpenAPI, public route, documented webhook) |
| `hasDeploymentArtifacts` | At least one `surfaces.deploymentArtifacts` entry exists |
| `hasSecuritySensitiveCode` | See rule below |
| `hasRegulatedDataReferences` | See rule below |
| `isInternalOnly` | `hasCustomerVisibleAPI` is false *and* no marketing-facing artefacts (public-facing site, end-user docs) exist |
| `isPureInfra` | The repo is a library, framework, SDK, or developer tool with no end users — typical evidence: a publishable manifest, no UI, no deployment artifacts, README framed for developers |

Each `true` value requires at least one concrete piece of evidence,
recorded under `signals.evidence[<signalName>]` per the unified shape
in the Output Contract. Bare keyword matches in filenames are not
evidence — see the co-occurrence rules below.

**`hasFrontend` rule.** True IFF either:

- (a) a UI framework is detected via manifest dependency entries
  (Next.js, React, Vue, Svelte, Astro, SolidStart, Remix, Nuxt,
  Gatsby, Qwik, etc.); OR
- (b) a UI path is present (`apps/web/`, `apps/frontend/`, `src/pages/`,
  `src/components/`, `src/views/`, or equivalent) **AND** that path
  contains at least one file with a UI extension (`.tsx`, `.jsx`,
  `.vue`, `.svelte`, `.astro`).

Path-only matches without a UI extension do not flip the signal —
service monorepos with `apps/*` for non-web purposes and Hugo or
Jekyll docs sites with `pages/` must read as `false`.

**`hasSecuritySensitiveCode` rule.** True IFF either:

- (a) a directory matching `auth*`, `oauth*`, or `session*` exists
  **and** contains code files (not just config or fixtures); OR
- (b) ≥2 distinct keywords from `{auth, oauth, jwt, session, crypto,
  bcrypt, argon, audit-log, secrets-manager, kms}` appear in code
  files outside tests and outside comment-only contexts.

A bare `crypto` substring in `cryptocurrency`, or an `audit-results/`
artefact directory, must not flip the signal on its own.

**`hasRegulatedDataReferences` rule.** True IFF a regulated-data term
(GDPR, NIS2, PII, PCI, HIPAA, PHI, payment, cardholder, financial-data,
health-data, etc.) appears in a code or data context — not in a
disclaimer phrase ("we do not store PII", "no PCI data is processed").
Operationalise as either:

- (a) ≥2 distinct regulated-data terms appear across the repo, OR
- (b) a single term appears in a non-comment, non-prose context (a
  schema field, an environment-variable name, a config key, a
  manifest tag).

If two signals are mutually contradictory under their evidence rules,
emit both with their evidence and flag the conflict in
`bundle.warnings` (use code `WARN_SIGNAL_CONFLICT`). Do not silently
pick a side.

### 7. Assemble the Bundle

Emit a single JSON object matching the Output Contract schema below.
Every top-level field must be present; collections may be empty.

## Output Contract

The skill emits exactly one JSON object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "repo": {
    "path": "<absolute path>",
    "name": "<basename of repoPath>",
    "isMonorepo": true | false,
    "monorepoMarkers": ["<marker file or pattern>"]
  },
  "fileStructure": {
    "totalFiles": 0,
    "topLevelDirs": [
      { "name": "<dir>", "fileCount": 0 }
    ],
    "byLanguage": [
      { "language": "<name>", "fileCount": 0, "share": 0.0 }
    ]
  },
  "languages": {
    "primary": "<language or null>",
    "secondary": ["<language>"]
  },
  "frameworks": [
    { "name": "<framework>", "version": "<version or null>", "evidence": "<path or manifest entry>" }
  ],
  "dependencies": {
    "byEcosystem": {
      "<ecosystem-key>": [
        { "name": "<dep>", "version": "<v>", "license": "<license or null>", "ecosystem": "<key>" }
      ]
    },
    "byKind": {
      "runtime": 0,
      "dev": 0,
      "peer": 0,
      "optional": 0
    },
    "truncated": false
  },
  "surfaces": {
    "customerFacingAPI": [{ "kind": "<openapi|route|webhook|grpc>", "path": "<path>", "evidence": "<note>" }],
    "internal": [{ "kind": "<admin|rpc|cli|...>", "path": "<path>", "evidence": "<note>" }],
    "deploymentArtifacts": [{ "kind": "<dockerfile|k8s|iac|workflow>", "path": "<path>", "evidence": "<note>" }]
  },
  "activity": {
    "windowDays": 30,
    "commits": 0,
    "authors": [{ "name": "<author>", "email": "<email>", "commits": 0 }],
    "churnHeavyFiles": [{ "path": "<file>", "additions": 0, "deletions": 0, "commits": 0 }]
  },
  "signals": {
    "hasFrontend": false,
    "hasCustomerVisibleAPI": false,
    "hasDeploymentArtifacts": false,
    "hasSecuritySensitiveCode": false,
    "hasRegulatedDataReferences": false,
    "isInternalOnly": false,
    "isPureInfra": false,
    "evidence": {
      "<signalName>": [
        { "kind": "filename | path-match | keyword-cooccurrence | manifest-entry", "details": ["<path or fact>"] }
      ]
    }
  },
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<path or fact>"] }
  ]
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  contract changes.
- All `*.evidence` strings reference a path *inside* the repo; never
  fabricate a path.
- Numeric counts are non-negative integers. Shares are decimals in
  `[0, 1]`.
- `null` is the explicit "unknown" marker for scalar fields.
- `signals.evidence[<signalName>]` is a single, uniform array shape:
  `Array<{ kind, details }>` where `kind` is one of `filename`,
  `path-match`, `keyword-cooccurrence`, or `manifest-entry`, and
  `details` is a list of strings (paths, manifest entries, or matched
  terms). One shape across all signals — downstream skills iterate
  without branching.
- `warnings` is a structured list, not a string array. Each entry has
  a `code` (uppercase snake-case, stable across releases —
  `WARN_DEPS_TRUNCATED`, `WARN_NO_GIT_HISTORY`,
  `WARN_FRAMEWORK_AMBIGUOUS`, `WARN_SIGNAL_CONFLICT`,
  `WARN_LICENSE_UNKNOWN`, etc.), a human-readable `message`, and an
  optional `evidence` array. Codes give downstream skills a
  programmatic handle; messages surface in human-facing reports.

## Quality Bar

A bundle meets the quality bar when:

- Every top-level field defined in the Output Contract is present, in
  the documented shape and types
- Every signal that is `true` has at least one concrete evidence entry
  pointing to a real path or manifest fact
- Dependencies are flattened to the four-field record shape — no
  ecosystem-specific extras leak into the common fields
- Surfaces include `evidence` strings that a reader can verify by
  opening the referenced file
- Activity figures match what the version-control history would show
  for the same window — no inflation, no deduplication errors that
  drop authors
- `warnings` lists every section that was skipped, truncated, or
  guessed at — silence implies completeness

A bundle fails the quality bar when any of the above is violated —
e.g. evidence that does not match the signal's rule
(`hasCustomerVisibleAPI: true` because of an internal admin route).

## Anti-Patterns

**The narrative bundle.** Replacing structured fields with paragraphs
of explanation. The bundle is consumed by code and other skills —
prose belongs in the wiki layers downstream, not here.

**The guessed license.** Filling in a license value because the
package name "looks open-source." If license metadata is not in the
manifest or registry response actually consulted, emit `null`.

**The unbounded crawl.** Walking dependency caches, version-control
internals, or generated build outputs. These distort file counts and
dwarf the signal. Apply ignore rules before counting.

## Critical Rules

1. **The bundle shape is contractual.** Downstream skills index into
   it by name. Adding, renaming, removing, or restructuring a field
   without bumping `schemaVersion` is a breaking change — new facts go
   in existing fields, or the version bumps.

2. **Every `true` signal needs evidence.** Booleans drive expensive
   downstream work; an unevidenced `true` is worse than `false`
   because it triggers wasted layer generation.

3. **Read once, emit once.** This skill exists to amortise repo
   reading across many consumers. Re-walking the tree for each section
   defeats the cost-saving rationale; build the structure in a single
   pass.

4. **Never write to the repo.** Analysis is read-only. No files are
   created, modified, or staged. The output is the bundle.

5. **Do not invoke audience-layer skills.** Layer dispatch is the
   orchestrator's responsibility. This skill produces the analysis;
   the orchestrator decides what runs against it.

6. **Surface every gap as a warning.** Truncated dependency lists,
   missing manifests, unreadable history, ambiguous signals — all go
   into `warnings`. A clean bundle with a populated `warnings`
   array is more useful than a "complete" bundle with hidden gaps.

7. **Keep the bundle reproducible.** Two runs over the same commit
   with the same options should produce the same bundle (modulo
   ordering of equally-ranked items, which should be sorted
   deterministically — by path, then by name).
