# Example Output — Stage 1.1 Customer Insights

Illustrative example for a B2B invoicing product for small businesses. Data inventory: pNPS export (412 responses), support tickets (1,890, 6 months), 8 interview summaries. Your output should follow this structure exactly — the content will of course differ.

## Data Inventory

| Source | Type | Records | Key Fields |
|--------|------|---------|------------|
| pnps_q2.csv | pNPS | 412 | score, comment, plan, submitted_at |
| tickets_jan_jun.csv | Support | 1,890 | subject, category, priority, created_at |
| interview_notes.md | Feedback | 8 interviews | verbatim notes, role |

## Top 5 Opportunities

| # | Pattern | Severity (1-10) | User Segment | Business Impact | Opportunity |
|---|---------|-----------------|--------------|-----------------|-------------|
| 1 | Manual re-entry of supplier invoices — users retype data from PDFs into the system | 8 — 34% of detractor verbatims mention "manual work"; #1 ticket category (312 tickets); all 8 interviewees demonstrated a paper-based workaround | Bookkeepers at 5–20 employee firms | High — top stated reason for considering competitors; affects the daily core workflow | Automated invoice data extraction (scan/upload → structured draft) |
| 2 | No visibility into payment status without leaving the product | 7 — 118 tickets ("did my invoice get paid?"); recurring interview theme (6 of 8) | Owner-operators invoicing directly | High — drives support load and daily anxiety; churn-adjacent | Payment status timeline + proactive notifications |
| 3 | Recurring invoice setup is hard to find and configure | 6 — 87 tickets; pNPS passives cite "clunky" setup; feature exists but usage data shows only 9% adoption among eligible users | Firms with subscription-style billing | Medium — existing feature failing silently; adoption problem, not build problem | Redesign recurring invoice setup flow; surface at first relevant moment |
| 4 | Mobile app can't create credit notes | 6 — 54 tickets; 3 interviewees keep a laptop "just for corrections" | Field-service businesses | Medium — forces channel-switch mid-task for a mobile-first segment | Bring credit note creation to mobile parity |
| 5 | Confusing VAT handling for cross-border sales | 5 — 41 tickets, seasonal spikes at reporting deadlines; low pNPS mention rate | Firms selling outside home market (~12% of base) | Medium — small segment but high-stakes errors; compliance risk perception | Guided VAT flow for cross-border invoices with validation |

**Confidence note:** Opportunities 1–2 are corroborated by 3 sources (strong). Opportunity 5 rests mainly on tickets (moderate) — flagged accordingly.

## What good looks like

- Every severity score cites **specific evidence** (counts, percentages, quotes) — never a bare number
- Segments are **specific** ("bookkeepers at 5–20 employee firms"), not generic ("users")
- The Opportunity column names a **product direction**, not a restatement of the pain
- Weak single-source patterns are either excluded or explicitly flagged
