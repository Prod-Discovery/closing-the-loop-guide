# Expected Data Formats — Stage 1.1 Customer Insights

Column names do **not** need to match these exactly. They describe the concepts the analysis looks for — map whatever columns the user provides onto these roles, and ask only when a mapping is genuinely ambiguous.

## pNPS (product Net Promoter Score)

| Column role | Typical names | Required? | Notes |
|---|---|---|---|
| Score | `score`, `nps`, `rating` | Yes | 0–10 scale. Classify: 0–6 detractor, 7–8 passive, 9–10 promoter |
| Verbatim | `comment`, `feedback`, `why` | Strongly recommended | The open-text answer — the analysis mostly runs on this |
| Segment | `segment`, `plan`, `company_size`, `role` | No | Enables per-segment pain patterns |
| Date | `date`, `submitted_at` | No | Enables trend detection |

## CES (Customer Effort Score)

| Column role | Typical names | Required? | Notes |
|---|---|---|---|
| Score | `ces`, `effort`, `score` | Yes | Usually 1–7 or 1–5. Confirm the scale and direction (is high = easy or hard?) with the user if unclear |
| Task/flow | `task`, `flow`, `touchpoint` | Strongly recommended | Which interaction the score refers to |
| Verbatim | `comment`, `feedback` | Recommended | |
| Segment / Date | as above | No | |

## Support tickets

| Column role | Typical names | Required? | Notes |
|---|---|---|---|
| Subject/summary | `subject`, `title`, `summary` | Yes | |
| Description | `description`, `body`, `first_message` | Recommended | Full text if available |
| Category | `category`, `tag`, `topic` | Recommended | Pre-existing taxonomy accelerates pattern detection |
| Priority/severity | `priority`, `severity` | No | |
| Created date | `created_at`, `date` | No | |
| Resolution | `status`, `resolution` | No | Unresolved clusters are a strong signal |

## Customer / user feedback (interviews, surveys, feature requests)

Free-form is fine. Useful columns when present: source (`interview`, `survey`, `in-app`), verbatim text, requester segment, date. A plain text or Markdown document of interview notes is also acceptable — it does not need to be a CSV.

## Usage / behavioral data

| Column role | Typical names | Notes |
|---|---|---|
| Feature/event | `feature`, `event`, `action` | What was used |
| Count / frequency | `count`, `sessions`, `users` | Volume metric |
| Segment | `segment`, `plan` | Optional |
| Period | `week`, `month`, `date` | Optional |

Usage data is supporting evidence — it shows *what* users do, not *why*. Pair it with verbatim sources before treating a pattern as a pain point.

## General rules

- **Minimum viable input**: one source with verbatim text. Score-only files (numbers, no comments) support severity calibration but can't generate pain patterns alone — tell the user this if that's all they have.
- **Encoding/format problems** (wrong delimiter, merged columns): show the user the first 3 rows as parsed and ask them to confirm before analyzing.
- **Multiple files of the same type**: treat as one source for cross-referencing purposes, but note the file split in the data inventory.
- **Non-English data**: analyze in the source language; output the analysis in the conversation language. Quote verbatims in the original with a translation.
