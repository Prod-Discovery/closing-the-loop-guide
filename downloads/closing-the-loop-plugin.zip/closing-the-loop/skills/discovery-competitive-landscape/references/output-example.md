# Example Output — Stage 1.2 Competitive Landscape

Condensed example: accounting/ERP software for small businesses in a Nordic market, three competitors. Your table will be fuller — this shows structure, tone, and sourcing style. (The product/market here is only an example — apply the same structure to any domain.)

## Comparison Table

| Category | CompetitorA | CompetitorB | CompetitorC | Sources |
|----------|-------------|-------------|-------------|---------|
| Must-haves | • Bank feeds<br>• Invoice + VAT reports<br>• Accountant access | • Bank feeds<br>• Invoice + VAT reports<br>• Accountant access | • Bank feeds<br>• Invoice + VAT reports<br>• ~~Accountant access~~ (add-on) | vendor sites, pricing pages |
| Should-haves | • 40+ integrations<br>• Payroll module | • 200+ integrations<br>• Payroll partner only | • 25 integrations<br>• Payroll module | integration directories |
| Delighters | • Auto-categorization praised in reviews ("magic") | — none found | • Free migration service incl. historical data | G2 reviews, vendor site |
| Performance | • Bank sync: real-time | • Bank sync: daily batch | • Bank sync: real-time<br>• Publishes 99.9% uptime SLA | docs, status pages |
| Adoption tactics | • Free for <20 invoices/mo<br>• Accountant referral program | • 6 months half price<br>• Annual contract only | • Free migration<br>• Month-to-month pricing | pricing pages |
| Limitations | • Mobile app rated 2.8/5 (iOS)<br>• Complaints: slow support (23 of 60 recent G2 reviews) | • UI called "dated" across review sites<br>• No API rate above 100 req/min | • Small integration ecosystem<br>• No English-language UI | app stores, G2, Capterra |

## Competitive Gap Summary — Input for Opportunity Framing

**Where competitors lead:**
- Integration breadth (CompetitorB, 200+) — Signal: Moderate — matters mainly for mid-market prospects
- Free/low-cost entry tiers (A and C) — Signal: Strong — all serious players now have one

**Where competitors are weak:**
- Mobile experience — weak across all three (best-rated app: 3.4/5) — Signal: Strong
- Support responsiveness — recurring complaint for A and B — Signal: Moderate

**Market whitespace:**
- No competitor offers proactive cash-flow warnings (all are record-keeping, none advisory) — Signal: Strong
- Cross-border VAT guidance absent everywhere — Signal: Moderate

**Emerging trends:**
- AI-assisted transaction categorization — A ships it, B announced beta — Maturity: Becoming standard
- E-invoicing compliance features — all three investing (regulatory driver) — Maturity: Table stakes within 12 months

## What good looks like

- Every cell traces to a **named public source**; gaps say "Limited public data available" instead of guessing
- Limitations cite **volume** ("23 of 60 recent reviews"), not single anecdotes
- The gap summary uses the exact signal-strength labels (Strong/Moderate/Weak) and maturity labels — Stage 1.3 parses these
- Parent-company relationships between the user's product and a competitor are flagged for the user to confirm (keep or replace)
