# Kano-Style Categorization Guide — Stage 1.2 Competitive Landscape

How to sort competitor findings into the six analysis categories. The first three follow the Kano model (basic → performance → excitement); the last three capture competitive dynamics the classic model misses.

## The six categories

### 1. Must-haves (Kano: basic needs)
Features whose *absence* causes rejection, but whose presence earns no credit. The market assumes them.

- **Test:** would a prospect eliminate a vendor from a shortlist for not having this? → must-have.
- **Examples:** login/SSO in B2B tools; invoice PDF export in accounting software; mobile app for a consumer service.
- **Signal to capture:** does each competitor have it (yes/no) — depth doesn't matter much here.

### 2. Should-haves (Kano: performance needs)
Features where *more/better is linearly better* and buyers actively compare. These decide shortlists.

- **Test:** does this feature appear in comparison pages, review pros/cons, and sales battle-cards? → should-have.
- **Examples:** number of bank integrations; report customization depth; API coverage.
- **Signal to capture:** not just presence but *how good* — this is where relative strength matters.

### 3. Delighters / Exciters (Kano: excitement needs)
Unexpected capabilities that create disproportionate enthusiasm. Absence costs nothing (nobody expects them); presence differentiates.

- **Test:** do reviews mention it with surprise or enthusiasm ("I didn't expect...", "game changer")? → delighter.
- **Examples:** an accounting tool that auto-drafts replies to auditor queries; one-click migration from a named competitor.
- **Caution:** delighters decay into should-haves and then must-haves over time (see Emerging trends). Note the trajectory.

### 4. Performance benefits
Measurable operational advantages that cut across features: speed, automation depth, integration breadth, onboarding time, uptime, scale limits.

- **Test:** can you attach a number to it? ("processes invoices in 3s", "500+ integrations", "go-live in 1 day")
- Capture the number and the source. If competitors publish conflicting numbers, note both.

### 5. Adoption & retention tactics
How competitors *acquire and keep* customers, as opposed to what the product does: pricing model, free tier, migration incentives, onboarding approach, ecosystem lock-in, partner channels.

- **Examples:** free tier up to N invoices/month; accountant-partner referral program; annual-only contracts; data export friction (a lock-in tactic worth flagging).

### 6. Notable limitations
Weaknesses and recurring complaints. Strongest evidence source: negative review patterns (G2/Capterra 1–3 star reviews, app store complaints, forum threads).

- **Test:** does the same complaint appear from 3+ independent reviewers? → include with sources. One-off complaints → exclude.
- Capture *shared* limitations separately (all competitors weak = whitespace) from *specific* ones (one competitor weak = positioning angle).

## Categorization heuristics

- **When torn between must-have and should-have:** check low-end competitors. If even the cheapest player has it → must-have.
- **When torn between should-have and delighter:** check buyer expectation. If prospects *ask* for it in sales conversations → should-have. If they only value it after seeing it → delighter.
- **Same feature, different categories per market:** e.g. AI-assisted entry may be a delighter for micro-businesses but a should-have for mid-market. Categorize for the *user's target market* (from Stage 0 context).
- **Don't force balance:** a category can be empty for a competitor. "No notable delighters found" is a valid, useful finding.
- **Every claim needs a source.** If it can't be sourced, either drop it or mark it explicitly as "unverified."
