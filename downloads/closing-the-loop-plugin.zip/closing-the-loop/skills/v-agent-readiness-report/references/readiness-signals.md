# Agent Readiness Signals

Signals version: `2026-10` (write it to `generator.signalsVersion`).

A check catalog for `v-agent-readiness-report`, distilled from vendor guidance
(Anthropic Claude Code, OpenAI Codex, GitHub Copilot coding agent, the
AGENTS.md spec) and practitioner analyses. It tells you what to look for; the
answer is always one of AIEA's checklist options, backed by concrete evidence
from the repo.

The recurring definition across sources: a repo is agent-ready when an agent
can complete a non-trivial task end-to-end — find the commands, run them, edit
within allowed scope, verify, and show evidence — using only what is committed
to the repo.

## Which AIEA questions a repo scan answers

| AIEA capability | Scan | Evidence for the option |
| --- | --- | --- |
| `agentic-context-ai-instructions` (checkbox) | direct | Root and path-scoped rule files, prompt files, committed skills, agents, hooks, MCP config |
| `agentic-context-dev-loop` | direct | Documented build, test, lint and run commands; CI validation; how the agent verifies its own changes |
| `foundation-delivery-environment-readiness` | direct | Devcontainer, compose, setup scripts, cloud-agent setup steps, infrastructure as code |
| `foundation-verification-fast-feedback` | direct | PR checks, lint, static analysis, security scans, per-file feedback loops, CI duration |
| `foundation-verification-test-coverage` | partial | Whether tests exist and CI blocks on them; the scan can't see whether the team trusts the suite |
| `foundation-delivery-path-to-production` | partial | CD workflows, release and tag cadence |
| `foundation-codebase-health` | partial | Structure, boundaries, churn hotspots |
| `agentic-delegation-and-scoping` | partial | Share of agent-authored commits and PRs in history |
| `agentic-tooling-multi-agent-orchestration` | partial | Committed subagent definitions, parallel agent branches |
| `agentic-tooling-ai-strategy` | partial | Shared committed tool config; evaluation and measurement aren't visible in a repo |
| `agentic-tooling-team-culture` | never | Only the questionnaire can answer this: put it in `notAssessed` |

"Partial" means answer with `medium` or `low` confidence and say in the note
what the repo cannot show. Never pick an option whose wording claims more
than the files prove (for example "the team trusts the test suite"); choose
the highest option the evidence fully supports. If a newer checklist adds a
capability that isn't in this table, answer it only when the repo shows direct
evidence.

Three judgment calls recur:

- **Not a service.** For a CLI or library, "start the service and verify its
  own changes" means running the built entry point (or an example) plus the
  tests, with both documented as commands.
- **Release gates.** CI that blocks a release or deploy on the test suite is
  strong indirect evidence of a trusted suite: level 2 at `medium`
  confidence. Level 3 also needs no manual verification step between merge
  and production.
- **Product assets.** Count only skills, hooks, agents and MCP config that
  steer agents working *on this repository*. Ones the repository ships as its
  product don't count toward `agentic-context-ai-instructions`.

The pillars below feed those capabilities. Safety & Guardrails,
Documentation and Repository Shape have no AIEA capability; report them as
`extraPillars`.

## Agent Context → `agentic-context-ai-instructions`, `agentic-context-dev-loop`

- Root `AGENTS.md` exists and is hand-written, not generated boilerplate.
  Hand-curated files measurably improve task success; generated ones that
  duplicate the README measurably hurt.
- Concise: agents lose instructions "in the middle" of long files (~150-line
  guidance for the root file; Codex truncates project docs at 32 KiB).
  Bloated context files cause agents to ignore the rules that matter.
- Content passes the deletion test: "would removing this line cause an agent
  to make a mistake?" Commands agents can't guess, conventions that differ
  from defaults, env quirks, gotchas — not restated README material.
- Executable commands appear early, copy-pasteable with exact flags — not
  described ("run the tests" vs the actual command line).
- One real code snippet showing house style beats paragraphs describing it.
- Monorepos: nested per-package context files; the closest file to the edited
  code wins. Root stays a map (stack, global commands, boundaries).
- Tool-specific layers present where the team uses them: `CLAUDE.md` (and
  child-directory files), `.github/copilot-instructions.md`,
  `.github/instructions/*.instructions.md` with `applyTo` globs,
  `AGENTS.override.md` for Codex-specific overrides.
- Context files churn alongside code in history (maintained, not rotting).

## Tool Configuration → `agentic-context-ai-instructions`, `agentic-tooling-ai-strategy`, `agentic-tooling-multi-agent-orchestration`

- MCP servers configured with described tools — an intent statement and input
  schema per tool; bare tool names force agents to guess from training data.
- Reusable workflows checked in where the team uses them: skills, prompt
  files, custom agent definitions, subagents.
- Permission allowlists and hooks committed (settings that let agents run the
  safe commands without prompts and be blocked from the unsafe ones).

## Verification → `foundation-verification-fast-feedback`, `foundation-verification-test-coverage`, `agentic-context-dev-loop`

- A check the agent can run for any change: tests, build exit code, linter,
  fixture diff, screenshot comparison. This is the single most emphasized
  signal in vendor guidance — without it the human is the verification loop.
- Commands documented with runtimes and when-to-run guidance (unit vs
  integration vs end-to-end), so agents pick the right suite.
- File-scoped feedback loops: per-file type-check/lint and per-package test
  commands documented alongside full-suite variants. When the only loop is a
  minutes-long suite, agents skip verification.
- Deterministic gates where advisory rules fail: hooks that run the linter
  after edits or block writes to protected paths; CI that actually blocks.
- Advisory gates match documented expectations (a lint step the docs call
  mandatory should not be `continue-on-error` in CI).
- Evidence discipline: PR template or convention requiring test output and
  commands run, not assertions of success.

## Environment Reproducibility → `foundation-delivery-environment-readiness`

- One-command environment setup (script or devcontainer) so an agent can go
  from clone to running checks deterministically. Trial-and-error dependency
  discovery is slow and unreliable for cloud agents.
- Cloud-agent environment config where the team uses them:
  `.github/workflows/copilot-setup-steps.yml` preinstalling dependencies for
  Copilot's ephemeral environment; setup scripts/container config for Codex
  cloud environments.
- Network needs declared: allowlisted hosts for agent firewalls; nothing that
  silently requires unstated credentials or VPN.

## Delivery → `foundation-delivery-path-to-production`

- Deployment workflows committed and triggered by merges or tags, not run by
  hand; release cadence visible in tags and workflow history.
- Promotion flow and deployment rules written down, with any prechecks
  scripted.

## History & Activity → `agentic-delegation-and-scoping`, `foundation-codebase-health`

- Agent adoption visible in authorship (bot/agent authors landing commits,
  agent-opened PRs) — evidence of how much work is delegated.
- Active, multi-author development; context files maintained as code evolves.
- Churn hotspots identified; hot paths covered by the verification story.

## Repository Shape → `foundation-codebase-health`, extra pillar

- Predictable structure with accepted-practice naming; agents navigate by
  convention.
- Explicit boundaries in three tiers: always fine / ask first / never touch
  (secrets, vendored deps, generated dirs, infra state, lockfiles by hand).
- Generated artifacts are labeled as such (migrations, snapshots, codegen
  output) with the regeneration command documented.
- Toolchain pinned and machine-readable: SDK/runtime version files, package
  manager pins, engine constraints.

## Documentation → extra pillar

- README gives an accurate map: what this is, layout, how to run it.
- One canonical setup path; duplicated quickstarts drift and steer agents to
  the stale copy.
- Architecture notes explain the non-inferable why (decisions, invariants),
  not file-by-file tours.
- Committed plans/specs carry status (active/done/abandoned) so agents don't
  execute stale intent.
- Sync rules live at the point of change (e.g. a directory-scoped context
  file: "editing files here requires updating doc X").

## Safety & Guardrails → extra pillar

- Branch protection on the default branch: required CI plus at least one
  human review — table stakes once agents author PRs.
- CODEOWNERS routes agent-touched paths to owning reviewers.
- Dependency-update automation and secret/code scanning enabled (agent-heavy
  repos process automated update PRs cheaply).
- No secrets in the repo; committed config is placeholder-only; secret
  handling documented.

## Prioritizing repo actions

AIEA's recommendation engine owns the general advice (workshops, practices).
`repoActions` are the repository-specific fixes next to it:

- **Next level only.** For each answered capability, act on the checklist's
  `levelRequirements` for the level above the one achieved — not the whole
  ladder.
- **Gap-weighted.** A small fix on the lowest capability outranks polish on a
  strong one; lead with the top three.
- **Cutoff exclusion.** Never recommend what the evidence already shows.
- **Executable.** Every action carries a `fixPrompt`: exact files, the
  verification step, and do-not-touch constraints.

## Sources

- Anthropic, "Best practices for Claude Code" — code.claude.com/docs/en/best-practices
- AGENTS.md spec — agents.md
- OpenAI, "Custom instructions with AGENTS.md" — developers.openai.com/codex/guides/agents-md
- GitHub, "How to write a great agents.md: lessons from 2,500 repositories" — github.blog
- GitHub, "Onboarding your AI peer programmer" (Copilot coding agent setup) — github.blog
- GitHub Docs, "Customize the agent environment" (copilot-setup-steps.yml) — docs.github.com
- RoboRhythms, "Make your repo agent-ready in 8 checks" — roborhythms.com
