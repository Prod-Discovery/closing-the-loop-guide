# Agent Readiness Signals

A check catalog for `v-agent-readiness-report`, distilled from vendor guidance
(Anthropic Claude Code, OpenAI Codex, GitHub Copilot coding agent, the
AGENTS.md spec) and practitioner analyses. Use it to decide what to look for
per pillar; every signal still needs concrete evidence from the repo.

The recurring definition across sources: a repo is agent-ready when an agent
can complete a non-trivial task end-to-end — find the commands, run them, edit
within allowed scope, verify, and show evidence — using only what is committed
to the repo.

## Score Bands: The Agentic Ladder

Score bands reuse the rungs of the AIEA agentic ladder (Visma's "AI in
Engineering" playbook; see `v-guidance`, `references/agentic-ladder.md`) so a
readiness score and an AIEA maturity conversation use the same words. A band
names the highest rung the repository is ready to support:

- **0–39 assistance** — safe only for inline suggestions; agents lack the
  committed context and verification to do more without close hand-holding.
- **40–69 supervision** — agents can take multi-file tasks with a human
  directing, reviewing, and approving each step.
- **70–89 delegation** — a single agent can run a workflow end-to-end: context
  is discoverable, verification is scripted, gates actually block.
- **90–100 orchestration** — the repo can host parallel agentic workflows:
  reproducible environments, enforced boundaries, and safety rails hold up
  without a human watching each agent.

## Agent Context

- Root `AGENTS.md` exists and is hand-written, not generated boilerplate.
  Hand-curated files measurably improve task success; generated ones that
  duplicate the README measurably hurt.
- Concise: agents lose instructions "in the middle" of long files (~150-line
  guidance for the root file; Codex truncates project docs at 32 KiB).
  Bloated context files cause agents to ignore the rules that matter.
- Content passes the deletion test: "would removing this line cause an agent
  to make a mistake?" Commands agents can't guess, conventions that differ
  from defaults, env quirks, gotchas — not restated README material.
- Executable commands appear early, copy-pasteable with exact flags — not
  described ("run the tests" vs the actual command line).
- One real code snippet showing house style beats paragraphs describing it.
- Monorepos: nested per-package context files; the closest file to the edited
  code wins. Root stays a map (stack, global commands, boundaries).
- Tool-specific layers present where the team uses them: `CLAUDE.md` (and
  child-directory files), `.github/copilot-instructions.md`,
  `.github/instructions/*.instructions.md` with `applyTo` globs,
  `AGENTS.override.md` for Codex-specific overrides.
- Context files churn alongside code in history (maintained, not rotting).

## Verification

- A check the agent can run for any change: tests, build exit code, linter,
  fixture diff, screenshot comparison. This is the single most emphasized
  signal in vendor guidance — without it the human is the verification loop.
- Commands documented with runtimes and when-to-run guidance (unit vs
  integration vs end-to-end), so agents pick the right suite.
- File-scoped feedback loops: per-file type-check/lint and per-package test
  commands documented alongside full-suite variants. When the only loop is a
  minutes-long suite, agents skip verification.
- Deterministic gates where advisory rules fail: hooks that run the linter
  after edits or block writes to protected paths; CI that actually blocks.
- Advisory gates match documented expectations (a lint step the docs call
  mandatory should not be `continue-on-error` in CI).
- Evidence discipline: PR template or convention requiring test output and
  commands run, not assertions of success.

## Documentation

- README gives an accurate map: what this is, layout, how to run it.
- One canonical setup path; duplicated quickstarts drift and steer agents to
  the stale copy.
- Architecture notes explain the non-inferable why (decisions, invariants),
  not file-by-file tours.
- Committed plans/specs carry status (active/done/abandoned) so agents don't
  execute stale intent.
- Sync rules live at the point of change (e.g. a directory-scoped context
  file: "editing files here requires updating doc X").

## Repository Shape

- Predictable structure with accepted-practice naming; agents navigate by
  convention.
- Explicit boundaries in three tiers: always fine / ask first / never touch
  (secrets, vendored deps, generated dirs, infra state, lockfiles by hand).
- Generated artifacts are labeled as such (migrations, snapshots, codegen
  output) with the regeneration command documented.
- Toolchain pinned and machine-readable: SDK/runtime version files, package
  manager pins, engine constraints.

## Environment Reproducibility

- One-command environment setup (script or devcontainer) so an agent can go
  from clone to running checks deterministically. Trial-and-error dependency
  discovery is slow and unreliable for cloud agents.
- Cloud-agent environment config where the team uses them:
  `.github/workflows/copilot-setup-steps.yml` preinstalling dependencies for
  Copilot's ephemeral environment; setup scripts/container config for Codex
  cloud environments.
- Network needs declared: allowlisted hosts for agent firewalls; nothing that
  silently requires unstated credentials or VPN.

## Tool Configuration

- MCP servers configured with described tools — an intent statement and input
  schema per tool; bare tool names force agents to guess from training data.
- Reusable workflows checked in where the team uses them: skills, prompt
  files, custom agent definitions.
- Permission allowlists and hooks committed (settings that let agents run the
  safe commands without prompts and be blocked from the unsafe ones).

## Safety & Guardrails

- Branch protection on the default branch: required CI plus at least one
  human review — table stakes once agents author PRs.
- CODEOWNERS routes agent-touched paths to owning reviewers.
- Dependency-update automation and secret/code scanning enabled (agent-heavy
  repos process automated update PRs cheaply).
- No secrets in the repo; committed config is placeholder-only; secret
  handling documented.
- Deployment rules and promotion flow written down, with any prechecks
  scripted.

## History & Activity

- Active, multi-author development; context files maintained as code evolves.
- Agent adoption visible in authorship (bot/agent authors landing commits) —
  evidence the readiness investment is exercised, and the strongest argument
  for closing guardrail gaps.
- Churn hotspots identified; hot paths covered by the verification story.

## Prioritizing Recommendations

Method adapted from Visma's AIBooster maturity-assessment engine
(weight × gap prioritization, cutoff exclusion, progressive visibility):

- **Priority = impact weight × gap.** A recommendation's urgency is how much
  the pillar matters times how far it sits from the target band. A small fix
  on the weakest pillar outranks polish on a strong one.
- **Cutoff exclusion.** Never recommend what a passing check already shows;
  drop zero-gap recommendations entirely.
- **Progressive visibility.** Per pillar, surface the single next step — the
  action that reaches the next band — not the whole ladder to a perfect score.
- **Tier the output.** Lead with the top three actions; collapse or tier the
  remainder so the reader starts moving instead of triaging.
- **Make each action executable.** Pair it with a `fixPrompt` the team can
  paste into their coding agent: exact files, verification step, and
  do-not-touch constraints.

## Sources

- Anthropic, "Best practices for Claude Code" — code.claude.com/docs/en/best-practices
- AGENTS.md spec — agents.md
- OpenAI, "Custom instructions with AGENTS.md" — developers.openai.com/codex/guides/agents-md
- GitHub, "How to write a great agents.md: lessons from 2,500 repositories" — github.blog
- GitHub, "Onboarding your AI peer programmer" (Copilot coding agent setup) — github.blog
- GitHub Docs, "Customize the agent environment" (copilot-setup-steps.yml) — docs.github.com
- RoboRhythms, "Make your repo agent-ready in 8 checks" — roborhythms.com
