# Agent Readiness Report Contract

This file defines the normalized JSON shape used by `v-agent-readiness-report`.
The HTML renderer is intentionally tolerant: unknown fields are ignored, so
teams can add local extensions without breaking older renderers.

## Top-Level Shape

```json
{
  "schemaVersion": "1.0",
  "generatedAt": "2026-06-26T12:00:00Z",
  "title": "Agent Readiness Report",
  "summary": {
    "overallScore": 74,
    "maturity": "delegation",
    "repositoryCount": 2,
    "topRisk": "Verification commands are not documented consistently"
  },
  "rawSources": [],
  "checks": [],
  "repositories": [],
  "recommendations": [],
  "extensions": {}
}
```

## Fields

### `summary`

- `overallScore`: number from 0 to 100, or `null` when no score can be
  computed.
- `maturity`: the agentic-ladder rung the score band maps to — the highest
  rung of the AIEA agentic ladder (Visma's "AI in Engineering" playbook) the
  repository is ready to support: `assistance` (0–39), `supervision` (40–69),
  `delegation` (70–89), `orchestration` (90–100). Custom labels are allowed,
  but rung-aligned labels keep successive reports comparable and match the
  language used in AIEA maturity conversations.
- `repositoryCount`: number of repositories assessed.
- `topRisk`: single highest-impact risk in plain language.

### `rawSources[]`

Use this to preserve where evidence came from.

```json
{
  "repo": "billing-api",
  "kind": "baseline-analyzer",
  "path": "reports/raw/billing-api-agent-readiness.json",
  "status": "available",
  "notes": "Structured output captured without modification"
}
```

Recommended `kind` values:

- `baseline-analyzer` — an optional external analyzer the user explicitly
  requested; a default run records no analyzer source at all
- `local-scan` — the bundled evidence collector and other local observation
- `history`
- `continuous-integration`
- `prior-report` — an earlier assessment bundle whose dated evidence is
  reused (say when it was collected in `notes`)
- `manual-note`

Recommended `status` values:

- `available`
- `unavailable`
- `skipped`
- `partial`

### `checks[]`

Use this for individual observations before they are grouped into repo
summaries.

```json
{
  "id": "agent-context.root-file",
  "repo": "billing-api",
  "pillar": "Agent Context",
  "score": 100,
  "status": "pass",
  "evidence": ["AGENTS.md exists at repository root"],
  "recommendation": null,
  "source": "local-scan"
}
```

Recommended `status` values:

- `pass`
- `warn`
- `fail`
- `unknown`
- `skipped`

`score` is 0–100, or `null` when the check is informational or was skipped.

### `repositories[]`

Each repository gets its own summary. A multi-repo report should never rely only
on a portfolio average.

```json
{
  "name": "billing-api",
  "path": "/workspace/billing-api",
  "branch": "main",
  "score": 74,
  "maturity": "delegation",
  "summary": "Good verification, missing agent-specific context.",
  "pillars": [],
  "findings": [],
  "history": {
    "commits": 84,
    "authors": 7,
    "window": "90 days",
    "notes": ["High churn in payment validation files"]
  }
}
```

### `repositories[].pillars[]`

Pillars are intentionally open-ended so an upstream analyzer can keep its own
taxonomy.

```json
{
  "name": "Verification",
  "score": 82,
  "status": "warn",
  "evidence": [
    "Continuous integration runs build and unit checks",
    "No documented command for full local verification"
  ],
  "recommendations": [
    "Document the complete local verification command in agent context"
  ]
}
```

### `repositories[].findings[]`

Findings should be concrete enough to become work items.

```json
{
  "severity": "high",
  "title": "Agent context is missing",
  "description": "The repo has custom verification commands but no agent-facing instructions.",
  "evidence": ["No AGENTS.md, CLAUDE.md, or equivalent file found"],
  "recommendation": "Create a short root context file with exact verification commands.",
  "fixPrompt": "Create an AGENTS.md at the repo root: document the exact build and test commands from package scripts, the directory layout, and anything non-obvious you find in CI config. Keep it under 60 lines. Verify every command runs before writing it down.",
  "effort": "small"
}
```

`fixPrompt` is optional: a self-contained prompt the team can paste into their
coding agent (Claude Code, Codex, Copilot, or any other harness) to implement
the fix. Write it for a fresh session in that repository: name the exact
files, include the verification step, and state what must not be touched. The
renderer shows it with a copy button.

Recommended `severity` values:

- `critical`
- `high`
- `medium`
- `low`
- `info`

Recommended `effort` values:

- `small`
- `medium`
- `large`
- `unknown`

### `recommendations[]`

Use top-level recommendations for cross-repo themes or the highest-priority
repo-specific actions.

```json
{
  "priority": 1,
  "repo": "billing-api",
  "title": "Add agent context",
  "impact": "high",
  "effort": "small",
  "evidence": ["Custom verification commands exist but are not agent-facing"],
  "nextAction": "Author root agent instructions and rerun the report",
  "fixPrompt": "Create an AGENTS.md at the repo root documenting verified build and test commands. Keep it under 60 lines."
}
```

Recommendations accept the same optional `fixPrompt` field as findings, plus
an optional `gain`: the estimated overall-score points unlocked by completing
the action (derived from the checks it would flip; the renderer shows it as an
"est. +N pts" chip). Order recommendations gap-weighted: impact times distance
from the next score band, so a small fix on the weakest pillar outranks polish
on a strong one. Recommend the step that reaches the next band, not the end
state, and never recommend what a passing check already shows.

### `extensions`

Use this object for team-specific data, new analyzer adapters, or experimental
signals. Keep extension fields additive. Do not change or overload the core
fields above when adding new checks.

## Comparing Runs

Keep one canonical `<repo>-agent-readiness.{json,html}` pair per repository.
Before writing a new pair, archive the previous one with its assessment date
(for example `billing-api-agent-readiness-2026-07-02.json`). A prior bundle is
a legitimate evidence source: cite it in `rawSources` as `kind: prior-report`
with the original assessment date in `notes`, and mention notable score
movements in the new report's summary.

## HTML Expectations

The rendered report should be self-contained and readable without a network
connection. It should show:

- Overall maturity, score, repository count, and top risk
- Repository comparison table
- Per-repo pillar summaries
- Findings ordered by severity
- Recommendations ordered by priority
- Copy-paste fix prompts wherever findings or recommendations carry them
- Any skipped or unavailable evidence sources

## Extension Pattern

When adding a new analyzer or local check:

1. Preserve the raw output in `rawSources`.
2. Convert each useful signal into `checks`.
3. Attach repo-level rollups to `repositories[].pillars` or
   `repositories[].findings`.
4. Add cross-repo themes to `recommendations`.
5. Place experimental fields under `extensions` until they prove stable.
