# Agent Readiness Report Contract (2.x)

The report answers AIEA's own capability questions with repository evidence.
AIEA owns the questions, scoring, level names and recommendations; this JSON
is what AIEA stores (`add_readiness_report`) and what the local HTML renders.
One file serves both, so the HTML and the upload never disagree.

## Shape

```json
{
  "schemaVersion": "2.0",
  "source": "agent-readiness-report",
  "generatedAt": "2026-10-15T09:00:00Z",
  "generator": { "skill": "v-agent-readiness-report", "skillVersion": "<visma-skills release>", "signalsVersion": "2026-10" },
  "aiea": { "assessmentId": "<guid>", "modelSetVersionId": "<guid from the live checklist>" },
  "summary": { "topRisk": "Agents cannot run or verify the service on their own" },
  "repositories": [
    {
      "name": "billing-api",
      "remoteUrl": "https://github.com/example-org/billing-api",
      "branch": "main",
      "commit": "a1b2c3d",
      "applicationId": "<AIEA application id, when known>",
      "isPrimary": true,
      "answers": [
        {
          "capabilityId": "agentic-context-ai-instructions",
          "value": [1, 2],
          "confidence": "high",
          "evidence": [
            { "option": 1, "path": "AGENTS.md", "note": "Root rule file, 84 lines, hand-written" },
            { "option": 2, "path": ".github/instructions/api.instructions.md", "note": "applyTo: src/api/**" }
          ]
        },
        {
          "capabilityId": "agentic-context-dev-loop",
          "value": 1,
          "confidence": "high",
          "evidence": [{ "option": 1, "path": "AGENTS.md", "note": "Build and test listed; no run or verify step" }]
        }
      ],
      "notAssessed": ["agentic-tooling-team-culture"],
      "repoActions": [
        {
          "capabilityId": "agentic-context-dev-loop",
          "title": "Let the agent start the service and verify its own changes",
          "severity": "high",
          "effort": "small",
          "evidence": ["AGENTS.md lists build but not run or verify commands"],
          "fixPrompt": "In AGENTS.md, add the exact commands to start the API locally and to check a change end to end…"
        }
      ],
      "extraPillars": [
        { "name": "Safety & Guardrails", "status": "warn", "evidence": ["No CODEOWNERS file"] }
      ]
    }
  ],
  "extensions": {}
}
```

## Rules AIEA enforces on upload

| Field | Rule |
| --- | --- |
| `schemaVersion` | Required; major version `2` |
| `generatedAt` | Required ISO 8601 timestamp, not in the future |
| `aiea.assessmentId` | Optional; must match the target assessment |
| `aiea.modelSetVersionId` | Optional; must match the assessment's model set. Copy it from a live checklist only, never from the bundled snapshot |
| `repositories` | Required, 1–50 entries |
| `repositories[].name` | Required; at most 200 characters; no control, format or invisible characters |
| `answers[].capabilityId` | A capability of the assessment's checklist, at most once per repository |
| `answers[].value` | `SingleChoice`: one option `index`. `Checkbox`: non-empty array of distinct option indices |
| `notAssessed` | Capability ids that are not also answered |

The whole document is capped at 128 KB. AIEA stores every other field
unvalidated, so adding fields never breaks an upload.

## Field meanings

- **`answers[]`** — only capabilities the repository shows evidence for. A
  missing answer means "not assessed", never level 0. `value` uses the
  checklist's option `index`, not its `mappedLevel`.
- **`evidence[]`** — per selected option: a repo-relative `path` and a short
  `note`. Never file contents, secrets, tokens, or personal data.
- **`confidence`** — `high` (the file shows it directly), `medium` (strong
  indirect signal), `low` (inferred; say why in the note).
- **`notAssessed`** — capabilities the scan cannot judge from a repository.
- **`repoActions[]`** — repository-specific fixes keyed by `capabilityId`,
  or by `pillar` (the extra pillar's `name`) when no capability fits. `severity`: `critical | high | medium |
  low`; `effort`: `small | medium | large`; `evidence` for the gap. `fixPrompt` is a self-contained
  prompt for a fresh agent session in that repository: exact files, the
  verification step, and what must not be touched.
- **`extraPillars[]`** — checks AIEA has no capability for (Safety &
  Guardrails, Documentation, Repository Shape). `status`: `pass | warn |
  fail | unknown`, with `evidence`. AIEA stores them but does not score them.
- **`aiea`** — set both ids from the live checklist when connected; omit the
  object when the report was made from the snapshot and not yet re-checked.
- **`summary.topRisk`** and **`extensions`** — local reading aids and
  team-specific data. Keep extension fields additive.

## Local preview scoring

The HTML shows a preview computed with AIEA's scoring rule. It is labelled as
a preview; AIEA's results page is authoritative.

- Capability level: `SingleChoice` → the selected option's `mappedLevel`;
  `Checkbox` → the highest selected `mappedLevel` (`HighestSelected`) or
  their mean (`AverageSelected`).
- Category level: mean of its answered capabilities. Overall: mean of the
  categories with at least one answer. Unanswered capabilities drop out.
- A level's name is the checklist level at `round(level)` (half rounds up),
  shown with the precise value as `x.xx / 3.0`.
- The next step for a capability is the checklist's `levelRequirements` for
  the level above the one achieved.

## Rendering without the script

If the bundled renderer cannot run, produce equivalent self-contained HTML
from the same JSON: preview label, per-repo levels, capability answers with
evidence, next-level requirements, actions with fix prompts, extra pillars,
and what was not assessed.

## Comparing runs

Keep one canonical `<name>-agent-readiness.{json,html}` pair. Before writing a
new pair, archive the previous one with its date (for example
`billing-api-agent-readiness-2026-07-02.json`). Answers keyed by
`capabilityId` compare directly across runs on the same model set; after a
model change, compare levels, not option indices.
