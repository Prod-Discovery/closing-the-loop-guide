# AIEA's MCP server

Read by **v-agent-readiness-report** when AIEA's MCP server is connected
(tools such as `get_readiness_checklist`): at step 2 to get the questions,
and at step 7 to add the report.

## Get the questions (step 2)

Find the team's assessment with `get_my_assessment` or `find_assessments`. If
the team has none and wants the report in AIEA, find the application with
`find_applications`, confirm the team name and application with the user,
and start one with `start_assessment` (if the server has no such tool, ask
the user to start the assessment in AIEA, and continue). Fetch the checklist
with `get_readiness_checklist` and save it as `<output>/checklist.json`.

## Add the report (step 7)

Only when the user says yes:

1. Show the user what will be added: team, application, repositories, preview
   levels, and the top actions.
2. If you answered from the snapshot, fetch the live checklist first. Re-answer
   every capability whose options changed (count or text), re-render, and
   check again.
3. Set `aiea.assessmentId` and `aiea.modelSetVersionId` from the live
   checklist, then call `add_readiness_report`. Clients that support it show
   AIEA's own confirmation as well.
4. On a validation error, fix the fields it names. Never drop answers or
   evidence just to make an upload pass.
