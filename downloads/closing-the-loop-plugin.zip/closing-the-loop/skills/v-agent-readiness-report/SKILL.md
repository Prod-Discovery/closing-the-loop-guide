---
name: v-agent-readiness-report
description: Use when a user wants an agent-readiness scorecard, an AIEA readiness report, a before/after adoption check, or a prioritized plan for making a repo work better with coding agents. Answers AIEA's own capability questions with repository evidence and renders a static HTML preview; when AIEA's MCP server is connected and the user agrees, adds the report to the team's AIEA assessment. Assesses only; fixes go to v-ship or v-build.
license: Apache-2.0
---

# Agent Readiness Report

## Objective

Answer AIEA's capability questions (Visma's AI Engineering Accelerator) for one
or more repositories, with evidence for every answer, plus repository-specific
fixes with copy-paste prompts and a local HTML preview. AIEA owns the
questions, scoring, level names and recommendations; the report sits beside
the team's questionnaire in AIEA and never changes its answers.

## When to Use

- A readiness report for one repo or several, locally or in AIEA: a first
  scorecard, a before/after comparison, or prioritized fixes.

Do not use this skill when:
- The user already knows the gap and wants the repo fixed now.
- The user wants a quick opinion, not a report.

## Workflow

### 1. Scope the Assessment

Confirm the target repositories and output location; prefer checked-out
local paths. With no location named, use `.reviews/agent-readiness/` in the
working directory, keep it out of version control, state the path in the
summary, and archive a previous run as `./references/report-contract.md`
(Comparing runs) describes.

For each repository, record its name, local path, remote URL, branch, commit,
and any constraint the user gives ("do not contact remote services", "last
quarter of history only").

### 2. Get AIEA's Questions

The checklist decides what you answer: its capabilities, options and option
indices, and level requirements.

- **AIEA's MCP server is connected** (tools such as `get_readiness_checklist`):
  find or start the team's assessment and save the live checklist as
  `<output>/checklist.json` — see `./references/aiea-mcp.md`.
- **Otherwise** (not connected, readiness reports not enabled for the user, or
  a local-only report): use `./references/aiea-checklist.json`, a snapshot of
  AIEA's active model set, and say so in the summary.

### 3. Run the Bundled Evidence Collector

It needs only a Python runtime and the git CLI — no installs, no network:

```sh
python3 ./scripts/collect_agent_readiness_evidence.py <repo-path> <output-dir>/raw/<repo>-evidence.json
```

If it cannot run, gather the same facts — context files and tool assets,
workflows, toolchain pins, safety config, repository shape, history, and
agent-authored commit share — with your own file and history tools. Run an
external analyzer only when it is already installed or the user asks, keep
its output unrewritten under `raw/`, and never install or fetch one.

### 4. Answer the Questions

Use `./references/readiness-signals.md`: it says which capabilities a repo
scan can answer and what evidence counts for each. Add the judgment no script
can make — instruction quality, whether gates actually block, doc duplication.

Per repository and capability, choose the highest option the evidence fully
supports, never one whose wording claims more than the files prove; a
checkbox question takes every option that applies. A capability the
repository cannot show goes in `notAssessed`, never in a low answer.
`value`, `evidence` and `confidence` follow `./references/report-contract.md`.

On a re-assessment, read the previous report first: reuse dated evidence you
cannot re-collect, say so in the note, and call out level movements in the
summary.

### 5. Add Repository Actions and Extra Pillars

For each answered capability below level 3, the unmet `levelRequirements` of
the next level up — only the next level, never what the evidence already
shows — become `repoActions`, each with a `fixPrompt`. Safety & Guardrails,
Documentation and Repository Shape have no AIEA capability: report them as
`extraPillars`. Field rules are in `./references/report-contract.md`.

### 6. Write the Report and Render the HTML

Write `<name>-agent-readiness.json` following `./references/report-contract.md`
(set `generator.signalsVersion` from the signals file's header), then render:

```sh
python3 ./scripts/render_agent_readiness_report.py <report.json> <report.html> --checklist <output>/checklist.json
```

Leave out `--checklist` when you used the snapshot. The renderer computes
levels with AIEA's scoring rule and labels them as a preview. If it cannot
run, see `./references/report-contract.md` (Rendering without the script).

### 7. Add the Report to AIEA

Only when AIEA's MCP server is connected and the user says yes: follow
`./references/aiea-mcp.md`.

When AIEA's MCP server is not connected, keep the JSON for a later upload and
say so. Never guess a server address or walk the user through configuring
one.

### 8. Recommend the Next Move

Lead with the top three actions, and separate quick wins from deeper work.
Once the report is in AIEA, point to the assessment's results page for the
official levels and AIEA's recommendations. When the report shows missing
context or verification gaps, suggest **v-ship**
(`references/agent-context.md`): a first-time bootstrap or targeted context
fixes.

**Sharing the report.** The `.html` report is made to be read by the whole
team, not just the person who ran it. When an artifact-publishing tool is
available (`Artifact` in Claude Code), offer — never do it silently — to
publish the report as a private page whose link the user can drop in a channel
or a pilot kickoff doc. Without such a tool, the saved `.html` file is the
share path.

## Output Contract

### Summary

One or two lines: report path, repository count, preview overall level
(labelled preview), whether the report was added to AIEA, and the top risk.

### Detail

The `.html` report and the `.json` it was rendered from, the raw inputs kept
beside them (Critical Rule 3), archives of replaced runs, and a short summary
of the top actions.

### Verification

Collector status per repository (and analyzer status when requested); the
checklist source (live model set id, or the snapshot's capture date); the
renderer outcome and report path; the AIEA upload result (report id) or why
it was not added; capabilities left `notAssessed` and data that was
unavailable.

### Follow-ups

Non-blocking actions such as adding missing context files, wiring verification
into continuous integration, answering the not-assessed capabilities in the
AIEA questionnaire, or running a remediation skill. Write `"None"` when there
are none.

## Quality Bar

A readiness report meets the bar when:

- Every answer cites evidence for each selected option.
- Unanswerable capabilities are `notAssessed`, not low answers.
- The HTML and the uploaded JSON come from the same file.
- Every level shown locally is labelled as a preview.

It fails the bar when it was added to AIEA without the user's go-ahead, or
against an unchecked snapshot.

## Anti-Patterns

**Generous answers.** An option one step too high inflates the team's AIEA
levels and hides the very gap the report exists to show. When in doubt, pick
the lower option and say what would prove the higher one.

**Portfolio averages hiding risk.** A strong average can conceal one repo that
agents cannot safely modify. Always show per-repo gaps.

**A second source of truth.** Rewording AIEA's questions, adding local
capabilities to the checklist, or keeping a private scale makes the report
drift from AIEA. New checks go in `extraPillars` until AIEA adopts them.

## Critical Rules

1. **Evidence is paths and short notes.** Never put file contents, secrets,
   tokens or personal data in the report: AIEA stores it as uploaded and the
   whole team can read it.
2. **Local-first by default.** Apart from the connected AIEA server, do not
   fetch hosted repositories or contact remote services unless the user asked
   and credentials are available.
3. **Keep raw inputs.** Store collector output, any analyzer output, and the
   checklist next to the report so it can be audited or rerun.
4. **Do not remediate during assessment.** Report the fixes; make them only
   after explicit user direction.

## Choices and next steps

Whenever this skill offers a choice (lettered options, yes or no) or a next step:

- **Use buttons when you can.** If you have a tool for clickable options (`AskUserQuestion` in Claude Code and Cowork), use it: one question, one button per option, worded like the list in this skill, keeping any "(Recommended)" label. Buttons mirror the listed options exactly — never add one that isn't an option.
- **Every path you just offered is a button.** If the message names ways forward in prose ("you could also iterate…", "or start a new run"), they all become buttons — never surface only a subset of them; with more than 4, use the lettered list so no option disappears.
- **Fall back to the list.** Without such a tool, show the lettered list as written so the user can answer with one letter.
- **Ask follow-ups in chat.** If an option needs more input ("tell me which"), ask for it after they pick. Corrections, feedback and data stay in chat, never in buttons.
- **Show where the user is.** Start each pause with one line placing the user in the loop — the phase this skill belongs to and the step within it, for example `Loop · Handover — shaping #6` or `Loop · Delivery — S-2 of 7`. Skip it when the skill runs standalone.
