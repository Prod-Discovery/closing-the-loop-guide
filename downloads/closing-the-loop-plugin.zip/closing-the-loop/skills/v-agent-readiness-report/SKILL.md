---
name: v-agent-readiness-report
description: Assess one or more repositories for AI-agent readiness and produce evidence-backed static HTML plus JSON findings, scored on the AIEA agentic ladder (assistance, supervision, delegation, orchestration). Use when a user wants an agent-readiness scorecard, before/after adoption report, or prioritized plan for improving repo ergonomics for coding agents.
trigger: [agent readiness report, audit agent readiness, score repo for agents, ai readiness scorecard, html readiness report]
license: Apache-2.0
---

# Agent Readiness Report

## Objective

Create a durable, evidence-backed readiness report for one or more
repositories. The report should answer: how ready is this repo for coding
agents, what evidence supports that score, and what should the team improve
first?

The skill deliberately separates assessment from remediation. It may recommend
agent context, verification, documentation, or workflow changes, but it does
not perform those changes unless the user asks for follow-up work.

## When to Use

- A team wants a static HTML readiness report for a repo or portfolio of repos.
- The user wants to compare readiness before and after adopting coding agents.
- A repository owner wants prioritized, evidence-backed improvements for agent
  ergonomics.
- A group wants to extend the readiness check catalog with local checks.

Do not use this skill when:
- The user already knows the gap and wants the repo fixed immediately.
- The target is not available locally and the user has not approved fetching it.
- The desired output is only a short conversational opinion, not a report.

## Workflow

### 1. Scope the Assessment

Confirm the target repositories and output location. Prefer checked-out local
paths; if the user supplies hosted URLs, fetch them only when credentials,
network access, and user intent are clear.

When the user names no output location, default to `.reviews/agent-readiness/`
in the working directory, keep it out of version control, and state the path in
the summary. Write report artifacts into an assessed repository only when the
user asks. If the output directory already holds a previous run, archive that
bundle with its assessment date (for example
`billing-api-agent-readiness-2026-07-02.json`) instead of overwriting it.

For each target, record:

- Repository name and local path
- Default branch if available
- Assessment timestamp
- Whether the repository is standalone or part of a larger workspace
- Any constraints the user gives, such as "do not contact remote services" or
  "include only the last quarter of history"

### 2. Run the Bundled Evidence Collector

The skill is self-sufficient: the bundled collector plus your own judgment is
the baseline. Nothing needs to be installed and no network access is required.

```sh
python3 ./scripts/collect_agent_readiness_evidence.py <repo-path> <output-dir>/raw/<repo>-evidence.json
```

It gathers deterministic facts — context files and tool assets, workflows,
toolchain pins, safety config, repository shape, history, and agent-authored
commit share — using only a Python runtime and the git CLI. Store its JSON
output under the output directory and record it as a `local-scan` raw source.
If the environment cannot execute it, gather the same facts with your own file
and history tools instead.

External analyzers (for example Kodus Agent Readiness) are an optional
cross-check, never the default: run one only when it is already installed or
the user explicitly asks for it, and record its output unrewritten as a
`baseline-analyzer` raw source. Never install or fetch one on your own, and do
not mention an analyzer the run never attempted — a default report carries no
analyzer row at all.

### 3. Collect Local Evidence

Interpret the collector's facts and add the judgment evidence no script can
gather — instruction quality, whether gates actually block, doc duplication.
Use `./references/readiness-signals.md` as the check catalog: it covers every
pillar (agent context, verification, documentation, history signals,
repository shape, environment reproducibility, tool configuration, safety)
and distills what vendor guidance and field data say each should contain.

Every finding must cite concrete evidence: a file path, a command result, a
history query, or a baseline analyzer check. Unknowns stay unknown.

On a re-assessment, read the previous normalized bundle before collecting
evidence: reuse dated evidence you cannot re-collect (for example a
network-verified check in an offline run), cite it as a `prior-report` source
with its original date, and call out score movements in the summary.

### 4. Normalize the Findings

Convert all evidence into the normalized contract in
`./references/report-contract.md`. Keep these layers separate:

- `rawSources`: where collector output, local observations, and any optional
  analyzer output came from
- `checks`: individual scored or observed checks
- `repositories`: per-repo summary, pillars, findings, and history notes
- `recommendations`: cross-repo or high-priority actions
- `extensions`: local fields added by a team or future analyzer adapter

The normalized JSON is the extension point. New analyzers and local checks
should add evidence to the contract rather than changing the HTML renderer.

When no baseline analyzer supplies scores, score each check 0–100, roll pillars
up from their checks, and set the overall score to the mean of pillar scores.
Maturity speaks the language of the agentic ladder from Visma's "AI in
Engineering" playbook (the AIEA framing — see **v-guidance**): the score band
names the highest ladder rung the repository is ready to support. Shared
bands: 0–39 assistance, 40–69 supervision, 70–89 delegation, 90–100
orchestration. Pick the maturity label from the overall band so successive
reports stay comparable and readiness conversations use the same rungs as the
AIEA.

Give each finding and recommendation with a concrete fix a `fixPrompt`: a
self-contained prompt the team pastes into their coding agent to implement it.
Write it for a fresh session in that repository — exact files, the
verification step, and what must not be touched.

### 5. Render the HTML Report

Generate a static HTML report from the normalized JSON. Use the bundled
renderer when the current environment can execute it — arguments are
positional:

```sh
python3 ./scripts/render_agent_readiness_report.py <bundle.json> <report.html>
```

Otherwise produce equivalent self-contained HTML using the same contract.

The report must include:

- Overall maturity and score
- Per-repo score table
- Per-pillar results with evidence
- Prioritized findings with severity and effort
- Recommended next actions
- Clear note of any skipped checks or unavailable data

Keep the HTML self-contained: no external assets are required to read it.

### 6. Recommend the Next Move

End with a concise interpretation of the report. Prioritize gap-weighted:
impact times distance from the next score band, so a small fix on the weakest
pillar outranks polish on a strong one. Recommend the step that reaches the
next band per pillar rather than the end state, lead with the top three
actions, and never recommend what a passing check already shows. Separate
immediate quick wins from deeper work. When the report shows missing context or verification gaps,
suggest the relevant follow-up skill by name, but do not start remediation
unless the user asks. The usual route is **v-setup-agent-context** — it
covers both a full first-time agent-readiness bootstrap of the repo and
targeted fixes when only the context files (`AGENTS.md` or equivalent) are
missing.

## Output Contract

### Summary

One or two lines stating the report path, repository count, overall readiness
score or maturity label, and the top risk.

### Detail

Produce these artifacts:

- A static `.html` readiness report
- A normalized `.json` evidence bundle following `./references/report-contract.md`
- The collector's raw evidence JSON (and analyzer output when one was
  requested)
- Date-suffixed archives of any previous run the new report replaced
- Copy-paste fix prompts on findings and recommendations with concrete fixes
- A short written summary of top findings and recommended next actions

### Verification

Report how the result was confirmed:

- Evidence collector status for each repository (and analyzer status only when
  one was explicitly requested)
- Local evidence sources collected
- Renderer outcome and report path
- Any checks skipped because data, credentials, or network access were
  unavailable

### Follow-ups

List non-blocking actions such as adding missing context files, wiring
verification into continuous integration, extending the normalized contract, or
running a remediation skill. Write `"None"` when no follow-up is needed.

## Quality Bar

A readiness report meets the bar when:

- Each score is backed by evidence or clearly marked as unavailable.
- The static HTML opens without external services.
- The normalized JSON is kept beside the HTML for future comparison.
- Recommendations are prioritized by impact and effort.
- Multi-repo reports make cross-repo comparisons without hiding per-repo gaps.

It fails the bar when:

- It repeats an analyzer score without evidence.
- It treats missing data as a passing check.
- It mixes remediation changes into the assessment without user approval.
- It cannot be regenerated because raw inputs were discarded.

## Anti-Patterns

**Score theater.** A polished dashboard with unexplained numbers is less useful
than a plain report with file-backed evidence. Keep every score traceable.

**One analyzer owns the truth.** External analyzers are optional cross-checks,
not the assessment. The bundled collector plus the check catalog is the
baseline; preserve any analyzer output as one more evidence source.

**Portfolio averages hiding risk.** A strong average can conceal one repo that
agents cannot safely modify. Always show per-repo gaps.

**Assessment drift.** If the HTML and JSON disagree, future comparisons become
meaningless. Generate both from the same normalized bundle.

## Critical Rules

1. **Evidence first.** Every finding needs a path, command result, history
   observation, or analyzer check. If evidence is unavailable, say so.
2. **Local-first by default.** Do not fetch hosted repositories or contact
   remote services unless the user asked for that and credentials are available.
3. **Keep raw inputs.** Store collector evidence, any analyzer output, and the
   normalized JSON next to the HTML so the report can be audited or rerun.
   Archive a previous run's bundle with its date; never overwrite it.
4. **Do not remediate during assessment.** Report recommended fixes; perform
   them only after explicit user direction.
5. **Extend through the contract.** Add new checks as normalized evidence and
   renderer-compatible fields, not one-off prose that cannot be compared later.
