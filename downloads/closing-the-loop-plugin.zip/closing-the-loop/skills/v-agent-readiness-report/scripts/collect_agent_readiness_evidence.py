#!/usr/bin/env python3
"""Collect agent-readiness evidence from a repository. Zero dependencies.

This is the skill's native evidence baseline: it gathers deterministic facts
(files, config, git history) using only the Python standard library and the
git CLI, so it runs anywhere an agent harness runs — no installs, no network.
It reports FACTS ONLY. Scoring and judgment stay with the agent, guided by
references/readiness-signals.md, so the rubric can evolve without code changes.

Usage:
    python3 collect_agent_readiness_evidence.py <repo-path> [output.json]
        [--window-days 90]

Output: JSON written to the output path (default: stdout).
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Optional

CONTEXT_FILE_NAMES = [
    "AGENTS.md",
    "CLAUDE.md",
    "GEMINI.md",
    ".cursorrules",
    ".github/copilot-instructions.md",
]

TOOL_ASSET_DIRS = [
    ".github/agents",
    ".github/prompts",
    ".github/instructions",
    ".claude/skills",
    ".claude/agents",
    ".claude/commands",
]

TOOLCHAIN_PINS = [
    ".nvmrc",
    ".node-version",
    "global.json",
    ".python-version",
    ".tool-versions",
    "rust-toolchain",
    "rust-toolchain.toml",
    ".ruby-version",
    ".java-version",
]

LOCKFILES = [
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "bun.lockb",
    "Cargo.lock",
    "poetry.lock",
    "uv.lock",
    "Gemfile.lock",
    "packages.lock.json",
    "composer.lock",
    "go.sum",
]

SETUP_SCRIPT_GLOBS = [
    "scripts/setup*",
    "scripts/bootstrap*",
    "bin/setup*",
    "setup.sh",
    "Makefile",
    "justfile",
    "Taskfile.yml",
]

CODEOWNER_LOCATIONS = ["CODEOWNERS", ".github/CODEOWNERS", "docs/CODEOWNERS"]

AGENT_AUTHOR_PATTERN = re.compile(
    r"\[bot\]|copilot|codex|claude|devin|aider|cursor|jules|sweep",
    re.IGNORECASE,
)


def run_git(repo: Path, *args: str) -> Optional[str]:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), *args],
            capture_output=True,
            text=True,
            timeout=60,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    return result.stdout


def line_count(path: Path) -> Optional[int]:
    try:
        return sum(1 for _ in path.open("r", encoding="utf-8", errors="replace"))
    except OSError:
        return None


def rel(repo: Path, path: Path) -> str:
    return path.relative_to(repo).as_posix()


def existing(repo: Path, candidates: list[str]) -> list[dict[str, Any]]:
    found = []
    for name in candidates:
        path = repo / name
        if path.is_file():
            found.append({"path": name, "lines": line_count(path)})
    return found


def collect_context_files(repo: Path) -> dict[str, Any]:
    root_files = existing(repo, CONTEXT_FILE_NAMES)
    nested: list[dict[str, Any]] = []
    for name in ("AGENTS.md", "CLAUDE.md"):
        for path in repo.glob(f"*/**/{name}"):
            parts = path.relative_to(repo).parts
            if any(p in ("node_modules", ".git", "vendor", "dist") for p in parts):
                continue
            nested.append({"path": rel(repo, path), "lines": line_count(path)})
    assets = {}
    for directory in TOOL_ASSET_DIRS:
        path = repo / directory
        if path.is_dir():
            assets[directory] = sum(1 for p in path.rglob("*") if p.is_file())
    instruction_globs = sorted(
        rel(repo, p) for p in (repo / ".github" / "instructions").glob("*.instructions.md")
    ) if (repo / ".github" / "instructions").is_dir() else []
    return {
        "rootFiles": root_files,
        "nestedFiles": sorted(nested, key=lambda item: item["path"]),
        "toolAssetDirs": assets,
        "pathScopedInstructions": instruction_globs,
    }


def collect_environment(repo: Path) -> dict[str, Any]:
    workflows_dir = repo / ".github" / "workflows"
    workflows = (
        sorted(p.name for p in workflows_dir.glob("*.y*ml")) if workflows_dir.is_dir() else []
    )
    package_json = repo / "package.json"
    package_manager = None
    engines = None
    if package_json.is_file():
        try:
            data = json.loads(package_json.read_text(encoding="utf-8"))
            package_manager = data.get("packageManager")
            engines = data.get("engines")
        except (json.JSONDecodeError, OSError):
            pass
    setup_scripts = []
    for pattern in SETUP_SCRIPT_GLOBS:
        setup_scripts.extend(rel(repo, p) for p in repo.glob(pattern) if p.is_file())
    return {
        "workflows": workflows,
        "copilotSetupSteps": (workflows_dir / "copilot-setup-steps.yml").is_file()
        if workflows_dir.is_dir()
        else False,
        "devcontainer": (repo / ".devcontainer").is_dir()
        or (repo / ".devcontainer.json").is_file(),
        "toolchainPins": existing(repo, TOOLCHAIN_PINS),
        "packageManager": package_manager,
        "engines": engines,
        "lockfiles": [name for name in LOCKFILES if (repo / name).is_file()],
        "setupScripts": sorted(set(setup_scripts)),
        "mcpConfig": [
            name
            for name in (".mcp.json", ".vscode/mcp.json")
            if (repo / name).is_file()
        ],
        "claudeSettings": (repo / ".claude" / "settings.json").is_file(),
    }


def collect_safety(repo: Path) -> dict[str, Any]:
    gitignore = repo / ".gitignore"
    ignores_env = False
    if gitignore.is_file():
        try:
            content = gitignore.read_text(encoding="utf-8", errors="replace")
            ignores_env = bool(re.search(r"^\s*\*?\.env", content, re.MULTILINE))
        except OSError:
            pass
    tracked = run_git(repo, "ls-files")
    tracked_files = tracked.splitlines() if tracked else []
    env_like = [
        name
        for name in tracked_files
        if re.search(r"(^|/)\.env($|\.)", name) and not name.endswith(".example")
    ]
    return {
        "codeowners": [name for name in CODEOWNER_LOCATIONS if (repo / name).is_file()],
        "dependabot": (repo / ".github" / "dependabot.yml").is_file(),
        "renovate": any(
            (repo / name).is_file()
            for name in ("renovate.json", ".github/renovate.json", ".renovaterc")
        ),
        "gitignoreCoversEnvFiles": ignores_env,
        "trackedEnvLikeFiles": env_like[:20],
        "license": any(
            (repo / name).is_file() for name in ("LICENSE", "LICENSE.md", "LICENSE.txt")
        ),
    }


def collect_shape(repo: Path) -> dict[str, Any]:
    tracked = run_git(repo, "ls-files")
    if not tracked:
        return {"trackedFiles": None}
    files = tracked.splitlines()
    extensions = Counter(
        Path(name).suffix.lstrip(".").lower() for name in files if Path(name).suffix
    )
    top_dirs = Counter(name.split("/", 1)[0] for name in files if "/" in name)
    root_markdown = sorted(
        name for name in files if "/" not in name and name.lower().endswith(".md")
    )
    return {
        "trackedFiles": len(files),
        "topExtensions": extensions.most_common(10),
        "topLevelDirs": top_dirs.most_common(15),
        "rootMarkdownFiles": root_markdown,
        "docsDirFileCount": sum(1 for name in files if name.startswith("docs/")),
    }


def collect_history(repo: Path, window_days: int) -> dict[str, Any]:
    since = f"--since={window_days} days ago"
    log = run_git(repo, "log", since, "--format=%an")
    if log is None:
        return {"available": False}
    authors = Counter(name.strip() for name in log.splitlines() if name.strip())
    agent_authors = {
        name: count for name, count in authors.items() if AGENT_AUTHOR_PATTERN.search(name)
    }
    churn_raw = run_git(repo, "log", since, "--name-only", "--format=") or ""
    churn = Counter(name for name in churn_raw.splitlines() if name)
    last_commit = run_git(repo, "log", "-1", "--format=%cI") or ""
    branch = run_git(repo, "rev-parse", "--abbrev-ref", "HEAD") or ""
    head = run_git(repo, "rev-parse", "--short", "HEAD") or ""
    total = sum(authors.values())
    context_churn = {
        name: count
        for name, count in churn.items()
        if Path(name).name in ("AGENTS.md", "CLAUDE.md")
        or name.startswith(".github/instructions")
    }
    return {
        "available": True,
        "windowDays": window_days,
        "branch": branch.strip(),
        "head": head.strip(),
        "lastCommit": last_commit.strip(),
        "commits": total,
        "authors": len(authors),
        "authorCounts": authors.most_common(15),
        "agentAuthors": agent_authors,
        "agentCommitShare": round(sum(agent_authors.values()) / total, 3) if total else None,
        "topChurnFiles": churn.most_common(15),
        "contextFileChurn": context_churn,
    }


def collect_docs(repo: Path) -> dict[str, Any]:
    readme = repo / "README.md"
    return {
        "readme": {"exists": readme.is_file(), "lines": line_count(readme) if readme.is_file() else None},
        "docsDir": (repo / "docs").is_dir(),
        "contributing": any(
            (repo / name).is_file() for name in ("CONTRIBUTING.md", ".github/CONTRIBUTING.md")
        ),
    }


def collect(repo: Path, window_days: int) -> dict[str, Any]:
    return {
        "schemaVersion": "1.0",
        "collector": "collect_agent_readiness_evidence.py",
        "collectedAt": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "repo": {"path": str(repo), "name": repo.name},
        "facts": {
            "contextFiles": collect_context_files(repo),
            "environment": collect_environment(repo),
            "safety": collect_safety(repo),
            "shape": collect_shape(repo),
            "history": collect_history(repo, window_days),
            "docs": collect_docs(repo),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("repo", type=Path, help="Path to the repository to scan.")
    parser.add_argument(
        "output",
        type=Path,
        nargs="?",
        help="Path to write JSON evidence. Defaults to stdout.",
    )
    parser.add_argument(
        "--window-days",
        type=int,
        default=90,
        help="History window in days (default: 90).",
    )
    args = parser.parse_args()

    repo = args.repo.resolve()
    if not repo.is_dir():
        raise SystemExit(f"Not a directory: {repo}")

    payload = json.dumps(collect(repo, args.window_days), indent=2, ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
        print(args.output)
    else:
        print(payload)
    return 0


if __name__ == "__main__":
    sys.exit(main())
