#!/usr/bin/env python3
"""Render an agent-readiness report (contract 2.x) as static HTML.

The report answers AIEA's own capability questions, so the page is driven by
AIEA's checklist: categories, questions, options, levels and level
requirements all come from it (the live checklist saved during the run, or the
bundled snapshot). The renderer never invents a scale of its own.

Design notes (kept so future edits stay coherent):
- Preview, not verdict: levels are computed locally with AIEA's scoring rule
  (single choice -> option level; checkbox -> highest selected, or mean for
  AverageSelected; categories and overall are means; unanswered capabilities
  drop out). Every score is labelled as a preview, because AIEA's results page
  is authoritative.
- Speaks AIEA's visual language (results dashboard, design turn 3a): 0-3
  level medals, "x.xx / 3.0" precise lines, and bars that reveal the brand
  maturity gradient up to the score. Level names come from the checklist.
- Verdict-first: overall level, coverage and top risk share the hero; the
  three most important repo actions come right after.
- Each capability row shows the chosen option in AIEA's words and expands to
  evidence, the next level's requirements (progressive visibility: only the
  next step), and the repo actions with copy-paste fix prompts.
- Checks AIEA has no capability for (extra pillars) render in their own
  section and are never mixed into the preview levels.
- Zero JavaScript required to read; a few lines add expand/collapse, copy
  buttons and open-for-print. Status is triple-encoded (shape, color, text).
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import math
import sys
from pathlib import Path
from typing import Any, Optional

DEFAULT_CHECKLIST = Path(__file__).resolve().parent.parent / "references" / "aiea-checklist.json"

MODEL_TITLES = {"AI": "Agentic Practices", "Foundational": "Engineering Foundation"}
FALLBACK_LEVELS = {0: "Assistance", 1: "Supervision", 2: "Delegation", 3: "Orchestration"}
SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
EFFORT_ORDER = {"small": 0, "medium": 1, "large": 2}
STATUS_META = {
    "pass": ("pass", "Pass", "✓"),
    "warn": ("warn", "Warn", "!"),
    "fail": ("fail", "Fail", "✕"),
    "unknown": ("unknown", "Unknown", "?"),
}


def esc(value: Any, fallback: str = "") -> str:
    if value is None or value == "":
        return html.escape(fallback)
    return html.escape(str(value))


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def dicts(value: Any) -> list[dict[str, Any]]:
    return [item for item in as_list(value) if isinstance(item, dict)]


def round_half_up(value: float) -> int:
    return int(math.floor(value + 0.5))


def mean(values: list[float]) -> Optional[float]:
    return sum(values) / len(values) if values else None


def format_timestamp(raw: Any) -> str:
    try:
        parsed = dt.datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ValueError:
        return str(raw)
    return parsed.strftime("%d %b %Y, %H:%M UTC")


# -- scoring (AIEA ScoringEngine rule, readiness variant) --------------------


class Checklist:
    def __init__(self, data: dict[str, Any]):
        self.data = data
        self.capabilities = dicts(data.get("capabilities"))
        self.by_id = {cap.get("capabilityId"): cap for cap in self.capabilities}
        levels = {
            item.get("level"): item.get("name")
            for item in dicts(data.get("levels"))
            if isinstance(item.get("level"), int)
        }
        self.level_names = {**FALLBACK_LEVELS, **levels}
        self.snapshot = data.get("snapshot") if isinstance(data.get("snapshot"), dict) else None

    def level_name(self, level: Optional[float]) -> str:
        if level is None:
            return "Not assessed"
        return str(self.level_names.get(min(3, max(0, round_half_up(level))), ""))

    def groups(self) -> list[tuple[str, list[tuple[str, list[dict[str, Any]]]]]]:
        """Model -> categories -> capabilities, in checklist order."""
        models: dict[str, dict[str, list[dict[str, Any]]]] = {}
        for cap in self.capabilities:
            models.setdefault(str(cap.get("model", "")), {}).setdefault(str(cap.get("category", "")), []).append(cap)
        return [(model, list(categories.items())) for model, categories in models.items()]


def capability_level(cap: dict[str, Any], value: Any) -> Optional[float]:
    """The capability's level for an answer, or None when the answer is invalid."""
    levels = {opt.get("index"): opt.get("mappedLevel", 0) for opt in dicts(cap.get("options"))}
    if cap.get("questionType") == "Checkbox":
        selected = [i for i in as_list(value) if isinstance(i, int) and not isinstance(i, bool)]
        if not selected or any(i not in levels for i in selected):
            return None
        picked = [float(levels[i]) for i in selected]
        result = mean(picked) if cap.get("scoringStrategy") == "AverageSelected" else max(picked)
    else:
        if isinstance(value, bool) or not isinstance(value, int) or value not in levels:
            return None
        result = float(levels[value])
    return min(result, 3.0)


class RepoScore:
    def __init__(self, repo: dict[str, Any], checklist: Checklist):
        self.repo = repo
        self.answers: dict[str, dict[str, Any]] = {}
        self.levels: dict[str, float] = {}
        self.invalid: list[str] = []
        for answer in dicts(repo.get("answers")):
            cap_id = answer.get("capabilityId")
            cap = checklist.by_id.get(cap_id)
            level = capability_level(cap, answer.get("value")) if cap else None
            if level is None:
                self.invalid.append(str(cap_id))
                continue
            self.answers[cap_id] = answer
            self.levels[cap_id] = level
        self.not_assessed = [str(item) for item in as_list(repo.get("notAssessed"))]

        self.categories: dict[tuple[str, str], Optional[float]] = {}
        self.models: dict[str, Optional[float]] = {}
        for model, categories in checklist.groups():
            category_levels = []
            for category, caps in categories:
                level = mean([self.levels[c["capabilityId"]] for c in caps if c.get("capabilityId") in self.levels])
                self.categories[(model, category)] = level
                if level is not None:
                    category_levels.append(level)
            self.models[model] = mean(category_levels)
        self.overall = mean([level for level in self.categories.values() if level is not None])
        self.answered = len(self.levels)
        self.total = len(checklist.capabilities)


# -- small components ---------------------------------------------------------


def medal(level: Optional[float], small: bool = False) -> str:
    size = " medal-sm" if small else ""
    if level is None:
        return f'<span class="medal medal-none{size}" aria-hidden="true">–</span>'
    rounded = min(3, max(0, round_half_up(level)))
    return f'<span class="medal medal-l{rounded}{size}" aria-hidden="true">{rounded}</span>'


def score_bar(level: Optional[float]) -> str:
    fill = 0 if level is None else max(0.0, min(100.0, level / 3 * 100))
    return f'<div class="score-bar" aria-hidden="true"><span class="score-bar-fill" style="--fill: {fill:.1f}%"></span></div>'


def precise(level: Optional[float]) -> str:
    return "not assessed" if level is None else f"{level:.2f} / 3.0"


def score_card(label: str, level: Optional[float], checklist: Checklist, primary: bool = False) -> str:
    klass = "score-card score-card-primary" if primary else "score-card"
    return f"""
      <div class="{klass}">
        {medal(level)}
        <div class="score-info">
          <span class="eyebrow">{esc(label)}</span>
          <span class="level-pill">{esc(checklist.level_name(level))}</span>
          <div class="precise num">{precise(level)}</div>
          {score_bar(level)}
        </div>
      </div>"""


def level_line(level: Optional[float], checklist: Checklist) -> str:
    if level is None:
        return '<span class="muted">Not assessed</span>'
    return f'<span class="level-word">{esc(checklist.level_name(level))}</span> <span class="num muted">{precise(level)}</span>'


def chip(text: str, klass: str = "") -> str:
    return f'<span class="chip {klass}">{esc(text)}</span>'


def severity_chip(severity: Any) -> str:
    value = str(severity or "medium").lower()
    return f'<span class="chip sev sev-{esc(value)}">{esc(value.capitalize())}</span>'


def fix_prompt(prompt: Any, collapsed: bool) -> str:
    if not prompt:
        return ""
    body = f"""
      <div class="prompt-panel">
        <div class="prompt-head">
          <span class="prompt-label">Fix prompt</span>
          <span class="prompt-hint">Paste into a fresh agent session in this repository</span>
          <button type="button" class="copy-btn" hidden>Copy</button>
        </div>
        <pre class="prompt-text">{esc(prompt)}</pre>
      </div>"""
    if collapsed:
        return f'<details class="row-details"><summary>Show fix prompt</summary>{body}</details>'
    return body


def evidence_list(items: Any) -> str:
    rows = []
    for item in as_list(items):
        if isinstance(item, dict):
            path = item.get("path")
            note = item.get("note")
            parts = []
            if path:
                parts.append(f"<code>{esc(path)}</code>")
            if note:
                parts.append(esc(note))
            if parts:
                rows.append(f"<li>{' — '.join(parts)}</li>")
        elif item:
            rows.append(f"<li>{esc(item)}</li>")
    return f"<ul>{''.join(rows)}</ul>" if rows else '<p class="muted">No evidence recorded.</p>'


def sorted_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        actions,
        key=lambda a: (
            SEVERITY_ORDER.get(str(a.get("severity", "")).lower(), 5),
            EFFORT_ORDER.get(str(a.get("effort", "")).lower(), 3),
        ),
    )


def action_card(action: dict[str, Any], rank: Optional[int], checklist: Optional[Checklist], repo_name: Optional[str]) -> str:
    cap = checklist.by_id.get(action.get("capabilityId")) if checklist else None
    context = []
    if repo_name:
        context.append(esc(repo_name))
    if cap:
        context.append(esc(cap.get("name")))
    elif action.get("pillar") and rank:
        context.append(esc(action.get("pillar")))
    chips = severity_chip(action.get("severity"))
    if action.get("effort"):
        chips += chip(f"{action['effort']} effort")
    rank_html = f'<span class="action-rank num">{rank}</span>' if rank else ""
    evidence = as_list(action.get("evidence"))
    return f"""
      <li class="action">
        <div class="action-head">
          {rank_html}
          <div class="action-body">
            <div class="action-title-row"><h3>{esc(action.get("title"), "Untitled action")}</h3><span class="chips">{chips}</span></div>
            {f'<p class="meta-line">{" · ".join(context)}</p>' if context else ""}
            {evidence_list(evidence) if evidence else ""}
            {fix_prompt(action.get("fixPrompt"), collapsed=bool(rank))}
          </div>
        </div>
      </li>"""


# -- sections -----------------------------------------------------------------


def render_hero(report: dict[str, Any], scores: list[RepoScore], checklist: Checklist) -> str:
    summary = report.get("summary") if isinstance(report.get("summary"), dict) else {}
    if len(scores) == 1:
        score = scores[0]
        cards = score_card("Overall", score.overall, checklist, primary=True)
        cards += "".join(
            score_card(MODEL_TITLES.get(model, model), score.models.get(model), checklist)
            for model, _ in checklist.groups()
        )
        coverage = f"{score.answered} of {score.total} AIEA questions answered from the repository"
    else:
        overalls = [s.overall for s in scores if s.overall is not None]
        lowest = min(overalls) if overalls else None
        cards = score_card("Lowest repository", lowest, checklist, primary=True)
        cards += "".join(
            score_card(str(s.repo.get("name")), s.overall, checklist) for s in scores[:3]
        )
        coverage = f"{len(scores)} repositories · AIEA combines them on its results page"
    risk = summary.get("topRisk")
    risk_html = (
        f'<div class="top-risk"><span class="top-risk-label">Top risk</span><p>{esc(risk)}</p></div>'
        if risk
        else ""
    )
    return f"""
      <div class="hero">
        <div class="preview-note"><strong>Preview.</strong> Levels use AIEA's scoring rule on the answers below; AIEA's results page is authoritative once the report is uploaded.</div>
        <div class="score-grid">{cards}</div>
        <div class="hero-meta"><span>{esc(coverage)}</span></div>
        {risk_html}
      </div>"""


def render_start_here(scores: list[RepoScore], checklist: Checklist) -> str:
    single = len(scores) == 1
    actions = [
        (action, None if single else str(score.repo.get("name")))
        for score in scores
        for action in dicts(score.repo.get("repoActions"))
    ]
    if not actions:
        return ""
    ranked = sorted(
        actions,
        key=lambda pair: (
            SEVERITY_ORDER.get(str(pair[0].get("severity", "")).lower(), 5),
            EFFORT_ORDER.get(str(pair[0].get("effort", "")).lower(), 3),
        ),
    )[:3]
    cards = "".join(action_card(action, i + 1, checklist, repo) for i, (action, repo) in enumerate(ranked))
    return f"""
    <section id="start">
      <div class="section-head"><h2>Start here</h2><span class="section-sub">The three most important repository fixes, each with a prompt for your coding agent</span></div>
      <ol class="action-list">{cards}</ol>
    </section>"""


def render_capability(cap: dict[str, Any], score: RepoScore, checklist: Checklist) -> str:
    cap_id = cap.get("capabilityId")
    answer = score.answers.get(cap_id)
    level = score.levels.get(cap_id)
    options = {opt.get("index"): opt for opt in dicts(cap.get("options"))}
    actions = [a for a in dicts(score.repo.get("repoActions")) if a.get("capabilityId") == cap_id]

    if answer is None:
        return ""  # listed apart, in render_not_assessed

    selected = [i for i in as_list(answer.get("value")) if i in options]
    chosen = "; ".join(str(options[i].get("text", "")) for i in selected)
    evidence_by_option: dict[Any, list[Any]] = {}
    for item in as_list(answer.get("evidence")):
        key = item.get("option") if isinstance(item, dict) else None
        evidence_by_option.setdefault(key, []).append(item)
    evidence_html = ""
    for i in selected:
        evidence_html += f'<h4>Option {i}: level {esc(options[i].get("mappedLevel"))}</h4>{evidence_list(evidence_by_option.pop(i, []))}'
    leftovers = [item for items in evidence_by_option.values() for item in items]
    if leftovers:
        evidence_html += f"<h4>Other evidence</h4>{evidence_list(leftovers)}"

    # AIEA counts a level's requirements as missing when that level is above the achieved one.
    next_level = math.floor(level) + 1 if level is not None and level < 3 else None
    next_html = ""
    if next_level is not None:
        reqs = next(
            (as_list(r.get("requirements")) for r in dicts(cap.get("levelRequirements")) if r.get("level") == next_level),
            [],
        )
        if reqs:
            items = "".join(f"<li>{esc(r)}</li>" for r in reqs)
            next_html = f'<h4>To reach {esc(checklist.level_name(next_level))}</h4><ul>{items}</ul>'

    actions_html = ""
    if actions:
        cards = "".join(action_card(a, None, checklist, None) for a in sorted_actions(actions))
        actions_html = f'<h4>Repository actions</h4><ul class="action-list nested">{cards}</ul>'

    confidence = str(answer.get("confidence") or "").lower()
    conf_chip = chip(f"{confidence} confidence", f"conf-{confidence}") if confidence else ""
    action_chip = chip(f"{len(actions)} action{'s' if len(actions) != 1 else ''}", "chip-action") if actions else ""
    return f"""
        <details class="cap-row">
          <summary>
            {medal(level, small=True)}
            <div class="cap-main"><span class="cap-name">{esc(cap.get("name"))}</span><span class="cap-answer">{esc(chosen)}</span></div>
            <span class="chips">{conf_chip}{action_chip}</span>
            <span class="chevron" aria-hidden="true"></span>
          </summary>
          <div class="cap-body">
            <p class="question">{esc(cap.get("questionTitle"))}</p>
            {evidence_html}
            {next_html}
            {actions_html}
          </div>
        </details>"""


def render_capabilities(score: RepoScore, checklist: Checklist) -> str:
    blocks = []
    for model, categories in checklist.groups():
        rows = []
        for category, caps in categories:
            # A category the scan answered nothing in would only show empty rows.
            if not any(cap.get("capabilityId") in score.answers for cap in caps):
                continue
            level = score.categories.get((model, category))
            caps_html = "".join(render_capability(cap, score, checklist) for cap in caps)
            rows.append(
                f"""
          <div class="category">
            <div class="category-head">
              <h3>{esc(category)}</h3>
              <span class="category-score">{level_line(level, checklist)}</span>
            </div>
            {score_bar(level)}
            <div class="cap-list">{caps_html}</div>
          </div>"""
            )
        if not rows:
            continue
        model_level = score.models.get(model)
        blocks.append(
            f"""
        <div class="model">
          <div class="model-head"><h3 class="model-title">{esc(MODEL_TITLES.get(model, model))}</h3><span class="category-score">{level_line(model_level, checklist)}</span></div>
          {''.join(rows)}
        </div>"""
        )
    return "".join(blocks)


def render_not_assessed(score: RepoScore, checklist: Checklist) -> str:
    """The questions the scan left to the questionnaire: collapsed, and never part of a level."""
    missing = [cap for cap in checklist.capabilities if cap.get("capabilityId") not in score.answers]
    if not missing:
        return ""
    items = "".join(
        f'<li><span class="cap-name">{esc(cap.get("name"))}</span> <span class="muted">{esc(cap.get("category"))}</span></li>'
        for cap in missing
    )
    count = f"{len(missing)} question{'s' if len(missing) != 1 else ''}"
    return f"""
      <details class="not-assessed">
        <summary><span class="not-assessed-title">Not assessed by the scan</span>{chip(count)}<span class="chevron" aria-hidden="true"></span></summary>
        <p class="muted">A repository can't show these, so the scan leaves them to the AIEA questionnaire. They are left out of the levels above.</p>
        <ul>{items}</ul>
      </details>"""


def pillar_actions(score: RepoScore) -> list[dict[str, Any]]:
    return [a for a in dicts(score.repo.get("repoActions")) if not a.get("capabilityId")]


def render_other_actions(score: RepoScore) -> str:
    pillars = {str(p.get("name", "")).lower() for p in dicts(score.repo.get("extraPillars"))}
    other = [a for a in pillar_actions(score) if str(a.get("pillar", "")).lower() not in pillars]
    if not other:
        return ""
    cards = "".join(action_card(a, None, None, None) for a in sorted_actions(other))
    return f'<div class="extra"><div class="section-head"><h3 class="model-title">Other repository actions</h3></div><ul class="action-list">{cards}</ul></div>'


def render_extra_pillars(score: RepoScore) -> str:
    pillars = dicts(score.repo.get("extraPillars"))
    if not pillars:
        return ""
    rows = []
    for pillar in pillars:
        state, label, glyph = STATUS_META.get(str(pillar.get("status", "unknown")).lower(), STATUS_META["unknown"])
        actions = [a for a in pillar_actions(score) if str(a.get("pillar", "")).lower() == str(pillar.get("name", "")).lower()]
        actions_html = (
            f'<h4>Repository actions</h4><ul class="action-list nested">{"".join(action_card(a, None, None, None) for a in sorted_actions(actions))}</ul>'
            if actions
            else ""
        )
        rows.append(
            f"""
        <details class="cap-row">
          <summary>
            <span class="status-dot status-{state}" aria-hidden="true">{glyph}</span>
            <div class="cap-main"><span class="cap-name">{esc(pillar.get("name"))}</span><span class="cap-answer status-text-{state}">{label}</span></div>
            <span class="chevron" aria-hidden="true"></span>
          </summary>
          <div class="cap-body">{evidence_list(pillar.get("evidence"))}{actions_html}</div>
        </details>"""
        )
    return f"""
      <div class="extra">
        <div class="section-head"><h3 class="model-title">Beyond AIEA's questions</h3><span class="section-sub">Checks AIEA has no capability for yet — not scored</span></div>
        <div class="cap-list">{''.join(rows)}</div>
      </div>"""


def render_repo_identity(repo: dict[str, Any]) -> str:
    bits = []
    for key, label in (("branch", "branch"), ("commit", "commit")):
        if repo.get(key):
            bits.append(f"{label} <code>{esc(repo[key])}</code>")
    if repo.get("remoteUrl"):
        bits.append(f'<a href="{esc(repo["remoteUrl"])}">{esc(repo["remoteUrl"])}</a>')
    return f'<p class="meta-line">{" · ".join(bits)}</p>' if bits else ""


def render_repositories(scores: list[RepoScore], checklist: Checklist) -> str:
    single = len(scores) == 1
    sections = []
    for i, score in enumerate(scores):
        repo = score.repo
        invalid = (
            f'<p class="notice">Answers ignored because they do not match this checklist: {esc(", ".join(score.invalid))}. Re-answer them against the current questions.</p>'
            if score.invalid
            else ""
        )
        head = (
            '<div class="section-head"><h2>Capabilities</h2><span class="section-sub">AIEA\'s questions, answered from the repository. Expand a row for evidence and the next step.</span></div>'
            if single
            else f'<div class="section-head"><h2>{esc(repo.get("name"))}</h2><span class="section-sub">{esc(checklist.level_name(score.overall))} · {precise(score.overall)}</span></div>'
        )
        sections.append(
            f"""
    <section id="{'capabilities' if single else f'repo-{i + 1}'}" class="repo">
      {head}
      {render_repo_identity(repo)}
      {invalid}
      {render_capabilities(score, checklist)}
      {render_not_assessed(score, checklist)}
      {render_extra_pillars(score)}
      {render_other_actions(score)}
    </section>"""
        )
    return "".join(sections)


def render_comparison(scores: list[RepoScore], checklist: Checklist) -> str:
    if len(scores) < 2:
        return ""
    models = [model for model, _ in checklist.groups()]
    head = "".join(f"<th>{esc(MODEL_TITLES.get(m, m))}</th>" for m in models)
    rows = []
    for i, score in enumerate(scores):
        cells = "".join(f'<td class="num">{precise(score.models.get(m))}</td>' for m in models)
        rows.append(
            f'<tr><td><a href="#repo-{i + 1}">{esc(score.repo.get("name"))}</a></td>'
            f'<td>{medal(score.overall, small=True)} {esc(checklist.level_name(score.overall))} <span class="num muted">{precise(score.overall)}</span></td>'
            f'{cells}<td class="num">{score.answered}/{score.total}</td></tr>'
        )
    return f"""
    <section id="compare">
      <div class="section-head"><h2>Repositories</h2><span class="section-sub">Preview levels per repository; AIEA decides how they combine for the team</span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>Repository</th><th>Overall</th>{head}<th>Answered</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table></div>
    </section>"""


def checklist_source(checklist: Checklist, report: dict[str, Any]) -> str:
    if checklist.snapshot:
        captured = checklist.snapshot.get("capturedAt", "unknown date")
        return f"AIEA questions from the bundled snapshot (captured {esc(captured)}); re-check against the live checklist before uploading"
    aiea = report.get("aiea") if isinstance(report.get("aiea"), dict) else {}
    model_set = aiea.get("modelSetVersionId") or checklist.data.get("modelSetVersionId")
    return f"AIEA questions from the live checklist (model set <code>{esc(model_set, 'unknown')}</code>)"


CSS = """
:root {
  color-scheme: light;
  /* Visma 2026 tokens as used by AIEA (frontend/src/styles/_visma-tokens.scss) */
  --visma-purple: #7f56fa;
  --ink: #131313; --body-text: #222628; --muted: #6e777c; --faint: #939fa5;
  --line: #d7dde0; --line-soft: #e7ebec; --panel: #ffffff; --bg: #fefefe; --sunken: #f1f2f3;
  --purple-50: #f3eeff; --purple-100: #e7ddff; --purple-200: #cdbbff; --purple-700: #5630c2;
  --good: #1f7a4d; --good-tint: #e4f2ea; --fair: #b5740b; --fair-tint: #fbf0dc;
  --poor: #b3261e; --poor-tint: #fbe9e7; --warning-ink: #7a5310;
  --accent: #6a3fe6; --accent-deep: #5630c2; --action-bg: #131313;
  --gradient-organic:
    radial-gradient(95% 95% at 10% 6%, #7f56fa 0%, rgba(127, 86, 250, 0) 62%),
    radial-gradient(120% 120% at 92% 96%, #ffab65 0%, rgba(255, 171, 101, 0) 72%),
    linear-gradient(135deg, #9172fb 0%, #ce8fb5 52%, #f8ae69 100%);
  --gradient-maturity: linear-gradient(90deg, #7f56fa 0%, #ce8fb5 50%, #ffab65 100%);
  --medal-0: linear-gradient(135deg, #b9c4c9 0%, #6e777c 100%);
  --medal-1: linear-gradient(135deg, #9a75fb 0%, #7f56fa 100%);
  --medal-2: linear-gradient(135deg, #d98fb6 0%, #b76ba0 100%);
  --medal-3: linear-gradient(135deg, #ffc49a 0%, #ffab65 100%);
  --hero-glass: rgba(19, 19, 19, 0.32);
  --radius: 16px; --radius-sm: 8px;
  --shadow: 0 1px 3px rgba(19, 19, 19, 0.08), 0 1px 2px rgba(19, 19, 19, 0.04);
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
@media (prefers-reduced-motion: reduce) { html { scroll-behavior: auto; } }
body { margin: 0; font: 15px/1.5 "Visma Text", system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: var(--body-text); background: var(--bg); -webkit-text-size-adjust: 100%; }
h1, h2, h3 { color: var(--ink); margin: 0; }
h1 { font-size: 27px; font-weight: 700; letter-spacing: -0.02em; }
h2 { font-size: 18px; font-weight: 700; letter-spacing: -0.015em; }
h3 { font-size: 15px; }
h4 { font-size: 11.5px; margin: 12px 0 4px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--muted); }
p { margin: 0 0 10px; }
a { color: var(--accent); text-underline-offset: 2px; }
ul { margin: 4px 0 8px 20px; padding: 0; }
li { margin: 3px 0; }
code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 0.86em; overflow-wrap: anywhere; }
.num { font-variant-numeric: tabular-nums; }
.muted { color: var(--muted); }
main { max-width: 920px; margin: 0 auto; padding: 0 20px 64px; }
section { margin: 34px 0 0; scroll-margin-top: 56px; }
main > section + section { border-top: 1px solid var(--line-soft); padding-top: 28px; }
.section-head { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; margin: 0 0 12px; }
.section-sub { color: var(--muted); font-size: 13px; }
.meta-line { color: var(--muted); font-size: 13px; margin: 0 0 6px; }
.eyebrow { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--muted); margin-bottom: 6px; }

/* hero */
.hero-band { background: var(--gradient-organic); position: relative; }
.hero-band::before { content: ""; position: absolute; inset: 0; pointer-events: none; background: radial-gradient(130% 115% at 20% 10%, rgba(19,19,19,0.28) 0%, rgba(19,19,19,0.12) 45%, transparent 68%); }
.hero-inner { position: relative; max-width: 920px; margin: 0 auto; padding: 30px 20px 30px; }
.page-head { display: flex; flex-wrap: wrap; gap: 6px 16px; align-items: baseline; justify-content: space-between; margin-bottom: 18px; }
.page-head h1 { color: #fff; text-shadow: 0 1px 2px rgba(19,19,19,0.18); }
.page-head .sub { display: block; color: rgba(255,255,255,0.92); font-size: 13px; margin-top: 5px; }
.toolbar { display: flex; gap: 8px; }
.toolbar button { font: inherit; font-size: 12.5px; color: #fff; background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.4); border-radius: 999px; padding: 6px 15px; cursor: pointer; }
.preview-note { color: #fff; font-size: 13px; background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.25); border-radius: var(--radius-sm); padding: 8px 12px; margin-bottom: 14px; }
.score-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; }
.score-card { display: flex; align-items: center; gap: 14px; background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); padding: 16px; min-width: 0; }
.score-card-primary { background: var(--purple-50); border-color: var(--purple-200); }
.score-card-primary .eyebrow { color: var(--purple-700); }
.score-info { flex: 1; min-width: 0; }
.level-pill { display: inline-flex; align-items: center; height: 22px; padding: 0 10px; border-radius: 999px; background: var(--visma-purple); color: #fff; font-size: 11px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; }
.precise { font-size: 13px; color: var(--muted); margin: 6px 0; }
.hero-meta { margin-top: 12px; color: #fff; font-size: 13px; }
.top-risk { margin-top: 12px; background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.28); border-radius: var(--radius); padding: 12px 16px; box-shadow: inset 3px 0 0 rgba(255,255,255,0.85); }
.top-risk-label { display: block; font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: #fff; margin-bottom: 4px; }
.top-risk p { margin: 0; color: #fff; font-size: 13.5px; }

/* medals and bars (AIEA results dashboard, design turn 3a) */
.medal { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 56px; height: 56px; border-radius: 999px; font-size: 26px; font-weight: 700; line-height: 1; color: #fff; box-shadow: inset 0 0 0 3px rgba(255,255,255,0.4); }
.medal-sm { width: 30px; height: 30px; font-size: 14px; box-shadow: inset 0 0 0 2px rgba(255,255,255,0.4); }
.medal-l0 { background: var(--medal-0); }
.medal-l1 { background: var(--medal-1); }
.medal-l2 { background: var(--medal-2); }
.medal-l3 { background: var(--medal-3); color: var(--warning-ink); }
.medal-none { background: var(--sunken); color: var(--faint); box-shadow: inset 0 0 0 1px var(--line); }
.score-bar { position: relative; height: 8px; border-radius: 999px; background: var(--sunken); overflow: hidden; }
.score-card-primary .score-bar { background: var(--panel); }
.score-bar-fill { position: absolute; inset: 0; background: var(--gradient-maturity); clip-path: inset(0 calc(100% - var(--fill, 0%)) 0 0 round 999px); }

/* sticky nav */
.report-nav { position: sticky; top: 0; z-index: 20; background: rgba(255,255,255,0.94); backdrop-filter: blur(8px); border-bottom: 1px solid var(--line); }
.nav-inner { max-width: 920px; margin: 0 auto; padding: 0 20px; display: flex; gap: 2px; overflow-x: auto; scrollbar-width: none; }
.nav-inner a { color: var(--muted); text-decoration: none; font-size: 13px; font-weight: 600; padding: 10px 11px; border-bottom: 2px solid transparent; white-space: nowrap; }
.nav-inner a:hover { color: var(--accent); border-bottom-color: var(--line); }

/* actions */
.action-list { list-style: none; margin: 0; padding: 0; }
.action-list.nested { margin-top: 6px; }
.action { background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); padding: 13px 16px; margin: 0 0 8px; }
.action-head { display: flex; gap: 12px; }
.action-rank { flex: none; width: 26px; height: 26px; border-radius: 999px; background: var(--action-bg); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12.5px; font-weight: 700; }
.action-body { flex: 1; min-width: 0; }
.action-title-row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; justify-content: space-between; margin-bottom: 4px; }
.action-title-row h3 { font-size: 14.5px; }
.chips { display: inline-flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.chip { display: inline-flex; align-items: center; font-size: 11.5px; font-weight: 600; color: var(--muted); background: var(--bg); border: 1px solid var(--line); border-radius: 999px; padding: 2px 9px; white-space: nowrap; }
.sev-critical, .sev-high { color: var(--poor); background: var(--poor-tint); border-color: color-mix(in srgb, var(--poor) 30%, transparent); }
.sev-medium { color: var(--fair); background: var(--fair-tint); border-color: color-mix(in srgb, var(--fair) 30%, transparent); }
.conf-high { color: var(--good); background: var(--good-tint); border-color: color-mix(in srgb, var(--good) 28%, transparent); }
.conf-low { color: var(--fair); background: var(--fair-tint); border-color: color-mix(in srgb, var(--fair) 28%, transparent); }
.chip-action { color: var(--accent-deep); background: var(--purple-50); border-color: var(--purple-200); }

/* capability rows */
.model { margin: 0 0 22px; }
.model-head { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; margin: 0 0 10px; }
.model-title { font-size: 16px; }
.category { background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); padding: 14px 16px 6px; margin: 0 0 10px; }
.category-head { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 8px; }
.category-score { font-size: 13px; }
.level-word { font-weight: 700; color: var(--purple-700); }
.cap-list { margin-top: 8px; }
.cap-row { border-top: 1px solid var(--line-soft); }
.cap-row > summary { display: flex; align-items: center; gap: 12px; padding: 10px 0; list-style: none; }
.cap-row > summary { cursor: pointer; }
.cap-row > summary::-webkit-details-marker { display: none; }
.cap-main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.cap-name { font-weight: 600; font-size: 14px; color: var(--ink); }
.cap-answer { font-size: 13px; color: var(--body-text); }
.cap-body { padding: 0 0 12px 42px; font-size: 14px; }
.question { color: var(--muted); font-style: italic; margin: 0 0 4px; }
.chevron { flex: none; width: 9px; height: 9px; border-right: 2px solid var(--faint); border-bottom: 2px solid var(--faint); transform: rotate(-45deg); transition: transform 0.15s; margin: 0 4px; }
details[open] > summary .chevron { transform: rotate(45deg); }
@media (prefers-reduced-motion: reduce) { .chevron { transition: none; } }
.status-dot { flex: none; width: 30px; height: 30px; border-radius: 999px; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: #fff; }
.status-pass { background: var(--good); } .status-warn { background: var(--fair); } .status-fail { background: var(--poor); } .status-unknown { background: var(--faint); }
.status-text-pass { color: var(--good); font-weight: 600; } .status-text-warn { color: var(--fair); font-weight: 600; } .status-text-fail { color: var(--poor); font-weight: 600; } .status-text-unknown { color: var(--muted); font-weight: 600; }
.extra { margin-top: 18px; }
.extra .cap-list { background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); padding: 0 16px; }
.extra .cap-row:first-child { border-top: 0; }

/* not assessed by the scan (collapsed) */
.not-assessed { margin-top: 14px; border: 1px dashed var(--line); border-radius: var(--radius); background: var(--bg); }
.not-assessed > summary { display: flex; align-items: center; gap: 10px; padding: 12px 16px; cursor: pointer; list-style: none; }
.not-assessed > summary::-webkit-details-marker { display: none; }
.not-assessed-title { flex: 1; font-weight: 600; font-size: 14px; color: var(--muted); }
.not-assessed > p { margin: 0 16px 6px; font-size: 13px; }
.not-assessed ul { margin: 0 16px 12px 36px; font-size: 14px; }

/* fix prompts */
.prompt-panel { border: 1px solid color-mix(in srgb, var(--visma-purple) 30%, transparent); background: var(--purple-50); border-radius: var(--radius-sm); margin: 10px 0 4px; overflow: hidden; }
.prompt-head { display: flex; align-items: center; gap: 8px; padding: 6px 11px; border-bottom: 1px solid color-mix(in srgb, var(--visma-purple) 18%, transparent); }
.prompt-label { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--accent-deep); }
.prompt-hint { font-size: 11.5px; color: var(--muted); flex: 1; }
.copy-btn { font: inherit; font-size: 11.5px; color: #fff; background: var(--action-bg); border: 0; border-radius: 999px; padding: 3px 12px; cursor: pointer; }
.prompt-text { margin: 0; padding: 9px 12px; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; line-height: 1.55; white-space: pre-wrap; overflow-wrap: anywhere; background: var(--panel); }
.row-details { margin-top: 6px; }
.row-details > summary { cursor: pointer; color: var(--accent); font-size: 12.5px; }
summary:focus-visible, a:focus-visible, button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 4px; }

/* tables, notices, footer */
.notice { font-size: 13px; border: 1px solid color-mix(in srgb, var(--fair) 30%, transparent); background: var(--fair-tint); border-radius: var(--radius-sm); padding: 9px 13px; color: #6b4a00; }
.table-wrap { overflow-x: auto; background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th, td { border-bottom: 1px solid var(--line-soft); padding: 8px 13px; text-align: left; vertical-align: middle; }
th { font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--muted); background: var(--bg); white-space: nowrap; }
tr:last-child td { border-bottom: 0; }
td .medal-sm { width: 24px; height: 24px; font-size: 12px; vertical-align: middle; }
footer.page-foot { max-width: 920px; margin: 28px auto 0; padding: 14px 20px 36px; color: var(--muted); font-size: 12px; line-height: 1.6; }
footer.page-foot div { border-top: 1px solid var(--line-soft); padding-top: 14px; }

@media (max-width: 640px) {
  .hero-inner { padding: 20px 16px 22px; }
  main { padding: 0 16px 48px; }
  .medal { width: 46px; height: 46px; font-size: 21px; }
  .cap-body { padding-left: 0; }
  .cap-row > summary .chips { display: none; }
}
@media print {
  .toolbar, .report-nav, .copy-btn { display: none; }
  .hero-band { background: #fff; border-bottom: 1px solid var(--line); }
  .hero-band::before { display: none; }
  .page-head h1, .hero-meta, .preview-note, .top-risk p, .top-risk-label { color: var(--ink); text-shadow: none; }
  .page-head .sub { color: var(--muted); }
  .preview-note, .top-risk { background: #fff; border-color: var(--line); }
  .medal, .score-bar-fill, .status-dot { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .category, .action, .prompt-panel { break-inside: avoid; }
}
"""

JS = """
(function () {
  var toolbar = document.querySelector('.toolbar');
  if (toolbar) {
    toolbar.hidden = false;
    var setAll = function (open) { document.querySelectorAll('details').forEach(function (d) { d.open = open; }); };
    toolbar.querySelector('[data-expand]').addEventListener('click', function () { setAll(true); });
    toolbar.querySelector('[data-collapse]').addEventListener('click', function () { setAll(false); });
  }
  document.querySelectorAll('.copy-btn').forEach(function (btn) {
    btn.hidden = false;
    btn.addEventListener('click', function () {
      var pre = btn.closest('.prompt-panel').querySelector('.prompt-text');
      var done = function () { btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = 'Copy'; }, 1600); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(pre.textContent).then(done, done);
      } else {
        var range = document.createRange(); range.selectNodeContents(pre);
        var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range); done();
      }
    });
  });
  var opened = [];
  window.addEventListener('beforeprint', function () {
    opened = [];
    document.querySelectorAll('details:not([open])').forEach(function (d) { opened.push(d); d.open = true; });
  });
  window.addEventListener('afterprint', function () { opened.forEach(function (d) { d.open = false; }); });
})();
"""


def render_html(report: dict[str, Any], checklist: Checklist) -> str:
    repositories = dicts(report.get("repositories"))
    scores = [RepoScore(repo, checklist) for repo in repositories]
    single = len(scores) == 1
    title = "Agent Readiness Report"
    if single and repositories[0].get("name"):
        title = f"{repositories[0]['name']} · Agent Readiness"
    subtitle = " · ".join(
        [
            "How ready this repository is for AI coding agents" if single else f"How ready these {len(scores)} repositories are for AI coding agents",
            "answered against AIEA's capability questions",
            esc(format_timestamp(report.get("generatedAt", ""))),
        ]
    )
    nav = ['<a href="#start">Start here</a>'] if any(dicts(s.repo.get("repoActions")) for s in scores) else []
    nav += ['<a href="#capabilities">Capabilities</a>'] if single else ['<a href="#compare">Repositories</a>']
    levels = " · ".join(f"{level} {esc(name)}" for level, name in sorted(checklist.level_names.items()))

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <style>{CSS}</style>
</head>
<body>
  <div class="hero-band">
    <div class="hero-inner">
      <header class="page-head">
        <div><h1>{esc(title)}</h1><span class="sub">{subtitle}</span></div>
        <div class="toolbar" hidden><button type="button" data-expand>Expand all</button><button type="button" data-collapse>Collapse all</button></div>
      </header>
      {render_hero(report, scores, checklist)}
    </div>
  </div>
  <nav class="report-nav" aria-label="Report sections"><div class="nav-inner">{''.join(nav)}</div></nav>
  <main>
    {render_start_here(scores, checklist)}
    {render_comparison(scores, checklist)}
    {render_repositories(scores, checklist)}
  </main>
  <footer class="page-foot"><div>
    Preview levels apply AIEA's scoring rule: a capability takes its chosen option's level (the highest selected for checkbox questions),
    categories and the overall level are means, and capabilities the scan did not answer are left out rather than counted as 0.
    Levels: {levels}. {checklist_source(checklist, report)}. Generated by the v-agent-readiness-report skill.
  </div></footer>
  <script>{JS}</script>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="Render an agent-readiness report (contract 2.x) as static HTML.")
    parser.add_argument("report", type=Path, help="Report JSON (contract 2.x).")
    parser.add_argument("output", type=Path, nargs="?", help="HTML path; defaults to the report path with .html.")
    parser.add_argument(
        "--checklist",
        type=Path,
        default=DEFAULT_CHECKLIST,
        help="AIEA checklist JSON the report answered (default: the bundled snapshot).",
    )
    args = parser.parse_args()

    report = json.loads(args.report.read_text(encoding="utf-8"))
    checklist_data = json.loads(args.checklist.read_text(encoding="utf-8"))
    if not isinstance(report, dict) or not isinstance(checklist_data, dict):
        raise SystemExit("The report and the checklist must both be JSON objects.")
    if not str(report.get("schemaVersion", "")).startswith("2."):
        raise SystemExit(f"Unsupported schemaVersion {report.get('schemaVersion')!r}; this renderer reads contract 2.x.")

    checklist = Checklist(checklist_data)
    for repo in dicts(report.get("repositories")):
        invalid = RepoScore(repo, checklist).invalid
        if invalid:
            print(f"warning: {repo.get('name')}: answers that do not match the checklist: {', '.join(invalid)}", file=sys.stderr)

    output = args.output or args.report.with_suffix(".html")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_html(report, checklist), encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
