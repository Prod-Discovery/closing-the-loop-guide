#!/usr/bin/env python3
"""Render a normalized agent-readiness JSON bundle as static HTML.

Design notes (kept so future edits stay coherent):
- Verdict-first: the overall score, maturity verdict, repo context, and top
  risk share the first card; the prioritized action plan comes right after.
- For a single-repo report the repo identity is hoisted into the hero and
  pillars/findings render as top-level sections; multi-repo reports keep
  per-repo sections with an identity card each.
- Pillars render as one aligned meter list, not a card grid: bars sharing an
  axis are directly comparable (bullet-chart guidance), and each row expands
  in place for evidence.
- Score bands are the four rungs of the AIEA agentic ladder (0-39 assistance /
  40-69 supervision / 70-89 delegation / 90-100 orchestration): a band names
  the highest rung the repo is ready to support, so the report speaks the same
  language as AIEA maturity conversations. A segmented scale bar under the
  verdict plots the overall score against the four rungs (and doubles as the
  legend for every meter); the footer repeats the thresholds in plain text for
  print and screen readers.
- Design language follows the Visma 2026 system as implemented in AIBooster
  (frontend/src/styles/_visma-tokens.scss): organic Amplify gradient hero
  (brand moments only), Visma Text-first type, white surfaces with creme/
  sunken panels, purple links, black action buttons, 16px cards. The hero is
  monochrome white-on-gradient (dark-glass panels keep contrast over the
  light rose/orange stops); semantic green/amber/red returns on the page
  surface. The score scale rides the brand maturity gradient
  (purple -> rose -> orange) with rung ticks at 40, 70 and 90. Print flips
  the band to white with dark ink.
- A sticky anchor nav (pure CSS, no JS) keeps long reports navigable:
  Start here / Pillars / Findings / Checks / Sources plus a score chip.
- Actionability devices from AIBooster's gap model: each recommendation may
  carry an estimated overall-score `gain` (rendered as an "est. +N pts"
  chip) and every pillar row shows its distance to the next band.
- Every status is triple-encoded (shape + color + text) so the report works
  for color-blind readers and grayscale printing; print styles keep rank
  numbers and meters visible with backgrounds stripped.
- Findings sort by severity, then effort ascending: a high-severity small
  fix outranks a high-severity large one. Chips that would repeat the same
  value on every row are lifted into the section subtitle instead.
- Zero JavaScript required to read the report; a few lines add expand/collapse
  conveniences, copy buttons for fix prompts, and open details for printing.
- Findings and recommendations may carry a `fixPrompt`: a self-contained
  prompt the team pastes into their coding agent to implement the fix. Inline
  in finding bodies (already opt-in), collapsed inside action cards (keeps the
  ranked list scannable). The copy button is a JS enhancement; the text stays
  selectable without it and prints with the button hidden.
- Recommendation ordering upstream follows a gap-weighted method (impact x
  distance-to-next-band, next step per pillar, top items first) adapted from
  AIBooster's weight-times-gap engine; the renderer just respects `priority`.
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import re
from pathlib import Path
from typing import Any, Optional


SEVERITY_ORDER = {
    "critical": 0,
    "high": 1,
    "medium": 2,
    "low": 3,
    "info": 4,
}

EFFORT_ORDER = {"small": 0, "medium": 1, "large": 2, "unknown": 3}

STATUS_META = {
    "pass": ("pass", "Pass"),
    "warn": ("warn", "Warn"),
    "fail": ("fail", "Fail"),
    "unknown": ("unknown", "Unknown"),
    "skipped": ("skipped", "Skipped"),
}

STATUS_BAND = {"pass": "good", "warn": "fair", "fail": "poor"}

# The AIEA agentic ladder (Visma "AI in Engineering" playbook): score bands
# are ladder rungs, each naming the highest rung the repo is ready to support.
# (threshold, rung label, color state) from top rung down.
LADDER = (
    (90, "orchestration", "peak"),
    (70, "delegation", "good"),
    (40, "supervision", "fair"),
    (0, "assistance", "poor"),
)


def text(value: Any, fallback: str = "n/a") -> str:
    if value is None:
        return fallback
    if isinstance(value, bool):
        return "yes" if value else "no"
    value_text = str(value).strip()
    return value_text if value_text else fallback


def esc(value: Any, fallback: str = "n/a") -> str:
    return html.escape(text(value, fallback))


def sentence_case(value: str) -> str:
    return value[:1].upper() + value[1:] if value else value


def slug(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text(value, "x").lower()).strip("-") or "x"


def format_timestamp(raw: str) -> str:
    try:
        parsed = dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return parsed.strftime("%d %b %Y, %H:%M")
    except ValueError:
        return raw.replace("T", " ")


def score_value(value: Any) -> Optional[int]:
    if value is None:
        return None
    try:
        score = round(float(value))
    except (TypeError, ValueError):
        return None
    return max(0, min(100, score))


def score_label(value: Any) -> str:
    score = score_value(value)
    return "–" if score is None else f"{score}"


def band(value: Any) -> str:
    """Color state for a score: agentic-ladder rungs at 40 / 70 / 90."""
    score = score_value(value)
    if score is None:
        return "unknown"
    for threshold, _label, state in LADDER:
        if score >= threshold:
            return state
    return "poor"


def rung(value: Any) -> str:
    """Agentic-ladder rung label for a score."""
    score = score_value(value)
    if score is None:
        return "not assessed"
    for threshold, label, _state in LADDER:
        if score >= threshold:
            return label
    return LADDER[-1][1]


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def clean_items(items: Any) -> list[str]:
    return [text(item) for item in as_list(items) if text(item, "") != ""]


# ---------------------------------------------------------------------------
# Small presentational atoms
# ---------------------------------------------------------------------------


def status_icon(state: str) -> str:
    """Shape-coded status icon: circle=pass, square=warn, triangle=fail.

    Shape + color + (elsewhere) text label gives three redundant cues.
    """
    shapes = {
        "peak": '<svg class="icon peak" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1l7 7-7 7-7-7z"/><path class="glyph" d="M4.8 8.2l2.2 2.2 4.2-4.6"/></svg>',
        "good": '<svg class="icon pass" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7"/><path class="glyph" d="M4.8 8.2l2.2 2.2 4.2-4.6"/></svg>',
        "pass": '<svg class="icon pass" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7"/><path class="glyph" d="M4.8 8.2l2.2 2.2 4.2-4.6"/></svg>',
        "fair": '<svg class="icon warn" viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="1.5" width="13" height="13" rx="2"/><path class="glyph" d="M8 4.5v4.2m0 2.6v.2"/></svg>',
        "warn": '<svg class="icon warn" viewBox="0 0 16 16" aria-hidden="true"><rect x="1.5" y="1.5" width="13" height="13" rx="2"/><path class="glyph" d="M8 4.5v4.2m0 2.6v.2"/></svg>',
        "poor": '<svg class="icon fail" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5l7 13H1z"/><path class="glyph" d="M8 6.2v3.4m0 2.2v.2"/></svg>',
        "fail": '<svg class="icon fail" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5l7 13H1z"/><path class="glyph" d="M8 6.2v3.4m0 2.2v.2"/></svg>',
        "skipped": '<svg class="icon skipped" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" class="hollow"/><path class="glyph muted-glyph" d="M5 8h6"/></svg>',
        "unknown": '<svg class="icon unknown" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" class="hollow"/><path class="glyph muted-glyph" d="M6.2 6.4c0-1 .8-1.8 1.8-1.8s1.8.7 1.8 1.7c0 1.4-1.8 1.4-1.8 2.7M8 11.4v.2"/></svg>',
    }
    return shapes.get(state, shapes["unknown"])


def severity_pill(severity: str) -> str:
    sev = severity if severity in SEVERITY_ORDER else "info"
    return f'<span class="pill sev-{sev}">{esc(sev)}</span>'


def effort_chip(effort: Any) -> str:
    value = text(effort, "unknown").lower()
    return (
        f'<span class="chip" title="Estimated effort to fix: {esc(value)}">'
        f"effort: {esc(value)}</span>"
    )


def quick_win_chip() -> str:
    return (
        '<span class="chip quick-win" title="High impact for small effort — do this first">'
        "&#9889; quick win</span>"
    )


def is_quick_win(severity_or_impact: str, effort: Any, threshold: set[str]) -> bool:
    return (
        severity_or_impact in threshold
        and text(effort, "unknown").lower() == "small"
    )


def values_vary(items: list[dict[str, Any]], key: str) -> bool:
    values = {text(item.get(key), "unknown").lower() for item in items}
    return len(values) > 1


def meter(value: Any, label: str) -> str:
    """Horizontal bar meter with ladder-rung ticks at 40, 70 and 90."""
    score = score_value(value)
    state = band(value)
    width = 0 if score is None else score
    return (
        f'<div class="meter" role="progressbar" aria-valuemin="0" aria-valuemax="100" '
        f'aria-valuenow="{width}" aria-label="{esc(label)}: {score_label(value)} of 100">'
        f'<div class="meter-fill band-{state}" style="width:{width}%"></div>'
        '<span class="tick" style="left:40%"></span>'
        '<span class="tick" style="left:70%"></span>'
        '<span class="tick" style="left:90%"></span>'
        "</div>"
    )


def gauge(value: Any) -> str:
    """Lighthouse-style donut: r=56, stroke 8, arc starts at 12 o'clock."""
    score = score_value(value)
    state = band(value)
    circumference = 2 * 3.14159265 * 56
    if score is None or score <= 0:
        arc = 0.0
    else:
        arc = max(score / 100 * circumference - 4, 0)  # -strokeWidth/2 for round caps
    return (
        f'<div class="gauge band-{state}" role="img" '
        f'aria-label="Overall score {score_label(value)} of 100">'
        '<svg viewBox="0 0 120 120">'
        '<circle class="gauge-track" r="56" cx="60" cy="60" stroke-width="8"/>'
        f'<circle class="gauge-arc" r="56" cx="60" cy="60" stroke-width="8" '
        f'stroke-dasharray="{arc:.2f} {circumference:.2f}" '
        'transform="rotate(-90 60 60)"/>'
        "</svg>"
        f'<div class="gauge-num">{score_label(value)}</div>'
        "</div>"
    )


def next_band_hint(value: Any) -> str:
    """Distance to the next ladder rung — the AIBooster 'next level' framing."""
    score = score_value(value)
    if score is None:
        return ""
    if score >= 90:
        return '<span class="pillar-next">orchestration</span>'
    if score >= 70:
        target, word = 90, "orchestration"
    elif score >= 40:
        target, word = 70, "delegation"
    else:
        target, word = 40, "supervision"
    return f'<span class="pillar-next">{target - score} to {word}</span>'


def scale_bar(value: Any) -> str:
    """Agentic-ladder scale (0-39 / 40-69 / 70-89 / 90-100) with a score marker.

    Doubles as the legend for every meter on the page; the footer repeats the
    rung thresholds as plain text for screen readers and print.
    """
    score = score_value(value)
    marker = (
        f'<span class="scale-marker" style="left:{score}%"></span>'
        if score is not None
        else ""
    )
    aria = (
        f"Score {score} of 100, on the {rung(value)} rung of the agentic ladder"
        if score is not None
        else "Score scale from 0 to 100"
    )
    return (
        f'<div class="scale" role="img" aria-label="{esc(aria)}">'
        '<div class="scale-track">'
        '<span class="scale-tick" style="left:40%"></span>'
        '<span class="scale-tick" style="left:70%"></span>'
        '<span class="scale-tick" style="left:90%"></span>'
        f"{marker}</div>"
        '<div class="scale-labels" aria-hidden="true">'
        "<span>assistance</span><span>supervision</span>"
        "<span>delegation</span><span>orchestration</span></div></div>"
    )


def fix_prompt_block(prompt: Any, collapsed: bool = False) -> str:
    """Copy-paste remediation prompt for the team's coding agent.

    The copy button is a JS enhancement (hidden until the script unhides it);
    without JS the prompt is still plain selectable text.
    """
    value = text(prompt, "")
    if not value:
        return ""
    panel = (
        '<div class="prompt-panel">'
        '<div class="prompt-head"><span class="prompt-label">Fix prompt</span>'
        '<span class="prompt-hint">paste into your coding agent</span>'
        '<button type="button" class="copy-btn" data-copy hidden>Copy</button></div>'
        f'<pre class="prompt-text">{esc(value)}</pre></div>'
    )
    if collapsed:
        return (
            '<details class="row-details prompt-details">'
            "<summary>Fix prompt for your coding agent</summary>"
            f"{panel}</details>"
        )
    return panel


def chevron() -> str:
    return '<span class="chevron" aria-hidden="true"></span>'


def render_list(items: Any, empty: str = "None recorded.") -> str:
    values = clean_items(items)
    if not values:
        return f'<p class="muted">{esc(empty)}</p>'
    return "<ul>" + "".join(f"<li>{esc(item)}</li>" for item in values) + "</ul>"


# ---------------------------------------------------------------------------
# Data shaping
# ---------------------------------------------------------------------------


def normalize_pillars(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, dict):
        pillars: list[dict[str, Any]] = []
        for name, value in raw.items():
            if isinstance(value, dict):
                pillar = dict(value)
                pillar.setdefault("name", name)
            else:
                pillar = {"name": name, "score": value}
            pillars.append(pillar)
    else:
        pillars = [item for item in as_list(raw) if isinstance(item, dict)]
    # Failures lead: sort ascending by score so the weakest pillar is seen first.
    return sorted(
        pillars,
        key=lambda p: (
            score_value(p.get("score")) is None,
            score_value(p.get("score")) if score_value(p.get("score")) is not None else 999,
        ),
    )


def sorted_findings(findings: Any) -> list[dict[str, Any]]:
    items = [item for item in as_list(findings) if isinstance(item, dict)]
    return sorted(
        items,
        key=lambda item: (
            SEVERITY_ORDER.get(text(item.get("severity"), "info").lower(), 5),
            EFFORT_ORDER.get(text(item.get("effort"), "unknown").lower(), 3),
            text(item.get("title"), ""),
        ),
    )


def all_findings(repositories: list[dict[str, Any]]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for repo in repositories:
        findings.extend(
            item for item in as_list(repo.get("findings")) if isinstance(item, dict)
        )
    return findings


def average_repo_score(repositories: list[dict[str, Any]]) -> Optional[int]:
    scores = [score_value(repo.get("score")) for repo in repositories]
    valid_scores = [score for score in scores if score is not None]
    if not valid_scores:
        return None
    return round(sum(valid_scores) / len(valid_scores))


def first_findings_anchor(repositories: list[dict[str, Any]]) -> Optional[str]:
    for repo in repositories:
        if any(isinstance(f, dict) for f in as_list(repo.get("findings"))):
            return f"findings-{slug(repo.get('name'))}"
    return None


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------


def render_severity_strip(repositories: list[dict[str, Any]]) -> str:
    counts = {sev: 0 for sev in SEVERITY_ORDER}
    for finding in all_findings(repositories):
        sev = text(finding.get("severity"), "info").lower()
        counts[sev if sev in counts else "info"] += 1
    anchor = first_findings_anchor(repositories)
    pills = []
    for sev in SEVERITY_ORDER:
        zero = " zero" if counts[sev] == 0 else ""
        inner = f"<strong>{counts[sev]}</strong> {sev}"
        if anchor and counts[sev] > 0:
            pills.append(
                f'<a class="count-pill sev-{sev}" href="#{anchor}" '
                f'title="Jump to findings">{inner}</a>'
            )
        else:
            pills.append(f'<span class="count-pill sev-{sev}{zero}">{inner}</span>')
    return f'<div class="severity-strip" aria-label="Findings by severity">{"".join(pills)}</div>'


def render_repo_context_line(repo: dict[str, Any]) -> str:
    """Slim context strip: path · branch · commits · authors, plus notes."""
    history = repo.get("history") if isinstance(repo.get("history"), dict) else {}
    window = text(history.get("window"), "")
    bits = []
    path = text(repo.get("path"), "")
    if path:
        bits.append(f'<span class="mono">{esc(path)}</span>')
    branch = text(repo.get("branch"), "")
    if branch and branch != "n/a":
        bits.append(f"branch <strong>{esc(branch)}</strong>")
    commits = text(history.get("commits"), "")
    authors = text(history.get("authors"), "")
    if commits and commits != "n/a":
        stat = f"<strong>{esc(commits)}</strong> commits"
        if authors and authors != "n/a":
            stat += f" / <strong>{esc(authors)}</strong> authors"
        if window and window != "n/a":
            stat += f" ({esc(window)})"
        bits.append(stat)
    if not bits:
        return ""
    notes = clean_items(history.get("notes"))
    notes_html = (
        f'<details class="row-details"><summary>History notes ({len(notes)})</summary>{render_list(notes)}</details>'
        if notes
        else ""
    )
    line = '<span class="ctx-sep">·</span>'.join(f"<span>{bit}</span>" for bit in bits)
    return f'<div class="repo-context"><p class="ctx-line">{line}</p>{notes_html}</div>'


def render_nav(
    summary: dict[str, Any],
    overall_score: Optional[int],
    repositories: list[dict[str, Any]],
    has_actions: bool,
    has_checks: bool,
) -> str:
    """Sticky anchor nav: plain links, works without JavaScript."""
    links: list[tuple[str, str]] = []
    if has_actions:
        links.append(("#action-plan", "Start here"))
    if len(repositories) == 1:
        repo = repositories[0]
        name = slug(repo.get("name"))
        if as_list(repo.get("pillars")):
            links.append((f"#pillars-{name}", "Pillars"))
        findings_count = len(
            [f for f in as_list(repo.get("findings")) if isinstance(f, dict)]
        )
        if findings_count:
            links.append((f"#findings-{name}", f"Findings ({findings_count})"))
    elif repositories:
        links.append(("#comparison-heading", "Repositories"))
    if has_checks:
        links.append(("#checks-heading", "Checks"))
    links.append(("#sources-heading", "Sources"))
    anchors = "".join(f'<a href="{href}">{label}</a>' for href, label in links)
    state = band(overall_score)
    score_chip = (
        f'<span class="nav-score"><strong class="num band-text-{state}">'
        f"{score_label(overall_score)}</strong> · "
        f'{esc(sentence_case(text(summary.get("maturity"), rung(overall_score))))}</span>'
    )
    return f'<nav class="report-nav" aria-label="Report sections"><div class="nav-inner">{anchors}{score_chip}</div></nav>'


def render_hero(
    summary: dict[str, Any],
    overall_score: Optional[int],
    repositories: list[dict[str, Any]],
    has_actions: bool,
) -> str:
    maturity = sentence_case(text(summary.get("maturity"), rung(overall_score)))
    top_risk = text(summary.get("topRisk"), "")
    state = band(overall_score)
    single = len(repositories) == 1

    verdict_summary = ""
    context_html = ""
    if single:
        repo_summary = text(repositories[0].get("summary"), "")
        if repo_summary:
            verdict_summary = f'<p class="verdict-summary">{esc(repo_summary)}</p>'
        context_html = render_repo_context_line(repositories[0])

    risk_link = (
        '<a class="risk-link" href="#action-plan">See where to start &#8595;</a>'
        if has_actions
        else ""
    )
    risk_html = (
        f'<div class="top-risk"><span class="top-risk-label">{status_icon("fail")} Top risk</span>'
        f"<p>{esc(top_risk)}</p>{risk_link}</div>"
        if top_risk
        else ""
    )

    return f"""
  <section class="hero" aria-labelledby="verdict-heading">
    <div class="hero-main">
      {gauge(overall_score)}
      <div class="verdict">
        <h2 id="verdict-heading" class="visually-hidden">Verdict</h2>
        <span class="verdict-pill band-{state}">{status_icon(state)} {esc(maturity)}</span>
        {verdict_summary}
      </div>
      {risk_html}
    </div>
    <div class="hero-meta">
      {render_severity_strip(repositories)}
      {scale_bar(overall_score)}
    </div>
    {context_html}
  </section>"""


def render_action_plan(recommendations: Any, single_repo: bool) -> str:
    items = [item for item in as_list(recommendations) if isinstance(item, dict)]
    if not items:
        return ""

    def priority(item: dict[str, Any]) -> tuple[int, str]:
        try:
            return int(item.get("priority", 999)), text(item.get("title"), "")
        except (TypeError, ValueError):
            return 999, text(item.get("title"), "")

    impact_varies = values_vary(items, "impact")
    effort_varies = values_vary(items, "effort")
    constant_notes = []
    if not impact_varies:
        constant_notes.append(f"all {text(items[0].get('impact'), 'unknown').lower()} impact")
    if not effort_varies:
        constant_notes.append(f"all {text(items[0].get('effort'), 'unknown').lower()} effort")
    subtitle = "Highest priority first"
    if constant_notes:
        subtitle += " — " + ", ".join(constant_notes)
    subtitle += "."

    rows = []
    for index, item in enumerate(sorted(items, key=priority), start=1):
        impact = text(item.get("impact"), "unknown").lower()
        chips = []
        if is_quick_win(impact, item.get("effort"), {"high"}):
            chips.append(quick_win_chip())
        gain = score_value(item.get("gain"))
        if gain:
            chips.append(
                f'<span class="chip chip-gain" title="Estimated overall score gain when completed">'
                f"est. +{gain} pts</span>"
            )
        if impact_varies:
            chips.append(
                f'<span class="chip impact-{impact}" title="Expected impact on readiness">impact: {esc(impact)}</span>'
            )
        if effort_varies:
            chips.append(effort_chip(item.get("effort")))
        chips_html = f'<span class="chips">{"".join(chips)}</span>' if chips else ""
        evidence = clean_items(item.get("evidence"))
        evidence_html = (
            f'<details class="row-details"><summary>Why this matters</summary>{render_list(evidence)}</details>'
            if evidence
            else ""
        )
        repo_line = (
            ""
            if single_repo
            else f'<p class="meta-line">Repository: {esc(item.get("repo"), "all")}</p>'
        )
        rows.append(
            f"""
      <li class="action">
        <div class="action-head">
          <span class="action-rank" aria-hidden="true">{index}</span>
          <div class="action-body">
            <div class="action-title-row">
              <h3>{esc(item.get('title'))}</h3>
              {chips_html}
            </div>
            <p class="next-action">{esc(item.get('nextAction'), '')}</p>
            {repo_line}
            {fix_prompt_block(item.get('fixPrompt'), collapsed=True)}
            {evidence_html}
          </div>
        </div>
      </li>"""
        )
    return f"""
  <section id="action-plan" aria-labelledby="action-plan-heading">
    <div class="section-head">
      <h2 id="action-plan-heading">Where to start</h2>
      <span class="section-sub">{esc(subtitle)}</span>
    </div>
    <ol class="action-list">{''.join(rows)}</ol>
  </section>"""


def render_pillar_list(repo: dict[str, Any]) -> str:
    pillars = normalize_pillars(repo.get("pillars"))
    if not pillars:
        return '<p class="muted">No pillar data recorded.</p>'

    rows = []
    for pillar in pillars:
        name = text(pillar.get("name"))
        state = band(pillar.get("score"))
        status_raw = text(pillar.get("status"), "").lower()
        status_key, status_word = STATUS_META.get(status_raw, (state, None))
        fail_class = " pillar-fail" if status_key == "fail" or state == "poor" else ""
        evidence = clean_items(pillar.get("evidence"))
        recs = clean_items(pillar.get("recommendations"))
        body_parts = []
        if status_word:
            body_parts.append(
                f'<span class="status-word status-{status_key}">{status_icon(status_key)} {status_word}</span>'
            )
        if evidence:
            body_parts.append(f"<h4>Evidence</h4>{render_list(evidence)}")
        if recs:
            body_parts.append(f"<h4>Recommended</h4>{render_list(recs)}")
        body = "".join(body_parts) or '<p class="muted">No detail recorded.</p>'
        rows.append(
            f"""
      <details class="pillar-row{fail_class}" id="pillar-{slug(name)}">
        <summary>
          {status_icon(status_key if status_word else state)}
          <span class="pillar-name">{esc(name)}</span>
          {meter(pillar.get('score'), name)}
          <span class="pillar-score"><span><strong class="num band-text-{state}">{score_label(pillar.get('score'))}</strong><span class="denom">/100</span></span>{next_band_hint(pillar.get('score'))}</span>
          {chevron()}
        </summary>
        <div class="pillar-body">{body}</div>
      </details>"""
        )
    return f'<div class="pillar-list">{"".join(rows)}</div>'


def render_findings(repo: dict[str, Any]) -> str:
    findings = sorted_findings(repo.get("findings"))
    if not findings:
        return (
            f'<p class="empty-state">{status_icon("pass")} '
            "No findings recorded for this repository.</p>"
        )

    effort_varies = values_vary(findings, "effort")
    rows = []
    for finding in findings:
        severity = text(finding.get("severity"), "info").lower()
        severity = severity if severity in SEVERITY_ORDER else "info"
        chips = []
        if is_quick_win(severity, finding.get("effort"), {"critical", "high"}):
            chips.append(quick_win_chip())
        if effort_varies:
            chips.append(effort_chip(finding.get("effort")))
        chips_html = f'<span class="chips">{"".join(chips)}</span>' if chips else ""
        effort_line = (
            ""
            if effort_varies
            else f'<p class="meta-line">Effort: {esc(text(finding.get("effort"), "unknown").lower())}</p>'
        )
        fix = text(finding.get("recommendation"), "")
        fix_html = (
            f'<div class="fix-panel"><span class="fix-label">How to fix</span><p>{esc(fix)}</p></div>'
            if fix
            else ""
        )
        evidence = clean_items(finding.get("evidence"))
        evidence_html = f"<h4>Evidence</h4>{render_list(evidence)}" if evidence else ""
        description = text(finding.get("description"), "")
        description_html = f"<p>{esc(description)}</p>" if description else ""
        rows.append(
            f"""
      <details class="finding">
        <summary>
          {severity_pill(severity)}
          <span class="finding-title">{esc(finding.get('title'))}</span>
          {chips_html}
          {chevron()}
        </summary>
        <div class="finding-body">
          {description_html}
          {fix_html}
          {fix_prompt_block(finding.get('fixPrompt'))}
          {evidence_html}
          {effort_line}
        </div>
      </details>"""
        )
    return f'<div class="finding-list">{"".join(rows)}</div>'


def findings_subtitle(repo: dict[str, Any]) -> str:
    findings = sorted_findings(repo.get("findings"))
    if not findings:
        return ""
    if values_vary(findings, "effort"):
        return "Ordered by severity, smallest effort first."
    effort_word = text(findings[0].get("effort"), "unknown").lower()
    return f"Ordered by severity — all are {effort_word}-effort fixes."


def render_repo_identity(repo: dict[str, Any]) -> str:
    summary = text(repo.get("summary"), "")
    summary_html = f'<p class="repo-summary">{esc(summary)}</p>' if summary else ""
    name = text(repo.get("name"))
    score_html = (
        f'<span class="repo-score"><strong class="num band-text-{band(repo.get("score"))}">'
        f'{score_label(repo.get("score"))}</strong><span class="denom">/100</span></span>'
    )
    return f"""
    <div class="repo-id">
      <div class="repo-head"><h2 id="repo-h-{slug(name)}">{esc(name)}</h2>{score_html}</div>
      {summary_html}
      {render_repo_context_line(repo)}
    </div>"""


def render_repo_sections(repositories: list[dict[str, Any]]) -> str:
    single = len(repositories) == 1
    sections = []
    for repo in repositories:
        name = text(repo.get("name"))
        findings_count = len(
            [f for f in as_list(repo.get("findings")) if isinstance(f, dict)]
        )
        pillars_block = f"""
    <div class="section-head">
      <{'h2' if single else 'h3'} class="sub-heading" id="pillars-{slug(name)}">Pillars</{'h2' if single else 'h3'}>
      <span class="section-sub">Weakest first. Expand a row for evidence.</span>
    </div>
    {render_pillar_list(repo)}"""
        findings_block = f"""
    <div class="section-head">
      <{'h2' if single else 'h3'} class="sub-heading" id="findings-{slug(name)}">Findings{f' ({findings_count})' if findings_count else ''}</{'h2' if single else 'h3'}>
      <span class="section-sub">{esc(findings_subtitle(repo), '')}</span>
    </div>
    {render_findings(repo)}"""
        if single:
            sections.append(f"<section>{pillars_block}</section><section>{findings_block}</section>")
        else:
            sections.append(
                f"""
  <section class="repo" id="repo-{slug(name)}" aria-labelledby="repo-h-{slug(name)}">
    {render_repo_identity(repo)}
    {pillars_block}
    {findings_block}
  </section>"""
            )
    return "".join(sections)


def render_repo_comparison(repositories: list[dict[str, Any]]) -> str:
    if len(repositories) < 2:
        return ""
    rows = []
    for repo in sorted(
        repositories,
        key=lambda r: score_value(r.get("score")) if score_value(r.get("score")) is not None else -1,
    ):
        name = text(repo.get("name"))
        rows.append(
            f"""
      <div class="compare-row">
        <a class="compare-name" href="#repo-{slug(name)}">{esc(name)}</a>
        {meter(repo.get('score'), name)}
        <span class="num band-text-{band(repo.get('score'))}">{score_label(repo.get('score'))}</span>
        <span class="chip">{esc(text(repo.get('maturity'), rung(repo.get('score'))))}</span>
      </div>"""
        )
    return f"""
  <section aria-labelledby="comparison-heading">
    <h2 id="comparison-heading">Repositories</h2>
    <div class="compare">{''.join(rows)}</div>
  </section>"""


def render_checks(checks: Any, single_repo: bool) -> str:
    items = [item for item in as_list(checks) if isinstance(item, dict)]
    if not items:
        return ""

    clumps: dict[str, list[dict[str, Any]]] = {
        "fail": [],
        "warn": [],
        "pass": [],
        "other": [],
    }
    for item in items:
        status = text(item.get("status"), "unknown").lower()
        clumps[status if status in clumps else "other"].append(item)

    def check_row(item: dict[str, Any]) -> str:
        status = text(item.get("status"), "unknown").lower()
        status_key = status if status in STATUS_META else "unknown"
        score_band = STATUS_BAND.get(status_key, "unknown")
        evidence = clean_items(item.get("evidence"))
        rec = text(item.get("recommendation"), "")
        body_parts = []
        if evidence:
            body_parts.append(render_list(evidence))
        if rec:
            body_parts.append(
                f'<div class="fix-panel"><span class="fix-label">How to fix</span><p>{esc(rec)}</p></div>'
            )
        if not single_repo:
            body_parts.append(
                f'<p class="meta-line">Repository: {esc(item.get("repo"), "all")}</p>'
            )
        body = "".join(body_parts) or '<p class="muted">No detail recorded.</p>'
        pillar = text(item.get("pillar"), "")
        pillar_html = f'<span class="chip">{esc(pillar)}</span>' if pillar else ""
        score_html = (
            f'<span class="check-score"><strong class="num band-text-{score_band}">'
            f'{score_label(item.get("score"))}</strong><span class="denom">/100</span></span>'
            if score_value(item.get("score")) is not None
            else '<span class="check-score"><span class="denom">–</span></span>'
        )
        return f"""
        <details class="check">
          <summary>
            {status_icon(status_key)}
            <span class="check-id">{esc(item.get('id'))}</span>
            {pillar_html}
            {score_html}
            {chevron()}
          </summary>
          <div class="check-body">{body}</div>
        </details>"""

    parts = []
    labels = {
        "fail": "Failing checks",
        "warn": "Warning checks",
        "pass": "Passing checks",
        "other": "Skipped / unknown checks",
    }
    for key in ("fail", "warn", "pass", "other"):
        group = clumps[key]
        if not group:
            continue
        rows = "".join(check_row(item) for item in group)
        if key in ("fail", "warn"):
            parts.append(f'<div class="clump-label">{labels[key]} ({len(group)})</div>{rows}')
        else:
            parts.append(
                f'<details class="clump"><summary><span class="clump-title">{labels[key]} ({len(group)})</span>{chevron()}</summary>{rows}</details>'
            )
    return f"""
  <section aria-labelledby="checks-heading">
    <div class="section-head">
      <h2 id="checks-heading">Check inventory ({len(items)})</h2>
      <span class="section-sub">Each check scores 0–100 and rolls up into its pillar.</span>
    </div>
    {''.join(parts)}
  </section>"""


def render_sources(sources: Any, single_repo: bool) -> str:
    items = [item for item in as_list(sources) if isinstance(item, dict)]
    if not items:
        return ""
    unavailable = [
        item for item in items if text(item.get("status"), "").lower() in ("unavailable", "skipped")
    ]
    notice = ""
    if unavailable:
        kinds = ", ".join(text(item.get("kind")) for item in unavailable)
        notice = (
            f'<p class="notice">{status_icon("warn")} Some evidence sources did not run: '
            f"{esc(kinds)}. All scores come from the sources listed as available.</p>"
        )
    repo_th = "" if single_repo else "<th>Repo</th>"
    rows = []
    for item in items:
        repo_td = "" if single_repo else f"<td>{esc(item.get('repo'), 'all')}</td>"
        rows.append(
            f"""
      <tr>
        <td class="nowrap">{esc(item.get('kind'))}</td>
        {repo_td}
        <td><span class="chip src-{slug(item.get('status'))}">{esc(item.get('status'))}</span></td>
        <td class="mono nowrap">{esc(item.get('path'), '—')}</td>
        <td>{esc(item.get('notes'), '')}</td>
      </tr>"""
        )
    return f"""
  <section aria-labelledby="sources-heading">
    <h2 id="sources-heading" class="visually-hidden">Evidence sources</h2>
    {notice}
    <details class="clump">
      <summary><span class="clump-title">Evidence sources ({len(items)})</span>{chevron()}</summary>
      <div class="table-wrap"><table>
        <thead><tr><th>Kind</th>{repo_th}<th>Status</th><th>Path</th><th>Notes</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table></div>
    </details>
  </section>"""


# ---------------------------------------------------------------------------
# Page shell
# ---------------------------------------------------------------------------

CSS = """
:root {
  color-scheme: light;
  /* Visma 2026 brand tokens (frontend/src/styles/_visma-tokens.scss) */
  --visma-purple: #7f56fa;
  --ink: #131313;
  --body-text: #222628;
  --muted: #6e777c;
  --faint: #939fa5;
  --line: #d7dde0;
  --line-soft: #e7ebec;
  --panel: #ffffff;
  --bg: #fefefe;
  --sunken: #f1f2f3;
  --creme: #f9f5f1;
  --peak: #0b5cad;
  --peak-tint: #e3edf8;
  --good: #1f7a4d;
  --good-tint: #e4f2ea;
  --fair: #b5740b;
  --fair-tint: #fbf0dc;
  --poor: #b3261e;
  --poor-tint: #fbe9e7;
  --unknown: #6e777c;
  --unknown-tint: #f1f2f3;
  --accent: #6a3fe6;
  --accent-deep: #5630c2;
  --accent-tint: #ede7ff;
  --accent-soft: #f3eeff;
  --action-bg: #131313;
  --gradient-organic:
    radial-gradient(95% 95% at 10% 6%, #7f56fa 0%, rgba(127, 86, 250, 0) 62%),
    radial-gradient(120% 120% at 92% 96%, #ffab65 0%, rgba(255, 171, 101, 0) 72%),
    linear-gradient(135deg, #9172fb 0%, #ce8fb5 52%, #f8ae69 100%);
  --gradient-maturity: linear-gradient(90deg, #7f56fa 0%, #ce8fb5 50%, #ffab65 100%);
  --hero-glass: rgba(19, 19, 19, 0.32);
  --sev-critical: #8f1d17;
  --sev-critical-tint: #fbe9e7;
  --sev-high: #b3261e;
  --sev-high-tint: #fbe9e7;
  --sev-medium: #b5740b;
  --sev-medium-tint: #fbf0dc;
  --sev-low: #6e777c;
  --sev-low-tint: #f1f2f3;
  --sev-info: #5630c2;
  --sev-info-tint: #ede7ff;
  --fix: #1f7a4d;
  --fix-tint: #e4f2ea;
  --radius: 16px;
  --radius-sm: 8px;
  --shadow: 0 1px 3px rgba(19, 19, 19, 0.08), 0 1px 2px rgba(19, 19, 19, 0.04);
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
@media (prefers-reduced-motion: reduce) { html { scroll-behavior: auto; } }
body {
  margin: 0;
  font: 15px/1.5 "Visma Text", system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  color: var(--body-text);
  background: var(--bg);
  -webkit-text-size-adjust: 100%;
}
h1, h2, h3, .sub-heading { color: var(--ink); }
.mono, code { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace; font-size: 0.86em; overflow-wrap: anywhere; }
.num { font-variant-numeric: tabular-nums; }
.nowrap { white-space: nowrap; }
main { max-width: 920px; margin: 0 auto; padding: 0 20px 64px; }
h1 { font-size: 23px; font-weight: 700; margin: 0; letter-spacing: -0.02em; }
h2 { font-size: 18px; font-weight: 700; margin: 0; letter-spacing: -0.015em; }
h3 { font-size: 15px; margin: 0; }
h4 { font-size: 11.5px; margin: 12px 0 4px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--muted); }
p { margin: 0 0 10px; }
a { color: var(--accent); text-decoration-thickness: 1px; text-underline-offset: 2px; }
ul { margin: 6px 0 8px 20px; padding: 0; }
li { margin: 3px 0; }
section { margin: 34px 0 0; }
main > section + section { border-top: 1px solid var(--line-soft); padding-top: 28px; }
.section-head { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; margin: 0 0 12px; }
.section-head .sub-heading, .section-head h2 { margin: 0; }
.section-sub { color: var(--muted); font-size: 13px; }
.sub-heading { font-size: 18px; font-weight: 700; letter-spacing: -0.015em; }
section[id], h1[id], h2[id], h3[id], .sub-heading, details[id] { scroll-margin-top: 56px; }
.visually-hidden { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.muted { color: var(--muted); }
.meta-line { color: var(--muted); font-size: 13px; margin: 0 0 6px; }

/* -- hero band (full-bleed Visma 2026 organic gradient) -------------------- */
.hero-band {
  background: var(--gradient-organic); color: #fff; position: relative; overflow: hidden;
}
.hero-band::before {
  /* Subtle vignette under the text zone: keeps white copy at >=4.5:1 over
     the gradient's light stops without visibly changing the brand moment. */
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background: radial-gradient(130% 115% at 20% 10%, rgba(19,19,19,0.28) 0%, rgba(19,19,19,0.12) 45%, transparent 68%);
}
.hero-inner { position: relative; max-width: 920px; margin: 0 auto; padding: 30px 20px 32px; }
.page-head {
  display: flex; flex-wrap: wrap; gap: 6px 16px; align-items: baseline;
  justify-content: space-between; margin-bottom: 22px;
}
.page-head .head-text { flex: 1 1 420px; }
.page-head h1 { color: #fff; font-size: 27px; letter-spacing: -0.02em; text-shadow: 0 1px 2px rgba(19,19,19,0.18); }
.page-head .sub { display: block; color: rgba(255,255,255,0.92); font-size: 13px; margin-top: 5px; text-shadow: 0 1px 2px rgba(19,19,19,0.22); }
.toolbar { display: flex; gap: 8px; align-items: center; }
.toolbar button {
  font: inherit; font-size: 12.5px; font-weight: 500; color: #fff;
  background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.4);
  border-radius: 999px; padding: 6px 15px; cursor: pointer;
}
.toolbar button:hover { background: rgba(19,19,19,0.45); }
.toolbar button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }

/* -- hero ---------------------------------------------------------------- */
.hero-main { display: flex; gap: 30px; align-items: center; flex-wrap: wrap; }
.hero-meta {
  display: flex; gap: 14px 30px; align-items: center; justify-content: space-between;
  flex-wrap: wrap; margin-top: 18px; padding: 12px 16px;
  background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.22);
  border-radius: var(--radius);
}
.hero-meta .scale { flex: 1 1 300px; }
.gauge { position: relative; width: 128px; height: 128px; flex: none; }
.gauge::before {
  content: ""; position: absolute; inset: 7px; border-radius: 50%;
  background: var(--hero-glass);
}
.gauge svg { position: relative; width: 100%; height: 100%; }
.gauge-track { fill: none; stroke: #fff; opacity: 0.25; }
.gauge-arc { fill: none; stroke: currentColor; stroke-linecap: round; }
.gauge-num {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  font-size: 42px; font-weight: 700; letter-spacing: -0.02em; font-variant-numeric: tabular-nums;
  color: #fff;
}
/* Hero is a brand moment: monochrome white on the gradient, semantic color
   returns on the page surface below. */
.hero .band-peak, .hero .band-good, .hero .band-fair, .hero .band-poor, .hero .band-unknown { color: #fff; }
.band-peak { color: var(--peak); }
.band-good { color: var(--good); }
.band-fair { color: var(--fair); }
.band-poor { color: var(--poor); }
.band-unknown { color: var(--unknown); }
.band-text-peak { color: var(--peak); }
.band-text-good { color: var(--good); }
.band-text-fair { color: var(--fair); }
.band-text-poor { color: var(--poor); }
.band-text-unknown { color: var(--unknown); }
.verdict { display: flex; flex-direction: column; gap: 9px; flex: 1 1 260px; min-width: 220px; }
.verdict-pill {
  display: inline-flex; align-items: center; gap: 8px; align-self: flex-start;
  font-size: 12px; font-weight: 600; padding: 6px 16px; border-radius: 999px;
  color: #fff; background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.4);
  text-transform: uppercase; letter-spacing: 0.08em;
}
.hero .icon.peak, .hero .icon.pass, .hero .icon.warn, .hero .icon.fail { fill: rgba(255,255,255,0.9); }
.hero .icon .glyph { stroke: #3a3a3a; }
.verdict-summary {
  font-size: 13.5px; color: #fff; margin: 0; max-width: 60ch;
  text-shadow: 0 1px 2px rgba(19,19,19,0.22);
}
/* Score scale: the Visma 2026 maturity gradient (purple -> rose -> orange)
   with ladder-rung ticks at 40, 70 and 90 and a white marker at the score. */
.scale { max-width: 460px; }
.scale-track {
  position: relative; height: 7px; margin: 2px 0 6px;
  background: var(--gradient-maturity); border-radius: 999px;
}
.scale-tick {
  position: absolute; top: -2px; bottom: -2px; width: 2px;
  background: rgba(255,255,255,0.55); border-radius: 1px;
}
.scale-marker {
  position: absolute; top: -4px; bottom: -4px; width: 4px; margin-left: -2px;
  background: #fff; border-radius: 2px; box-shadow: 0 0 0 1.5px rgba(19,19,19,0.55);
  z-index: 1;
}
.scale-labels { display: flex; justify-content: space-between; gap: 8px; color: #fff; font-size: 10.5px; font-weight: 600; letter-spacing: 0.02em; }
.scale-labels span:nth-child(2), .scale-labels span:nth-child(3) { text-align: center; }
.scale-labels span:last-child { text-align: right; }
.severity-strip { display: flex; gap: 6px; flex-wrap: wrap; }
.count-pill {
  display: inline-flex; align-items: center; gap: 4px; font-size: 11.5px; font-weight: 600;
  padding: 2px 9px; border-radius: 999px; border: 1px solid; text-decoration: none;
}
a.count-pill:hover { filter: brightness(0.96); }
.count-pill strong { font-size: 12.5px; font-variant-numeric: tabular-nums; }
.count-pill.zero { opacity: 0.65; }
.hero .count-pill {
  background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.3); color: #fff;
}
a.count-pill:focus-visible { outline-color: #fff; }
.sev-critical { color: var(--sev-critical); background: var(--sev-critical-tint); border-color: color-mix(in srgb, var(--sev-critical) 30%, transparent); }
.sev-high { color: var(--sev-high); background: var(--sev-high-tint); border-color: color-mix(in srgb, var(--sev-high) 30%, transparent); }
.sev-medium { color: var(--sev-medium); background: var(--sev-medium-tint); border-color: color-mix(in srgb, var(--sev-medium) 30%, transparent); }
.sev-low { color: var(--sev-low); background: var(--sev-low-tint); border-color: color-mix(in srgb, var(--sev-low) 30%, transparent); }
.sev-info { color: var(--sev-info); background: var(--sev-info-tint); border-color: color-mix(in srgb, var(--sev-info) 30%, transparent); }
.top-risk {
  flex: 1 1 230px; align-self: stretch; display: flex; flex-direction: column; justify-content: center;
  border: 1px solid rgba(255,255,255,0.28); border-left: none;
  background: var(--hero-glass);
  border-radius: var(--radius); padding: 13px 16px 13px 18px; position: relative;
  box-shadow: inset 3px 0 0 rgba(255,255,255,0.85);
}
.top-risk-label {
  display: inline-flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.08em; color: #fff; margin-bottom: 5px;
}
.top-risk p { margin: 0 0 6px; font-size: 13.5px; line-height: 1.5; color: #fff; }
.risk-link { font-size: 12.5px; font-weight: 600; color: #fff; }
.repo-context {
  margin-top: 12px; padding: 10px 16px;
  background: var(--hero-glass); border: 1px solid rgba(255,255,255,0.22);
  border-radius: var(--radius);
}
.ctx-line {
  margin: 0; color: #fff; font-size: 12.5px; display: flex; flex-wrap: wrap;
  gap: 4px 8px; align-items: baseline;
}
.ctx-line strong { color: #fff; font-weight: 700; font-variant-numeric: tabular-nums; }
.ctx-sep { color: rgba(255,255,255,0.6); }
.repo-context .row-details { margin-top: 6px; }
.repo-context .row-details > summary { color: #fff; font-weight: 600; text-shadow: 0 1px 2px rgba(19,19,19,0.28); }
.repo-context .row-details li { color: #fff; text-shadow: 0 1px 2px rgba(19,19,19,0.28); }

/* -- sticky section nav ---------------------------------------------------- */
.report-nav {
  position: sticky; top: 0; z-index: 20;
  background: rgba(255,255,255,0.94); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  border-bottom: 1px solid var(--line); box-shadow: 0 1px 4px rgba(15,23,42,0.05);
}
.nav-inner {
  max-width: 920px; margin: 0 auto; padding: 0 20px;
  display: flex; align-items: center; gap: 2px; overflow-x: auto; scrollbar-width: none;
}
.nav-inner::-webkit-scrollbar { display: none; }
.nav-inner a {
  color: var(--muted); text-decoration: none; font-size: 13px; font-weight: 600;
  padding: 10px 11px; border-bottom: 2px solid transparent; white-space: nowrap;
}
.nav-inner a:hover { color: var(--accent); border-bottom-color: var(--line); }
.nav-score {
  margin-left: auto; padding-left: 14px; font-size: 12.5px; font-weight: 600;
  color: var(--muted); white-space: nowrap;
}
.nav-score strong { font-size: 13.5px; }

/* -- icons --------------------------------------------------------------- */
.icon { width: 14px; height: 14px; flex: none; vertical-align: -2px; }
.icon.peak { fill: var(--peak); }
.icon.pass { fill: var(--good); }
.icon.warn { fill: var(--fair); }
.icon.fail { fill: var(--poor); }
.icon.skipped, .icon.unknown { fill: var(--faint); }
.icon .glyph { fill: none; stroke: #fff; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }
.icon .hollow { fill: none; stroke: currentColor; stroke-width: 1.6; }
.icon .muted-glyph { stroke: var(--faint); }
.icon.skipped, .icon.unknown { color: var(--faint); }

/* -- chips & pills ------------------------------------------------------- */
.chips { display: inline-flex; gap: 6px; flex-wrap: wrap; align-items: center; }
.chip {
  display: inline-flex; align-items: center; gap: 4px; font-size: 11.5px; font-weight: 600;
  color: var(--muted); background: var(--bg); border: 1px solid var(--line);
  border-radius: 999px; padding: 2px 9px; white-space: nowrap;
}
.chip.quick-win { color: var(--accent); background: var(--accent-tint); border-color: color-mix(in srgb, var(--accent) 30%, transparent); }
.chip.chip-gain { color: var(--good); background: var(--good-tint); border-color: color-mix(in srgb, var(--good) 28%, transparent); font-variant-numeric: tabular-nums; }
.chip.impact-high { color: var(--sev-high); background: var(--sev-high-tint); border-color: color-mix(in srgb, var(--sev-high) 25%, transparent); }
.chip.impact-medium { color: var(--sev-medium); background: var(--sev-medium-tint); border-color: color-mix(in srgb, var(--sev-medium) 25%, transparent); }
.chip.src-available { color: var(--good); background: var(--good-tint); border-color: color-mix(in srgb, var(--good) 25%, transparent); }
.chip.src-unavailable, .chip.src-skipped { color: var(--sev-high); background: var(--sev-high-tint); border-color: color-mix(in srgb, var(--sev-high) 25%, transparent); }
.pill {
  display: inline-flex; align-items: center; justify-content: center;
  width: 70px; flex: none; font-size: 10.5px; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.04em; border-radius: 999px; padding: 3px 0; border: 1px solid;
}

/* -- meters -------------------------------------------------------------- */
.meter { position: relative; height: 9px; border-radius: 999px; background: var(--line-soft); overflow: hidden; }
.meter-fill { height: 100%; border-radius: 999px; background: currentColor; min-width: 3px; }
.meter .tick { position: absolute; top: 0; bottom: 0; width: 1px; background: rgba(28,31,35,0.25); }

/* -- action plan --------------------------------------------------------- */
.action-list { list-style: none; margin: 0; padding: 0; }
.action {
  background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius);
  box-shadow: var(--shadow); padding: 13px 16px; margin: 0 0 8px;
}
.action-head { display: flex; gap: 12px; }
.action-rank {
  flex: none; width: 26px; height: 26px; border-radius: 999px; background: var(--action-bg); color: #fff;
  display: flex; align-items: center; justify-content: center; font-size: 12.5px; font-weight: 700;
  font-variant-numeric: tabular-nums; margin-top: 1px; box-shadow: 0 2px 6px rgba(19,19,19,0.22);
}
.action-body { flex: 1; min-width: 0; }
.action-title-row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; justify-content: space-between; }
.action-title-row h3 { font-size: 14.5px; }
.next-action { margin: 5px 0 0; font-size: 13.5px; color: var(--muted); }
.action .row-details { margin-top: 6px; }

/* -- pillar list --------------------------------------------------------- */
.pillar-list {
  background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius);
  box-shadow: var(--shadow); overflow: hidden;
}
details.pillar-row { border-bottom: 1px solid var(--line-soft); }
details.pillar-row:last-child { border-bottom: 0; }
details.pillar-row summary {
  display: grid; grid-template-columns: 16px minmax(150px, 200px) 1fr 118px 11px;
  gap: 14px; align-items: center; padding: 11px 16px; cursor: pointer; list-style: none;
}
details.pillar-row summary:hover { background: var(--bg); }
details.pillar-row summary::-webkit-details-marker { display: none; }
details.pillar-row.pillar-fail { box-shadow: inset 3px 0 0 var(--poor); }
.pillar-name { font-weight: 600; font-size: 14px; }
.pillar-score { text-align: right; display: flex; flex-direction: column; align-items: flex-end; gap: 1px; }
.pillar-score .num { font-size: 15px; font-weight: 650; }
.pillar-next { font-size: 10.5px; color: var(--muted); white-space: nowrap; }
.denom { color: var(--muted); font-size: 11.5px; margin-left: 1px; }
.pillar-body { padding: 2px 16px 14px 46px; font-size: 14px; }
.pillar-body .status-word { margin-bottom: 2px; }
.status-word { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; font-size: 12.5px; }
.status-pass { color: var(--good); }
.status-warn { color: var(--fair); }
.status-fail { color: var(--poor); }
.status-unknown, .status-skipped { color: var(--muted); }

/* -- repo section (multi-repo) ------------------------------------------- */
.repo-id {
  background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius);
  box-shadow: var(--shadow); padding: 18px 20px;
}
.repo-head { display: flex; justify-content: space-between; align-items: baseline; gap: 12px; flex-wrap: wrap; }
.repo-score .num { font-size: 20px; font-weight: 650; }
.repo-summary { font-size: 14.5px; color: var(--ink); margin: 8px 0 0; max-width: 75ch; }
.repo .sub-heading { margin-top: 22px; }
.compare { background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); padding: 8px 16px; margin-top: 10px; }
.compare-row { display: grid; grid-template-columns: minmax(120px, 200px) 1fr 40px auto; gap: 14px; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--line-soft); }
.compare-row:last-child { border-bottom: 0; }
.compare-name { font-weight: 600; text-decoration: none; }

/* -- findings ------------------------------------------------------------ */
.finding-list { display: flex; flex-direction: column; gap: 7px; }
details.finding { background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); box-shadow: var(--shadow); }
details.finding summary {
  display: flex; align-items: center; gap: 12px; padding: 10px 15px; cursor: pointer;
  list-style: none; border-radius: var(--radius);
}
details.finding summary:hover, details.check summary:hover { background: var(--bg); }
details.finding[open] summary:hover, details.check[open] summary:hover { border-radius: var(--radius) var(--radius) 0 0; }
details.finding summary::-webkit-details-marker { display: none; }
.finding-title { flex: 1; min-width: 0; font-weight: 600; font-size: 14px; overflow-wrap: anywhere; }
.finding-body { padding: 4px 16px 14px 97px; font-size: 14px; }
.fix-panel {
  border: 1px solid color-mix(in srgb, var(--fix) 30%, transparent); background: var(--fix-tint);
  border-radius: 8px; padding: 9px 13px; margin: 10px 0;
}
.prompt-panel {
  border: 1px solid color-mix(in srgb, var(--visma-purple) 30%, transparent);
  background: var(--accent-soft);
  border-radius: var(--radius-sm); margin: 10px 0 4px; overflow: hidden;
}
.prompt-head {
  display: flex; align-items: center; gap: 8px; padding: 6px 11px;
  border-bottom: 1px solid color-mix(in srgb, var(--visma-purple) 18%, transparent);
}
.prompt-label {
  font-size: 11px; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.08em; color: var(--accent-deep);
}
.prompt-hint { font-size: 11.5px; color: var(--muted); flex: 1; }
.copy-btn {
  font: inherit; font-size: 11.5px; font-weight: 500; color: #fff;
  background: var(--action-bg); border: 1px solid var(--action-bg);
  border-radius: 999px; padding: 3px 12px; cursor: pointer;
}
.copy-btn:hover { background: #000; }
.prompt-text {
  margin: 0; padding: 9px 12px; font-family: "SFMono-Regular", ui-monospace, Menlo, Consolas, monospace;
  font-size: 12px; line-height: 1.55; white-space: pre-wrap; overflow-wrap: anywhere;
  background: var(--panel);
}
.prompt-details[open] > summary { margin-bottom: 2px; }
.fix-label {
  display: block; font-size: 11px; font-weight: 700; text-transform: uppercase;
  letter-spacing: 0.05em; color: var(--fix); margin-bottom: 3px;
}
.fix-panel p { margin: 0; font-size: 13.5px; }
.empty-state { display: flex; align-items: center; gap: 8px; color: var(--muted); background: var(--panel); border: 1px dashed var(--line); border-radius: var(--radius); padding: 13px 16px; }

/* -- checks -------------------------------------------------------------- */
.clump-label { font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--muted); margin: 14px 0 7px; }
details.clump { margin-top: 14px; }
details.clump > summary {
  display: flex; align-items: center; justify-content: space-between; cursor: pointer;
  background: var(--panel); border: 1px solid var(--line); border-radius: 8px; box-shadow: var(--shadow);
  padding: 8px 14px; list-style: none; font-size: 13px; font-weight: 600; color: var(--muted);
}
details.clump > summary:hover { color: var(--ink); }
details.clump > summary::-webkit-details-marker { display: none; }
details.clump[open] > summary { margin-bottom: 6px; }
details.check { background: var(--panel); border: 1px solid var(--line); border-radius: 8px; margin: 0 0 6px; }
details.check summary { display: flex; align-items: center; gap: 10px; padding: 8px 14px; cursor: pointer; list-style: none; font-size: 13.5px; border-radius: 8px; }
details.check summary::-webkit-details-marker { display: none; }
.check-id { flex: 1; min-width: 0; font-weight: 600; overflow-wrap: anywhere; }
.check-score { flex: none; }
.check-score .num { font-weight: 650; }
.check-body { padding: 2px 14px 12px 38px; font-size: 13.5px; }

/* -- details shared ------------------------------------------------------ */
.chevron { flex: none; width: 9px; height: 9px; border-right: 2px solid var(--faint); border-bottom: 2px solid var(--faint); transform: rotate(-45deg); transition: transform 0.15s; margin: 0 2px; }
details[open] > summary .chevron { transform: rotate(45deg); margin-top: -3px; }
@media (prefers-reduced-motion: reduce) { .chevron { transition: none; } }
.row-details { margin-top: 8px; font-size: 14px; }
.row-details > summary { cursor: pointer; color: var(--accent); font-size: 12.5px; list-style: none; }
.row-details > summary::-webkit-details-marker { display: none; }
.row-details > summary::after { content: " ▸"; }
.row-details[open] > summary::after { content: " ▾"; }
summary:focus-visible, a:focus-visible, button:focus-visible {
  outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 4px;
}

/* -- notices, tables, footer --------------------------------------------- */
.notice {
  display: flex; align-items: center; gap: 8px; font-size: 13px;
  border: 1px solid color-mix(in srgb, var(--fair) 30%, transparent); background: var(--fair-tint);
  border-radius: 8px; padding: 9px 13px; color: #6b4a00; margin: 0 0 4px;
}
.table-wrap { overflow-x: auto; background: var(--panel); border: 1px solid var(--line); border-radius: var(--radius); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th, td { border-bottom: 1px solid var(--line-soft); padding: 8px 13px; text-align: left; vertical-align: top; }
th { font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--muted); background: var(--bg); white-space: nowrap; }
tr:last-child td { border-bottom: 0; }
footer.page-foot {
  max-width: 920px; margin: 28px auto 0; padding: 14px 20px 36px;
  color: var(--muted); font-size: 12px; line-height: 1.6;
}
footer.page-foot .foot-rule { max-width: 100%; border-top: 1px solid var(--line-soft); padding-top: 14px; }

@media (max-width: 640px) {
  .hero-inner { padding: 20px 16px 22px; }
  .hero-main { gap: 16px; }
  .gauge { width: 98px; height: 98px; }
  .gauge-num { font-size: 32px; }
  .verdict { min-width: 150px; }
  .scale-labels { font-size: 9.5px; }
  .nav-inner { padding: 0 12px; }
  .nav-inner a { padding: 9px 9px; font-size: 12.5px; }
  details.pillar-row summary { grid-template-columns: 16px 1fr auto 11px; row-gap: 8px; padding: 10px 14px; }
  details.pillar-row summary .meter { grid-column: 1 / -1; }
  .pillar-body { padding-left: 14px; }
  details.finding summary { flex-wrap: wrap; }
  .finding-title { flex: 1 1 calc(100% - 94px); }
  details.finding summary .chips { margin-left: 82px; }
  .finding-body { padding-left: 15px; }
  .check-body { padding-left: 14px; }
  .pill { width: 64px; }
}
@media print {
  body { background: #fff; }
  .toolbar, .report-nav { display: none; }
  .hero-band { background: #fff; color: var(--ink); border-bottom: 1px solid var(--line); }
  .hero-band::before { display: none; }
  .hero-band h1, .hero-band .sub, .hero-band p, .hero-band span, .hero-band li { text-shadow: none; }
  .page-head h1 { color: var(--ink); }
  .page-head .sub { color: var(--muted); }
  .gauge-num { color: var(--ink); }
  .gauge-track { stroke: var(--ink); opacity: 0.15; }
  .gauge::before { background: none; }
  .hero .band-peak { color: var(--peak); }
  .hero .band-good { color: var(--good); }
  .hero .band-fair { color: var(--fair); }
  .hero .band-poor { color: var(--poor); }
  .hero .band-unknown { color: var(--unknown); }
  .verdict-pill, .hero .count-pill { color: var(--ink); background: #fff; border-color: var(--line); }
  .hero-meta { background: #fff; border-color: var(--line); }
  .verdict-summary, .scale-labels, .ctx-line { color: var(--muted); }
  .scale-track { border: 1px solid var(--line); print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .scale-tick { background: rgba(19,19,19,0.5); }
  .scale-marker { background: var(--ink); box-shadow: 0 0 0 1.5px #fff; }
  .top-risk { background: #fff; border-color: var(--line); box-shadow: inset 3px 0 0 var(--poor); }
  .top-risk-label { color: var(--poor); }
  .top-risk p { color: var(--ink); }
  .risk-link { color: var(--accent); }
  .repo-context { background: #fff; border-color: var(--line); }
  .ctx-line strong { color: var(--ink); }
  .repo-context .row-details > summary, .repo-context .row-details li { color: var(--muted); text-shadow: none; }
  .hero .icon.peak { fill: var(--peak); }
  .hero .icon.pass { fill: var(--good); }
  .hero .icon.warn { fill: var(--fair); }
  .hero .icon.fail { fill: var(--poor); }
  .hero .icon .glyph { stroke: #fff; }
  .hero, .action, details.pillar-row, details.finding, details.check, .table-wrap, .fix-panel { break-inside: avoid; }
  h2, .sub-heading, .clump-label { break-after: avoid; }
  .action-rank { background: none; color: var(--ink); border: 2px solid var(--ink); box-shadow: none; }
  .meter { border: 1px solid var(--line); print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .meter-fill { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .scale-track, .scale-tick, .scale-marker { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .top-risk { box-shadow: inset 3px 0 0 var(--poor); print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .copy-btn { display: none; }
  .prompt-panel { break-inside: avoid; }
}
"""

JS = """
(function () {
  var toolbar = document.querySelector('.toolbar');
  if (!toolbar) return;
  toolbar.hidden = false;
  function setAll(open) {
    document.querySelectorAll('details').forEach(function (d) { d.open = open; });
  }
  toolbar.querySelector('[data-expand]').addEventListener('click', function () { setAll(true); });
  toolbar.querySelector('[data-collapse]').addEventListener('click', function () { setAll(false); });
  document.querySelectorAll('.copy-btn').forEach(function (btn) {
    btn.hidden = false;
    btn.addEventListener('click', function () {
      var pre = btn.closest('.prompt-panel').querySelector('.prompt-text');
      var done = function () {
        btn.textContent = 'Copied';
        setTimeout(function () { btn.textContent = 'Copy'; }, 1600);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(pre.textContent).then(done, done);
      } else {
        var range = document.createRange();
        range.selectNodeContents(pre);
        var sel = window.getSelection();
        sel.removeAllRanges(); sel.addRange(range);
        done();
      }
    });
  });
  var openedForPrint = [];
  window.addEventListener('beforeprint', function () {
    openedForPrint = [];
    document.querySelectorAll('details:not([open])').forEach(function (d) {
      openedForPrint.push(d); d.open = true;
    });
  });
  window.addEventListener('afterprint', function () {
    openedForPrint.forEach(function (d) { d.open = false; });
  });
})();
"""


def render_html(data: dict[str, Any]) -> str:
    repositories = [item for item in as_list(data.get("repositories")) if isinstance(item, dict)]
    summary = data.get("summary") if isinstance(data.get("summary"), dict) else {}
    overall_score = score_value(summary.get("overallScore"))
    if overall_score is None:
        overall_score = average_repo_score(repositories)

    generated_at = format_timestamp(
        text(data.get("generatedAt"), dt.datetime.now(dt.timezone.utc).isoformat())
    )
    title = text(data.get("title"), "Agent Readiness Report")
    repo_count = summary.get("repositoryCount", len(repositories))
    single_repo = len(repositories) == 1
    checks = [item for item in as_list(data.get("checks")) if isinstance(item, dict)]
    recommendations = [
        item for item in as_list(data.get("recommendations")) if isinstance(item, dict)
    ]

    subtitle_bits = [
        "How ready this repository is for AI coding agents"
        if single_repo
        else f"How ready these {esc(repo_count)} repositories are for AI coding agents"
    ]
    if checks:
        subtitle_bits.append(f"{len(checks)} evidence-backed checks")
    subtitle_bits.append(esc(generated_at))
    subtitle = " · ".join(subtitle_bits)

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <style>{CSS}</style>
</head>
<body>
  <div class="hero-band">
    <div class="hero-inner">
      <header class="page-head">
        <div class="head-text">
          <h1>{esc(title)}</h1>
          <span class="sub">{subtitle}</span>
        </div>
        <div class="toolbar" hidden>
          <button type="button" data-expand>Expand all</button>
          <button type="button" data-collapse>Collapse all</button>
        </div>
      </header>
      {render_hero(summary, overall_score, repositories, bool(recommendations))}
    </div>
  </div>
  {render_nav(summary, overall_score, repositories, bool(recommendations), bool(checks))}
  <main>
    {render_action_plan(recommendations, single_repo)}
    {render_repo_comparison(repositories)}
    {render_repo_sections(repositories)}
    {render_checks(checks, single_repo)}
    {render_sources(data.get("rawSources"), single_repo)}
  </main>
  <footer class="page-foot">
    <div class="foot-rule">
    Agentic-ladder rungs: 0–39 assistance · 40–69 supervision · 70–89 delegation · 90–100 orchestration.
    Findings are ordered by severity, then by effort (smallest first). A quick win is a
    high-impact item with small effort. Generated by the v-agent-readiness-report skill.
    </div>
  </footer>
  <script>{JS}</script>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Render a normalized agent-readiness JSON bundle as static HTML."
    )
    parser.add_argument("input", type=Path, help="Path to normalized JSON input.")
    parser.add_argument(
        "output",
        type=Path,
        nargs="?",
        help="Path to write HTML. Defaults to the input path with .html suffix.",
    )
    args = parser.parse_args()

    with args.input.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise SystemExit("Input JSON must be an object at the top level.")

    output = args.output or args.input.with_suffix(".html")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_html(data), encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
