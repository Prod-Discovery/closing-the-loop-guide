---
name: v-address-review
description: Iterate on an open pull request — triage comments, push fixes, handle stale reviews and conflicts — until the merge gate is met. Use when reviewers have left comments on a PR, when CI status changes on an open PR, when a draft PR is marked ready-for-review, when the base branch advances and a rebase is needed, or whenever an open PR needs to converge to merge-ready.
trigger: [address pr comments, respond to review, iterate on pr, pr review loop, ready to merge]
license: Apache-2.0
output_contract_schema: custom
---

# Address Review

## Objective

Drive an open pull request from "first reviewer comment" to "merge gate
satisfied" without losing scope, accumulating churn, or merging on a stale
or partial signal. Triage comments, push fixes, keep the review state
coherent across force-pushes, and stop the loop only when the merge gate is
met.

## When to Use

- A pull request is open and reviewers have left comments
- A draft PR has been marked ready-for-review and feedback is incoming
- CI status changed on an open PR (passed, failed, flaked)
- The base branch advanced and the PR needs a rebase or merge
- An orchestrator (e.g. `v-ticket-to-release`) has reached the post-PR phase

Do not use this skill for initial review of changes before the PR exists or
self-review of your own changes — use `v-review-changes` — or for the first
commit and PR-description authoring — use `v-prepare-commit`.

## Tooling Note

Use the strongest PR-management integration your environment supports:

- **GitHub MCP server** or **`gh` CLI**, when available, for fetching
  comments, CI runs, branch-protection status, and posting inline replies
  (`gh pr view --comments`, `gh pr review`, `gh run list`).
- **Bitbucket / Azure Repos / GitLab CLIs or MCPs** for repos hosted there
  — the same triage and gate logic applies; only the read/write commands
  differ.
- **Agent teams or subagents**, when available, can run the triage and the
  fix-implementation in separated contexts so reviewer prose does not bias
  the implementer.
- **Fallback:** if no integration is available, ask the user to paste the
  comments and CI status. Never fail-stop on a missing integration.

## Workflow

### 1. Pull the current PR state

Gather a fresh snapshot before triaging: all review comments since the last
iteration, CI status per check, approval state per reviewer,
branch-protection rules in effect (required reviewers, required checks,
up-to-date-branch requirement, dismissal rules on push), and whether the
base branch has advanced. Acting on stale data is the most common way the
loop goes wrong.

### 2. Triage every comment

Classify each new comment before doing anything:

- **Substantive defect** — the reviewer found a real correctness, security,
  performance, or maintainability problem. Fix.
- **Style or nit** — naming, formatting, comment wording. Fix if cheap;
  defer to a follow-up if the diff is already large.
- **Question** — reply; do not edit code unless the answer reveals a defect.
- **Out-of-scope request** — a feature or refactor beyond this PR's stated
  goal. Push back: propose a follow-up issue or PR rather than expanding
  scope.
- **Conflicting with another comment** — two reviewers disagree. Do not
  pick a side silently. Surface the conflict and ask both reviewers (or the
  user) to settle it.
- **Already addressed** — points at code that subsequent pushes have already
  changed. Mark resolved with a brief note.

### 3. Address substantive defects

For each substantive defect:

1. invoke **v-implement-code** for the fix, scoped to the comment.
2. invoke **v-run-tdd** to verify the fix and to add regression coverage
   when the comment exposed a missing case.
3. invoke **v-review-changes** against the new diff before pushing — a
   self-review pass catches secondary defects introduced by the fix and
   prevents the next reviewer round-trip.

Do not push a partial fix and let the reviewer catch what you missed.

### 4. Reply to reviewers

Close the loop on every comment thread: cite the commit SHA for fixed
defects, link the follow-up issue for deferrals, answer questions with code
references, name conflicts and ask for a settlement. Post inline replies
threaded to the original comment when the API allows; otherwise summarize
in the PR description update or ask the user to relay them. Never silently
change code without acknowledging the comment that prompted it.

### 5. Push the iteration

Commit the fix batch — invoke **v-prepare-commit** for message and scoping
conventions — and push to the PR branch. Force-pushing during review is
intentional, not casual: use it when the history needs to be coherent
(squashing fixups, rebasing onto an updated base); avoid it when reviewers
are mid-thread on lines that would shift. After a force-push, expect
stale-approval dismissal per branch-protection rules — re-request review
explicitly from the affected reviewers and note in the PR what changed. A
fast-forward push of additive commits generally keeps existing approvals;
verify against the project's dismissal policy.

### 6. Re-check CI

After every push, wait for required checks to complete. On green, continue.
On a single failed check that looks flaky (intermittent timeout, network
blip, known-bad runner): retry once. If it fails again, escalate to the user
— never auto-rerun-until-green. One retry is a tolerance for infrastructure
noise; a loop of retries is hiding a real problem. On a real failure, treat
it as a substantive defect and return to step 3.

### 7. Resolve conflicts with the base branch

When the base branch advances: rebase or merge following the project's
convention (state which one before doing it), then invoke **v-run-tdd** —
base-branch changes can break the PR even when text-merge succeeds — and
invoke **v-review-changes** against the post-rebase diff before pushing.
Note in the PR what was rebased or merged and re-request review if approvals
were dismissed.

### 8. Check the merge gate

The loop terminates only when all of the following are true:

- Every required reviewer has approved (per branch protection or CODEOWNERS)
- Every required CI check is green on the latest commit
- The branch is up to date with the base branch if the project requires it
- All open comment threads are resolved, replied to, or explicitly deferred
  with reviewer agreement
- No conflicting comments remain unresolved

When the gate is met, return the "ready to merge" assertion.

## Output Contract

Per iteration, produce:

```markdown
## PR Iteration <N>

**PR:** <repo#PR-number or branch reference>
**Base:** <base branch>
**Head:** <head SHA>

### Comments triaged
- Substantive: <count> — <one-line summaries>
- Style/nit: <count> — <one-line summaries>
- Questions: <count>
- Out-of-scope: <count> — <follow-up issue links if filed>
- Conflicting: <count> — <how surfaced>
- Already addressed: <count>

### Changes pushed
- Commits: <SHAs and one-line subjects>
- Force-push: <yes/no — and why if yes>
- Stale approvals dismissed: <list, if any>

### CI
- Status: <green / failing / flaked-once-retried / failing-after-retry>
- Failed checks: <names and reasons>

### Approvals
- Required: <list per CODEOWNERS or branch protection>
- Recorded: <list with reviewer names>
- Outstanding: <list>

### Open threads
- <count> unresolved — <one-line notes if blocking>

### Gate status
- Approvals satisfied: <yes/no>
- CI green: <yes/no>
- Up-to-date with base: <yes/no>
- All threads resolved or deferred: <yes/no>
- **Ready to merge: <yes/no>**
```

When the gate is met, the final iteration log ends with
`Ready to merge: yes` and the SHA that should be merged.

## Quality Bar

A pass through this skill meets the bar when:

- Every comment was triaged into a category before action was taken
- Substantive defects were fixed with regression coverage, not patched
- Out-of-scope requests were pushed back with a follow-up suggestion
- Force-pushes were intentional, named, and followed by re-requested review
- Every comment thread received a reply or an explicit deferral

## Anti-Patterns

**The reviewer-pleaser.** Implementing every comment regardless of scope.
The PR balloons, the original goal blurs, and the reviewer who cared about
the original change can no longer find it.

**The thread that never closes.** Pushing fixes without replying to the
comment that prompted them. Threads stay unresolved in the host UI, and the
next reviewer redoes the work.

## Critical Rules

1. **Triage before act.** Every comment goes through classification before
   any code changes. Implementing on autopilot is how scope dies.

2. **Out-of-scope means out-of-PR.** Propose a follow-up issue; do not
   expand the diff. The PR's goal was set when it was opened; honor it.

3. **The merge gate is the protection rule.** Approval count is a heuristic;
   CODEOWNERS, required-reviewer lists, and branch-protection policy are the
   truth. Read the rule, not just the headline count.

4. **Stop at "ready to merge."** This skill does not perform the merge —
   return the assertion; the merge is a separate authorization.
