---
name: v-audit-readiness
description: ISAE 3000 Type 2 audit-readiness verifier and evidence-pack generator. Checks each security control on two axes — design (the control exists) and operating effectiveness (it is enforced continuously throughout the observation period) — against a pluggable criteria framework (ISO 27001 / SOC 2 / NIST). Use when preparing for an external assurance audit, answering a customer security questionnaire or RFP, or proving controls actually run instead of merely being documented.
trigger: [isae 3000 readiness, audit readiness, evidence pack, security questionnaire, soc 2 readiness, compliance evidence]
license: Apache-2.0
author: Ron Koldeweid (@ron1326312356)
---

# Audit Readiness (ISAE 3000 Type 2)

## Objective

Get a repository ready for an **ISAE 3000 (Revised) Type 2** assurance engagement
and produce the re-verifiable evidence handed to customers and auditors. ISAE 3000
is the assurance *method*, not a control framework — the control benchmarks come
from a framework you plug in (ISO 27001 Annex A, SOC 2 Trust Services Criteria, or
NIST). The skill keeps that split: the assurance structure is fixed, the criteria
framework and the control set are configuration.

A **Type 2** engagement verifies controls **operated effectively throughout a
specified period** (typically 6–12 months), not at a single point in time. That
temporal scope is the whole value of Type 2 and what this skill makes
machine-checkable: every control is tested on two axes — **design** (it exists and
is suitably designed) and **operating effectiveness** (it ran consistently across
the entire period, with an unbroken evidence trail).

This skill produces **evidence, not an opinion**. Only an independent practitioner
expresses assurance. The skill's job is to make controls and evidence
re-verifiable so the real audit is cheap and clean.

## When to Use

- Preparing for an external assurance audit (ISAE 3000 / SOC 2 / ISO 27001).
- Answering a customer security questionnaire, vendor assessment, or RFP.
- Proving to procurement/due-diligence that controls actually run over time.
- Gating a changeset: confirm no security control silently regressed.

Do not use for:
- A deep, single-pass security vulnerability hunt — use **v-review-changes** (its Security Depth pass).
- Authoring the controls themselves — that is engineering work, not this audit.
- Writing the actual audit opinion — only a practitioner can issue assurance.

## Context

Before running, establish the inputs that shape every check:

1. **The control set.** A configuration file describing each control, its mapped
   criterion, and how to verify it. A starter lives at
   [references/isae-3000.example.yml](./references/isae-3000.example.yml) — copy it
   into the repo and record its path in `AGENTS.md`. If no control-set file exists,
   say so and stop; there is nothing to verify.
2. **The criteria framework.** ISO 27001 Annex A, SOC 2 Trust Services Criteria, or
   NIST — declared in the config. Each control references a specific criterion.
3. **The observation period.** Start date + length (e.g. 12 months). Used for the
   continuity test — the machine-checkable analog of "throughout the period".

## Setup check

Confirm a control-set config exists and `AGENTS.md` records its path and the
project's verification commands. If the config is missing, run no checks and report
a DISCLAIMER (scope limitation) — never present absence of evidence as a pass.

## Workflow

### 1. Load inputs

Read the control-set config: criteria framework, observation period, control
families, complementary user-entity controls (CUECs), and carved-out subservice
organizations. Resolve the report output path.

### 2. Test design (axis 1)

For each control, prove it exists using whichever evidence form is configured:

- **code** — search for the configured pattern across the configured file glob;
  pass when matches meet the threshold. Record `file:line` hits.
- **document** — a policy/register/DPA path; pass when the file exists and is
  non-empty. Record the path.
- **attestation** — a named owner + statement + an evidence reference; pass design
  when owner and statement are present, and note whether the referenced evidence
  exists.

No design evidence (or attestation only, with nothing backing it) → `MISSING`.

### 3. Test operating effectiveness (axis 2)

Prove the control *runs*, not just that it exists:

- **continuous-integration evidence** — a job in the project's CI that enforces the
  control on every change. Record the workflow and job. This is *inspection of
  continuous operation*.
- **probe** — exercise the control live (e.g. an unauthenticated request must
  return 401/403) and record the observed result. This is *re-performance* — the
  strongest evidence.

Inquiry alone is never sufficient. A control with design but no enforcement signal
is `DESIGN-ONLY`.

### 4. Test continuity (throughout the period)

For any control with a CI signal, confirm the job triggers on every change (push /
pull request) and, where CI history is available, that runs span the observation
period with no gap longer than the control's frequency. A control enforced only
recently, or with a coverage gap, is `PARTIAL-PERIOD` — a Type-2 exception.

### 5. Classify and record exceptions

Assign each control: `EFFECTIVE` (design + operating effectiveness across the full
period) · `PARTIAL-PERIOD` · `DESIGN-ONLY` · `MISSING` · `N/A` (with rationale).
Record every failure as an **exception** — a factual data point — with control,
criterion, test performed, and what failed.

### 6. Roll up to an opinion-style verdict

Exceptions are not auto-failures; judge **severity × pervasiveness**, allowing a
noted compensating control to neutralize one:

- **UNQUALIFIED** — no missing controls; any warnings isolated and compensated.
- **QUALIFIED** — material deficiencies, significant but not pervasive.
- **ADVERSE** — pervasive deficiencies (a whole family broken, or auth/data
  isolation broken).
- **DISCLAIMER** — evidence could not be gathered (a scope limitation, not a
  control failure).

### 7. Emit the evidence pack

Write the report. Lead with the framing **independently re-verifiable, not
self-declared**. One section per family, a table per control, then the CUEC and
subservice carve-out disclosures. When the config defines a questionnaire map,
append **Questionnaire responses** — answer each mapped question from its control's
status (effective → Yes, warning → Partly, missing → No) with the evidence pointer;
leave externally-sourced answers (e.g. "do you hold a certificate?") for a human.

## Output Contract

### Summary

One line: `coverage: EFFECTIVE n/N · PARTIAL m · DESIGN-ONLY d · MISSING k →
<opinion>`, plus the criteria framework and observation period.

### Detail

Per family, a table per control with three rows — Design, Operating effectiveness,
Throughout period — each citing concrete evidence (`file:line`, workflow:job, probe
result, document path). Then the CUEC list (what the customer must operate) and the
subservice carve-out disclosures (what is relied upon but not tested here). When
configured, the questionnaire-responses appendix.

### Verification

State how the result is reproducible: re-running the skill reproduces every
pointer; probes were re-performed live; CI history was inspected for continuity.
Population is 100% (every change), not a sample — note this; it is stronger than an
auditor's sampling.

### Follow-ups

Each `DESIGN-ONLY` / `PARTIAL-PERIOD` control with its one-line remediation (add a
CI job, add a probe, surface a field). `"None"` if every control is effective.

## Quality Bar

- `EFFECTIVE` requires **both** axes to pass and cover the full period — never one.
- An attestation with no backing evidence cannot exceed `DESIGN-ONLY`.
- Absence of evidence is a DISCLAIMER, never a pass.
- Questionnaire answers are truthful: an unmet control is No (or Partly) with a
  remediation note, never a hopeful Yes.
- Every reported status cites reproducible evidence, not a claim.

## Anti-Patterns

- Auto-answering "Yes" on a questionnaire because it would be convenient.
- Dressing an attestation up as automated proof.
- Claiming coverage of carved-out subservice (cloud-provider) controls — they are
  the provider's; rely on their own attestation, do not test them here.
- Treating a single point-in-time check as "throughout the period".
- Auto-failing the whole verdict on an isolated, compensated exception.
- Publishing internal names, emails, or customer data into the evidence pack.

## Critical Rules

- This skill produces **evidence, not an assurance opinion** — only an independent
  practitioner issues the opinion. Frame the output accordingly.
- The criteria framework is **pluggable** — never hardcode one; read it from config.
- Describe verification in **tool-neutral** terms; the control-set config holds any
  project-specific commands or patterns.
- Keep the control set in sync with whatever framework the audit programme requires.
