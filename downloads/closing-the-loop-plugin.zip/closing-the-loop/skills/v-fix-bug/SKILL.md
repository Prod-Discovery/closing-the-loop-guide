---
name: v-fix-bug
description: Orchestrate bug resolution from diagnosis through committed fix by composing stage skills into a coherent sequence. Use when a request starts with a symptom rather than a specification, when an error or regression needs investigation and repair, when a previously working feature has broken, when a production issue needs a targeted fix with minimal blast radius, or whenever the user says "fix this bug" or "ship the fix end to end".
trigger: [ship a bug fix, complete the fix lifecycle, bug from report to merge, fix this bug end to end, full bug fix cycle]
license: Apache-2.0
---

# Fix Bug

## Objective

Resolve a bug — from first symptom through committed, verified fix — by
routing the work through the right stage skills. A bug fix is not "make the
error go away." It is "understand why the error occurs, then remove the
cause." The core of the lifecycle lives in **v-debug-issue**, which diagnoses
the root cause and carries the fix itself; this orchestrator wraps it with
symptom capture, scope control, sibling checks, review, and delivery.

## When to Use

- An error, regression, or unexpected behavior needs investigation and repair
- The root cause is unknown and requires structured diagnosis before fixing
- A test is failing and the reason is not immediately obvious
- A production issue needs a targeted fix with minimal blast radius

Do not use this workflow for:
- New feature development — use **v-develop-feature**, which starts with
  planning rather than diagnosis
- Release preparation — use **v-prepare-release**
- Trivial one-line fixes where cause and solution are both obvious — just
  fix it directly
- Configuration or environment issues that don't require code changes

For ticket-driven delivery through PR, merge, and ticket close, use
v-ticket-to-release.

## Workflow

### Step 1: Capture the symptom

Collect concrete evidence before diagnosing: error messages, stack traces,
failing test output, reproduction steps, related recent changes. "It doesn't
work" is not a symptom. "Login returns 500 with 'null reference at
auth.validate line 42'" is. Then identify the bug type — it shapes the
diagnosis focus:

| Bug type | Diagnosis focus |
|---|---|
| **Regression** — worked before, broken now | Recent changes |
| **Latent defect** — existed, only now triggered | The triggering conditions |
| **Integration failure** — parts work alone, fail combined | Boundaries and contracts |
| **Data-dependent** — only with specific input | Edge cases and validation |

**Gate:** The symptom is concrete, and the repository is in a clean state.

### Step 2: Diagnose and fix — invoke **v-debug-issue**

v-debug-issue carries the core of this workflow: it diagnoses the root cause
with evidence, applies the minimal fix, adds the regression test, and
verifies.

**Conditional:** If the fix turns out architectural or multi-file,
invoke **v-plan-work** before continuing the fix — a targeted repair plan
with an explicit blast-radius assessment, not a feature plan.

**Gate (narrow scope):** The root cause is identified with evidence — not
guessed. The fix is the smallest change that removes the cause. A regression
test exists that fails with the old code and passes with the fix. The full
test suite passes, with no tests weakened or deleted to get there.

### Step 3: Check for siblings

If the root cause is a pattern error (not a one-off typo), check whether the
same pattern exists elsewhere in the codebase. A bug that exists in one place
often exists in similar places.

### Step 4: Review — invoke **v-review-changes**

**Gate:** The review confirms the fix addresses the root cause (not just the
symptom), the diff is minimal and scoped to the bug, and the regression test
actually exercises the failure path. All findings are addressed.

**Loop-back condition:** If review finds the fix incomplete, scope-crept, or
missing sibling cases, return to **Step 2 (v-debug-issue)** to correct it,
re-verify, then return here.

**Optional deepening:** For high-stakes fixes — security vulnerabilities,
data corruption, auth or payment paths — additionally
invoke **v-scored-code-review** before committing.

### Step 5: Commit — invoke **v-prepare-commit**

**Gate:** Only fix-related files are staged, and the commit message states
the root cause — what was wrong, why it was wrong, and what was done to fix
it. "Fixed null pointer" without context is almost as unhelpful as the bug.

### Step 6: Learn — invoke **v-capture-learning**

Record the root cause pattern, effective diagnostic techniques, and any test
coverage gap the bug revealed. Trivial bugs with obvious causes may skip —
but default to capturing; most bugs reveal something worth remembering.

## Output Contract

A completed v-fix-bug workflow produces these sections under `## Output Contract`:

### Summary

- **Bug:** [one-sentence description of the symptom]
- **Root cause:** [one-sentence description of why it happened]
- **Stages completed:** [list of stages invoked, with any skipped and why]

### Detail

Artifacts produced by each stage:

- **Diagnosis:** [root cause analysis — what, where, why]
- **Fix:** [files changed, what was fixed — plan reference if v-plan-work ran]
- **Tests:** [regression test added, suite results]
- **Siblings:** [same pattern checked elsewhere — findings or "none found"]
- **Review:** [findings addressed, blast radius confirmed]
- **Commit:** [commit message and structure]
- **Learnings:** [lessons captured — or "No notable learnings"]

### Verification

| Check | Command | Result |
|-------|---------|--------|
| Regression test | [command] | ✅ pass |
| Full suite | [command] | ✅ pass |
| Root cause confirmed | [specific check] | ✅ resolved |

### Follow-ups

- [related issues filed for separate work]
- [areas to monitor or revisit]
- "None" if the fix is fully self-contained

## Quality Bar

A bug fix workflow meets the quality bar when:

- The root cause was identified with evidence before a fix was attempted
- The fix addresses the root cause, not just the symptom — minimal, with no
  scope creep or unrelated changes
- A regression test exists that would catch this specific bug
- Similar patterns elsewhere were checked if the bug was systemic
- Review confirmed the fix is correct and complete
- The commit message explains the root cause and the fix

## Anti-Patterns

**Symptom patching.** Adding a null check, try-catch, or default value to
suppress an error without understanding what produced it. Guards are fine —
but only after you know what you are guarding against and why.

**Diagnosis paralysis.** Spending excessive time on diagnosis when the fix
is straightforward. Match the depth of diagnosis to the complexity of the bug.

**Copy-paste fix propagation.** Fixing the same broken pattern in multiple
places individually. If the pattern is broken, fix the pattern — a shared
function, a base class, a utility — not every instance separately.

## Critical Rules

1. **Diagnose before you fix.** Do not change code until you understand what
   is wrong and why — that is v-debug-issue's contract; hold it to it.
2. **Invoke stage skills — don't re-implement them.** This orchestrator
   routes and gates; the stage skills do the work.
3. **Keep the scope narrow.** A bug fix changes only what is necessary to
   resolve the root cause and add a regression test — improvements and
   refactors go in separate work.
4. **Always add a regression test.** It is the proof the bug will not recur
   silently.
5. **Explain the root cause in the commit.** What was wrong, why it was
   wrong, and what was done to fix it.
6. **Check for siblings.** A bug that exists in one place often exists in
   similar places.
