---
name: v-implement-code
description: Execute scoped code changes with minimal diffs, convention adherence, and verification evidence. Use when a plan exists and it is time to write code, when a bug has been diagnosed and the fix is known, when a feature has clear scope, when a refactor has defined boundaries, or whenever the user says "implement", "build", "write the code", "make this change", or "add this".
trigger: [implement this, write the code, make this change, add this endpoint, create this component]
license: Apache-2.0
---

# Implement Code

## Objective

Execute code changes that are minimal, correct, and verifiable. Good
implementation is invisible — it follows existing patterns, changes only what
needs changing, updates tests alongside behavior, and produces evidence that
the change works. The goal is a diff that a reviewer can understand in one
pass and that passes verification on the first run.

## When to Use

- A plan exists and it's time to execute the changes
- A bug has been diagnosed and the fix is known
- A feature or refactor has clear boundaries and a verification strategy

Do not use this skill when the work hasn't been scoped yet — plan first.
Implementation without a clear scope produces sprawling diffs that are hard
to review and hard to revert.

## Workflow

### 1. Restate Scope

Before touching code, state in one sentence what you will change and what you
will not change. This isn't ceremony — it's a forcing function against scope
creep. If you can't state the scope clearly, you're not ready to implement.

Example: "Adding a rate-limit check to the upload endpoint. Not changing the
rate-limit configuration, the upload logic, or the error response format."

If you discover something that needs fixing but isn't in scope, note it as a
follow-up and move on.

### 2. Make the Minimal Change

Read every file before editing it — the structure and patterns around the
change site, not just the line you'll change. Then write the smallest diff
that achieves the goal: add rather than reorganize, follow the surrounding
naming and error-handling patterns, leave code that isn't broken alone, and
add nothing speculative — no parameters "for future use", no abstraction
layers for flexibility that isn't needed yet.

### 3. Update Tests Alongside Changes

- Changed behavior requires changed tests — in the same change, not later
- New behavior requires new tests: happy path, primary error path, and any
  edge case that's not obvious from reading the code
- Run focused tests for the changed module first and fix failures before
  running the broader suite

### 4. Verify the Change

**Tooling note:** Use the strongest verification toolchain available, in
this order: look up the project's verification commands in `AGENTS.md` /
`CLAUDE.md` / `README.md`; detect from repo signals (manifest files, lock
files, tool config files, CI workflow files) when conventions aren't
documented; prefer the harness's test, lint, and type-check integrations
when present; ask the user for the verification command as a last resort.
Never fail-stop on a missing tool — continue with whatever combination is
available.

Run verification in layers, stopping to fix issues at each layer:

1. **Syntax and types** — the code compiles, types check, the linter passes
2. **Focused tests** — the specific code you changed
3. **Broad tests** — the full suite or relevant subset, for indirect breakage
4. **Acceptance** — the specific command or behavior the task asked for
5. **Behavioral** — the change exercised in the running system

Layer 5 is not optional. Launch the app and click through the flow, hit the
endpoint, run the CLI command, trigger the export. Green unit tests are a
static signal: they prove the units behave as the tests expect, not that the
feature works when the application actually runs — a wired-up controller can
still fatal on a property name no unit test touches. If the running system
genuinely cannot be exercised in this environment, say so explicitly in the
report and downgrade the claim to "unit-verified, not run in the application".

## Output Contract

Every implementation produces these sections under `## Output Contract`:

### Summary

One sentence stating what was implemented and how many files were touched.

### Detail

| File | Change | Reason |
|------|--------|--------|
| `path/to/file.ext` | [what changed] | [why] |

### Verification

| Check | Command | Result |
|-------|---------|--------|
| Types/lint | [your type check command] | ✅ pass |
| Focused tests | [focused test command] | ✅ pass |
| Full suite | [broader test command] | ✅ pass |
| Acceptance | [specific verification] | ✅ pass |
| Behavioral | [how the running system was exercised] | ✅ pass |

### Follow-ups

- [items discovered, deferred, or flagged during implementation]
- "None" when the change is fully scoped and self-contained

## Quality Bar

An implementation meets the quality bar when:

- The diff contains only changes related to the stated scope, with nothing
  speculative added for future use
- Naming, formatting, and patterns match the surrounding code
- Tests are updated alongside the behavior they verify
- All verification layers pass — types, focused tests, broad tests, acceptance,
  behavioral
- Error paths are handled, not silently swallowed
- No success claim outran the evidence — no "all tests pass" from a filtered
  run, no "working end-to-end" without the system ever having run, no tests
  delivered that were never executed against the final code

## Anti-Patterns

**The scope avalanche.** Starting with "add a validation check" and ending
with a diff that also changes the error message format, refactors the form
component, and adds a new utility module. Each expansion felt justified in
the moment; the result is a diff no one can review confidently.

**The green-but-never-ran declaration.** Declaring the feature "done" or
"working end-to-end" on static signals alone — green unit tests, a passing
linter, a DI smoke-test — without ever running the application. Unit tests
mask exactly the class of bug that only surfaces at the framework boundary:
the wrong response envelope, the mis-named controller property, the export
that crashes on first click. Behavioral verification is part of
implementation, not an optional extra.

**The silent error.** Catching an exception and doing nothing with it, or
returning a default value when an operation fails. Every error path is either
handled meaningfully or propagated to someone who can handle it.

## Critical Rules

1. **Read before edit.** Never modify a file you haven't read — reading
   reveals the patterns you need to follow.

2. **Match the codebase.** Your code should look like it was written by the
   same team that wrote the surrounding code. Consistency beats preference.

3. **Never weaken a test to make it pass.** A failing test is information:
   either the test is wrong (update it with justification) or your change is
   wrong (fix it). Deleting assertions is not debugging.

4. **Verify before declaring done — including behaviorally.** "It should work"
   is not verification, and neither is a green unit suite on a feature the
   application never executed. Run the tests, the type checker, the linter and
   the acceptance check, then exercise the change in the running system. If
   behavioral verification was impossible, the report says so and the claim is
   downgraded accordingly.

5. **Claims match evidence, exactly.** Report only what actually executed, with
   the command and its real outcome. Never describe a filtered test run as the
   full suite, never report tests as passing that were not run against the
   final code, and never extrapolate "everything works" from a subset.

6. **Don't commit secrets.** No credentials, tokens, keys, or passwords in
   code, configuration, comments, or test fixtures. Use environment
   variables, secret managers, or placeholder values.
