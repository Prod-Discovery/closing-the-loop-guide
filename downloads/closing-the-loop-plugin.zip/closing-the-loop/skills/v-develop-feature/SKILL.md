---
name: v-develop-feature
description: Orchestrate end-to-end feature development by composing stage skills into a coherent sequence with decision points and quality gates. Use when building a feature end-to-end (plan, implement, test, review, document, deliver), when a request implies a full development cycle rather than a single edit, when UI work needs design consideration before code, or whenever the change is large enough that jumping straight to code would skip stages.
trigger: [develop a feature, build this end to end, implement this feature fully, take this from plan to commit, complete feature cycle]
license: Apache-2.0
metadata:
  requires:
    - AGENTS.md
    - repo conventions
---

# Develop Feature

## Objective

Deliver a complete feature — from initial scope through committed, tested,
documented code — by invoking the right stage skills in the right order. This
skill does not replace individual stages; it sequences them, handles the
decision points between them, and defines when a stage is skipped, repeated,
or looped back to. The goal is a feature that was specified before it was
planned, planned before it was built, tested before it was reviewed,
documented before it was committed, and learned from before it was forgotten.

## Setup check

Before proceeding, verify `AGENTS.md` exists at the repo root and has been
updated within the last quarter (check git log on the file). If it is missing
or stale, run `v-setup-agent-context` first — every downstream stage assumes
current conventions, commands, and constraints are codified there.

**Toolchain preflight.** Confirm the environment can actually verify the work
before any of it is written: the runtime version matches what the repo
requires (manifest engine/platform constraints — e.g. `composer.json`'s PHP
version, `.nvmrc`, `go.mod`), the test command executes successfully on
unchanged code, and the application can be launched (or the reason it cannot
is recorded now). A version mismatch or a test harness that won't run is a
blocker to resolve or surface to the user at this point — discovering it in
Phase 4 means the feature ships with its core verification silently skipped.

**Working from a handover ticket?** Route by its explicit marker before Phase 0:

- `context-first-handover` or a local `handover/[feature]-delivery-context.md` → read
  [`handover-shape-feature`'s delivery contract](../handover-shape-feature/references/delivery-contract.md),
  load the live requirements and complete Delivery Context directly, and check only its evidence
  paths for drift. Changed evidence invokes a targeted **handover-shape-feature** refresh. Report
  `gate: not applicable`; feed unresolved decisions into normal planning and do not look for a
  Brief, AGENTS block, manifest, or sign-off.
- `discovery-handover` or a governed local `handover/` package → invoke
  **handover-retrieval**. It verifies the PM + Dev sign-off gate and loads the
  approved Engineering Brief + AGENTS.md block. The Brief becomes the spec
  input and the AGENTS block is appended before development.

Both markers on one ticket are an ambiguous path: stop and resolve it rather
than choosing whichever reader runs first.

## When to Use

- A feature requires multiple coordinated stages: planning, implementation,
  testing, review, documentation, and delivery
- The work is large enough that jumping straight to code would produce an
  unscoped, untested, or undocumented result
- The request implies a full development cycle ("build a feature", "develop
  this", "implement end to end"), including UI work that needs design
  consideration before code

Do not use this workflow for:
- Single-line fixes or trivial changes — just do the work directly
- Bug fixes — use **v-fix-bug**, which starts with diagnosis
- Release preparation — use **v-prepare-release**
- Pure refactoring with no behavior change — use **v-implement-code**
  directly with a clear scope

For ticket-driven delivery through PR, merge, and ticket close, use
v-ticket-to-release. For a fixed, gate-scored pipeline, use v-ship-feature.

**Optional deepening:** for high-stakes or security-relevant changes,
escalate via v-review-changes' security depth or
invoke **v-scored-code-review** for a harder verdict before merging.

## Context

Before starting the workflow, establish the foundation:

1. **Understand the request.** If the goal is vague ("make search better"),
   clarify the concrete outcome before entering the workflow.

2. **Assess complexity.** The default is to include all stages and justify
   exclusions, not to exclude stages and justify inclusions.

3. **Check preconditions.** The repository is in a clean state, the target
   branch is up to date, required tooling is available, and blocking issues
   from prior work are resolved.

4. **Identify the feature type.** This determines which stages are mandatory
   and which are conditional:
   - **Backend-only:** Skip **v-design-frontend**
   - **Frontend-involved:** Include **v-design-frontend** after planning
   - **Full-stack:** Include all stages
   - **Infrastructure/config:** May skip **v-design-frontend** and adjust
     **v-update-docs** scope to configuration documentation

5. **Assess specification needs.** Does this feature need a formal spec?
   - **Complex or ambiguous requests:** Start with **v-write-spec** to lock
     down requirements and acceptance criteria before planning
   - **Well-defined, small scope:** Proceed directly to planning
   - **Multi-team or user-facing features:** Always spec first — the spec
     becomes the contract between intent and implementation

## Workflow

Invoke each stage skill when you reach its phase — do not re-implement what
the stage skill already teaches.

### Phase 0: Specify — invoke **v-write-spec** (conditional)

**Condition:** The request is ambiguous, complex, multi-team, or user-facing
— the intent needs to be locked down before planning.

**Skip criteria:** The request is small, specific, and unambiguous. The
implementer would not interpret it two different ways.

**Gate:** Every requirement has testable acceptance criteria; constraints
and non-requirements are explicit. Any "TBD" means it is not ready.

### Phase 1: Plan — invoke **v-plan-work**

**Gate:** An implementer could execute every step without making design
decisions — no "TBD" or "figure out later" remains. If a spec exists from
Phase 0, every requirement is addressed by at least one step.

### Phase 2: Design — invoke **v-design-frontend** (conditional)

**Condition:** The feature involves user-facing interface changes — new
pages, components, layouts, visual interactions, or changes to existing UI.

**Skip criteria:** Pure backend work, API-only changes, infrastructure
changes, CLI tools, or any feature with no visual interface.

**Gate:** Every UI element has defined states (empty, loading, populated,
error) and responsive behavior.

### Phase 3: Implement — invoke **v-implement-code**

**Gate:** All planned changes are implemented. Types check. Focused tests
for the changed code pass. The diff contains only changes specified in the
plan — no unrelated "while I'm here" modifications.

### Phase 4: Test — invoke **v-run-tdd**

**Gate:** All tests pass — *executed against the final code in this phase*,
not assumed from an earlier run; a test that was written but never run does
not count as coverage. Coverage for new code meets project standards. No
tests were weakened or deleted to achieve a passing state. If a spec exists,
every Phase 0 acceptance criterion is covered by at least one test.
Additionally, the feature was exercised **behaviorally**: the application was
run and the feature executed end to end (the page loaded, the endpoint
responded, the export downloaded). If the running system cannot be exercised
in this environment, that is recorded as an explicit verification gap and
carried into the Phase 5 review and the final report — never silently
absorbed into a "done" claim.

**Loop-back condition:** If tests reveal implementation defects, return to
**Phase 3 (v-implement-code)** to fix the root cause. Do not patch tests to
mask broken behavior. After fixing, re-run this phase.

### Phase 5: Review — invoke **v-review-changes**

Review **adversarially**: treat the implementation's own success claims as
unverified and try to refute them against the code. Green tests are not
exoneration — a passing suite can mask a controller that crashes on every
request if no test crosses the framework boundary. Hunt specifically for the
bugs the tests *cannot* see.

**Gate:** The review surfaces no blocking issues. All findings are addressed
or explicitly documented as known limitations. Every must-fix finding that
was fixed is locked in by a test that **fails without the fix** — strengthen
or add tests until reverting the fix would turn the suite red. A fix without
a fail-without-fix test is one refactor away from silently regressing.

**Loop-back condition:** If review surfaces implementation issues — bugs,
security problems, missing error handling, pattern violations — return to
**Phase 3 (v-implement-code)** to address them. After fixing, re-run
**Phase 4 (v-run-tdd)** to verify the fixes, then return here.

**Optional deepening:** For high-stakes changes — security boundaries, auth,
payments, data migrations, public API contracts — additionally
invoke **v-scored-code-review** for a harder second verdict before merging.

### Phase 6: Document — invoke **v-update-docs**

**Skip criteria:** Internal refactors with no user-visible behavior change,
when no documentation references the changed code.

**Gate:** All documentation references to changed behavior are accurate. No
stale examples or instructions remain.

### Phase 7: CI — invoke **v-manage-ci**

**Skip criteria:** Changes that don't affect build, test, or deployment
configuration — most features that only add code within existing patterns.

**Gate:** CI configuration is valid and would handle the new code correctly.

### Phase 8: Commit — invoke **v-prepare-commit**

**Gate:** The commit is clean, well-messaged, and contains only
feature-related changes.

### Phase 9: Learn — invoke **v-capture-learning**

**Skip criteria:** Straightforward features with no notable friction or
discoveries. But default to capturing — most features teach something.

**Gate:** Any lessons worth preserving are recorded in a form that future
sessions can discover and apply.

## Output Contract

A completed v-develop-feature workflow produces these sections under `## Output Contract`:

### Summary

- **Feature:** [one-sentence description of what was built]
- **Stages completed:** [list of stages invoked, with any that were skipped and why]

### Detail

Artifacts produced by each stage:

- **Spec:** [requirements and acceptance criteria — or "N/A: request was unambiguous"]
- **Plan:** [scope, approach, and step breakdown]
- **Design:** [UI decisions — or "N/A: no UI changes"]
- **Implementation:** [files changed with rationale]
- **Tests:** [test coverage added, commands run, results]
- **Review:** [findings addressed, any known limitations]
- **Documentation:** [docs updated — or "N/A: no doc changes needed"]
- **CI:** [CI changes — or "N/A: no CI changes needed"]
- **Commit:** [commit message(s) and structure]
- **Learnings:** [lessons captured — or "No notable learnings"]

### Verification

| Check | Command | Result |
|-------|---------|--------|
| Types/lint | [command] | ✅ pass |
| Focused tests | [command] | ✅ pass |
| Full suite | [command] | ✅ pass |
| Acceptance | [specific check] | ✅ pass |

### Follow-ups

- [items deliberately deferred to later changes]
- [known limitations or technical debt taken on]
- "None" if the feature ships fully complete

## Quality Bar

A feature workflow meets the quality bar when:

- Every included stage was completed with its own quality bar satisfied
- Stages were skipped only with explicit justification, not by default
- Loop-backs were handled: issues found in review or testing were fixed at
  the source (implementation), not patched over
- The plan was followed — deviations were noted with rationale, not silent
- Tests verify behavior, not implementation details
- Documentation is current with the shipped behavior
- The commit is clean and well-messaged
- Learnings were captured for anything non-trivial

## Anti-Patterns

**Design-last.** Building the UI first, then trying to design it after the
implementation is done. When design is needed, it comes before implementation.

**Test-last scramble.** Implementing the entire feature, then scrambling to
add tests — those tend to test the implementation rather than the behavior.

**Documentation debt.** Shipping the feature and promising to "update docs
later." Docs written with the feature fresh in mind are accurate; docs
written from memory weeks later are not.

## Critical Rules

1. **Specify or justify skipping.** Phase 0 is the default for complex,
   ambiguous, or user-facing features.
2. **Plan before you build.** Phase 1 is not optional. Even a small feature
   gets a scope statement.
3. **Invoke stage skills — don't re-implement them.** Use each stage
   skill's full guidance; this orchestrator sequences stages, it does not
   replace them.
4. **Respect loop-back conditions.** Fix root causes in implementation. Do
   not patch tests, skip findings, or weaken assertions.
5. **Skip with justification, not by default.** "It seemed unnecessary" is
   not justification. "No UI changes exist in this feature" is.
6. **Stages are sequential with defined gates.** Do not start a phase until
   the previous phase's gate is met — gates prevent compounding errors.
7. **The workflow adapts to scope, not the other way around.** The sequence
   remains the same — only the depth varies.
8. **Produce evidence, not claims.** "I tested it" is not evidence. "All 47
   tests pass including 12 new ones for the search endpoint" is.
9. **Route the handover path explicitly.** A governed `discovery-handover`
   feature clears its PM + Dev sign-off gate through `handover-retrieval`
   before Phase 0. A `context-first-handover` loads requirements plus Delivery
   Context directly from the shared contract; it has no handover-specific
   approval gate, and its unresolved items enter the normal plan gate. Never
   apply one path's rules to the other.
10. **Calibrate every claim to what actually executed.** "Done" requires the
    feature to have run, behaviorally, in the application — or an explicit,
    prominent statement that it could not and why. "All tests pass" requires
    the full suite to have run against the final code. Over-claiming success
    is a workflow defect even when the code later turns out to be correct,
    because it removes the human's reason to check.
