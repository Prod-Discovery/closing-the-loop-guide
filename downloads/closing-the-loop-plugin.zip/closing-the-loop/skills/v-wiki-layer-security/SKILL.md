---
name: v-wiki-layer-security
description: Generate the security-audience layer for a repository wiki — auth model, data flows, sensitive-data handling, dependency CVE posture, audit-log paths, deployment security — from an AnalysisBundle. Use when the wiki orchestrator dispatches the security layer, when a security reviewer needs a "what should I know about this repo" page, or when an always-emit layer must scale from a terse read on a CLI tool up to a full surface map on a customer-facing service.
trigger: [generate security wiki, write security layer, security audience layer, security overview page for the repo, security posture summary]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Security

## Objective

Produce the security-audience layer of a generated wiki: a structured
read for a security person who has just opened this repo and wants to
know what surfaces matter. The layer answers operational questions —
auth model, data-flow shape, dependency CVE posture, audit-log paths,
deployment exposure — using only what the upstream `v-analyze-repo`
skill captured.

This layer is **always-emit**. Depth scales with signal richness: a
CLI tool with no auth surface and no regulated data still gets a
section — three terse paragraphs covering dependency posture, an
explicit "no auth surface" assessment, and a regulatory line. A
customer-facing service with auth code, regulated-data references,
and deployment artefacts gets the full surface map.

This skill is **scope-bounded**. It describes what a security person
would want to *know about* this repo. It does not audit the code for
vulnerabilities — that is `v-review-changes`' Security Depth pass.
Do not drift into vuln-hunting here.

## When to Use

- The wiki orchestrator (`v-generate-wiki`) dispatches the security
  layer — always-emit, regardless of signals
- A caller needs a structured security-audience read of a repo, with
  surfaces and posture grounded in an `AnalysisBundle`
- An organisation-level synthesis step needs each repo's security
  layer as input — dependency CVE counts, regulatory flags, auth
  surface assessments roll up across a portfolio

Do not use this skill when:

- No `AnalysisBundle` is available — invoke `v-analyze-repo` first
- The caller wants a vulnerability audit of the code — that is
  `v-review-changes`' Security Depth territory; do not freelance into it
- The caller wants threat modelling, attack-tree synthesis, or a
  pen-test plan — those are different artefacts entirely
- The caller wants free-form prose; this skill emits structured
  content for the orchestrator's `format-output` step to render

## Setup check

Before proceeding, verify that an `AnalysisBundle` is available as
input. If not, stop and instruct the caller to run `v-analyze-repo`
first. This skill never re-reads the repository to recover bundle
fields; that breaks the read-once contract the wiki layers all share.

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` matching `v-analyze-repo`'s
  output contract (`schemaVersion: "1.0"` at time of writing). The
  load-bearing fields are `dependencies.byEcosystem` (CVE coverage),
  `surfaces.*` (auth, data-flow, deployment surfaces), and the four
  scaling signals — `hasSecuritySensitiveCode`,
  `hasRegulatedDataReferences`, `hasCustomerVisibleAPI`,
  `hasDeploymentArtifacts`
- `options` (optional):
  - `cveCatalog`: pre-resolved map of dependency name + version → CVE
    entries when the caller has run a vulnerability database query
    alongside the bundle. When absent, the layer reports CVE status
    as unscored via a warning rather than fabricating findings
  - `regulatoryHints`: caller-supplied notes about regional regimes
    (e.g. `["GDPR", "NIS2"]`) that nudge emphasis. The skill never
    invents regulatory applicability; hints only weight signals the
    bundle already surfaces

If `bundle` is missing or its `schemaVersion` does not match, stop
and emit a warning. Do not proceed against an inferred shape.

## Workflow

### 1. Read the bundle, decide section scope

Walk the bundle once. Decide which sections this repo earns:

| Section | Conditional on… |
| --- | --- |
| `dependencyPosture` | always |
| `surfaceAssessment` | always (terse "no auth surface" is valid content) |
| `authModel` | `hasSecuritySensitiveCode` |
| `dataFlows` | `hasCustomerVisibleAPI` |
| `sensitiveDataHandling` | `hasSecuritySensitiveCode` OR `hasRegulatedDataReferences` |
| `auditLogPaths` | `hasSecuritySensitiveCode` |
| `regulatoryTouchpoints` | `hasRegulatedDataReferences` |
| `deploymentSecurity` | `hasDeploymentArtifacts` |

The scaling guarantee: the two always-emit sections appear even on a
one-file utility with no manifest. A repo with all four signals false
produces a short layer; that short layer is the contractual output,
not a defect.

### 2. Compose dependency posture — always emit

Walk `dependencies.byEcosystem`. Capture:

- `totalDependencies`: sum across `dependencies.byKind` (runtime +
  dev + peer + optional)
- `severityDistribution`: when `options.cveCatalog` is provided,
  count of deps with at least one open vulnerability, bucketed by
  `critical`, `high`, `medium`, `low`. When the catalogue is absent,
  emit zeros plus a `WARN_SEC_DEPS_UNVERSIONED` warning — never
  fabricate CVE counts
- `unknownLicenseCount`: deps the bundle flagged with
  `WARN_LICENSE_UNKNOWN` or whose `license` field is null
- `truncated`: passes through `dependencies.truncated`
- `notableDeps`: up to 8 entries the bundle flags as load-bearing
  for security — auth libraries, crypto primitives, payment deps,
  logging libraries that own the audit-log surface. Each carries
  `name`, `ecosystem`, `version`, and a short `reason`

When `dependencies.byEcosystem` is empty (no manifest at all),
emit the section with `totalDependencies: 0` and a
`WARN_SEC_NO_DEPENDENCY_MANIFEST` warning. Empty-state is signal,
not silence.

### 3. Compose the surface assessment — always emit

A one-paragraph plain-text read on three questions, each with a
verdict (`yes`, `no`, `partial`) plus one sentence of grounding:

1. Auth-bearing? — from `hasSecuritySensitiveCode` plus surface
   evidence
2. Data-handling? — from `hasRegulatedDataReferences` plus
   database / object-store integrations in `surfaces.internal`
3. Public-facing? — from `hasCustomerVisibleAPI` plus
   `surfaces.customerFacingAPI` entries

The assessment is the layer's elevator pitch: a security person
scanning the wiki should be able to read this paragraph alone and
decide whether to read further.

When all three verdicts are `no`, emit a `WARN_SEC_NO_AUTH_SURFACE`
warning so the reader knows the layer is intentionally short, not
underdone.

### 4. Auth model — when `hasSecuritySensitiveCode` is true

Derive from surface evidence and dependency entries. Capture per
detected mechanism:

- `kind`: short label (`session-cookie`, `bearer-token`, `oauth2`,
  `oidc`, `mtls`, `api-key`, `none-detected`, `unknown`). Multiple
  mechanisms get multiple entries
- `evidence`: bundle paths or fields (auth-library manifest entries,
  `auth*` / `oauth*` surface entries, signal evidence for
  `hasSecuritySensitiveCode`)
- `note`: one or two sentences on what the bundle reveals

Do not infer beyond the bundle. If `hasSecuritySensitiveCode` fires
purely on keyword co-occurrence with no framework or library, mark
`kind: "unknown"` and record the keywords as evidence.

### 5. Data flows — when `hasCustomerVisibleAPI` is true

Trace the request → processing → storage → response path. For each
flow (typically one primary; up to three on a richer service),
capture an ordered list of stages:

- `name`: short label (`ingress`, `auth`, `validation`, `handler`,
  `persistence`, `egress`, `external-call`)
- `note`: one sentence on what happens at this stage from a security
  lens — input validated, auth enforced, secrets read, data
  encrypted at rest, third-party call out
- `evidence`: bundle path or surface entry

Mark input-validation surfaces explicitly. A handler with no
validation evidence (no schema, no validator library) earns a
`WARN_SEC_INPUT_VALIDATION_NOT_SURFACED` warning — not because
validation is necessarily missing, but because the bundle does not
prove it exists.

The architecture layer also emits data flows; the two views are
different lenses. Architecture cares about component boundaries;
security cares about trust boundaries, input validation, and
secret reads. Cross-link rather than duplicate.

### 6. Sensitive-data handling — when security or regulated signals fire

Capture how the repo handles data that warrants protection:

- `dataKinds`: short labels for sensitive-data kinds surfaced by
  signal evidence (`pii`, `payment`, `health`, `financial`,
  `credentials`, `internal-secrets`)
- `handlingNotes`: observations grounded in bundle fields —
  encryption library presence, secret-management integrations,
  structured logging libraries that mask fields, ORM layers
  mediating database access. Each carries `evidence`
- `gaps`: when a sensitive-data signal fires but no protective
  surface is detectable, record as an analyst-facing note ("the
  bundle does not surface protective controls for this data kind;
  worth a closer look") — not as an audit finding

The `gaps` framing keeps the layer out of vulnerability-audit
territory. The layer reports what the bundle *does and does not
show*; it does not pronounce the code vulnerable.

### 7. Audit-log paths — when `hasSecuritySensitiveCode` is true

Surface where audit-relevant events flow:

- `paths`: list of `{ path, kind, evidence }` where `kind` is one of
  `structured-log`, `audit-trail`, `event-stream`, `db-table`,
  `external-sink`. `evidence` points at a logging library, a
  directory match, or an audit-shaped table name surfaced in the
  bundle
- `coverageNote`: one-sentence read on whether coverage looks
  comprehensive or partial — anchored in evidence, not opinion

When the security signal fires but no audit-shaped surface is
detectable, emit empty `paths` and a
`WARN_SEC_AUDIT_LOGS_NOT_SURFACED` warning. Absence is the finding.

### 8. Regulatory touchpoints — when `hasRegulatedDataReferences` is true

For each regime surfaced by signal evidence, capture:

- `regime`: short label (`GDPR`, `NIS2`, `PII`, `PCI`, `HIPAA`,
  `financial-services`, `payment-services`)
- `triggers`: the bundle fields that surfaced the regime
- `note`: one sentence on what the regime implies for *this* repo,
  grounded in the trigger — not generic regulatory copy

Do not summarise the regime; do not paraphrase its requirements.
Flag the touchpoint, point at the evidence, stop. Emit a
`WARN_SEC_REGULATED_DATA_DETECTED` warning so downstream consumers
can route on the bundle signal even when prose is short.

### 9. Deployment security — when `hasDeploymentArtifacts` is true

From `surfaces.deploymentArtifacts`, capture:

- `secretManagement`: how secrets enter the runtime — secret-manager
  references, env-var injection patterns in workflow files, `.env`
  templates. Each entry carries `evidence`
- `networkExposure`: ingress shape — public ports, ingress
  controllers, public-facing routes cross-referenced with deployment
  manifests. The lens is "what is reachable from outside"
- `iamAndRoles`: identity surfaces — service accounts, IAM role
  bindings, RBAC configs. When none are detectable, say so with a
  warning rather than omitting

Cross-reference the architecture layer's `deploymentTopology` rather
than duplicating it. Security focuses on exposure, identity, and
secrets; architecture focuses on runtime layout.

### 10. Assemble the structured output

Emit a single object matching the Output Contract. Conditional
sections that did not earn their place (signal false) are omitted
entirely — not emitted as null or empty. The two always-emit sections
are present in every output.

## Output Contract

The skill emits exactly one JSON object:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "security",
  "repo": { "name": "<bundle.repo.name>", "path": "<bundle.repo.path>" },
  "dependencyPosture": {
    "totalDependencies": 0,
    "severityDistribution": { "critical": 0, "high": 0, "medium": 0, "low": 0 },
    "unknownLicenseCount": 0,
    "truncated": false,
    "notableDeps": [
      { "name": "<dep>", "ecosystem": "<key>", "version": "<v>", "reason": "<why load-bearing>" }
    ]
  },
  "surfaceAssessment": {
    "authBearing": "yes | no | partial",
    "dataHandling": "yes | no | partial",
    "publicFacing": "yes | no | partial",
    "summary": "<one paragraph plain text>"
  },
  "authModel": [
    {
      "kind": "session-cookie | bearer-token | oauth2 | oidc | mtls | api-key | none-detected | unknown",
      "evidence": ["<bundle path or field>"],
      "note": "<one to two sentences>"
    }
  ],
  "dataFlows": [
    {
      "name": "<flow name>",
      "stages": [
        { "name": "<stage>", "note": "<one sentence>", "evidence": "<bundle path>" }
      ]
    }
  ],
  "sensitiveDataHandling": {
    "dataKinds": ["pii | payment | health | financial | credentials | internal-secrets"],
    "handlingNotes": [
      { "note": "<observation>", "evidence": "<bundle path>" }
    ],
    "gaps": [
      { "note": "<analyst-facing observation>", "evidence": "<bundle path>" }
    ]
  },
  "auditLogPaths": {
    "paths": [
      { "path": "<repo-relative path>", "kind": "structured-log | audit-trail | event-stream | db-table | external-sink", "evidence": "<bundle field>" }
    ],
    "coverageNote": "<one sentence>"
  },
  "regulatoryTouchpoints": [
    {
      "regime": "GDPR | NIS2 | PII | PCI | HIPAA | financial-services | payment-services",
      "triggers": ["<bundle path or matched term>"],
      "note": "<one sentence>"
    }
  ],
  "deploymentSecurity": {
    "secretManagement": [
      { "kind": "<short label>", "evidence": "<path>" }
    ],
    "networkExposure": [
      { "kind": "<short label>", "evidence": "<path>" }
    ],
    "iamAndRoles": [
      { "kind": "<short label>", "evidence": "<path>" }
    ]
  },
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<bundle field>"] }
  ]
}
```

Field-level rules:

- `schemaVersion` is fixed at `"1.0"` for this skill version. Bump on
  contract changes
- `audience` is the literal string `"security"` — the orchestrator's
  `format-output` step routes by this field
- `dependencyPosture` and `surfaceAssessment` are always present.
  Every other top-level section is omitted entirely when its signal
  is false; do not emit `null` or empty objects — absence is the
  signal
- Every `evidence` value points at a bundle field or repo-relative
  path the bundle already references. Never fabricate a path
- `surfaceAssessment.summary` is plain prose — no markdown headings,
  no fenced code, no tool names rendered as identifiers
- `severityDistribution` carries zeros when no `cveCatalog` was
  supplied; the accompanying `WARN_SEC_DEPS_UNVERSIONED` is what
  signals "not assessed", not the zero counts
- `warnings` uses stable codes:
  - `WARN_SEC_NO_AUTH_SURFACE` — surface assessment all `no`
  - `WARN_SEC_DEPS_UNVERSIONED` — no CVE catalogue supplied; severity
    distribution is unscored
  - `WARN_SEC_NO_DEPENDENCY_MANIFEST` — bundle has no manifest at all
  - `WARN_SEC_REGULATED_DATA_DETECTED` — regulatory touchpoints emitted
  - `WARN_SEC_AUDIT_LOGS_NOT_SURFACED` — security signal true but no
    audit-shaped surface detectable
  - `WARN_SEC_INPUT_VALIDATION_NOT_SURFACED` — public API present but
    no validator library detected in dependencies
  - `WARN_SEC_BUNDLE_INCOMPLETE` — bundle missing fields the layer
    needs; output is best-effort

## Quality Bar

A security layer meets the quality bar when:

- `dependencyPosture` and `surfaceAssessment` are present in every
  output, regardless of signal richness
- A security person opening the layer on a CLI tool reads three
  short paragraphs and feels oriented — not empty, not padded
- A security person opening it on a customer-facing service reads a
  full surface map across auth, data flows, sensitive-data
  handling, audit-log paths, regulatory touchpoints, and deployment
- Tool, library, or framework names appear only in structured
  `evidence` fields, never as code identifiers in body prose
  (general labels — "structured-logging library",
  "secret-management integration" — are fine)

## Anti-Patterns

**The regulatory boilerplate.** Pasting GDPR or PCI summary text
instead of pointing at the bundle's trigger evidence. The reader
knows what GDPR is; what they want to know is *why this regime
fires for this repo*. Cite the trigger and stop.

**The silently dropped signal.** A bundle with
`WARN_SIGNAL_CONFLICT` on a security-relevant signal — and the
layer silently picks one side. Surface the conflict so the reviewer
knows the underlying signal was ambiguous.

## Critical Rules

1. **Always emit; depth scales.** Every wiki run produces a security
   layer. A thin bundle yields a terse layer; a rich bundle yields a
   full one. Skipping is not allowed — even on a CLI tool with no
   surfaces, the dependency-posture and surface-assessment sections
   appear.

2. **The bundle is the only ground truth.** No re-reading the repo,
   no opening a Dockerfile, no shelling out to a CVE database. The
   bundle plus the optional `cveCatalog` are the entire input
   surface. If the bundle is wrong, fix it in `v-analyze-repo`; do not
   patch it here.

3. **No verdicts, only surfaces.** The layer describes what is
   visible — auth bearing, public-facing, data-handling, audit
   paths, regulatory triggers. It never pronounces the code
   vulnerable, the configuration broken, or the design unsafe. That
   is `v-review-changes`' Security Depth scope.

4. **Every assertion has evidence.** Every section, every callout,
   every notable dep, every audit-log path carries an `evidence`
   field that points at a bundle path or repo-relative location the
   reviewer can open. Un-evidenced claims are removed, not hedged.

5. **Stay in your lane.** Security ≠ architecture ≠ engineering ≠
   executive. When a sentence starts to describe component
   boundaries, stop — that is architecture. When it starts to
   describe how to set up the project, stop — that is engineering.
   When it starts to argue for investment, stop — that is executive.

6. **Output is structured content, never markup.** The skill returns
   the constrained JSON shape defined in the Output Contract. The
   orchestrator's `format-output` step renders it. Emitting markup
   directly here breaks the audience-skill / format-step seam and
   prevents independent improvements to either side.
