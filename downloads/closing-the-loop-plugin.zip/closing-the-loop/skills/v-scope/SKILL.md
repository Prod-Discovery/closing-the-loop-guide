---
name: v-scope
description: Use when a ticket (Jira, Linear, GitHub, or pasted) is picked up, when asked to write a spec or plan, to check whether work is ready, to 'grill me' or 'interview me' on a plan, or when a request is vague, too big, or needs splitting — and to run a feature or bug end to end. Interviews until the scope is shared, then produces testable acceptance criteria, a success signal with a check date, and a first slice that fits one PR; runs outcome checks. Not for diagnosing a failure (v-investigate).
license: Apache-2.0
metadata:
  author: "Gated pipeline recipe contributed by the PreCount team (@sjimmunck)"
---

# Scope

**What problem, for whom, how will we know it's solved, and what is the
smallest first slice?**

## When to Use

- Before any code: a ticket was assigned, or someone asked for a change
- The ticket is vague, too big, or has no testable acceptance criteria
- A shipped change's outcome check is due (see **v-ship**)
- Someone asks to be grilled or interviewed on a plan

Skip when the change fits one obvious sentence with nothing to decide: state
the sentence and go straight to **v-build**.

## Workflow

### 1. Load the work

First, list unticked `.visma-skills/outcomes.md` lines dated today or
earlier, and offer to run each outcome check.

Fetch the ticket with the best available integration (tracker MCP server >
forge CLI > text the user pastes) and record its reference. A missing
integration is never a stop: ask for the text. Then read the code the work
touches — a ticket can read clearly and still contradict the code.

A Closing the Loop handover — the ticket or its parent carries a
`discovery-handover*` or `context-first-*` marker, or the input is a local
`handover/` package — is loaded by `references/recipe-handover.md` before
anything else here.

Classify it, because the type decides what "done" means:

- **Feature** — acceptance criteria describe new behavior.
- **Bug** — the criterion is "the reproduction passes and no sibling of the
  defect remains". Diagnosis happens in **v-investigate**, not here.
- **Chore** (refactor, config, dependency bump) — the criteria are the list
  of what must *not* change.
- **Outcome check** — compare the success signal recorded at scope time (in
  the tracker or `.visma-skills/outcomes.md`) with what actually happened.
  Report it; close the item (in `outcomes.md`: tick the line, add the result,
  and ship that like any change) or open new work.

### 2. Check readiness

| Check | Ready when |
|---|---|
| Problem | Names who is affected and what changes for them |
| Acceptance criteria | Each is decided pass/fail by a test or a command — `Given … when … then …` |
| Success signal | Observable after release (a metric, a behavior, support volume), with a date to check it. Only chores no user can see may say "criteria pass" |
| Size | Fits one reviewable PR |
| Boundaries | Out-of-scope items named; dependencies and blockers known |

### 3. Grill until the scope is shared

While the Quality Bar fails, or when the user asks to be grilled, settle
each decision that changes what gets built — which screen, what data, real
or placeholder — or is hard to undo. Each is the user's call, even after
"ship it"; a literal reading of the ticket doesn't settle it when another
reading would build something different. Decide reversible details yourself
(step 5).

1. Map those decisions as a tree: which answers depend on others.
2. Answer from the code, docs, and tracker what they can.
3. Ask one question per reply — the first unsettled prerequisite, else the
   highest-impact decision — with your recommended answer and why, so
   "yes" accepts it. Mark guesses as guesses.
4. Re-map after each answer; record hard-to-undo answers (step 5).
5. Until the Quality Bar holds, a reply holds what you learned and that one
   question.

Nobody can answer — the run is unattended, or the user doesn't know: draft
every open question with your recommendation for the ticket owner, and stop
rather than pick an interpretation. Propose criteria, never facts or invented
data; a missing number stays an open question with an owner.

Too big: split into **vertical slices** — each delivers or proves something
end to end — ordered riskiest first, each with its own criteria, and tagged
*can run unattended* (its criteria are commands, nothing left to decide) or
*needs a human*.

### 4. Choose the depth

| The work is… | Produce |
|---|---|
| Small and clear | The scope statement in the Output Contract |
| Ambiguous, user-facing, multi-team, or contract-changing | A spec — read `references/spec.md` |
| Multi-step, cross-module, or carries ordering or migration risk | A plan — read `references/plan.md` |

A spec or plan the ticket cannot hold goes in
`.visma-skills/specs/<ticket-or-slug>.md` unless the team settings name
another place.

### 5. Flag one-way doors

Name every decision that is expensive to undo — public API shape, data model,
migrations, vendor lock-in — and get the user's call before building.
Read earlier decisions on the same subject first. Record each one-way door
the user decides in `.visma-skills/decisions/` — or the team's existing
decision log, if the settings name one; a decision that replaces an earlier
one says so.
Reversible decisions: make them, note why in the scope, move on.

### 6. Hand off

Hand off only when the user asked for the work to be done, not just scoped,
and accepted any criteria you proposed. Otherwise report and stop.

Unfamiliar code or a bug: invoke **v-investigate**.
Clear path: invoke **v-build**.
The whole flow end to end: follow a recipe below.

Called by a recipe or another skill's reference for one step: do that
step, return the result to the caller, and let it continue.

## References

| When | Read |
|---|---|
| Writing a full spec | `references/spec.md`, example in `references/spec-example.md` |
| Writing a step-by-step plan | `references/plan.md` |
| Feature end to end, from ticket to merged PR | `references/recipe-feature.md` |
| Bug end to end, from symptom to merged fix | `references/recipe-bug.md` |
| A Closing the Loop handover ticket or package (added by this bundle) | `references/recipe-handover.md` |
| A fixed pipeline with a scored spec gate and a spec-to-code trace at review, or drafting spec, plan, and tasks for the backlog to ship later | `references/recipe-gated.md` (contributed by the PreCount team) |

## Make it yours

Before step 1, read the team's `.visma-skills/project.md` if it exists.
Precedence: the user's instruction for this task, then that file and
`AGENTS.md` (or `CLAUDE.md`), then your own
`.visma-skills/local/preferences.md` — which never relaxes an approval gate
— then this skill. The layout is in **v-ship** (`references/project-settings.md`). This skill reads: questions per
reply (default one), extra readiness checks, the maximum slice size, where
specs and plans live, who may edit tickets in which states, and any team
reference files to load, each with its condition.

## Output Contract

### Summary

One line: the ticket or request, the verdict (ready / refined / split /
blocked), and the next skill.

### Detail

```markdown
**Problem:** who is affected, what changes for them
**Acceptance criteria:**
1. Given …, when …, then …
**Success signal:** what we will observe after release — check on <date>
**Out of scope:** …
**Slices:** 1. (this one) … — needs a human / can run unattended 2. …
**One-way doors:** decision — owner — decided / open
```

A spec or plan, when one was written, replaces the matching lines.

### Verification

What readiness was checked against: files read, questions asked and who
answered, tracker updated (link) or "not written back".

### Follow-ups

Open questions with owners, later slices, or "None".

## Quality Bar

It fails when two engineers reading the scope would build different
things.

## Anti-Patterns

**Horizontal slicing.** "Slice 1: database, slice 2: API, slice 3: UI" —
nothing is usable until the last slice lands, so risk is discovered last.

## Critical Rules

1. **Tracker writes need approval.** Show the exact text — refined criteria,
   new sub-tickets, questions — and write it only after the user says yes.
