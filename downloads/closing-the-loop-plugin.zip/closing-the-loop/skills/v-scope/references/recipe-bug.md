# Recipe: Bug, End to End

Read by **v-scope** when a bug should go from symptom to merged fix in one
flow. A fix is not "make the error go away"; it removes the cause.

Trivial bugs, where the error names its own cause, skip straight to
**v-build**. Start from a clean working tree on an up-to-date base, so the
reproduction tests the code everyone else runs. Pausing mid-flow: write
where you stopped, what is next, and open questions to
`.visma-skills/local/handoff.md` (gitignored — create `.visma-skills/.gitignore` containing `local/` if it is missing); read it first on resume and
delete it when the flow ends.

## Sequence

| Stage | Skill | Gate before the next stage |
|---|---|---|
| 1. Capture the symptom | **v-scope** | Concrete: exact error, steps, environment, when it last worked — "it doesn't work" is not a symptom. A success signal, usually "no new reports of this symptom by <date>" |
| 2. Diagnose | **v-investigate** | Root cause shown with evidence; a reproduction exists — a failing test when the project has tests; siblings of a pattern error listed |
| 3. Fix | **v-build** | The reproduction passes; the fix is the smallest change that removes the cause; each sibling is fixed here or filed — a broken pattern is fixed once, at its source; nothing unrelated in the diff |
| 4. Challenge | **v-challenge** | The review confirms the fix removes the cause rather than hiding the symptom |
| 5. Ship | **v-ship** | The commit message names the root cause: what was wrong, why, and what changed |

A fix that turns out architectural or multi-file gets a repair plan before
stage 3 ([plan.md](plan.md)), with its blast radius stated.

## Loop-backs

- The fix passes the reproduction but breaks another test: the diagnosis was
  incomplete — back to stage 2.
- Challenge finds the fix treats a symptom, misses siblings, or creeps in
  scope — back to stage 2.

## Report

Each stage's Output Contract in order, opening with the bug in one sentence
and its root cause in one sentence.
