# Recipe: Feature, End to End

Read by **v-scope** when a feature should run from intake to landed code in
one flow. Each stage's skill owns *how*; this recipe owns the order, the
gates between stages, and the loop-backs.

## Modes

Set both at the start:

- **Entry** — *direct* (the user describes the feature) or *ticket* (a
  tracker reference is the source of truth).
- **Landing** — *local* (ends at a clean commit) or *PR* (ends merged on the
  default branch, ticket updated). Ticket entry with PR landing is the common
  pair; neither requires the other.

Agree up front how far to go unattended. Default: stop before merging and
ask. Auto-merge happens only when the user said so for this change.

## Preconditions

- Clean working tree and an up-to-date base. In ticket mode, a fresh branch
  off the default branch, named by the project's convention.
- `AGENTS.md` read if present; it need not mention these skills. Missing,
  or its commands fail: continue, and offer **v-ship**
  (`references/agent-context.md`) as a follow-up, with this task as its
  representative task.
- Pausing mid-flow: write where you stopped, what is next, and open
  questions to `.visma-skills/local/handoff.md` (gitignored — create `.visma-skills/.gitignore` containing `local/` if it is missing); read it
  first on resume and delete it when the flow ends.

## Sequence

| Stage | Skill | Gate before the next stage |
|---|---|---|
| 1. Scope | **v-scope** | Ready: testable criteria, a success signal, fits one PR. Bugs switch to [recipe-bug.md](recipe-bug.md) |
| 2. Investigate — when the code is unfamiliar or the approach uncertain | **v-investigate** | The change site is mapped, or the spike answered its question |
| 3. Build — UI work starts with the frontend reference | **v-build** | Every criterion has evidence; every verification layer passes |
| 4. Challenge — fresh context, depth by risk | **v-challenge** | No blocking finding open |
| 5. Ship | **v-ship** | Local: a clean commit. PR: merged under the protection rules, default-branch CI green, ticket updated, outcome follow-up created |

## Loop-backs

- Challenge finds a defect: back to stage 3, then re-run stage 4. Fix the
  cause; never weaken a test to get a pass.
- Review feedback reveals an architectural problem, not a local defect: back
  to stage 1.
- The default branch moved while the PR was open: integrate it, then re-run
  stage 3's verification and stage 4 on the result.
- The merge broke the default branch: open a revert and, with the user's
  yes, merge it and reopen the ticket with the finding; report `reverted`.
  This recipe owns the merge it asked for.

## Skipping a stage

Skip only with a reason tied to the change ("no UI in this feature"), never
because a stage seemed unnecessary. Stage 2 is the usual skip; stage 4 never
is.

## Report

Each stage's Output Contract in order, opening with: entry and landing mode,
stages skipped and why, and — for PR landing — the PR, merge SHA, and final
ticket state.
