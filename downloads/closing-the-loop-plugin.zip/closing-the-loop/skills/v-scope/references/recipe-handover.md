# Recipe: A Closing the Loop Handover

> Added by the Closing the Loop bundle; not part of the upstream `visma-skills` library.

Read by **v-scope** when the ticket, or its parent, carries a Closing the
Loop handover marker, or when a local `handover/` package is the input. It
wraps [recipe-feature.md](recipe-feature.md): the stages, gates and
loop-backs are the same. This recipe owns what differs, which is how the
work is loaded and what the build must prove.

## 1. Route by marker, before any scoping

Read the marker first. Do not grill, re-scope or plan before the handover is
loaded.

| The ticket carries… | Path | Load it by |
|---|---|---|
| `discovery-handover`, or a governed local `handover/` package | governed | Invoke **handover-retrieval** with the ticket key. It folds in new comments, checks the PM + Dev sign-off gate and, on pass, loads the approved Engineering Brief, the frozen PRD and the AGENTS.md block. Gate open: stop and report what is missing. |
| `discovery-handover-story` / `discovery-handover-backlog-item`, or a parent carrying `discovery-handover` | governed child | Invoke **handover-retrieval** on the child. It walks up to the Epic, checks the same gate and loads the payload for that slice or chore. |
| `context-first-handover`, or a local `handover/<feature>-delivery-context.md` | context-first | Follow *Direct delivery read* in the [delivery contract](../../handover-shape-feature/references/delivery-contract.md): split the description at `## Delivery Context`, load both halves in full, then check the evidence-index paths against the recorded base commit. Changed evidence: a targeted **handover-shape-feature** refresh, then reload. |
| `context-first-story` / `context-first-backlog-item` | context-first child | Walk to the parent and compare the child's stamped context hash with the parent's current one. Stale: invoke **handover-project-stories** reconciliation and stop before building. |
| A governed and a context-first marker together | ambiguous | Stop and resolve it. Never let whichever reader runs first decide. |
| No marker | not a handover | Leave this recipe; scope the ticket the ordinary way. |

## 2. What the loaded handover settles

- **Governed: the Brief is the scope.** Its §6 was ratified at the PM + Dev
  gate. Take the problem, acceptance criteria (`AC-n`) and out-of-scope list
  from the Brief as they stand: no grilling, no fresh spec. On a conflict the
  Brief wins over the frozen PRD. A real gap or contradiction is not yours to
  fill: report it, because a requirement change reopens the gate. Append the
  AGENTS.md block to the repo's `AGENTS.md` if it is not there yet.
- **Context-first: there is no handover gate** (`gate: not applicable`). The
  live requirements and the Delivery Context are the input, and its open
  items are ordinary scoping questions: grill on those, as **v-scope** step 3
  does. A spec or plan written here is an engineering aid. It is not a
  handover artifact and needs no PM or Dev sign-off.
- **One child per run.** For an epic-shaped feature the caller
  (**handover-deliver-epic**) passes one child at a time, chores first. Scope
  is that child's slice, never the whole Epic.

## 3. Before building

- **Fresh branch** off the updated default branch, named by the project's
  convention.
- **Mark the ticket in flight.** Move it into the project's first in-flight
  state, chosen from the transitions the tracker offers, not from an assumed
  name, so started work does not read as untouched. This is the one tracker
  write the handover pre-approves. It is best effort and never a gate: with
  no write path, say so and carry on.
- **Toolchain preflight.** Confirm the environment can verify the work
  before any of it is written: the runtime version matches what the repo
  requires, the test command passes on unchanged code, and the application
  starts (or the reason it cannot is recorded now). A mismatch is a blocker
  to resolve or raise here. Found later, it means the feature ships with its
  main verification skipped.

## 4. Extra gates on the feature recipe's stages

| Stage | Also required for a handover |
|---|---|
| 3. Build (**v-build**) | **Behavioural verification:** the change was exercised in the running application, not only in tests. Where that was impossible, the report says so and "done" is not claimed. Every fix is held by a test that fails without the fix. |
| 4. Challenge (**v-challenge**) | Use the adversarial review whatever the diff size, and treat the build's own success claims as unverified. Check each `AC-n` (or the Delivery Context's acceptance behaviour) against evidence. |
| 5. Ship (**v-ship**) | **No process artifacts on the branch.** Discovery files, the handover package, prototypes, specs, plans and review write-ups stay on the ticket or in untracked local directories. Never edit `.gitignore` to force them in. Documentation that ships with the change is not a process artifact. The PR links the ticket. Do not merge unless the user said so for this change. |

Calibrate every claim to what actually ran. The final report lists, per
criterion, the evidence and how it was produced.

## Report

The feature recipe's report, opening with: the handover path (governed,
governed child, context-first, context-first child), the gate result
(`passed`, `open` or `not applicable`), the version of the Brief or the
context hash that was built from, and the ticket's state.
