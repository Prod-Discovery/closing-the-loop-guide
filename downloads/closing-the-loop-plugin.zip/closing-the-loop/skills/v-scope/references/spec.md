# Write Spec

Read by **v-scope** when the work is ambiguous, user-facing, multi-team, or
contract-changing. A spec answers three questions: what are we building, what
does done look like, and what are we explicitly not building.

Contents: Workflow · Output Contract · Quality Bar · Anti-Patterns · Critical Rules

## Workflow

### 1. Capture Requirements

Turn the user's intent into concrete outcomes (not feature labels) and write
each requirement as a behavior statement:

- "When a user submits a search query, the system returns matching results
  within 200ms" — NOT "The search should be fast"

Each requirement must be independent (understandable on its own), testable
(clear pass/fail criterion), unambiguous (one interpretation), and bounded
(explicit scope limits). Capture what the system does, who triggers it, when
it applies, and what success looks like.

### 2. Define Acceptance Criteria

For each requirement, write criteria that an automated test or manual
verification can check:

```
Given: [precondition — the state of the system before the action]
When:  [action — what the actor does]
Then:  [outcome — what the system does in response, observable and measurable]
```

Assert on behavior, not implementation ("returns JSON with status 200", not
"uses the framework's response helper"). Cover the edges: happy path, error
path, empty state, boundary values, authorization failures.

### 3. Document Constraints and Non-Requirements

Constraints limit how the implementation can be done — performance budgets,
compatibility, security, regulatory requirements — and need specific
thresholds, not vague qualifiers. Non-requirements prevent scope creep:
features explicitly excluded, quality attributes deferred, edge cases
acknowledged but not addressed now.

### 4. Surface Ambiguities

For each requirement, ask whether two engineers could interpret it
differently, whether implicit assumptions should be explicit, and whether it
conflicts with existing behavior. An ambiguity the code or docs settle:
settle it and cite the source. One that changes what gets built or is hard
to undo goes to the user through the grill in SKILL.md step 3, with your
recommended answer — never resolved on your own, because a guess written into
a spec reads as a decision; record the answer, who gave it, and why. A
reversible detail: choose, and list it under Assumptions. A decision that
belongs to someone else is marked blocked with its owner, and the spec moves
on.

### 5. Break Down Into Tasks (Optional)

For complex specs, decompose into implementation tasks: each small enough for
a single agent context window, ordered by dependency, independently
verifiable, and linked to the requirements it implements. Task breakdown
follows the same risk-first ordering as [plan.md](plan.md) — the most
uncertain tasks go first.

Before handing the spec to an implementer, check it against the Quality Bar.
Blocked open questions are acceptable; silent gaps are not.

## Output Contract

Every spec must include these sections:

```markdown
# [Feature/Change Name]

## Overview
[2-3 sentences: what this is, why it matters, who it's for]

## Requirements

### REQ-1: [Requirement title]
[Behavior statement]

**Acceptance criteria:**
- Given [precondition], when [action], then [outcome]
- Given [precondition], when [action], then [outcome]

### REQ-2: [Requirement title]
...

## Constraints
- [Performance, compatibility, security, or regulatory constraint]
- [Constraint with specific threshold or boundary]

## Non-Requirements (Explicit Exclusions)
- [Feature or behavior explicitly NOT included in this work]
- [Edge case acknowledged but deferred]

## Assumptions
- [Something believed true but not verified — if wrong, the spec changes]

## Open Questions (if any)
- [ ] [Question that blocks a requirement — with who needs to answer it]

## Tasks (if breaking down into implementation units)
1. [Task title] — implements REQ-1, REQ-2
2. [Task title] — implements REQ-3
...
```

Gated pipelines (e.g. [recipe-gated.md](recipe-gated.md)) may require
additional spec sections — users & stakeholders, user journeys, success
metrics — carried as extra H2s extending this same contract.

See [spec-example.md](spec-example.md) for a worked example applying this
contract.

## Quality Bar

A spec meets the quality bar when:

- Every requirement has at least one testable acceptance criterion
- An implementer can build the feature without asking clarifying questions
- Constraints have specific thresholds and non-requirements draw explicit
  scope boundaries
- Ambiguities are resolved with documented rationale, or explicitly marked
  as blocked and assigned
- Requirements trace to a user need, not to implementation convenience

## Anti-Patterns

**The wish list spec.** A bullet list of features with no acceptance
criteria, no constraints, and no exclusions. Agents will interpret each
bullet differently every time.

**The spec novel.** A 20-page document that no one reads. If a spec is too
long, the feature is too big — break it into smaller specs.

**The living spec that never ships.** Continuously refining the spec instead
of declaring it ready for implementation. A spec needs to be specific enough
to implement and verify, not perfect.

## Critical Rules

1. **Behavior over implementation.** Specs define what the system should do,
   not how to build it. Exception: when the implementation approach is itself
   a requirement (e.g., "must use the existing auth middleware").

2. **Explicit exclusions are not optional.** Scope without boundaries expands
   until the work is unshippable. Name what you are not building and which
   edge cases you are deferring.

3. **Assumptions are first-class.** List them. Making assumptions visible
   lets you validate them early and adapt when they break.

4. **Specs are versioned artifacts.** When requirements change, update the
   spec. A stale spec is worse than no spec — it actively misleads.

5. **Proportional depth.** A one-endpoint API addition needs a one-page spec;
   a payment system rewrite needs a thorough one. Match depth to the risk and
   complexity of the work.
