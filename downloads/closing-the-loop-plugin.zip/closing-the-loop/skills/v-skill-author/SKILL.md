---
name: v-skill-author
description: Create new SKILL.md-format skills, refine existing skills' frontmatter and sections, decide which tier (composed/strict vs standalone/relaxed) a skill belongs in, and run the bundled verifier against drafts. Use when starting a new skill from scratch, refactoring an existing one, debugging why a skill is failing the verifier, picking a tier for a new skill, or any time you're touching the YAML frontmatter or required sections of a SKILL.md file.
trigger: [create a skill, write a new skill, draft a skill, fix the verifier, author a skill]
license: Apache-2.0
output_contract_schema: custom
---

# Skill Author

## Objective

This skill is the entry point for any new SKILL.md authoring across Visma's
600+ repos. It walks an agent (or a human) from a rough idea through a
verifier-clean SKILL.md: a `skills/<name>/` directory whose `SKILL.md`
returns 0 fails / 0 warnings from the bundled verifier, has a defensible
tier classification, ships only the assets it genuinely needs, and is ready
for a conventional-commit PR.

## When to Use

- Starting a new skill from scratch and you need the frontmatter shape,
  required sections, and tier rules in one place.
- Refactoring an existing skill — splitting, merging, or shifting it
  between tiers because its composition changed.
- Debugging why a skill is failing the verifier (missing section, wrong
  line count, hardcoded tool reference, frontmatter typo).
- Reviewing or refining frontmatter on any SKILL.md file, or adding a
  bundled asset (`scripts/`, `references/`, `agents/`, `assets/`).

Do not use this skill for:

- Editing vendored skills under `skills/external/`. They are read-only
  mirrors of upstream skills and the lenient verifier mode covers them.
- Deciding whether a workflow needs a skill at all — that decision sits
  in the orchestrator skill being composed, or in the team's roadmap.
- Authoring non-SKILL.md instruction files (system prompts, agent
  config). The two-tier contract here only applies to SKILL.md.

## Workflow

### 1. Capture intent

Write down, in plain prose, before opening an editor:

- **What does this skill enable?** A single sentence. If you cannot say
  it in one sentence, the skill is too broad — split it.
- **When should it trigger?** 3–5 short keyword phrases an agent or
  installer would match against a user's prompt. These become the
  `trigger:` field.
- **What is the expected output?** A passing build, a file at a known
  path, a committed change, a written document. Be precise — downstream
  composition relies on this contract.
- **Will it be invoked by an orchestrator, or stand alone?** This is
  the tier decision. Lean on prior art: if a similar workflow already
  exists, mirror its tier choice.

If any of these questions has no clean answer, stop and clarify with
the requester before drafting anything.

### 2. Pick a tier

The verifier classifies every first-party skill into one of two tiers:

- **Strict tier (`composed/orchestrator → strict`).** Applies if EITHER
  another skill references this one via `invoke **<name>**`, OR the
  skill itself contains `invoke **<other>**` references in its body
  (i.e. it IS an orchestrator). Strict skills must ship `## Workflow`,
  `## Output Contract`, and `## Quality Bar`, plus the recommended
  sections (`## Anti-Patterns`, `## Critical Rules`, `## When to Use`).
- **Relaxed tier (`standalone → relaxed`).** Applies to standalone
  leaves that neither invoke other skills nor are invoked by other
  skills. Only `## Workflow` is required.

Both tiers share the same line-count rule: at most 500 lines, no
minimum. Reference `CLAUDE.md` in the repo root for the canonical tier
rule — it stays in sync with the verifier and is the source of truth
when in doubt. To see how each existing skill is classified, run
`bash scripts/verify-skills.sh` and read the per-skill banner lines.

If you are unsure, start relaxed. Promote to strict the moment an
orchestrator composes the skill or the skill grows orchestration logic
of its own.

### 3. Draft the frontmatter

Start from the bundled template at `./references/template.md` — it
ships a strict and a relaxed variant plus the full frontmatter field
reference (formats, character limits, examples). Pick the variant
matching your tier choice from step 2. The essentials:

- **`name`** — kebab-case, must equal the directory name.
- **`description`** — one sentence stating what the skill does, ending
  in a pushy "Use when…" clause that an installer matching against user
  prompts can key on. Examples belong in `trigger:`, not here.
- **`trigger:`** — 3+ short, lowercase, tool-agnostic keyword phrases.
- **`license`** / **`metadata.requires`** — optional; see the template.

**Trigger sanity-check (manual).** The verifier can't execute prompts,
so do this by hand: list 3 example prompts that SHOULD trigger the
skill and 3 related-but-distinct prompts that should NOT. Read the
`description`'s "Use when…" clause against all six and confirm it would
route the should-trigger cases and reject the should-not ones. If a
should-not case looks like it would match, the clause is too broad —
tighten it.

### 4. Draft the body sections

Ship the sections your tier requires (step 2); the template shows the
expected shape of each. Add optional sections to a relaxed skill only
when it grows enough decisions, gates, or anti-patterns that an agent
would otherwise miss them.

Keep the body **tool-agnostic outside frontmatter and headings**. The
verifier rejects a fixed list of tool names anywhere in the body — say
"the test command", "the project's linter", "the dependency manager"
instead. The full reject-list lives in the verifier comment header.

### 5. One home per rule

Each gate or constraint appears exactly once in the skill:

- The **Workflow** teaches it, at the step where it applies.
- A **Critical Rule** may state it only if the Workflow doesn't.
- **Quality-Bar** fail-lists must not be pass-lists negated — if the
  fail list mirrors the pass list, cut the fail list.
- An **Anti-Pattern** that restates a Critical Rule is cut; keep only
  anti-patterns that name a distinct failure mode.
- Every line must pass: "would a strong agent get this wrong without
  it?" If not, the line is padding — delete it.

### 6. Run the bundled verifier

If you are working inside the visma-skills repo itself, run the
canonical script: `bash scripts/verify-skills.sh`. If you have copied
this skill into a downstream repo, run the bundled copy:
`bash skills/v-skill-author/scripts/verify-skills.sh`. Both are
byte-identical and produce the same output.

Read the per-skill banner to confirm the tier the verifier inferred
matches the tier you chose in step 2. If they disagree, the skill's
body either grew an `invoke **<other>**` reference (bumping it to
strict) or lost one (relegating it to relaxed) — fix whichever is
wrong.

Iterate until the verifier returns 0 fails and 0 warnings. Warnings
today become failures in the next minor release, so do not merge with
any warning outstanding.

### 7. Bundle assets when they earn their keep

Skills MAY ship folders alongside `SKILL.md`: `scripts/` (runnable
scripts), `references/` (templates, examples, longer reading),
`agents/` (subagent prompt files), `assets/` (anything else). The
verifier only validates `SKILL.md`. Reference every asset via relative
path from inside the SKILL.md (e.g. `./scripts/foo.sh`) so the skill
stays portable when copied into a downstream tool's skill directory.

Only ship an asset when it genuinely makes the skill more capable — an
asset an agent can derive from standard tooling adds noise. Prefer the
top-level `references/` for cross-skill material; per-skill
`references/` is for assets only that skill uses.

### 8. Optional: Tooling note

Skills that interact with external tooling — test runners, continuous
integration providers, ticket trackers, version control hosts — should
include a short Tooling note describing the discovery and integration
ladder plus a fallback. The canonical pattern lives in
`skills/v-address-review/SKILL.md`: strongest integration first (MCP
server, then host CLI), then the fallback (user-provided context), so
the skill degrades gracefully across environments.

### 9. Update the README index

When adding a new stage skill or orchestrator **while working in the
skill library repo itself** (skip this step in downstream repos, which
have none of this structure), update the top-level `README.md`:

- Add a row to the relevant skill table (Stage Skills or Workflow
  Orchestrators) with a short description matching the new skill's
  frontmatter.
- For orchestrators, also add a Mermaid flowchart in the "How the
  skills fit together" section and a column in the composition matrix.
- Add an entry to `CHANGELOG.md` under the next version section.

Skip these updates only when refining an existing skill in place
(no name change, no tier change, no new orchestration link).

## Output Contract

A v-skill-author session produces:

- A `skills/<name>/SKILL.md` whose tier matches the author's stated
  intent and which returns 0 fails, 0 warnings from the bundled
  verifier.
- Optional bundled assets under `skills/<name>/scripts/`,
  `skills/<name>/references/`, `skills/<name>/agents/`, or
  `skills/<name>/assets/`, each referenced by relative path from the
  SKILL.md.
- For new stage skills or orchestrators: an updated `README.md`
  skill index (and Mermaid flowchart + composition matrix column for
  orchestrators) and a `CHANGELOG.md` entry under the next version
  section.
- A conventional-commit message of the form
  `feat(skills): add <name> skill` (or `refactor(skills): …` for
  refactors), with a body summarising the tier choice, any bundled
  assets, and any README/CHANGELOG updates.

## Quality Bar

A v-skill-author run meets the bar when:

- The verifier returns 0 fails and 0 warnings against the new or
  edited SKILL.md, and the tier in its banner matches the author's
  stated intent from step 2.
- The `description` includes a pushy "Use when…" clause and the
  `trigger:` field has 3+ short, tool-agnostic, lowercase phrases;
  the manual trigger sanity-check passed.
- The body is tool-agnostic outside frontmatter and headings, and
  each rule has one home (step 5).
- Bundled assets, if any, are referenced from the SKILL.md.
- README and CHANGELOG are updated for any new stage skill or
  orchestrator; no vendored skill under `skills/external/` was
  modified.

## Anti-Patterns

**Mixing strict and relaxed sections without intent.** A standalone
leaf with a 4-line `## Quality Bar` because the author copied a strict
template, or an orchestrator missing `## Output Contract` because it
was drafted from a relaxed template. Pick a tier in step 2 and stick
with it.

**The echo skill.** Stating the same gate in the Workflow, a Critical
Rule, both Quality-Bar lists, and an Anti-Pattern. Restatement does not
reinforce — it dilutes. Apply step 5 and give each rule one home.

## Critical Rules

1. **The verifier MUST pass before merge.** 0 fails and 0 warnings.
   Warnings today become failures in the next minor release; do not
   defer them.
2. **Tier choice must be defensible.** A skill is strict if it is
   composed by an orchestrator OR contains `invoke **<other>**`
   references in its body. Otherwise it is relaxed. The verifier
   detects this automatically; the author's stated tier must match.
3. **Vendored skills are read-only.** Do not edit anything under
   `skills/external/`. To adapt, copy into `skills/<name>/` and treat
   the copy as a first-party skill.
4. **Bundled assets must earn their keep.** Reference every asset
   from the SKILL.md by relative path. An unreferenced asset is a
   maintenance liability with no payoff.
