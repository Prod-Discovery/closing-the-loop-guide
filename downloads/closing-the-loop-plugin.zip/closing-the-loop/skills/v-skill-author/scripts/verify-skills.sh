#!/usr/bin/env bash
# verify-skills.sh — Validate all skills in skills/*/SKILL.md
#
# Two-tier contract for first-party skills (skills/<name>/, not skills/external/):
#
#   STRICT mode — applies to a skill if EITHER:
#     (a) another first-party skill references it via `invoke **<name>**`
#         (i.e. it is composed by an orchestrator), OR
#     (b) the skill itself contains one or more `invoke **<other>**` references
#         anywhere in its body (i.e. it IS an orchestrator).
#     Full contract: required sections (## Workflow, ## Output Contract,
#     ## Quality Bar), line count <= 500, tool-agnostic language,
#     recommended sections.
#
#   RELAXED mode — first-party skills that are neither invoked by another
#     skill nor invoke other skills themselves. Still require `## Workflow`,
#     frontmatter (name+description+kebab-case), and tool-agnostic language;
#     line count capped at <= 500 with no minimum; ## Output Contract and
#     ## Quality Bar are not required.
#
# Authoring note: the canonical invocation form is `invoke **<name>**` (no
# backticks around the name). The verifier also tolerates the backtick variant
# `invoke **` + backtick + name + backtick + `**` for legacy compatibility,
# but new skills should stick to the non-backtick form.
#
# Vendored skills under skills/external/<name>/SKILL.md run a LENIENT check only:
# frontmatter parses, name field present and matches directory. Promote a vendored
# skill into skills/<name>/ to subject it to one of the first-party tiers.
#
# Hard-fail frontmatter checks (the v0.4.0 warn-to-fail plan, now enforced):
# kebab-case name, description <= 500 characters (what + "Use when…" trigger
# clause), trigger field with >= 3 items. When a description is present, a
# warn-only lint flags it if it lacks a discovery/trigger clause ("use when",
# "use for", etc.). Optional `license:` field, when present, must be a
# non-empty string.
#
# Warn-only Output Contract schema check (AI-194): when a skill has a
# `## Output Contract` section, the verifier warns unless the four canonical
# H3s `### Summary` / `### Detail` / `### Verification` / `### Follow-ups`
# are all present (in any order). Skills that intentionally deviate (phase
# progression, per-iteration log, JSON output, spec primitives, etc.) opt
# out by setting `output_contract_schema: custom` in frontmatter. That
# per-skill flag is the source of truth — there is no script-side allowlist.
# Any list of opted-out skills named in `CLAUDE.md` is illustrative only. H3s
# inside fenced code blocks (templates) are ignored.

set -euo pipefail
shopt -s nullglob

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

PASS=0
FAIL=0
WARN=0

pass() {
  echo -e "  ${GREEN}✓${NC} $1"
  PASS=$((PASS + 1))
}

fail() {
  echo -e "  ${RED}✗${NC} $1"
  FAIL=$((FAIL + 1))
}

warn() {
  echo -e "  ${YELLOW}⚠${NC} $1"
  WARN=$((WARN + 1))
}

# Collect all skill directories — first-party plus vendored under skills/external/
SKILL_DIRS=(skills/*/SKILL.md skills/external/*/SKILL.md)

if [ ${#SKILL_DIRS[@]} -eq 0 ]; then
  echo -e "${RED}No skills found in skills/*/SKILL.md${NC}"
  exit 1
fi

# --- Pre-pass: build the STRICT set ---
# A skill is in the strict tier if EITHER:
#   - it appears as `invoke **<name>**` in another first-party SKILL.md
#     (composed by an orchestrator), OR
#   - its own body contains `invoke **<other>**` references (it IS an
#     orchestrator).
# Both the canonical form (`invoke **name**`) and the backtick variant
# (`invoke **` + backtick + name + backtick + `**`) are recognized, so legacy
# code-styled invocations don't slip past tier detection.
INVOKE_REGEX='invoke \*\*`?[a-z-]+`?\*\*'

STRICT=()

# (a) Skills invoked by some other skill — extract target names from all
# matches across all first-party SKILL.md files.
while IFS= read -r name; do
  [ -n "$name" ] && STRICT+=("$name")
done < <(grep -hoE "$INVOKE_REGEX" skills/*/SKILL.md 2>/dev/null \
  | sed 's/invoke \*\*//; s/\*\*$//; s/`//g' | sort -u)

# (b) Skills that themselves contain invoke references — they are
# orchestrators and stay strict regardless of whether anyone composes them.
for SKILL_FILE in skills/*/SKILL.md; do
  if grep -qE "$INVOKE_REGEX" "$SKILL_FILE" 2>/dev/null; then
    STRICT+=("$(basename "$(dirname "$SKILL_FILE")")")
  fi
done

# De-duplicate the union of (a) and (b). STRICT is always declared as an
# empty array above, so `${#STRICT[@]}` is safe to read directly. The
# previous `${#STRICT[@]:-0}` form combined the array-length operator with
# the default-value modifier, which is non-portable across bash versions
# (CI's bash rejects it as "bad substitution"). Keep this simple.
if [ "${#STRICT[@]}" -gt 0 ]; then
  STRICT=($(printf '%s\n' "${STRICT[@]}" | sort -u))
fi

is_strict() {
  local needle="$1"
  [ "${#STRICT[@]}" -eq 0 ] && return 1
  for n in "${STRICT[@]}"; do
    [ "$n" = "$needle" ] && return 0
  done
  return 1
}

echo "Strict-tier skills (composed or orchestrator): ${STRICT[*]:-<none>}"
echo ""
echo "Verifying ${#SKILL_DIRS[@]} skill(s)..."
echo ""

for SKILL_FILE in "${SKILL_DIRS[@]}"; do
  SKILL_DIR=$(dirname "$SKILL_FILE")
  DIR_NAME=$(basename "$SKILL_DIR")

  # --- Detect tier: vendored / strict (composed or orchestrator) / relaxed ---
  IS_VENDORED=false
  IS_RELAXED=false
  if [[ "$SKILL_DIR" == skills/external/* ]]; then
    IS_VENDORED=true
    echo "━━━ ${DIR_NAME} (vendored — lenient checks only) ━━━"
  elif is_strict "$DIR_NAME"; then
    echo "━━━ ${DIR_NAME} (composed/orchestrator — strict) ━━━"
  else
    IS_RELAXED=true
    echo "━━━ ${DIR_NAME} (standalone — relaxed) ━━━"
  fi

  # --- File existence ---
  if [ -f "$SKILL_FILE" ]; then
    pass "SKILL.md exists"
  else
    fail "SKILL.md not found at $SKILL_FILE"
    echo ""
    continue
  fi

  # --- YAML frontmatter presence ---
  FIRST_LINE=$(head -n 1 "$SKILL_FILE")
  if [ "$FIRST_LINE" != "---" ]; then
    fail "Missing YAML frontmatter (file must start with ---)"
    echo ""
    continue
  fi

  # Find closing --- (line 2+)
  CLOSING_LINE=$(awk 'NR > 1 && /^---$/ { print NR; exit }' "$SKILL_FILE")
  if [ -z "$CLOSING_LINE" ]; then
    fail "YAML frontmatter never closed (no closing ---)"
    echo ""
    continue
  fi

  pass "YAML frontmatter present (lines 1-${CLOSING_LINE})"

  # Extract frontmatter content (between the ---'s)
  FRONTMATTER=$(sed -n "2,$((CLOSING_LINE - 1))p" "$SKILL_FILE")

  # --- name field ---
  NAME_VALUE=$(echo "$FRONTMATTER" | grep -E '^name:\s*' | head -1 | sed 's/^name:[[:space:]]*//')
  if [ -z "$NAME_VALUE" ]; then
    fail "Missing 'name' field in frontmatter"
  else
    pass "name field present: ${NAME_VALUE}"

    # Check name matches directory name
    if [ "$NAME_VALUE" = "$DIR_NAME" ]; then
      pass "name matches directory name"
    else
      fail "name '${NAME_VALUE}' does not match directory '${DIR_NAME}'"
    fi

    # --- FAIL: kebab-case name (no underscores, no camelCase) ---
    if [[ "$NAME_VALUE" =~ _ ]] || [[ "$NAME_VALUE" =~ [A-Z] ]]; then
      fail "${DIR_NAME}: name '${NAME_VALUE}' is not kebab-case (no underscores, no camelCase)"
    else
      pass "name is kebab-case"
    fi

    # --- FAIL: first-party skills must carry the Visma provenance prefix 'v-' ---
    # The 'v-' prefix lets an installed skill be recognised as Visma's when it
    # sits alongside skills from other sources (the installer places skills flat,
    # with the skill name as the on-disk identifier in every harness). Vendored
    # skills under skills/external/ are third-party mirrors and are exempt.
    if ! $IS_VENDORED; then
      if [[ "$NAME_VALUE" == v-* ]]; then
        pass "name carries Visma 'v-' prefix"
      else
        fail "${DIR_NAME}: first-party skill name '${NAME_VALUE}' must start with 'v-' (Visma provenance prefix)"
      fi
    fi
  fi

  # --- Vendored skills stop here: skip strict structural checks ---
  if $IS_VENDORED; then
    echo ""
    continue
  fi

  # --- description field ---
  # Description may be multi-line (YAML folded/literal scalar), so check for the key
  if echo "$FRONTMATTER" | grep -qE '^description:'; then
    pass "description field present"

    # --- FAIL: description should fit in <= 500 characters ---
    # Counts the description value's character length, joining the key line and
    # any immediately following indented continuation lines (folded/literal
    # block) into a single string. Counting characters rather than physical YAML
    # lines is robust to the common single-line form, which would otherwise
    # trivially satisfy a line-count cap regardless of length. The 500-char cap
    # accommodates the "what + Use when…" pushy pattern with comfortable
    # headroom over the longest current description; longer values degrade
    # installer/router matching.
    DESC_START=$(echo "$FRONTMATTER" | grep -nE '^description:' | head -1 | cut -d: -f1)
    if [ -n "$DESC_START" ]; then
      # Concatenate description key line (after `description:`) with any
      # following indented continuation lines, stopping at the next top-level
      # YAML key or end of frontmatter, then measure character length.
      DESC_VALUE=$(echo "$FRONTMATTER" | awk -v start="$DESC_START" '
        NR == start { sub(/^description:[[:space:]]*/, ""); printf "%s", $0; next }
        NR > start {
          if ($0 ~ /^[[:space:]]+/) {
            line = $0
            sub(/^[[:space:]]+/, " ", line)
            printf "%s", line
            next
          }
          if ($0 ~ /^[A-Za-z]/) { exit }
        }
      ')
      DESC_CHARS=${#DESC_VALUE}
      if [ "$DESC_CHARS" -le 500 ]; then
        pass "description is <= 500 chars (${DESC_CHARS})"
      else
        fail "${DIR_NAME}: description is ${DESC_CHARS} chars (expected <= 500)"
      fi

      # --- WARN: description should carry a discovery/trigger clause ---
      # A "Use when…" (or equivalent) phrase names the concrete contexts that
      # should surface the skill, which the installer/router keys on. Warn only;
      # the `trigger:` field is the hard requirement.
      if echo "$DESC_VALUE" | grep -qiE 'use when|use for|use this when|use after|use it when|trigger when'; then
        pass "description has a discovery/trigger clause"
      else
        warn "${DIR_NAME}: description lacks a discovery clause (e.g. \"Use when…\")"
      fi
    fi
  else
    fail "Missing 'description' field in frontmatter"
  fi

  # --- license field (optional; if present must be a non-empty, non-whitespace
  # value). Strip surrounding whitespace, then surrounding single/double quotes,
  # then any whitespace inside the quotes — `license: "   "` must fail.
  LICENSE_LINE=$(echo "$FRONTMATTER" | grep -E '^license:' | head -1 || true)
  if [ -n "$LICENSE_LINE" ]; then
    LICENSE_VALUE=$(echo "$LICENSE_LINE" | sed 's/^license:[[:space:]]*//; s/[[:space:]]*$//')
    # Strip a single layer of surrounding double or single quotes, if present.
    LICENSE_VALUE="${LICENSE_VALUE%\"}"; LICENSE_VALUE="${LICENSE_VALUE#\"}"
    LICENSE_VALUE="${LICENSE_VALUE%\'}"; LICENSE_VALUE="${LICENSE_VALUE#\'}"
    # Trim whitespace that was inside the quotes (e.g. `license: "   "`).
    LICENSE_VALUE=$(echo "$LICENSE_VALUE" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
    if [ -z "$LICENSE_VALUE" ]; then
      fail "license field present but empty (or whitespace-only)"
    else
      pass "license field present: ${LICENSE_VALUE}"
    fi
  fi

  # --- FAIL: trigger field present with >= 3 items ---
  # Supports inline form `trigger: [a, b, c]` and YAML block sequence form
  # (one `- item` per line).
  TRIGGER_LINE=$(echo "$FRONTMATTER" | grep -E '^trigger:' | head -1)
  if [ -z "$TRIGGER_LINE" ]; then
    fail "${DIR_NAME}: missing 'trigger' field (need >= 3 keyword phrases)"
  else
    # Try inline array form first
    INLINE=$(echo "$TRIGGER_LINE" | sed -nE 's/^trigger:[[:space:]]*\[(.*)\][[:space:]]*$/\1/p')
    if [ -n "$INLINE" ]; then
      # Count comma-separated items
      TRIGGER_COUNT=$(echo "$INLINE" | awk -F',' '{ n=0; for(i=1;i<=NF;i++) if(length($i)>0) n++; print n }')
    else
      # YAML block sequence: count `- item` lines after the trigger: key
      TRIG_START=$(echo "$FRONTMATTER" | grep -nE '^trigger:' | head -1 | cut -d: -f1)
      TRIGGER_COUNT=$(echo "$FRONTMATTER" | awk -v start="$TRIG_START" '
        NR > start {
          if ($0 ~ /^[[:space:]]*-[[:space:]]/) { count++; next }
          if ($0 ~ /^[A-Za-z]/) { exit }
        }
        END { print count + 0 }
      ')
    fi
    if [ "${TRIGGER_COUNT:-0}" -ge 3 ]; then
      pass "trigger field present (${TRIGGER_COUNT} items)"
    else
      fail "${DIR_NAME}: trigger has ${TRIGGER_COUNT:-0} items (expected >= 3)"
    fi
  fi

  # --- Line count ---
  # Both tiers: <= 500 cap only, no floor. Larger skills overwhelm agent context.
  LINE_COUNT=$(wc -l < "$SKILL_FILE")
  if [ "$LINE_COUNT" -le 500 ]; then
    pass "Line count: ${LINE_COUNT} (<= 500)"
  else
    fail "Line count: ${LINE_COUNT} (expected <= 500)"
  fi

  # --- Hardcoded tool references ---
  # Check for specific tool/framework names that indicate non-agnostic language
  TOOL_PATTERN='npm|yarn|pip|pytest|jest|eslint|prettier|webpack|cargo|maven|gradle|go test|ruff|black|mypy'
  # -w treats word-boundaries (alphanumeric + _) as match separators so substrings
  # inside common English words (pip in pipeline, gradle in gradient, etc.) do not
  # trip false positives. Multi-word tokens like "go test" still match because the
  # space between is not a word character.
  TOOL_HITS=$(grep -winE "$TOOL_PATTERN" "$SKILL_FILE" | grep -v '^---' | grep -v '^#' || true)
  if [ -z "$TOOL_HITS" ]; then
    pass "No hardcoded tool references"
  else
    fail "Hardcoded tool references found:"
    echo "$TOOL_HITS" | while IFS= read -r line; do
      echo -e "      ${RED}→${NC} $line"
    done
  fi

  # --- Required sections ---
  # Strict tier: ## Workflow, ## Output Contract, ## Quality Bar.
  # Relaxed tier (standalone leaves): only ## Workflow is required;
  # ## Output Contract and ## Quality Bar are dropped silently.
  if $IS_RELAXED; then
    REQUIRED_SECTIONS=("Workflow")
  else
    REQUIRED_SECTIONS=("Workflow" "Output Contract" "Quality Bar")
  fi
  for SECTION in "${REQUIRED_SECTIONS[@]}"; do
    if grep -qE "^##\s+${SECTION}" "$SKILL_FILE"; then
      pass "Section present: ${SECTION}"
    else
      fail "Missing section: ${SECTION}"
    fi
  done

  # --- Recommended sections (warn if missing) ---
  RECOMMENDED_SECTIONS=("Anti-Patterns" "Critical Rules" "When to Use")
  for SECTION in "${RECOMMENDED_SECTIONS[@]}"; do
    if grep -qE "^##\s+${SECTION}" "$SKILL_FILE"; then
      pass "Section present: ${SECTION}"
    else
      warn "Missing recommended section: ${SECTION}"
    fi
  done

  # --- WARN: canonical four-H3 Output Contract schema (AI-194) ---
  # Stage skills that emit a markdown report follow a canonical four-H3 schema
  # under `## Output Contract`: `### Summary` / `### Detail` / `### Verification`
  # / `### Follow-ups` (any order). Skills that intentionally deviate (phase
  # progression, per-iteration log, JSON output, spec primitives, etc.) opt out
  # by setting `output_contract_schema: custom` in frontmatter. The check is
  # skipped entirely when the skill has no `## Output Contract` section
  # (relaxed-tier standalone leaves) — the strict tier already fails on a
  # missing `## Output Contract` above.
  if grep -qE "^##\s+Output Contract" "$SKILL_FILE"; then
    SCHEMA_LINE=$(echo "$FRONTMATTER" | grep -E '^output_contract_schema:' | head -1 || true)
    SCHEMA_OPT_OUT=$(echo "$SCHEMA_LINE" | sed 's/^output_contract_schema:[[:space:]]*//; s/[[:space:]]*$//')
    # Strip a single layer of surrounding double or single quotes, if present.
    SCHEMA_OPT_OUT="${SCHEMA_OPT_OUT%\"}"; SCHEMA_OPT_OUT="${SCHEMA_OPT_OUT#\"}"
    SCHEMA_OPT_OUT="${SCHEMA_OPT_OUT%\'}"; SCHEMA_OPT_OUT="${SCHEMA_OPT_OUT#\'}"
    if [ "$SCHEMA_OPT_OUT" = "custom" ]; then
      pass "Output Contract schema: custom (opted out of four-H3 check)"
    else
      # Extract the H3 names directly under `## Output Contract`, ignoring any
      # H3s that appear inside fenced code blocks (templates) and stopping at
      # the next H2. Fence toggle is fence-text agnostic — any line beginning
      # with ``` flips the in_fence flag.
      H3_LIST=$(awk '
        /^```/ { in_fence = !in_fence; next }
        in_fence { next }
        /^##[[:space:]]+Output Contract/ { in_oc = 1; next }
        /^##[[:space:]]/ { in_oc = 0 }
        in_oc && /^###[[:space:]]/ {
          sub(/^###[[:space:]]+/, "")
          sub(/[[:space:]]+$/, "")
          print
        }
      ' "$SKILL_FILE")
      MISSING_H3=()
      for CANONICAL in "Summary" "Detail" "Verification" "Follow-ups"; do
        if ! printf '%s\n' "$H3_LIST" | grep -qxE "${CANONICAL}"; then
          MISSING_H3+=("${CANONICAL}")
        fi
      done
      EXTRA_H3=()
      while IFS= read -r H3; do
        [ -z "$H3" ] && continue
        case "$H3" in
          "Summary"|"Detail"|"Verification"|"Follow-ups") ;;
          *) EXTRA_H3+=("$H3") ;;
        esac
      done <<< "$H3_LIST"
      if [ "${#MISSING_H3[@]}" -eq 0 ] && [ "${#EXTRA_H3[@]}" -eq 0 ]; then
        pass "Output Contract has canonical four-H3 schema"
      else
        if [ "${#MISSING_H3[@]}" -gt 0 ]; then
          warn "${DIR_NAME}: Output Contract missing canonical H3(s): ${MISSING_H3[*]} — set 'output_contract_schema: custom' in frontmatter to opt out (AI-194)"
        fi
        if [ "${#EXTRA_H3[@]}" -gt 0 ]; then
          warn "${DIR_NAME}: Output Contract has non-canonical H3(s): ${EXTRA_H3[*]} — set 'output_contract_schema: custom' in frontmatter to opt out (AI-194)"
        fi
      fi
    fi
  fi

  echo ""
done

# --- Summary ---
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
TOTAL=$((PASS + FAIL + WARN))
echo -e "Results: ${GREEN}${PASS} passed${NC}, ${RED}${FAIL} failed${NC}, ${YELLOW}${WARN} warnings${NC} (${TOTAL} total)"

if [ "$FAIL" -gt 0 ]; then
  echo -e "${RED}VERIFICATION FAILED${NC}"
  exit 1
else
  echo -e "${GREEN}ALL CHECKS PASSED${NC}"
  exit 0
fi
