# SKILL.md Templates

Two starter templates for the visma-skills two-tier contract. Copy the variant
that matches your skill, rename the directory, and run the bundled verifier.

- **Strict tier** — choose this when the skill is referenced by an
  orchestrator (another skill mentions it via `invoke **<your-name>**`) OR
  the skill itself orchestrates other skills. Strict skills must ship
  `## Output Contract` and `## Quality Bar` in addition to `## Workflow`.
- **Relaxed tier** — choose this when the skill is a pure standalone leaf:
  no other skill invokes it, and it does not invoke other skills with the
  `invoke **<name>**` form. Only `## Workflow` is required.

Both tiers are capped at 500 lines; neither has a minimum line count.

If unsure, start relaxed. Promote to strict the moment an orchestrator
composes the skill or the skill grows orchestration logic of its own.

---

## Strict-tier template

```markdown
---
name: <your-skill-name>
description: <One-sentence statement of what this skill does. Use when <pushy clause about when an agent should reach for it>.>
trigger: [<keyword phrase 1>, <keyword phrase 2>, <keyword phrase 3>]
license: Apache-2.0
---

# <Your Skill Name>

## Objective

<2–4 sentences. What problem this skill solves and what an agent walks
away with after running it. Mention the strongest constraint or quality
bar so the reader knows the bar before reading the workflow.>

## When to Use

- <Concrete situation 1>
- <Concrete situation 2>
- <Concrete situation 3>

Do not use this skill when:
- <Anti-trigger 1>
- <Anti-trigger 2>

## Workflow

### 1. <First phase>

<Imperative steps. Describe actions in tool-neutral terms — say "the test
command" rather than naming a specific runner. Frontmatter and headings
are exempt from the tool-neutral rule, the body is not.>

### 2. <Second phase>

<...>

### 3. <Third phase>

<...>

## Output Contract

<What the skill produces. A passing build? A document at a known path?
A specific commit shape? Be precise — downstream skills rely on this.>

## Quality Bar

A run of this skill meets the bar when:

- <Verifiable criterion 1>
- <Verifiable criterion 2>
- <Verifiable criterion 3>

It fails the bar when:

- <Anti-criterion 1>
- <Anti-criterion 2>

## Anti-Patterns

**<Pattern name>.** <One-paragraph description of the failure mode and
why it costs more than it saves.>

**<Pattern name>.** <...>

## Critical Rules

1. **<Rule>.** <Justification.>
2. **<Rule>.** <Justification.>
3. **<Rule>.** <Justification.>
```

---

## Relaxed-tier template

```markdown
---
name: <your-skill-name>
description: <One-sentence statement of what this skill does. Use when <pushy clause about when an agent should reach for it>.>
trigger: [<keyword phrase 1>, <keyword phrase 2>, <keyword phrase 3>]
license: Apache-2.0
---

# <Your Skill Name>

## Workflow

### 1. <First phase>

<Imperative steps in tool-neutral language.>

### 2. <Second phase>

<...>

### 3. <Third phase>

<...>
```

Other sections (`## When to Use`, `## Output Contract`, `## Quality Bar`,
`## Anti-Patterns`, `## Critical Rules`, `## Objective`) are optional in
the relaxed tier but recommended once the skill earns them. Add them when
the skill grows enough decisions, gates, or anti-patterns that an agent
would otherwise miss them.

---

## Frontmatter field reference

- **`name`** — kebab-case, equal to the directory name. The verifier
  fails on a mismatch.
- **`description`** — 1–2 lines, single sentence. Include a pushy "Use
  when…" clause so an installer matching against user prompts surfaces
  this skill at the right moment.
- **`trigger`** — YAML list of 3+ short, lowercase keyword phrases that
  would surface in a user's prompt asking for this skill. Inline form is
  preferred: `trigger: [phrase one, phrase two, phrase three]`. Keep
  phrases tool-agnostic.
- **`license`** — optional; recommended `Apache-2.0` for first-party
  skills. The repo's top-level `LICENSE` file carries the full text.
- **`metadata.requires`** — optional. List obvious prerequisites the
  installer can pre-flight check (e.g. `[AGENTS.md, test command]`). Omit
  the field when there are no clear prerequisites.

## Bundled assets

Skills MAY ship folders alongside `SKILL.md` — `scripts/`, `references/`,
`agents/`, `assets/`. Reference them via relative paths from inside the
SKILL.md (e.g. `./scripts/foo.sh`, `./references/example.md`). The
verifier ignores non-SKILL.md files. Only ship a bundled asset when it
genuinely makes the skill more capable; an asset an agent can derive
from standard tooling adds noise.
