# MDX render templates — v-generate-wiki format output

These templates pin the exact MDX shape `format-output` emits per
layer and per semantic content type. They supplement Phase 4 of
`v-generate-wiki`; the callout-level mapping table and the fallback
transport rules stay pinned in `SKILL.md` (they are contract).
**Slot fidelity** applies throughout: templates render the layer's
slots verbatim and never inject tool names, paths, or framework names
the AST did not carry.

## Content-type templates

**`section`** — heading plus prose body. No JSX:

    ## {title}

    {body}

**`callout`** — `Callout` JSX with a severity-mapped fallback
blockquote. `{jsxType}` and `{Label}` come from the callout-level
mapping table in `SKILL.md`; format-output maps every emitted level
through that table deterministically — never an ad-hoc mapping per
run:

    <Callout type="{jsxType}">
      {body}
    </Callout>

    <!-- fallback:
    > **{Label}:** {body}
    -->

**`diagram`** — `Diagram` JSX whose `source` prop carries the
mermaid body, paired with a fenced mermaid block carrying the same
source. Caption renders as italic text below the fence.

    <Diagram caption="{caption}" source={`{source}`} />

    <!-- fallback:
    ```mermaid
    {source}
    ```
    *{caption}*
    -->

**`steps`** — `Steps`/`Step` JSX preserving the bold lead-in,
falling back to an ordered list:

    <Steps>
      <Step>**{lead}** {body}</Step>
      …
    </Steps>

    <!-- fallback:
    1. **{lead}** {body}
    2. …
    -->

**`tabs`** — `Tabs`/`Tab` JSX grouping alternatives (e.g. engineering
`steps.alternatives`). Fallback is one `###` heading per
tab label in order, since plain-MD viewers cannot interleave tabbed
content:

    <Tabs items={["{labelA}", "{labelB}"]}>
      <Tab value="{labelA}">{bodyA}</Tab>
      <Tab value="{labelB}">{bodyB}</Tab>
    </Tabs>

    <!-- fallback:
    ### {labelA}

    {bodyA}

    ### {labelB}

    {bodyB}
    -->

## Layer templates (M2 audiences)

Each file opens with frontmatter (`title`, `audience`) and composes
the layer's slots against the content-type templates. Slot names
match each audience's Output Contract.

**`executive.mdx`** — `tldr` section first, then remaining
`elements[]` in emit order; `section` elements via the section
template, `callout` elements via the callout template, at their
AST index.

**`overview.mdx`** — fixed slots, no diagrams/callouts/steps: a
blockquote with `oneLineSummary`; `## What it is` (description);
`## Who it's for` (audienceRoles as a bullet list); `## Category`
(`label` plus `evidence`); `## In the landscape` only when the layer
emitted the `landscape` slot — render `landscape.siblings` as a
`Sibling | Relationship` table and `landscape.note` as a paragraph
underneath. The layer omits `landscape` when no `siblingRepos` were
supplied to it; format-output reads the emitted shape, not the
layer's input.

**`architecture.mdx`** — `## System overview` (systemOverview.summary);
`## Components` (component diagram via the diagram template, then a
`Component | Responsibility | Runtime` table); `## Data flows`
(`### {name}` per flow with the diagram template);
`## Integration points` (table); `## Deployment topology` (diagram
template) only when the bundle signal is true; `## Seams` (callout
template per seam, level `note`, body `"{seam.kind}: {seam.note}"`).

**`engineering.mdx`** — one section per `topics[]` entry in emit
order; content dispatches by `topic.kind`:

| `kind`     | Renders as                                                |
| ---------- | --------------------------------------------------------- |
| `layout`   | `Path \| Role \| Note` table                              |
| `prose`    | paragraphs joined                                         |
| `steps`    | steps template; with `alternatives` see below             |
| `callouts` | callout template per entry, `severity` → level via table  |
| `table`    | Markdown table from `rows`                                |

When a `steps` topic carries `alternatives`, render the primary
`steps` array via the steps template, then a `Tabs` block whose
items are each `alternatives[i].label` and whose tab bodies render
that alternative's `steps` via the same template — the primary path
stays scannable while alternatives are reachable in one click. The
`callouts` topic's `severity` field uses the engineering vocabulary
(`warning | note | important`); the architecture layer's seam slot
emits `level: "note"` per seam — both pass through the callout
mapping table in `SKILL.md`.

## Future M3 layers

The M3 audiences (`security`, `product`, `marketing`, `support`,
`devops`) reuse these content-type templates and the same skeleton —
frontmatter, then slots in emit order dispatching to one of the four
content types. They emit different slots, not different MDX shapes.
A layer that genuinely needs a new shape is a palette extension
(see the skill's Critical Rules), not a freelance-rendering license.
