---
name: v-generate-wiki
description: Orchestrate audience-segmented wiki generation for a repository — analyze once, dispatch the right audience-layer skills in parallel, and emit MDX (or plain Markdown) files plus an index. Use when a caller asks to "generate the wiki", "produce audience-segmented docs", or "build the executive/engineering/security/etc. layers" for a repo, when the GitHub App or visma-skills CLI invokes wiki generation, or whenever multiple audience views must be derived from a single shared analysis pass.
trigger: [generate the wiki, build audience-segmented docs, produce wiki layers, run wiki generation, write the executive and engineering wiki]
license: Apache-2.0
output_contract_schema: custom
---

# Generate Wiki

## Objective

Produce an audience-segmented wiki for a repository by composing one
shared analysis pass with multiple audience-layer skills. The result is
a directory of MDX (or plain Markdown) files — one per generated
audience plus an `index` — and a manifest describing what was
generated, what was skipped (and why), and the analysis bundle the
content was derived from.

This skill is the **top-level orchestrator** an external caller invokes
(the GitHub App, the `visma-skills` CLI, future products). It does not
write content itself: it runs the analysis skill once to produce the
shared bundle, applies signal-driven routing to decide which audience
layers to run, dispatches the routed layer skills in parallel
(Phase 3), and renders the returned structured content via a single
`format-output` step.

## When to Use

- A caller wants the full audience-segmented wiki for a repo
  (executive, overview, architecture, engineering, security always;
  product / marketing / support / devops when signals justify them)
- The wiki must be derivable from one analysis pass — no layer re-walks
- The output destination is a filesystem directory the caller controls
  (hosted Convex-backed renderer, local CLI to `./docs/`, or PR-export
  — all callers writing to different `outputDir` values)
- The user says "generate the wiki", "build the audience layers",
  "produce executive + engineering + security docs", or similar

Do not use this skill when:

- A single audience view is needed — invoke that layer directly with
  a fresh analysis bundle
- The work is a free-form natural-language summary — layers emit
  structured content rendered through the 4-component palette, not
  arbitrary prose
- The repository is unreadable (no working tree) — `v-analyze-repo` will
  warn; do not proceed against an empty bundle

## Inputs

```
v-generate-wiki(
  repoPath: string,                // absolute path to the repo
  options: {
    audiences?: AudienceList,      // explicit override; default: auto-detect
    outputDir: string,             // directory to write MDX/Markdown into
    format?: "mdx" | "markdown"    // default: mdx
  }
) -> {
  docsDir: string,
  audiencesGenerated: AudienceList,
  audiencesSkipped: { [audience: string]: string },  // reason per audience
  analysisBundle: AnalysisBundle
}
```

`AudienceList` is the union of audience names this orchestrator
recognises: `executive`, `overview`, `architecture`, `engineering`,
`security`, `product`, `marketing`, `support`, `devops`. (v2 layers —
`sales`, `design`, `legal`, `finance` — are out of scope for v1; the
orchestrator must reject them with a clear error rather than silently
ignore.)

If `repoPath` is missing or not a directory, stop and report. If
`outputDir` is missing, stop and report — never write to a guessed
location.

## Workflow

The orchestrator runs five phases in order. Phases 1–3 must complete
before the next begins; phase 4 fans out per audience; phase 5 writes
the filesystem and assembles the manifest.

### Phase 1: Analyse — invoke **v-analyze-repo**

Produce the shared `AnalysisBundle` for `repoPath`. Pass through the
caller's optional knobs (`since`, `maxDeps`, `includeLockfiles`) when
provided; otherwise accept the analyse-repo defaults.

Validate the result before proceeding:

- `bundle.schemaVersion` must equal `"1.0"`. If not, append a
  `WARN_BUNDLE_VERSION_MISMATCH` warning and continue — the orchestrator
  is pinned to 1.0; a higher version may carry fields layers don't expect.
- The bundle's own `warnings` array passes through unmodified — layers
  and the index surface them so readers see gaps.

**Gate:** A `schemaVersion: "1.0"` bundle is in hand and its required
top-level fields are populated (per `v-analyze-repo`'s Output Contract).

### Phase 2: Route — signal-driven audience selection (inline)

Decide which audience layers to dispatch. This logic lives **inline
in this orchestrator**, not in a separate sub-skill — keep it short
and concrete; if it ever grows past roughly 50 lines of decision
table, split it out then.

**Always-emit audiences** (regardless of signals):

- `executive`, `overview`, `architecture`, `engineering`, `security`

The security layer always emits but **scales depth with signal
richness** — that scaling is the security layer's own concern; the
orchestrator only decides whether the layer runs at all.

**Signal-gated audiences** (skip rules):

| Audience | Skip when… | Skip reason recorded as |
| --- | --- | --- |
| `product` | `signals.isPureInfra === true` | `"isPureInfra: repo is a library/framework/SDK"` |
| `marketing` | `signals.isInternalOnly === true` | `"isInternalOnly: no customer-facing surface"` |
| `support` | `signals.hasCustomerVisibleAPI === false` | `"!hasCustomerVisibleAPI: nothing for support to triage"` |
| `devops` | `signals.hasDeploymentArtifacts === false` | `"!hasDeploymentArtifacts: nothing to deploy or run"` |

**Explicit override.** If `options.audiences` is provided, honour it
verbatim and record `signalsOverridden: true`. The caller owns the
consequences of forcing a signal-skipped layer (e.g. `marketing` on
an internal CLI yields thin output). Omitted-by-override audiences
record `"excluded by caller override"`.

**Conflict handling.** On `WARN_SIGNAL_CONFLICT` warnings for a routing
signal, run the layer the more inclusive way (default to *not* skipping)
and record the conflict in `routingNotes`.

**Gate:** A finalised `audiencesGenerated` list and an
`audiencesSkipped` map (audience → reason string) are computed.

### Phase 3: Dispatch audience layers in parallel

Dispatch one layer skill per audience in `audiencesGenerated` — and
only those — per this routing list:

- `executive` → invoke **v-wiki-layer-executive**
- `overview` → invoke **v-wiki-layer-overview**
- `architecture` → invoke **v-wiki-layer-architecture**
- `engineering` → invoke **v-wiki-layer-engineering**
- `security` → invoke **v-wiki-layer-security**
- `product` → invoke **v-wiki-layer-product**
- `marketing` → invoke **v-wiki-layer-marketing**
- `support` → invoke **v-wiki-layer-support**
- `devops` → invoke **v-wiki-layer-devops**

Run the dispatched layers concurrently — they do not share state and
must not re-read the repo. Each layer receives the shared bundle plus
any of its own layer-specific options (depth and truncation caps,
`cveCatalog`, `audienceHints`, etc. — see each layer's Inputs):

```
v-wiki-layer-<audience>(
  bundle: AnalysisBundle,
  options?: { /* layer-specific knobs */ }
) -> StructuredContent
```

`StructuredContent` is the shape each audience layer emits — a
constrained AST of headings, paragraphs, lists, code blocks, and
references to the four palette components (`Callout`, `Tabs`,
`Diagram`, `Steps`). Layers never emit markup; the `format` decision
belongs to phase 4 alone. The orchestrator does not interpret the
AST; it hands it to phase 4.

**Failure handling.** If a layer fails or returns empty content, do
not abort the wiki. Record the failure in `audiencesSkipped` with the
reason (`"layer-failed: <message>"`), and continue with the rest. A
partial wiki is more useful than no wiki — the index page surfaces
which layer failed.

**Gate:** Every dispatched layer has either returned
`StructuredContent` or been recorded as failed.

### Phase 4: Format output

Render each layer's `StructuredContent` to a single file in the
configured `format`.

**MDX format** (default). Emit using the locked 4-component palette
(`Callout`, `Tabs`, `Diagram`, `Steps`) per the **MDX Templates**
section below. Every component invocation carries its plain-MD
fallback per the dual-emission contract so the file reads
correctly in GitHub's plain Markdown viewer as well as in
Fumadocs/Docusaurus/Nextra. Render via the templates verbatim;
freelancing new shapes per run is a quality-bar failure.

**`markdown` format.** Emit the fallback form only — fenced code,
ordered lists, headed sections, blockquotes — with no JSX
components. Use this when the renderer is known to ignore MDX.

**Index page.** Compose `index.<ext>` for `outputDir`:

- Short header naming the repo (`bundle.repo.name`)
- TOC linking each generated audience file with a one-line summary
- "Skipped audiences" section listing each `audiencesSkipped` entry
  with its reason, so readers see *why* a layer is missing
- `routingNotes` and bundle-level warnings worth surfacing (schema
  mismatch, signal conflicts, truncated deps)

**Gate:** One output file per generated audience plus the index file
exists in memory ready to write.

### Phase 5: Write to filesystem and assemble manifest

Write every rendered file to `outputDir`, creating the directory if
needed. Naming: `<audience>.<ext>` per layer, `index.<ext>` for the
TOC (`<ext>` is `mdx` or `md`). No files for skipped audiences.
Assemble the manifest and return it.

**Gate:** Every file referenced by the index exists at the expected
path; `audiencesGenerated` is the exact set of files written (minus
the index).

## Output Contract

The skill returns a single manifest object and writes a directory.

**Filesystem layout** under `outputDir`:

- `index.mdx` (or `index.md` for `markdown` format) — table of
  contents, skip reasons, surfaced warnings
- `<audience>.mdx` per generated audience (e.g. `executive.mdx`,
  `engineering.mdx`, `security.mdx`)

**Manifest** (return value):

```jsonc
{
  "docsDir": "<absolute path to outputDir>",
  "audiencesGenerated": ["executive", "overview", "architecture", "engineering", "security", "..."],
  "audiencesSkipped": {
    "marketing": "isInternalOnly: no customer-facing surface",
    "devops": "!hasDeploymentArtifacts: nothing to deploy or run"
  },
  "signalsOverridden": false,
  "routingNotes": [
    { "code": "ROUTE_SIGNAL_CONFLICT", "audience": "support", "message": "<bundle-level conflict description>" }
  ],
  "warnings": [
    { "code": "WARN_BUNDLE_VERSION_MISMATCH", "message": "v-analyze-repo emitted schemaVersion 1.1; orchestrator pinned to 1.0" }
  ],
  "analysisBundle": { /* the full AnalysisBundle from v-analyze-repo */ }
}
```

Field-level rules:

- `docsDir` is the absolute path actually written; resolve any
  relative `outputDir` before returning.
- `audiencesGenerated` ∪ `audiencesSkipped` covers every audience
  considered (v1 set or caller override); no audience appears in both.
- `audiencesSkipped[a]` starts with the signal name, `"excluded by
  caller override"`, or `"layer-failed: …"`.
- `analysisBundle` is included verbatim so callers reusing the analysis
  (e.g. follow-up security audit) do not re-invoke `v-analyze-repo`.
- `warnings[].code` uses uppercase snake-case (`WARN_BUNDLE_VERSION_MISMATCH`,
  `WARN_LAYER_FAILED`, etc.) per `v-analyze-repo` convention.

## Quality Bar

A wiki run meets the quality bar when:

- Every always-emit audience appears in `audiencesGenerated` or in
  `audiencesSkipped` with a `"layer-failed: …"` reason — missing from
  both is the one unrecoverable failure
- No skip reason is generic ("not needed") or contradicts the bundle
  (e.g. `marketing` skipped as `isInternalOnly` when
  `signals.hasCustomerVisibleAPI === true`)
- Layer dispatch ran in parallel — sequential dispatch is a quality miss

## Anti-Patterns

**The forced layer.** Honouring `options.audiences` to force every v1
audience on a repo where signals would skip half, then shipping the
fluff as the wiki. Overrides are valid; flag them in the manifest so
the next reader sees the caller forced the layer.

**The fail-fast wiki.** Aborting the run because one layer failed.
Record the failure in `audiencesSkipped` and ship the rest — the
index page surfaces which layer is missing and why.

## Critical Rules

1. **Analyse once, dispatch many.** `v-analyze-repo` runs exactly once
   per invocation; every layer consumes that bundle. No re-reads.

2. **Route from signals, not vibes.** Inclusion follows the phase-2
   decision table and the caller's override — nothing else. "Felt
   thin last run" is the layer's concern, not the orchestrator's.

3. **Every skip is explainable.** Every `audiencesSkipped` entry
   carries a concrete reason that traces to the signal, override, or
   failure that caused it — and is surfaced on the index page.

4. **Pin the bundle schema.** Bound to `schemaVersion: "1.0"`. A
   mismatch yields a warning, not silent acceptance. Bumping
   requires updating this skill alongside `v-analyze-repo`.

5. **The 4-component palette is locked.** `Callout`, `Tabs`,
   `Diagram`, `Steps` — and nothing else. Extension is a cross-cutting
   design decision, not a per-layer choice.

6. **Dual emission is non-negotiable.** Every MDX component carries
   its plain-MD fallback so the file degrades cleanly. `markdown`
   format is the fallback-only path for MDX-blind renderers.

7. **The manifest is the contract.** Callers drive their UX off its
   shape. Adding, renaming, or removing fields is a contract change
   — coordinate with consumers.

8. **Never write outside `outputDir`.** Only the index and per-audience
   files, into the caller-supplied directory. No side-effect writes
   anywhere else.

## MDX Templates

Phase 4 renders each layer per `./references/mdx-templates.md` — the
per-content-type and per-layer templates live there and are rendered
verbatim. Two contract rules stay pinned here:

**Fallback transport.** Every JSX component carries its plain-MD
fallback inside a `<!-- fallback: ... -->` comment the MDX renderer
ignores. Other transports such as side-by-side `.mdx`/`.md` files
are possible; this skill pins the HTML-comment form so a single file
serves both renderers, and the `markdown` format simply strips the
JSX, leaving the fallback.

**Callout-level mapping.** The audience layers emit a wider callout
vocabulary than the base set; format-output applies the table below
to map every emitted level deterministically — both to the JSX
`type=` and to the plain-MD label. New levels need a new row here,
never an ad-hoc mapping per run.

| Layer-emitted level   | Template label | JSX `type=` | Plain-MD label   |
| --------------------- | -------------- | ----------- | ---------------- |
| `info`                | Note           | `info`      | `> **Note:**`    |
| `note`                | Note           | `info`      | `> **Note:**`    |
| `important`           | Important      | `info`      | `> **Important:**` |
| `warning` / `warn`    | Warning        | `warning`   | `> **Warning:**` |
| `risk`                | Risk           | `warning`   | `> **Risk:**`    |
| `error`               | Danger         | `error`     | `> **Danger:**`  |
| `success`             | Tip            | `success`   | `> **Tip:**`     |
