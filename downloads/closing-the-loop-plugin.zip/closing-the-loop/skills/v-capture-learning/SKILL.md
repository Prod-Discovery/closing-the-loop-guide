---
name: v-capture-learning
description: Capture durable lessons from high-friction tasks and store them so future sessions can reuse them at the point of need. Use when a non-obvious root cause was just resolved, when a tool or library behaved unexpectedly and the workaround is worth preserving, when an undocumented project convention caused confusion, or whenever the user says "remember this", "save a lesson", or "document this gotcha".
trigger: [remember this, save a lesson, capture what we learned, document this gotcha, record this pattern]
license: Apache-2.0
---

# Capture Learning

## Objective

Turn hard-won task knowledge into durable, retrievable entries that prevent
future sessions from repeating the same investigation. A captured learning
is not documentation — it's a specific, actionable signal that surfaces at
the right moment to short-circuit a problem someone has already solved.

## When to Use

- A task required significant debugging and the root cause was non-obvious
- A tool, library, or service behaved differently than expected and the
  workaround is worth preserving
- An undocumented project convention caused confusion
- A recurring issue was resolved and the fix should be the default approach

Do not use this skill for documenting features or API usage, recording
architectural decisions, or writing onboarding guides — those are separate
documentation concerns. Never use it to store credentials, tokens, or
personal data.

## Workflow

### 1. Assess Capture Worthiness

Not every piece of task knowledge deserves a permanent entry. Evaluate:

- **Recurrence likelihood:** Will this situation come up again? A one-off
  issue with a since-deleted file is not worth capturing. A gotcha in a
  commonly-used library is.
- **Investigation cost:** How long did it take to figure this out? If the
  answer took five minutes of reading docs, it's probably not worth a learning
  entry. If it took an hour of debugging with misleading error messages, it
  is.
- **Discoverability gap:** Is this knowledge easy to find through normal
  channels (official docs, error messages, search)? If yes, skip it. If the
  answer is buried in a forum thread from three years ago or requires
  combining information from multiple sources, capture it.
- **Scope match:** Is this specific to the current project, or is it general
  knowledge? Project-specific learnings go in the project's knowledge store.
  General tool behavior might belong in a personal reference instead.

If fewer than two of these criteria are met, the learning probably doesn't
warrant capture. Move on.

### 2. Identify the Trigger Condition

A learning that says "the library has a bug" is useless; "when you see error
X after doing Y, the cause is Z" is immediately actionable. Before writing
the entry, identify the observable situation that activates this knowledge —
an error message, a configuration pattern, a sequence of operations — and
what a future agent or developer would be doing when they need it. If you
can't state the trigger concretely, the learning won't activate when needed.

### 3. Locate the Knowledge Store

Check where learnings are stored in this project and match the existing
format. Two storage modes are common; pick the one that matches the
project's needs:

- **Minimal mode:** a single human-readable lessons log (for example,
  `docs/ai-memory.md`). Easy to scan, easy to edit, suitable for projects
  with a small set of high-value learnings.
- **Structured mode:** a `.ai-memory/` directory with append-only JSONL files
  (`events.jsonl`, `candidates.jsonl`, `memories.jsonl`) for projects that
  want time-ordered, machine-readable logs that downstream tools can index.

If neither convention exists yet, choose one explicitly and note the choice
in the entry. Where a harness ships its own native memory, the
repo-committed store remains the shared team convention — capture there.

### 4. Capture Raw, Then Distill

Immediately after the friction event, write down what happened — the task,
the obstacle, the exact error messages or misleading signals, what didn't
work and why, the version context if behavior is version-specific. Then
strip it to what a future reader needs:

- **Remove narrative and ephemeral details** — the story of the debugging
  session, file paths that will change, ticket numbers, names of people.
- **Preserve the trigger, the resolution, and the reason it works** —
  without the reason, the learning can't be adapted to
  similar-but-different situations.

A distilled learning should be readable in under 30 seconds and actionable
immediately. If it takes more than a paragraph, split it or capture it as
documentation instead.

### 5. Categorize the Entry

Assign a category that helps with retrieval and staleness management:

- **Gotcha:** a non-obvious behavior that causes confusion or errors
- **Pattern:** a recurring solution shape that applies across situations
- **Convention:** a project-specific rule not enforced by tooling
- **Tool behavior:** tool/library behavior that differs from documentation
  or reasonable expectation

If a learning doesn't fit any category, it might be too vague — sharpen the
trigger condition and try again.

### 6. Format and Store the Entry

Write the learning in a consistent format that supports scanning and search:

- **Trigger:** One line describing the observable situation that activates
  this learning (error message, pattern, task type)
- **Learning:** One to three sentences with the actual knowledge — what's
  happening, why, and what to do about it
- **Category:** One of: gotcha, pattern, convention, tool-behavior
- **Scope:** Project-specific or general
- **Added:** Date of capture for staleness tracking

Append to the knowledge store in the established format without reformatting
existing entries, and verify the file format remains valid.

### 7. Verify Retrievability

Search the knowledge store for the trigger condition terms and confirm the
entry surfaces. Read the entry cold, as if you'd never seen the original
problem — is it clear what situation it addresses and what to do? If the
trigger matches too many situations or only one exact scenario, adjust it.

### 8. Set Staleness Expectations

Not all learnings age the same way:

- **Tool behavior** entries become stale when the tool version changes.
  Note the version if the behavior is version-specific.
- **Convention** entries become stale when the project's practices evolve.
  These should be reviewed when major structural changes happen.
- **Gotcha** entries may become stale when the underlying cause is fixed
  upstream. Note the conditions under which the gotcha would no longer apply.
- **Pattern** entries are the most durable — they encode problem-solving
  approaches that outlast specific tool versions. These rarely go stale.

## Output Contract

Every learning capture produces these sections under `## Output Contract`:

### Summary

One sentence stating what was learned and where it was filed (e.g. "Captured
a tool-behavior gotcha about cache invalidation into `docs/ai-memory.md`").

### Detail

- **Entry:** the formatted learning as it appears in the knowledge store
  (Trigger / Learning / Category / Scope / Added)
- **Location:** file path, position within the file, and whether a new file
  or section was created
- **Reuse trigger:** when this learning should surface in future work, and
  recommended search terms or file patterns for retrieval

### Verification

- Search the knowledge store for the trigger condition terms — confirm the
  entry surfaces
- Read the entry cold — confirm the situation and action are clear
- Confirm the entry contains no credentials, tokens, or personal data

### Follow-ups

- Related learnings that may need their own entries
- Staleness conditions worth recording (versions, conventions to revisit)
- "None" if the entry is self-contained

## Quality Bar

A captured learning meets the quality bar when:

- The capture-worthiness gate was applied (at least two criteria met)
- The learning body is actionable and self-contained — a cold reader can
  apply it without further research or context from the original task
- The category and scope are accurate
- The format matches the existing entries in the knowledge store
- The entry contains no credentials, tokens, or personal data

## Anti-Patterns

**The knowledge hoarder.** Capturing everything regardless of recurrence
likelihood or investigation cost. A knowledge store with 200 low-value
entries buries the 10 that actually matter — a smaller set of high-signal
learnings beats a comprehensive archive of trivia.

## Critical Rules

1. **Never capture credentials, tokens, or personal data.** Learnings are
   stored in files that may be shared, version-controlled, or read by
   automated tools. Secrets in a knowledge store are a security incident.
   If the learning involves authentication, capture the pattern without
   the actual values.

2. **Specific over general.** "The API has quirks" is not a learning. "The
   API returns 200 with an error body instead of a 4xx status when the
   token has expired" is a learning. The more specific the trigger condition,
   the more useful the entry.

3. **Trigger conditions are mandatory.** Every entry must state when it
   should activate. A learning without a trigger condition is a note buried
   in a file.

4. **One learning per entry.** If a single friction event yielded multiple
   independent insights, capture them as separate entries with separate
   trigger conditions. Combined entries are harder to retrieve and harder
   to evaluate for staleness.
