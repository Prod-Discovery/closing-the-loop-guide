---
name: component-remediation
description: Take a component flagged by component-readiness-scan and make it cleanly reusable standalone — any stack — via the right fix pattern — decouple an app dependency, promote app-only UI into the library, extract a trapped piece, extend a missing capability, or build from the Figma spec. Works in an editable lab copy, then verifies the component renders and behaves with no app wiring. Use after a readiness scan, or for "fix this component for reuse", "decouple X from the app", "make X prototype-ready", or "remediate a flagged component".
trigger: [fix this component for reuse, decouple from the app, promote into the design system, extract the component, make it prototype-ready, remediate a flagged component, make this component standalone, remove the monorepo coupling]
license: Apache-2.0
---

# Component Remediation

Turn one flagged component into a cleanly reusable one and **prove it** — it renders
(and behaves) in a standalone prototype with no app wiring, no shims.

The five fix **patterns** are stack-independent. The **mechanics** — import style,
token layer, icon component, naming — are not hardcoded here: read them from the
project's `prototype-rules.md` (written by `component-readiness-scan`) and follow them
exactly. If no rules file exists, run the scan first.

## ⚠️ Safety: this edits someone's real component code

This skill is **guided, not fully automatic.** It edits design-system source, so:

- Work in an **editable lab copy**, never a read-only synced mirror or the pristine
  monorepo clone. If no lab exists, create one (Step 1) and mark it as a deliberate
  fork so nobody re-syncs over it.
- Every change carries a `// CTL FIX:` (or `// CTL NEW:`) comment saying what changed
  and why.
- The output is a **proposal for the design-system owners to review** — a human
  approves before anything ships back to the product.

## The five fix patterns

Pick from the scan's flag:

1. **Decouple** (🟡) — the component reaches into the app/monorepo for something small.
   Move a shared helper into the library (a `_shared/` module), or replace an injected
   app service / required store / data hook with a plain input or prop.
   *Field example:* an avatar injected an environment service only to prefix an image
   URL → take `pictureUrl` directly.
2. **Promote** (🔴 legacy/app-only) — the UI exists but only as app-coupled code.
   Rebuild it as a clean, logic-free, data-driven component (inputs/props + events, no
   services, routing, or data fetching). *Field example:* header, sidenav.
3. **Extract** (🔴 trapped) — a useful piece lives inside another component and was
   never exported. Pull it into its own component + public export.
   *Field example:* the value chip trapped inside a multi-select → a standalone badge.
4. **Extend** (🔴 capability gap) — the component exists but can't do what screens
   need. Add the capability without breaking existing use. *Field example:* a
   string-cells-only table → add per-column custom cell templates.
5. **Build** (🔴 nothing exists) — create the component from the Figma spec, in full
   library conventions, flagged for design review. *Field example:* popover, menu.

## Workflow

### 1. Set up / confirm the editable lab

Ensure an editable design-system copy exists that can build and render (a minimal app
workspace in the project's own stack, embedding the library). If none exists, scaffold
one and mark its design-system folder as an editable fork (a `FORK-NOTE.md` + a note in
the project's `CLAUDE.md` so nobody re-syncs over it).

### 2. Read the component + its real spec

Read the component's source files (all of them — template, styles, types/models). For
**build / promote / extract**, pull the exact Figma node via the Figma MCP
(`get_design_context` / `get_variable_defs`) so metrics are node-exact, not guessed.
Honour any designer "known issue" notes left in Figma description fields.

### 3. Apply the pattern

- Follow the conventions in `prototype-rules.md` exactly — import style, component
  idiom, token references, icon usage, export conventions. Match the surrounding
  library code; a remediated component should be indistinguishable from a native one.
- Compose from the library's own components: if the fix needs a button, icon, or link,
  use the library's, never a raw element.
- If a needed token is missing, use the closest primitive and **flag the drift** in a
  comment — don't invent a token.
- Keep the change minimal and reversible; add the `// CTL FIX/NEW` comment.

### 4. Verify standalone (mandatory)

Build a small showcase in the lab that uses the fixed component **with no app
providers/shims**, and drive it in the browser:

- It renders in all its variants/states.
- Its **behaviour** works, not just its appearance — a moved search helper still
  filters; a remove/select event actually fires and mutates data.
- No console errors; no environment/provider needed.

Screenshot / DOM-check as proof.

### 5. Record

Update the scan's reports and `component-inventory.md` (mark the component 🟢, note the
fix applied) and record any new DS-team findings (token drift, bugs surfaced).

## Output

The remediated component (in the lab), a verification screenshot/summary, an updated
inventory/audit entry, and any new findings for the design-system owners.

## Reference — Dialog runs (2026-07-29)

Decoupled 6 (avatar + selects + cards); promoted header/sidenav; extracted a trapped
input badge; extended the table (cell templates, plus fixed a track-by-index bug);
built popover/menu/breadcrumbs/avatar-group. All verified standalone in a lab workspace.
Findings logged for the DS team: two missing tokens, a raw rgba in the header active
state, the table track-by bug.
