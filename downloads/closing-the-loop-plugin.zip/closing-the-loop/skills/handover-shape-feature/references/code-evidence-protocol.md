# Feature-driven code evidence protocol

Use this protocol inside `handover-shape-feature`. Its purpose is to retain the rigor of codebase
discovery without making every feature pay for a separate component dossier.

## Scope from the desired change

For each `D-n`, trace the smallest complete live path that can prove current behavior and constrain
the delta:

1. entry point or caller;
2. orchestration/domain behavior;
3. state and persistence, when relevant;
4. outbound integration and inbound consumers;
5. live composition/wiring;
6. flags, config, schedules, test doubles, and tests;
7. reference surface/pattern for additions.

Stop when every change, reuse choice, preserve constraint, and verification target is supported.
Do not expand into unrelated architecture.

## Evidence rules

- Read files; never infer behavior from names or directory layout.
- Cite factual code claims with `file:line`.
- Search every named identifier and confirm the cited implementation is live.
- Distinguish current wiring from duplicate, legacy, or commented-out code.
- Count exactly when a count is load-bearing.
- “No tests” or “no caller” requires a recorded search, not an assumption.
- Existing implementation is not automatically a constraint. Call it a constraint only when the
  evidence shows what breaks or which contract would be violated.
- Mark anything not confirmed as `unknown` or an inference.

## Reusing a component reference

A current `handover/[component]-reference.md` may supply evidence when:

- it covers the required layers;
- its citations still resolve;
- none of its evidence paths changed since its recorded revision.

Reuse only the claims needed for this feature and cite the underlying code. A reference is an
accelerator, not a mandatory intermediate artifact and not a substitute for checking live wiring.

## Refresh boundary

Record the base commit and evidence paths in Delivery Context. At delivery:

- no evidence path changed → use the context directly;
- evidence paths changed → rerun only the affected `D-n` rows and their owned `AC-n`/`S-n`;
- unrelated repository changes → do not refresh;
- freshness cannot be checked → reopen each load-bearing fact before relying on it.

Freshness is evidence maintenance, never a handover approval gate.
