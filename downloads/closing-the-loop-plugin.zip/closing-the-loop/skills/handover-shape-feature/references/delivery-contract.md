# Context-first Delivery Context contract

This is the only context-first handover payload. `handover-shape-feature` writes it; delivery reads
it directly.

**Where it lives depends on the requirements surface** — the content below is identical either way:

| `requirementsSurface` | Requirements | Delivery Context |
|---|---|---|
| `jira` / `linear` | the ticket description, above the section | the same description, in a `## Delivery Context` section |
| `confluence` | the requirements page | a **sub-page** titled `<Feature> — Delivery Context`, parented to it |

On Confluence the split is physical, which is strictly safer: a context refresh writes only the
sub-page, so it cannot clobber a PM's edits to the requirements. It also means the requirements page is
never "everything above the section" — it is the whole page minus its marker block.

## Canonical shape

````markdown
## Delivery Context

> **Path:** context-first
> **Backlog shape:** epic | single-ticket (team default: <X>; chosen per feature)
> **Base commit:** `<sha>`
> **Context hash:** `sha256:<hex>`
> **Refreshed:** <ISO date>
> **Scope:** <included code paths/layers>
> **Excluded:** <deliberate exclusions or None>

### Change map

| ID | Intent + source | Current behavior + evidence | Required delta | Reuse / preserve | Verification | Owner |
|---|---|---|---|---|---|---|
| D-1 | ... | ... `file:line` | ... | ... | ... | `feature` / `S-1` / `already-supported` / `unresolved` |

### Acceptance behavior

#### AC-1 — <observable behavior> · Owner: feature | S-1

```gherkin
Scenario: <behavioral outcome>
  Given <observable starting state>
  When <actor or system event>
  Then <observable result>
```

### Story map

<!-- Epic-shaped only. Omit the whole section for a single-ticket-shaped feature. Its presence is what downstream reads as the shape. -->

| ID | Demonstrable outcome | Change IDs | Acceptance IDs | Depends on |
|---|---|---|---|---|
| S-1 | ... | D-1, D-2 | AC-1, AC-2 | None |

#### Technical chores

| ID | Independently completable prerequisite | Evidence | Blocks |
|---|---|---|---|
| C-1 | ... | `file:line` | S-2 |

### Decisions and cross-cutting constraints

| ID | Decision / constraint | Impact | Resolution or evidence |
|---|---|---|---|
| Q-1 | ... | acceptance / slicing / implementation | unresolved / decision |

### Evidence index

| Path | What was verified |
|---|---|
| `path` | live behavior, wiring, tests, config, or convention |
````

Omit empty chores, decisions, and excluded-scope content; never emit placeholder rows.

## Identity and hash

Keep `D-n`, `AC-n`, `S-n`, and `C-n` stable across refreshes when their meaning survives. Allocate a
new id for a genuinely new item; do not reuse a removed id for different meaning.

Compute the context hash as SHA-256 over the normalized `## Delivery Context` section with the
`Context hash` value blank and the `Refreshed` line omitted. Normalize line endings to LF and remove
trailing whitespace. The hash changes for delivery meaning, not merely for a timestamp.

Older contexts carry the legacy header `> **Backlog mode:** …`. Read it as equivalent to `Backlog shape:`
and relabel it only on the next refresh; the relabel changes the context hash once, so projected
children are flagged stale one time — expected, not a defect.

## Ownership invariants

- Every requirement maps to one `D-n`, an already-supported row, or an unresolved decision.
- For a single-ticket-shaped feature, every delivery `D-n` and `AC-n` is owned by `feature`.
- For an epic-shaped feature, every delivery `D-n` and every `AC-n` is owned by exactly one `S-n`.
- An already-supported row names its regression verification but needs no delivery owner.
- An unresolved row cannot be projected until the decision affecting behavior or slicing is made.
- Every story is vertical and demonstrable; chores carry no fabricated Gherkin.

## Direct delivery read

For a context-first parent ticket:

1. read the full description;
2. treat everything above `## Delivery Context` as live requirements;
3. read the entire Delivery Context;
4. verify the base commit exists and compare only evidence-index paths from that commit to `HEAD`;
5. if none changed, plan from the payload directly;
6. if some changed, invoke `handover-shape-feature` for the affected `D-n` rows, then reload;
7. if freshness cannot be checked, reopen load-bearing sources before implementation.

For a context-first Confluence page pair:

1. resolve the requirements page — directly, or by following the `delivery` issue's marker block;
2. read the page as **`html`** (a `markdown` read flattens panels and task lists) and treat the whole
   page minus its marker block as live requirements;
3. read the `<Feature> — Delivery Context` sub-page in full;
4. apply steps 4-7 above unchanged — the freshness check is on the base commit and evidence paths, not
   on where the text is stored.

For a projected story or chore:

1. require `context-first-backlog-item` (`context-first-story` additionally identifies stories) and
   walk to its context-first parent. On the Confluence surface the parent is the Jira delivery issue;
   follow its marker block to the requirements page, then to the `Context page:` sub-page named in the
   child's own body;
2. compare the child's stamped context hash with the parent's current hash;
3. if stale, invoke `handover-project-stories` reconciliation and stop before implementation;
4. for a story, load its owned `D-n` rows and `AC-n` scenarios; for a chore, load its `C-n`
   prerequisite and evidence. In both cases load dependencies plus the parent's decisions and
   cross-cutting constraints;
5. resolve material open decisions in the normal engineering plan gate.

There is no handover gate and no retrieval skill. Freshness checks preserve evidence; they do not
approve scope.
