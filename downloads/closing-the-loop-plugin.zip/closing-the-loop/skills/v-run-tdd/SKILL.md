---
name: v-run-tdd
description: Execute a strict red-green-refactor cycle with verification evidence at every phase. Use when fixing a bug (write a reproducing test first), when adding new behavior whose interface should be defined by tests, when changing logic or validation rules, when refactoring code with runtime impact risk, or whenever a change would otherwise be verified only by running the application manually.
trigger: [write tests first, tdd this, add test coverage, red-green-refactor, regression test this change]
license: Apache-2.0
output_contract_schema: custom
---

# Run TDD

## Objective

Drive implementation through tests that define correct behavior before code
is written. TDD is a design discipline: every behavior change produces a
failing test first, a minimal implementation second, and a clean structure
third.

## When to Use

- Bug fixes — write a test that reproduces the bug before fixing it
- New behavior — define the expected interface through tests before building
  it
- Logic or validation changes — capture the new rules as assertions first
- Refactors with runtime impact risk — lock existing behavior in tests, then
  change structure

Skip TDD for changes with no runtime behavior impact: documentation,
comments, formatting, configuration with no logic, static assets. When
skipping, state explicitly why TDD does not apply. Never skip silently.

## Context

Before writing any test, establish the testing environment:

1. **Discover the framework and conventions.** Read existing test files:
   where they live, how they're named and organized, what utilities and
   shared fixtures they use. Match those patterns.

2. **Identify two commands.** A **focused command** that runs a single test
   file or subset relevant to the change (the inner loop — fast feedback),
   and a **broader command** that runs the full suite or a wider scope (the
   outer loop — regression confidence).

3. **Understand the behavior under test:** current behavior, desired
   behavior, boundary conditions, possible error states.

**Tooling note:** Find the test command in `AGENTS.md` / `CLAUDE.md` /
`README.md` first; detect from manifest and lock files when unstated; prefer
the harness's test-runner integration when present; ask the user as the last
resort. If detection finds no test framework — only a verifier script, an
integration check, a linter-style validator, or no formal gate — treat that
as the test gate for this repo: run it, capture its output as the focused-
and broader-command evidence, and report observed gaps as findings rather
than fail-stop. Never fail-stop on a missing test runner.

## Workflow

### 1. Red — Write a Failing Test

Write a test that describes the desired behavior and run the focused command.
The test must fail, and it must fail for the right reason — the assertion
itself fails because the behavior doesn't exist yet, not because of a syntax
error, missing import, or broken setup. Capture the output.

Prefer an existing test file for the module being changed; create a new one
only when the module has no tests or the behavior is a distinct concern. A
good test asserts on observable behavior — outputs, side effects, state
changes — tests one behavior per case, and has a descriptive name stating
what behavior is verified.

### 2. Green — Minimal Implementation

Write the smallest change to production code that makes the failing test
pass. Do not write the "full" implementation, optimize, or handle cases
beyond what the current test requires — untested behavior is unspecified
behavior. If you are tempted to implement more, write another test first.

Run the focused command; the test that was red should now pass. If it still
fails, debug the implementation — do not modify the test. Then run the
broader command: if other tests broke, the implementation introduced a side
effect — fix it before continuing.

### 3. Refactor — Improve Structure

With all tests green, improve structure, naming, and readability without
changing observable behavior. Make improvements in small, discrete changes
and run the focused tests after each — all must stay green. If you discover
needed behavior during refactoring, stop and note it: new behavior starts a
new red phase, never a refactor.

### 4. Repeat — Add Coverage Depth

Each cycle targets a different aspect of the behavior. For behavior changes,
the minimum is:

- One happy-path test
- One edge-case test
- One error-handling test

For critical or complex logic, increase coverage proportionally. If the green
phase used a shortcut (a hard-coded return value), the next red phase must
eliminate it.

### 5. Verify — Broader Confidence Check

Run the broader command. Confirm all tests in the affected area pass and no
tests elsewhere broke. If broader verification reveals failures, determine
whether they are pre-existing or caused by your changes — fix only
regressions from your work. Never accept a flaky test without investigation.

## Output Contract

Every TDD session must report the following. Use this format:

```markdown
## TDD Evidence

### Red Phase
- **Test file:** `path/to/test_file`
- **Tests added/modified:** [list of test names]
- **Focused command:** `[command]`
- **Result:** FAIL — [brief failure description]

### Green Phase
- **Files changed:** `path/to/implementation_file`
- **Change summary:** [what was implemented]
- **Focused command:** `[command]`
- **Result:** PASS

### Refactor Phase
- **Changes:** [structural improvements made, or "None — code was already clean"]
- **Focused command:** `[command]`
- **Result:** PASS

### Verification
- **Broader command:** `[command]`
- **Result:** PASS — [N tests passed, 0 failed]
- **Coverage gaps:** [known untested areas, or "None identified"]
```

## Quality Bar

A TDD cycle meets the quality bar when:

- Tests were written and observed failing before implementation began
- Test failures were caused by missing behavior, not broken setup
- The implementation is the minimum needed to pass the tests
- Refactoring did not change observable behavior
- At least one edge case or error path is covered for behavior changes
- Broader verification passed, and every command and outcome is captured in
  the output

## Anti-Patterns

**The green-only loop.** Writing tests that pass immediately to generate
coverage statistics. If no test was observed failing first, there is no
evidence it can detect regressions.

**The permanent hack.** Hard-coding a return value to pass a single test and
never writing the test that forces the real implementation. Shortcuts in the
green phase are fine only while more tests are coming.

## Critical Rules

1. **Red before green.** Never write implementation code without a failing
   test that specifies the desired behavior. The test suite is the
   specification.

2. **Never weaken assertions.** If a test fails and you believe the
   implementation is correct, re-examine the test's specification first. If
   the specification is wrong, fix the test with clear rationale; if it is
   right, fix the implementation. Do not loosen an assertion just to force
   green.

3. **Test behavior, not implementation.** Assert on return values, state
   changes, side effects, and outputs — not internal calls, private state, or
   execution paths. Good tests survive refactoring.

4. **Capture evidence at every phase.** Record the failing test, the passing
   test, and the broader verification. Reviewable evidence is the primary
   output of TDD alongside the code itself.
