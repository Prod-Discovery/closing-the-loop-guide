---
name: v-find-missing-documentation
description: Find missing documentation by analyzing Claude Code, GitHub Copilot, and OpenCode agent logs for moments where agents searched, retried, branched, or took alternative paths to locate information. Use when asked to audit AI coding sessions, identify agent confusion, find documentation gaps, or report opportunities to improve project docs, onboarding docs, runbooks, architecture notes, APIs, commands, or tool usage guidance from agent behavior.
trigger: [audit agent logs, find documentation gaps, analyze agent confusion, where did the agent get stuck, missing docs from sessions]
license: Apache-2.0
author: Kent Karlsson (@vogonistic)
---

# Find Missing Documentation

Use this skill to turn agent log history into documentation opportunities. The goal is not to score agent quality; it is to identify places where better documentation would have helped an agent find the right context, file, command, API, convention, or decision faster.

## Log Sources

Analyze these sources by default. First determine whether the tool ran natively on the host OS or inside WSL; those environments have separate home directories and log trees.

| Tool | Location |
|---|---|
| Claude Code | macOS/Linux/WSL: `~/.claude/projects/<project>/<session>.jsonl`; Windows native: `%USERPROFILE%\.claude\projects\<project>\<session>.jsonl` |
| GitHub Copilot | macOS/Linux/WSL: `~/.copilot/session-state/<session>/events.jsonl`; Windows native: `%USERPROFILE%\.copilot\session-state\<session>\events.jsonl`; if `COPILOT_HOME` is set, use `$COPILOT_HOME/session-state/<session>/events.jsonl` |
| OpenCode | macOS/Linux/WSL: `~/.local/share/opencode/opencode.db`; Windows native likely: `%USERPROFILE%\.local\share\opencode\opencode.db`; if `XDG_DATA_HOME` is set, use `$XDG_DATA_HOME/opencode/opencode.db` |

OpenCode recommends WSL on Windows. Native Windows OpenCode storage is inferred from its XDG-based data directory behavior, so verify with local files when possible.

## Quick Start

Run the bundled analyzer first:

```bash
python3 scripts/analyze_agent_logs.py --latest 20
```

By default, the analyzer reports only findings for the repository it is run from. It infers the repository from the current working directory's nearest `.git` root and shows the active `Repository filter` in the metadata.

Useful options:

```bash
python3 scripts/analyze_agent_logs.py --provider claude --latest 10
python3 scripts/analyze_agent_logs.py --provider copilot --since 2026-05-01
python3 scripts/analyze_agent_logs.py --provider opencode --output segments.md
python3 scripts/analyze_agent_logs.py --project=<repo-name> --latest 50
python3 scripts/analyze_agent_logs.py --all-repos --latest 50
```

**Note on `--project`:** Pass the bare repository name (the `.git` root directory name), not the encoded path. Use `--project=<value>` syntax (with equals sign) if the repo name starts with a hyphen to avoid argparse treating it as an option flag.

## Expected Output

When you run this skill, you will receive a report like:

```markdown
## Documentation Opportunities

### <Opportunity Title>
- Impact: <High|Medium|Low>
- Repo: <repository name>
- Evidence: <what the agent did>
- Recommendation: <doc to create or update>

### <Another Opportunity>
- Impact: <High|Medium|Low>
- ...
```

If no documentation gaps are found in the analyzed sessions, the output will say so explicitly.

## Workflow

When you invoke this skill, follow these steps:

### 1. Run the analysis orchestrator

```bash
python3 scripts/analyze_with_subagents.py --provider claude --latest 20
```

This script will:
- Extract segments from your logs
- Show you the segments
- **Generate analysis prompts for each segment**
- Tell you what to do next

### 2. For each segment in the index, spawn a subagent

The script prints a compact index of prioritized segments. Each entry includes a fetch instruction in triple-backticks.

**For each segment, you MUST:**
1. Copy the fetch instruction (everything between the triple backticks)
2. Spawn a subagent for that segment
3. Pass the fetch instruction as the subagent's instruction
4. Collect the subagent's response

The subagent will run `analyze_agent_logs.py --extract-segment <spec>` itself to retrieve the full event details, then analyze them for documentation opportunities.

Spawn one subagent per segment: give it a short description (e.g. "Analyze segment 1") and pass the fetch instruction emitted by the script as its instruction. If your tool can run subagents in parallel, do so; otherwise process the segments one at a time.

### 3. Aggregate the findings

After all subagents respond, compile their findings:
- List only segments with actual documentation opportunities
- Sort by impact: High → Medium → Low
- For each opportunity, report:
  - **Title**: What documentation is missing
  - **Impact**: High/Medium/Low
  - **Evidence**: What the agent did (specific searches, failed commands, etc.)
  - **Recommendation**: Type of doc to create/update

## Opportunity Signals

Count these as strong signals when connected to a goal:

- Repeated `Glob`, `Grep`, `Read`, `ls`, `find`, `rg`, SQL inspection, or database schema queries before the agent can act.
- Several searches using synonym terms for the same concept.
- Opening many files to infer a convention that could be documented once.
- Failed commands followed by discovery of the correct command, package script, path, or environment variable.
- Tool or API calls that reveal missing examples, payload shapes, table names, config names, or authentication steps.
- Subagents independently looking for the same context.
- The agent explicitly says it is looking for, trying to find, searching for, locating, tracing, investigating, or figuring out something.
- A user asks a follow-up such as "How do I run this?" or "How many did it find?" after implementation, which may indicate missing Quick Start, FAQ, or sample-output docs.
- Tool transport succeeds but command output contains failures, crashes, tracebacks, type/runtime compatibility errors, or test failures followed by fixes.
- Plan-to-build transitions drift from the saved plan, revealing missing scope, roadmap, or implementation-status documentation.
- Subagent delegation performs a bounded transformation or refactor that future maintainers may need to repeat, such as merging files, generating standalone scripts, or adapting a provider.
- Large parallel fanout or repeated web searches are accepted without local validation, suggesting a reference doc should separate verified local facts from researched assumptions.

Treat elapsed time as secondary. A short but tangled search can still be a documentation opportunity if the agent took avoidable alternative paths.

## Validation Playbook

Each segment block includes `Session: <path>` and event line numbers. To inspect raw JSONL records before reporting a finding:

```bash
FILE=$HOME/.claude/projects/<encoded-project>/session.jsonl
START=42
sed -n "${START},$((START+19))p" "$FILE" | jq .
```

Confirm the cited events show actual search/retry/failure behavior. If the evidence events only show routine implementation reads, discard the finding.

## Report Format

Return Markdown findings ordered by impact:

```markdown
## Documentation Opportunities

### <Missing information or decision>
- Impact: <High|Medium|Low>
- Repo: <repository name>
- Tool/session: <claude|copilot|opencode> <session id or path>
- Goal: <what the agent or subagent was trying to accomplish>
- Estimated wasted turns: <turn/event estimate spent searching or recovering>
- Evidence: <specific searches, files, commands, retries, or timestamps>
- Alternative paths: <how the agent branched or retried to find it>
- Documentation improvement: <specific doc/runbook/API note/example to add or update>
```

Close the report with a suggested next step phrased as an offer, for example: "Suggested next step — want me to run the **v-update-docs** skill to remediate these gaps now? (Or the **v-setup-agent-context** skill if the gap is recurring missing project context.)" Phrase it as a question, never as an automatic action.

If the script reports `Confidence: Medium`, say what still needs manual validation or omit the finding when the raw records do not prove alternate search paths.

Include a short `No Findings` section if the analyzed sessions do not show avoidable search behavior.

## Handling Sensitive Data

Logs may contain prompts, file paths, command outputs, secrets, and private source snippets. Do not copy secrets into reports. Redact tokens, credentials, cookies, private keys, and full personal data values while preserving enough context to explain the documentation gap.
