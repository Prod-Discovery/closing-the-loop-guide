"""Core dataclasses and shared helpers for find-missing-documentation."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


HOME = Path.home()

SECRET_TERMS = re.compile(
    r"(?i)(token|api[_-]?key|secret|password|cookie|authorization|private[_-]?key)\s*[:=]\s*\S+"
)
FAILURE_TERMS = re.compile(
    r"\b(error|failed|failure|not found|no such file|cannot|can't|unable|exception|timeout|denied|too large|traceback)\b",
    re.I,
)
SEARCH_TOOLS = {
    "grep", "glob", "read", "view", "bash", "web_search", "webfetch",
    "github-mcp-server-search_code", "github-mcp-server-get_file_contents",
}
CLAUDE_CONTROL_TERMS = re.compile(
    r"\b(tool_result|task-notification|async agent launched|internal id|do not read|queue-operation|sdk version|telemetry)\b",
    re.I,
)
META_ANALYSIS_TERMS = re.compile(
    r"\b(analy[sz]e[- ]logs|extract_copilot_agent_starts|documentation opportunities|agent logs|session log)\b",
    re.I,
)
SKILL_INVOCATION_TERMS = re.compile(r"^(?:agent\s+)?(?:Base directory for this skill:|# \w)", re.I)
NOISE_EVENTS = {
    "attachment", "file-history-snapshot", "last-prompt", "custom-title",
    "agent-name", "permission-mode",
}


@dataclass
class Event:
    provider: str
    session: str
    source: str
    line: int
    ts: str
    type: str
    text: str
    tool_name: str = ""
    args: str = ""
    parent_tool_call_id: str = ""
    tool_call_id: str = ""
    cwd: str = ""


@dataclass
class Segment:
    provider: str
    session: str
    source: str
    start_line: int
    label: str
    repo: str
    events: list[Event]
    delegated_by: Event | None = None


def compact(value: Any, limit: int = 240) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        try:
            value = json.dumps(value, ensure_ascii=True, sort_keys=True)
        except TypeError:
            value = str(value)
    value = SECRET_TERMS.sub(
        lambda m: m.group(0).split("=", 1)[0].split(":", 1)[0] + "=<REDACTED>",
        value,
    )
    value = re.sub(r"\s+", " ", value).strip()
    return value[: limit - 3] + "..." if len(value) > limit else value


def dict_text(value: Any) -> str:
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("{") or stripped.startswith("["):
            try:
                return dict_text(json.loads(stripped))
            except json.JSONDecodeError:
                return value
        return value
    if isinstance(value, list):
        return " ".join(dict_text(v) for v in value)
    if isinstance(value, dict):
        parts = []
        for key in (
            "role", "type", "name", "tool", "toolName", "content", "text",
            "message", "command", "query", "path", "arguments", "input",
            "output", "result", "data",
        ):
            if key in value:
                parts.append(dict_text(value[key]))
        return " ".join(p for p in parts if p) or " ".join(
            dict_text(v) for v in value.values()
        )
    return str(value) if value is not None else ""


def pick_ts(record: dict[str, Any]) -> str:
    for key in ("timestamp", "created_at", "createdAt", "time", "ts", "date"):
        if record.get(key):
            return str(record[key])
    return ""


def parse_json(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def latest_paths(paths, limit: int) -> list[Path]:
    existing = [p for p in paths if p.exists()]
    return sorted(existing, key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
