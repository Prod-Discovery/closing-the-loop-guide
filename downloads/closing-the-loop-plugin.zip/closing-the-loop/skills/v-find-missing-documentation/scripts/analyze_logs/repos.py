"""Repository inference helpers for find-missing-documentation."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .events import Event

HOME = Path.home()


def _repo_from_encoded_dir(session: str) -> str:
    path = Path(session)
    encoded = path.parent.name
    prefix = str(HOME).replace("\\", "-").replace("/", "-").replace(":", "-") + "-"
    if not encoded.startswith(prefix):
        return ""
    parts = encoded[len(prefix):].split("-")
    current = HOME
    i = 0
    while i < len(parts):
        for j in range(len(parts), i, -1):
            candidate = current / "-".join(parts[i:j])
            if candidate.is_dir():
                current = candidate
                i = j
                break
        else:
            break
    return str(current) if current != HOME else ""


def infer_repo(session: str, goal: str, events: list[Event]) -> str:
    for e in events:
        if e.cwd:
            cwd_path = Path(e.cwd)
            for p in (cwd_path, *cwd_path.parents):
                if (p / ".git").exists():
                    return p.name
            return cwd_path.name

    if "/.claude/projects/" in session:
        repo_path = _repo_from_encoded_dir(session)
        if repo_path:
            return Path(repo_path).name

    return "Unknown"


def current_repo_name() -> str:
    cwd = Path.cwd().resolve()
    for path in (cwd, *cwd.parents):
        if (path / ".git").exists():
            return path.name
    return cwd.name


def normalize_repo(repo: str) -> str:
    return repo.strip().lower().replace("_", "-")
