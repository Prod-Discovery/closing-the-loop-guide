"""Segment materialization and scoring helpers for find-missing-documentation."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from .events import (
    META_ANALYSIS_TERMS,
    SKILL_INVOCATION_TERMS,
    Event,
    Segment,
    compact,
)
from .repos import infer_repo

if TYPE_CHECKING:
    from .providers.base import Provider


def materialize_segments(
    events: list[Event],
    starts: list[tuple[int, str, str]],
    delegations: dict[str, Event],
) -> list[Segment]:
    segments: list[Segment] = []
    for idx, (line, label, parent) in enumerate(starts):
        next_line = starts[idx + 1][0] if idx + 1 < len(starts) else 10**18
        if parent:
            segment_events = [
                e for e in events if line <= e.line < next_line and e.parent_tool_call_id == parent
            ]
        else:
            segment_events = [e for e in events if line <= e.line < next_line]
        if not segment_events:
            continue
        goal = label
        segments.append(
            Segment(
                segment_events[0].provider,
                segment_events[0].session,
                segment_events[0].source,
                line,
                compact(goal, 180),
                infer_repo(segment_events[0].session, goal, segment_events),
                segment_events,
                delegations.get(parent),
            )
        )
    return segments


def build_segments_for_provider(
    provider: Provider, session_events: list[Event]
) -> list[Segment]:
    """Build segments for a single session's events using the provider's predicates."""
    starts: list[tuple[int, str, str]] = []
    delegations: dict[str, Event] = {}
    seen_subagent_parents: set[str] = set()

    for event in session_events:
        if provider.is_agent_start(event):
            starts.append((event.line, f"agent {event.text}", ""))

        delegation_id = provider.detect_delegation(event)
        if delegation_id:
            delegations[delegation_id] = event

        sub = provider.is_subagent_start(event)
        if sub is not None:
            parent_id, label = sub
            if parent_id not in seen_subagent_parents:
                seen_subagent_parents.add(parent_id)
                starts.append((event.line, label, parent_id))

    if not starts and session_events:
        starts = [(session_events[0].line, f"agent {session_events[0].text}", "")]

    return materialize_segments(session_events, sorted(starts), delegations)


def build_segments(events: list[Event], providers_map: dict) -> list[Segment]:
    """Group events by (provider, session), then build segments per provider.

    providers_map: dict[str, Provider] — the PROVIDERS registry.
    """
    from .providers import PROVIDERS

    by_session: dict[tuple[str, str], list[Event]] = {}
    for event in events:
        by_session.setdefault((event.provider, event.session), []).append(event)

    segments: list[Segment] = []
    for (_provider_name, _session), session_events in by_session.items():
        session_events = sorted(session_events, key=lambda e: e.line)
        if not session_events:
            continue
        provider = PROVIDERS.get(session_events[0].provider)
        if provider is not None:
            segments.extend(build_segments_for_provider(provider, session_events))
        else:
            # Fallback: generic (first event or user-ish events as starts)
            starts: list[tuple[int, str, str]] = []
            for event in session_events:
                lower = event.text.lower()
                if (
                    event.line == session_events[0].line
                    or "user" in event.type.lower()
                    or "user" in lower[:80]
                    or "task" in lower[:120]
                    or "prompt" in lower[:120]
                ):
                    starts.append((event.line, f"agent {event.text}", ""))
            if not starts:
                starts = [(session_events[0].line, f"agent {session_events[0].text}", "")]
            segments.extend(materialize_segments(session_events, sorted(starts), {}))

    return segments


def segment_elapsed(events: list[Event]) -> str:
    if len(events) < 2 or not events[0].ts or not events[-1].ts:
        return ""
    from datetime import datetime

    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S"):
        try:
            t0 = datetime.strptime(events[0].ts[:26], fmt)
            t1 = datetime.strptime(events[-1].ts[:26], fmt)
            delta = int((t1 - t0).total_seconds())
            if delta < 0:
                return ""
            return f"{delta // 60}m{delta % 60}s" if delta >= 60 else f"{delta}s"
        except ValueError:
            continue
    return ""


def is_meta_analysis_segment(segment: Segment) -> bool:
    if SKILL_INVOCATION_TERMS.match(segment.label):
        return True
    text = "\n".join(e.text + " " + e.args for e in segment.events[:12])
    return bool(segment.provider == "opencode" and META_ANALYSIS_TERMS.search(text))
