"""Rendering functions for find-missing-documentation: markdown, JSON, and segment extraction."""

from __future__ import annotations

import json
from pathlib import Path

from .events import FAILURE_TERMS, NOISE_EVENTS, Event, Segment, compact
from .repos import _repo_from_encoded_dir
from .segments import segment_elapsed


def extract_session_id(session_path: str, provider: str) -> str:
    """Extract session ID from the session path."""
    from .providers import PROVIDERS

    p = PROVIDERS.get(provider)
    if p is not None:
        return p.extract_session_id(session_path)
    # Fallback
    if provider == "opencode":
        return session_path.split("/")[-1] if "/" in session_path else session_path
    basename = Path(session_path).name
    return basename.replace(".jsonl", "")


def extract_segment_by_spec(spec: str) -> str:
    """Extract and return full events for a segment based on extraction spec.

    Spec format: provider:session_id:start:end
    Returns markdown with full event details (no truncation).
    """
    from .providers import PROVIDERS, all_names
    from .providers.opencode import OpenCodeProvider

    parts = spec.split(":")
    if len(parts) < 4:
        return "Error: Invalid extraction spec format. Expected: provider:session_id:start:end"

    provider_name, session_id, start_str, end_str = (
        parts[0],
        parts[1],
        parts[2],
        parts[3],
    )

    try:
        start = int(start_str)
        end = int(end_str)
    except ValueError:
        return "Error: start and end must be integers"

    provider = PROVIDERS.get(provider_name)
    if provider is None:
        return f"Error: Unknown provider '{provider_name}' (known: {all_names()})"

    # Load events for this provider (large limit for extraction)
    if provider_name == "opencode":
        # OpenCode needs special limit handling
        oc = provider
        if hasattr(oc, "load_events_with_limit"):
            events: list[Event] = oc.load_events_with_limit(1000)
        else:
            sources = provider.discover_sessions(1000)
            events = provider.load_events(sources)
    else:
        sources = provider.discover_sessions(1000)
        events = provider.load_events(sources)

    # Filter to matching session and line range
    segment_events = [
        e
        for e in events
        if e.provider == provider_name
        and provider.extract_session_id(e.session) == session_id
        and start <= e.line <= end
    ]

    if not segment_events:
        return f"No events found for {provider_name}:{session_id} lines {start}-{end}"

    lines = [
        f"## Extracted Segment: {provider_name}:{session_id}:{start}:{end}",
        f"- Provider: {provider_name}",
        f"- Events: {len(segment_events)} total",
        "",
        "### Events (Full Context)",
    ]

    for event in segment_events:
        ref = f"{event.line}"
        args = f" args={event.args}" if event.args else ""
        tool = f" tool={event.tool_name}" if event.tool_name else ""
        lines.append(f"{ref} {event.type}{tool}{args} {event.text}")

    return "\n".join(lines)


def render_segments_json(segments: list[Segment], repo_filter: str | None) -> str:
    """Render segments as a single JSON document for structured consumption."""
    from .providers import all_names

    provider_counts = {p: len([s for s in segments if s.provider == p]) for p in all_names()}
    seg_list = []
    for i, segment in enumerate(segments, 1):
        elapsed = segment_elapsed(segment.events)
        shown_events = [
            e
            for e in segment.events
            if "thinking" not in (e.type + " " + e.text).lower()
            and e.type not in NOISE_EVENTS
            and (e.text or "").strip()
        ]
        session_id = extract_session_id(segment.session, segment.provider)
        start_line = segment.events[0].line
        end_line = segment.events[-1].line
        extract_spec = f"{segment.provider}:{session_id}:{start_line}:{end_line}"

        tool_counts: dict[str, int] = {}
        for e in segment.events:
            if e.tool_name:
                tool_counts[e.tool_name] = tool_counts.get(e.tool_name, 0) + 1

        failure_event_count = sum(1 for e in segment.events if FAILURE_TERMS.search(e.text))

        seg_list.append(
            {
                "index": i,
                "provider": segment.provider,
                "repo": segment.repo,
                "session": segment.session,
                "session_id": session_id,
                "start_line": start_line,
                "end_line": end_line,
                "extract_spec": extract_spec,
                "label": segment.label,
                "elapsed": elapsed,
                "events_total": len(segment.events),
                "events_shown": len(shown_events),
                "tool_counts": tool_counts,
                "failure_event_count": failure_event_count,
            }
        )

    doc = {
        "metadata": {
            "segment_count": len(segments),
            "provider_counts": provider_counts,
            "repo_filter": repo_filter or "all repositories",
        },
        "segments": seg_list,
    }
    return json.dumps(doc, indent=2)


def render_segments(
    segments: list[Segment], repo_filter: str | None, text_width: int = 180
) -> str:
    from .providers import all_names

    provider_counts = {p: len([s for s in segments if s.provider == p]) for p in all_names()}
    provider_summary = ", ".join(f"{p}={provider_counts[p]}" for p in all_names())
    lines = [
        "## Segment Analysis",
        "",
        f"- Segments extracted: {len(segments)}",
        f"- Provider breakdown: {provider_summary}",
        f"- Repository filter: {repo_filter or 'all repositories'}",
        f"- Text width: {'unlimited' if text_width == 0 else text_width}",
        "",
    ]
    if not segments:
        lines += ["No segments found for the selected criteria."]
        return "\n".join(lines)

    for i, segment in enumerate(segments, 1):
        elapsed = segment_elapsed(segment.events)
        elapsed_part = f" — ~{elapsed}" if elapsed else ""
        shown_events = [
            e
            for e in segment.events
            if "thinking" not in (e.type + " " + e.text).lower()
            and e.type not in NOISE_EVENTS
            and (e.text or "").strip()
        ]

        repo_root = None
        if "/.claude/projects/" in segment.session:
            try:
                repo_root_str = _repo_from_encoded_dir(segment.session)
                if repo_root_str:
                    repo_root = Path(repo_root_str)
            except Exception:
                pass

        session_id = extract_session_id(segment.session, segment.provider)
        start_line = segment.events[0].line
        end_line = segment.events[-1].line
        extract_spec = f"{segment.provider}:{session_id}:{start_line}:{end_line}"
        lines += [
            f"## Segment {i}: {compact(segment.label, 100 if text_width > 0 else 1000)}{elapsed_part}",
            f"- Repo: {segment.repo} | Provider: {segment.provider} | Lines: {start_line}–{end_line} ({len(shown_events)} shown / {len(segment.events)} total)",
            f"- Session: {segment.session}",
            f"- Source: {extract_spec}",
            f"- Extract: python3 analyze_agent_logs.py --extract-segment {extract_spec}",
            "",
        ]
        lines += ["### Events"]
        for event in shown_events:
            ref = f"{event.line}"
            if repo_root:
                repo_path = str(repo_root)
                repo_name = repo_root.name
                normalized_args = (
                    event.args.replace(repo_path + "/", repo_name + "/") if event.args else ""
                )
                normalized_text = event.text.replace(repo_path + "/", repo_name + "/")
            else:
                normalized_args = event.args if event.args else ""
                normalized_text = event.text
            args = f" args={normalized_args}" if normalized_args else ""
            tool = f" tool={event.tool_name}" if event.tool_name else ""
            display_text = (
                normalized_text if text_width == 0 else compact(normalized_text, text_width)
            )
            lines.append(f"{ref} {event.type}{tool}{args} {display_text}")
        lines.append("")

    return "\n".join(lines)
