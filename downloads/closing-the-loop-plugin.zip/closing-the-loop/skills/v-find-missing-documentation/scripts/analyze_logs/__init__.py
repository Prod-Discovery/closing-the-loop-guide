"""analyze_logs — provider-agnostic agent log analysis package.

To run from the scripts/ directory:
    python3 -m analyze_logs [args]

Or via the thin shim:
    python3 analyze_agent_logs.py [args]

Test suite:
    cd skills/find-missing-documentation/scripts
    python3 -m unittest discover -s analyze_logs/tests -v
"""
