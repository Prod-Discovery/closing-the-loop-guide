# OpenCode Test Fixtures

OpenCode tests are skipped for fixture-based unit tests.

SQLite fixtures are messy to ship (binary format, schema coupling) and are out of scope for this test suite. OpenCode provider correctness is covered by integration testing on real databases (run `python3 scripts/analyze_agent_logs.py --provider opencode --latest 5` against a live install).
