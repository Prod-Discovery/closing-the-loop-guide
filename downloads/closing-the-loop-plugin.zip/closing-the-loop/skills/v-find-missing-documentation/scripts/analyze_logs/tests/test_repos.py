"""Tests for repository inference helpers in repos.py."""

import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

# Add scripts/ to path so imports work when run directly or via unittest discover
import sys
_scripts_dir = Path(__file__).resolve().parents[3]  # scripts/
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))

from analyze_logs import repos
from analyze_logs.events import Event
from analyze_logs.repos import _repo_from_encoded_dir, current_repo_name, infer_repo, normalize_repo


def _event(cwd: str = "") -> Event:
    return Event(
        provider="claude", session="x", source="x",
        line=1, ts="", type="user", text="", cwd=cwd,
    )


class TestInferRepo(unittest.TestCase):

    def test_cwd_with_git_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "myrepo"
            repo.mkdir()
            (repo / ".git").mkdir()
            result = infer_repo("session", "", [_event(cwd=str(repo))])
            self.assertEqual(result, "myrepo")

    def test_cwd_with_no_git_anywhere(self):
        with tempfile.TemporaryDirectory() as tmp:
            # Isolated temp dir with no .git in any ancestor (os.sep root aside)
            leaf = Path(tmp) / "somedir"
            leaf.mkdir()
            result = infer_repo("session", "", [_event(cwd=str(leaf))])
            self.assertEqual(result, leaf.name)

    def test_cwd_walks_up_to_find_git(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "myrepo"
            src = repo / "src" / "components"
            src.mkdir(parents=True)
            (repo / ".git").mkdir()
            result = infer_repo("session", "", [_event(cwd=str(src))])
            self.assertEqual(result, "myrepo")

    def test_empty_events_returns_unknown(self):
        result = infer_repo("no-projects-path/abc.jsonl", "", [])
        self.assertEqual(result, "Unknown")

    def test_first_empty_cwd_skipped_second_used(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "secondrepo"
            repo.mkdir()
            (repo / ".git").mkdir()
            events = [_event(cwd=""), _event(cwd=str(repo))]
            result = infer_repo("session", "", events)
            self.assertEqual(result, "secondrepo")

    def test_encoded_dir_fallback_macos_style(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake_home = Path(tmp)
            projects_dir = fake_home / "Projects" / "myrepo"
            projects_dir.mkdir(parents=True)

            encoded = str(fake_home).replace("\\", "-").replace("/", "-").replace(":", "-") + "-Projects-myrepo"
            session = f"/.claude/projects/{encoded}/abc.jsonl"

            with patch.object(repos, "HOME", new=fake_home):
                result = infer_repo(session, "", [])
            self.assertEqual(result, "myrepo")

    def test_encoded_dir_fallback_linux_style(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake_home = Path(tmp)
            projects_dir = fake_home / "Projects" / "coolrepo"
            projects_dir.mkdir(parents=True)

            encoded = str(fake_home).replace("\\", "-").replace("/", "-").replace(":", "-") + "-Projects-coolrepo"
            session = f"/.claude/projects/{encoded}/abc.jsonl"

            with patch.object(repos, "HOME", new=fake_home):
                result = infer_repo(session, "", [])
            self.assertEqual(result, "coolrepo")

    def test_encoded_dir_unrelated_home_returns_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake_home = Path(tmp)

            # Build encoded dir that matches a completely different home path
            other_encoded = "-totally-unrelated-home-Projects-somerepo"
            session = f"/.claude/projects/{other_encoded}/abc.jsonl"

            with patch.object(repos, "HOME", new=fake_home):
                direct = _repo_from_encoded_dir(session)
                self.assertEqual(direct, "")
                result = infer_repo(session, "", [])
            self.assertEqual(result, "Unknown")


class TestCurrentRepo(unittest.TestCase):

    def setUp(self):
        self._original_cwd = os.getcwd()

    def tearDown(self):
        os.chdir(self._original_cwd)

    def test_current_repo_name_returns_git_root_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp) / "myproject"
            repo.mkdir()
            (repo / ".git").mkdir()
            os.chdir(str(repo))
            result = current_repo_name()
            self.assertEqual(result, "myproject")


class TestNormalizeRepo(unittest.TestCase):

    def test_underscores_become_dashes(self):
        self.assertEqual(normalize_repo("My_Repo"), "my-repo")

    def test_whitespace_stripped(self):
        self.assertEqual(normalize_repo("  myrepo  "), "myrepo")

    def test_idempotent(self):
        self.assertEqual(normalize_repo("my-repo"), "my-repo")


if __name__ == "__main__":
    unittest.main()
