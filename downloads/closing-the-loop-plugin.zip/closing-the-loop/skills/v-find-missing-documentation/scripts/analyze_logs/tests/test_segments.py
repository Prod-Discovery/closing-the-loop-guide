"""Tests for segment materialization and rendering using fixtures."""

import json
import unittest
from pathlib import Path

# Add scripts/ to path so imports work when run directly or via unittest discover
import sys
_scripts_dir = Path(__file__).resolve().parents[3]  # scripts/
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))

FIXTURES = Path(__file__).parent / "fixtures"

from analyze_logs.providers import PROVIDERS
from analyze_logs.providers.claude import ClaudeProvider
from analyze_logs.providers.copilot import CopilotProvider
from analyze_logs.render import extract_segment_by_spec, render_segments_json
from analyze_logs.segments import build_segments, is_meta_analysis_segment


class TestClaudeSegments(unittest.TestCase):
    FIXTURE = FIXTURES / "claude" / "sample.jsonl"

    def setUp(self):
        provider = ClaudeProvider()
        events = provider.load_events([self.FIXTURE])
        self.segments = build_segments(events, PROVIDERS)

    def test_segments_produced(self):
        self.assertGreater(len(self.segments), 0, "Should produce at least one segment")

    def test_segment_fields(self):
        for seg in self.segments:
            self.assertEqual(seg.provider, "claude")
            self.assertGreater(seg.start_line, 0)
            self.assertGreater(len(seg.events), 0)
            self.assertIsInstance(seg.label, str)
            self.assertIsInstance(seg.repo, str)

    def test_segment_start_lines_ascending(self):
        # Multiple segments should have ascending start lines
        if len(self.segments) >= 2:
            start_lines = [s.start_line for s in self.segments]
            for i in range(1, len(start_lines)):
                self.assertGreaterEqual(start_lines[i], start_lines[i - 1])

    def test_render_json_valid(self):
        json_str = render_segments_json(self.segments, "test-repo")
        doc = json.loads(json_str)
        self.assertIn("metadata", doc)
        self.assertIn("segments", doc)
        self.assertIsInstance(doc["segments"], list)

    def test_render_json_schema(self):
        json_str = render_segments_json(self.segments, "test-repo")
        doc = json.loads(json_str)
        if not doc["segments"]:
            self.skipTest("No segments to check schema")
        seg = doc["segments"][0]
        expected_keys = {
            "index", "provider", "repo", "session", "session_id",
            "start_line", "end_line", "extract_spec", "label", "elapsed",
            "events_total", "events_shown", "tool_counts", "failure_event_count",
        }
        missing = expected_keys - set(seg.keys())
        self.assertEqual(missing, set(), f"JSON schema missing keys: {missing}")

    def test_render_json_extract_spec_format(self):
        json_str = render_segments_json(self.segments, "test-repo")
        doc = json.loads(json_str)
        if not doc["segments"]:
            self.skipTest("No segments")
        for seg in doc["segments"]:
            spec = seg["extract_spec"]
            parts = spec.split(":")
            self.assertEqual(len(parts), 4, f"extract_spec should have 4 colon-parts: {spec}")
            self.assertEqual(parts[0], "claude")
            # parts[2] and [3] should be integers
            self.assertTrue(parts[2].isdigit(), f"start should be int in spec: {spec}")
            self.assertTrue(parts[3].isdigit(), f"end should be int in spec: {spec}")

    def test_render_json_tool_counts_structure(self):
        json_str = render_segments_json(self.segments, "test-repo")
        doc = json.loads(json_str)
        for seg in doc["segments"]:
            tc = seg["tool_counts"]
            self.assertIsInstance(tc, dict)
            for k, v in tc.items():
                self.assertIsInstance(k, str)
                self.assertIsInstance(v, int)

    def test_render_json_failure_event_count(self):
        json_str = render_segments_json(self.segments, "test-repo")
        doc = json.loads(json_str)
        # fixture has an "Error" and a "FAILED" event, so at least one segment
        # should have failure_event_count > 0
        total_failures = sum(seg["failure_event_count"] for seg in doc["segments"])
        self.assertGreater(total_failures, 0, "Fixture has failure-term events")

    def test_extract_segment_by_spec_round_trip(self):
        """extract_segment_by_spec should find events when given a valid spec."""
        json_str = render_segments_json(self.segments, "test-repo")
        doc = json.loads(json_str)
        if not doc["segments"]:
            self.skipTest("No segments")
        spec = doc["segments"][0]["extract_spec"]
        # The spec points to the fixture file via session path, but extract_segment_by_spec
        # calls discover_sessions(1000) on the live system — it will find the spec only if
        # the fixture file is actually in ~/.claude or similar. Instead, we test the spec
        # format parses correctly and the function handles a known-absent spec gracefully.
        parts = spec.split(":")
        # Re-form with a bogus session id to confirm graceful "not found" response
        bogus_spec = f"claude:no-such-session-000:{parts[2]}:{parts[3]}"
        result = extract_segment_by_spec(bogus_spec)
        self.assertIn("No events found", result)

    def test_extract_segment_by_spec_bad_format(self):
        result = extract_segment_by_spec("bad-spec")
        self.assertIn("Error", result)

    def test_extract_segment_by_spec_unknown_provider(self):
        result = extract_segment_by_spec("unknownprovider:session:1:10")
        self.assertIn("Error", result)


class TestCopilotSegments(unittest.TestCase):
    FIXTURE_DIR = FIXTURES / "copilot"
    FIXTURE = FIXTURE_DIR / "events.jsonl"

    def setUp(self):
        provider = CopilotProvider()
        events = provider.load_events([self.FIXTURE])
        self.segments = build_segments(events, PROVIDERS)

    def test_segments_produced(self):
        self.assertGreater(len(self.segments), 0, "Should produce at least one segment")

    def test_segment_provider(self):
        for seg in self.segments:
            self.assertEqual(seg.provider, "copilot")

    def test_no_meta_analysis_segments(self):
        meta = [s for s in self.segments if is_meta_analysis_segment(s)]
        # fixture does not contain analyze-logs or similar meta invocations
        self.assertEqual(len(meta), 0, "Fixture should not contain meta-analysis segments")

    def test_render_json_schema(self):
        json_str = render_segments_json(self.segments, None)
        doc = json.loads(json_str)
        if not doc["segments"]:
            self.skipTest("No segments")
        seg = doc["segments"][0]
        expected_keys = {
            "index", "provider", "repo", "session", "session_id",
            "start_line", "end_line", "extract_spec", "label", "elapsed",
            "events_total", "events_shown", "tool_counts", "failure_event_count",
        }
        missing = expected_keys - set(seg.keys())
        self.assertEqual(missing, set(), f"JSON schema missing keys: {missing}")


if __name__ == "__main__":
    unittest.main()
