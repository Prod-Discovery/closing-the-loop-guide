"""Tests for provider implementations using JSONL fixtures."""

import json
import unittest
from pathlib import Path

# Fixtures directory
FIXTURES = Path(__file__).parent / "fixtures"

# Add scripts/ to path so imports work when run directly or via unittest discover
import sys
_scripts_dir = Path(__file__).resolve().parents[3]  # scripts/
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))

from analyze_logs.providers.claude import ClaudeProvider
from analyze_logs.providers.copilot import CopilotProvider


class TestClaudeProvider(unittest.TestCase):
    FIXTURE = FIXTURES / "claude" / "sample.jsonl"

    def setUp(self):
        self.provider = ClaudeProvider()
        self.fixture_path = self.FIXTURE
        self.assertTrue(self.fixture_path.exists(), f"Fixture missing: {self.fixture_path}")

    def test_load_events_returns_events(self):
        events = self.provider.load_events([self.fixture_path])
        self.assertGreater(len(events), 0, "Should load at least one event from fixture")

    def test_events_have_expected_provider(self):
        events = self.provider.load_events([self.fixture_path])
        for e in events:
            self.assertEqual(e.provider, "claude")

    def test_events_have_types(self):
        events = self.provider.load_events([self.fixture_path])
        types = {e.type for e in events}
        # fixture has user and assistant events
        self.assertIn("user", types)
        self.assertIn("assistant", types)

    def test_events_have_tool_names(self):
        events = self.provider.load_events([self.fixture_path])
        tool_names = {e.tool_name for e in events if e.tool_name}
        # fixture has Bash, Read, Glob tool_use events
        self.assertTrue(len(tool_names) > 0, "Should find at least one tool_use event")
        self.assertIn("Bash", tool_names)

    def test_is_agent_start_on_user_event(self):
        events = self.provider.load_events([self.fixture_path])
        user_events = [e for e in events if e.type == "user"]
        self.assertTrue(len(user_events) > 0)
        # Most user events should be agent starts (unless CLAUDE_CONTROL_TERMS match)
        starts = [e for e in user_events if self.provider.is_agent_start(e)]
        self.assertGreater(len(starts), 0, "Should detect at least one agent start")

    def test_is_agent_start_false_for_assistant(self):
        events = self.provider.load_events([self.fixture_path])
        assistant_events = [e for e in events if e.type == "assistant"]
        for e in assistant_events:
            # tool_use assistant events may have is_subagent_start but NOT is_agent_start
            self.assertFalse(
                self.provider.is_agent_start(e),
                f"Assistant event should not be agent start: {e.type}",
            )

    def test_detect_delegation_on_task_tool(self):
        # The fixture doesn't have Task tool, but we can test the logic directly
        from analyze_logs.events import Event
        e = Event(
            provider="claude", session="test.jsonl", source="test.jsonl",
            line=1, ts="", type="assistant", text="delegating",
            tool_name="Task", tool_call_id="id-abc123",
        )
        result = self.provider.detect_delegation(e)
        self.assertEqual(result, "id-abc123")

    def test_detect_delegation_none_for_non_task(self):
        from analyze_logs.events import Event
        e = Event(
            provider="claude", session="test.jsonl", source="test.jsonl",
            line=1, ts="", type="assistant", text="running bash",
            tool_name="Bash", tool_call_id="id-bash001",
        )
        result = self.provider.detect_delegation(e)
        self.assertIsNone(result)

    def test_extract_session_id_strips_jsonl(self):
        sid = self.provider.extract_session_id(
            "/Users/x/.claude/projects/-Users-x-Projects-repo/abc-123.jsonl"
        )
        self.assertEqual(sid, "abc-123")

    def test_extract_session_id_stable(self):
        path = "/Users/x/.claude/projects/-Users-x-Projects-repo/abc-123.jsonl"
        self.assertEqual(
            self.provider.extract_session_id(path),
            self.provider.extract_session_id(path),
        )


class TestCopilotProvider(unittest.TestCase):
    FIXTURE_DIR = FIXTURES / "copilot"
    FIXTURE = FIXTURE_DIR / "events.jsonl"

    def setUp(self):
        self.provider = CopilotProvider()
        self.assertTrue(self.FIXTURE.exists(), f"Fixture missing: {self.FIXTURE}")

    def _load(self):
        # copilot.load_events expects a list of paths to events.jsonl files
        return self.provider.load_events([self.FIXTURE])

    def test_load_events_returns_events(self):
        events = self._load()
        self.assertGreater(len(events), 0)

    def test_events_have_expected_provider(self):
        events = self._load()
        for e in events:
            self.assertEqual(e.provider, "copilot")

    def test_events_have_types(self):
        events = self._load()
        types = {e.type for e in events}
        self.assertIn("user.message", types)

    def test_events_have_tool_names(self):
        events = self._load()
        tool_names = {e.tool_name for e in events if e.tool_name}
        # fixture has bash, view, grep, glob
        self.assertTrue(len(tool_names) > 0, "Should find tool_use events")

    def test_is_agent_start_on_user_message(self):
        events = self._load()
        user_msg_events = [e for e in events if e.type == "user.message"]
        self.assertTrue(len(user_msg_events) > 0)
        for e in user_msg_events:
            self.assertTrue(
                self.provider.is_agent_start(e),
                f"user.message should be agent start",
            )

    def test_is_agent_start_false_for_tool_events(self):
        events = self._load()
        tool_events = [e for e in events if e.type in ("tool.execution_start", "tool.execution_complete")]
        for e in tool_events:
            self.assertFalse(self.provider.is_agent_start(e))

    def test_extract_session_id_returns_dir_name(self):
        # Copilot session is the directory name (UUID)
        sid = self.provider.extract_session_id("fixture-session-01")
        self.assertEqual(sid, "fixture-session-01")
        # Also stable
        self.assertEqual(sid, self.provider.extract_session_id("fixture-session-01"))

    def test_extract_session_id_non_empty(self):
        events = self._load()
        self.assertTrue(len(events) > 0)
        sid = self.provider.extract_session_id(events[0].session)
        self.assertTrue(len(sid) > 0, "extract_session_id should return non-empty string")


if __name__ == "__main__":
    unittest.main()
