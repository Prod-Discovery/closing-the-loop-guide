"""Provider registry for find-missing-documentation.

To add a new provider, create providers/<name>.py implementing the Provider
protocol, then call register(<YourProvider>()) below.
"""

from __future__ import annotations

from .base import Provider
from .claude import ClaudeProvider
from .copilot import CopilotProvider
from .opencode import OpenCodeProvider

PROVIDERS: dict[str, Provider] = {}


def register(p: Provider) -> None:
    PROVIDERS[p.name] = p


def get(name: str) -> Provider:
    return PROVIDERS[name]


def all_names() -> list[str]:
    return list(PROVIDERS.keys())


register(ClaudeProvider())
register(CopilotProvider())
register(OpenCodeProvider())
