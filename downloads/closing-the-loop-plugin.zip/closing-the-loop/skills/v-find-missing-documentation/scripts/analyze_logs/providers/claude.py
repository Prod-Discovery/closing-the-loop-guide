"""Claude Code provider for find-missing-documentation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..events import (
    CLAUDE_CONTROL_TERMS,
    Event,
    compact,
    dict_text,
    latest_paths,
    pick_ts,
)


HOME = Path.home()


def _claude_tool(record: dict[str, Any]) -> tuple[str, Any, str]:
    msg = record.get("message") if isinstance(record.get("message"), dict) else record
    content = msg.get("content") if isinstance(msg, dict) else None
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "tool_use":
                return (
                    str(item.get("name", "")),
                    item.get("input", ""),
                    str(item.get("id", "")),
                )
    return "", "", ""


class ClaudeProvider:
    name = "claude"

    def discover_sessions(self, limit: int) -> list[Path]:
        root = HOME / ".claude" / "projects"
        return latest_paths(root.glob("*/*.jsonl") if root.exists() else [], limit)

    def load_events(self, sources: list[Path]) -> list[Event]:
        events: list[Event] = []
        for path in sources:
            for line_no, line in enumerate(
                path.read_text(encoding="utf-8", errors="ignore").splitlines(), start=1
            ):
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                text = dict_text(record)
                if CLAUDE_CONTROL_TERMS.search(text):
                    continue
                tool_name, args, call_id = _claude_tool(record)
                events.append(
                    Event(
                        "claude",
                        str(path),
                        str(path),
                        line_no,
                        pick_ts(record),
                        str(record.get("type") or record.get("role") or "event"),
                        compact(text),
                        tool_name,
                        compact(args, 500),
                        "",
                        call_id,
                        cwd=record.get("cwd", ""),
                    )
                )
        return events

    def is_agent_start(self, e: Event) -> bool:
        return (
            e.type.lower() == "user"
            and not CLAUDE_CONTROL_TERMS.search(e.text)
        )

    def detect_delegation(self, e: Event) -> str | None:
        if e.tool_name.lower() in {"task", "agent"} and e.tool_call_id:
            return e.tool_call_id
        return None

    def is_subagent_start(self, e: Event) -> tuple[str, str] | None:
        # A Task tool_use starts a subagent segment
        if e.tool_name.lower() in {"task", "agent"} and e.tool_call_id:
            return (e.tool_call_id, f"subagent {e.tool_name} {e.args}")
        # Assistant message with delegation phrasing
        lower_type = e.type.lower()
        lower_text = e.text.lower()
        if (
            "assistant" in lower_type
            and "your task" in lower_text
            and "agent" in lower_text
        ):
            key = e.tool_call_id or str(e.line)
            return (key, f"subagent {e.text}")
        return None

    def extract_session_id(self, session: str) -> str:
        basename = Path(session).name
        return basename.replace(".jsonl", "")
