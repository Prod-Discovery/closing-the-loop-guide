"""GitHub Copilot provider for find-missing-documentation."""

from __future__ import annotations

import json
import os
from pathlib import Path

from ..events import Event, compact, dict_text, latest_paths, pick_ts


HOME = Path.home()


class CopilotProvider:
    name = "copilot"

    def discover_sessions(self, limit: int) -> list[Path]:
        root = (
            Path(os.environ.get("COPILOT_HOME", HOME / ".copilot")) / "session-state"
        )
        return latest_paths(
            root.glob("*/events.jsonl") if root.exists() else [], limit
        )

    def load_events(self, sources: list[Path]) -> list[Event]:
        events: list[Event] = []
        for path in sources:
            session = path.parent.name
            for line_no, line in enumerate(
                path.read_text(encoding="utf-8", errors="ignore").splitlines(), start=1
            ):
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                data = record.get("data") or {}
                tool_name = (
                    data.get("toolName", "") if isinstance(data, dict) else ""
                )
                args = (
                    data.get("arguments", "") if isinstance(data, dict) else ""
                )
                parent_id = (
                    str(data.get("parentToolCallId", "") or "")
                    if isinstance(data, dict)
                    else ""
                )
                call_id = (
                    str(data.get("toolCallId", "") or "")
                    if isinstance(data, dict)
                    else ""
                )
                events.append(
                    Event(
                        "copilot",
                        session,
                        str(path),
                        line_no,
                        pick_ts(record),
                        record.get("type", "event"),
                        compact(dict_text(data)),
                        tool_name,
                        compact(args, 500),
                        parent_id,
                        call_id,
                    )
                )
        return events

    def is_agent_start(self, e: Event) -> bool:
        return e.type == "user.message"

    def detect_delegation(self, e: Event) -> str | None:
        if (
            e.type == "tool.execution_start"
            and e.tool_name == "task"
            and e.tool_call_id
        ):
            return e.tool_call_id
        return None

    def is_subagent_start(self, e: Event) -> tuple[str, str] | None:
        if e.parent_tool_call_id:
            return (
                e.parent_tool_call_id,
                f"subagent parentToolCallId={e.parent_tool_call_id} {e.text}",
            )
        return None

    def extract_session_id(self, session: str) -> str:
        # session is the directory name (UUID) for copilot
        return session
