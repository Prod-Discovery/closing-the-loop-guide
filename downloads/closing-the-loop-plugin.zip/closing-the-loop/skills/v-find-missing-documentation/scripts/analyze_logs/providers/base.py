"""Provider Protocol/ABC for find-missing-documentation provider plugins."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable

from ..events import Event


@runtime_checkable
class Provider(Protocol):
    """Interface that every provider must implement.

    Adding a new provider (Codex, Cursor, Factory, ...) means creating one
    new file under providers/ that implements this protocol and calling
    register() in providers/__init__.py.
    """

    name: str  # e.g. "claude", "copilot", "opencode"

    def discover_sessions(self, limit: int) -> list[Path]:
        """Return up to `limit` most-recent session paths, or [] if not configured."""
        ...

    def load_events(self, sources: list[Path]) -> list[Event]:
        """Load and return events for the given sources."""
        ...

    def is_agent_start(self, e: Event) -> bool:
        """True if this event marks the start of an agent turn (user message, etc.)."""
        ...

    def detect_delegation(self, e: Event) -> str | None:
        """If this event is a Task/delegation tool_use, return its tool_call_id. Else None."""
        ...

    def is_subagent_start(self, e: Event) -> tuple[str, str] | None:
        """If this event is the first event of a subagent run, return (parent_tool_call_id, label). Else None."""
        ...

    def extract_session_id(self, session: str) -> str:
        """Pull a stable session identifier out of a session path/string."""
        ...
