"""OpenCode provider for find-missing-documentation."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any

from ..events import Event, compact, dict_text, parse_json


HOME = Path.home()


def _opencode_part_text(part: dict[str, Any]) -> str:
    part_type = str(part.get("type") or "")
    if part_type in {"text", "reasoning"}:
        return str(part.get("text") or "")
    if part_type == "tool":
        state = part.get("state") if isinstance(part.get("state"), dict) else {}
        output = state.get("output") or state.get("error") or ""
        return f"tool {part.get('tool', '')} {dict_text(state.get('input'))} {dict_text(output)}"
    return dict_text(part)


class OpenCodeProvider:
    name = "opencode"

    def _db_path(self) -> Path:
        data_home = Path(os.environ.get("XDG_DATA_HOME", HOME / ".local" / "share"))
        return data_home / "opencode" / "opencode.db"

    def discover_sessions(self, limit: int) -> list[Path]:
        db = self._db_path()
        if db.exists():
            return [db]
        return []

    def load_events(self, sources: list[Path]) -> list[Event]:
        """sources is expected to be a list containing (at most) the db path."""
        if not sources:
            return []
        db = sources[0]
        if not db.exists():
            return []
        events: list[Event] = []
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            con.row_factory = sqlite3.Row
            rows = con.execute(
                """
                select p.rowid as rowid, s.id as session_id, s.directory as directory, s.title as title,
                       m.id as message_id, m.data as message_data, p.id as part_id,
                       p.time_created as time_created, p.data as part_data
                from session s
                join message m on m.session_id = s.id
                join part p on p.message_id = m.id
                order by s.time_updated desc, m.time_created, p.time_created, p.id
                limit 20000
                """
            )
            for row in rows:
                part = parse_json(str(row["part_data"] or ""))
                if not isinstance(part, dict):
                    continue
                part_type = str(part.get("type") or "part")
                if part_type in {"step-start", "step-finish"}:
                    continue
                text = _opencode_part_text(part)
                tool_name = str(part.get("tool") or "")
                args = ""
                state = part.get("state")
                if isinstance(state, dict):
                    args = state.get("input") or ""
                if not text and not tool_name:
                    continue
                prefix_text = dict_text({"title": row["title"]}) if row["title"] else ""
                combined_text = " ".join([p for p in [prefix_text, text] if p])
                events.append(
                    Event(
                        "opencode",
                        str(row["session_id"]),
                        f"{db}:part:{row['rowid']}",
                        int(row["rowid"]),
                        str(row["time_created"] or ""),
                        part_type,
                        compact(combined_text),
                        tool_name,
                        compact(args, 500),
                        "",
                        str(part.get("callID") or ""),
                        cwd=str(row["directory"] or ""),
                    )
                )
            con.close()
        except sqlite3.Error:
            return []

        # Limit to `limit` most-recent sessions — honour the limit passed to load_events
        # by storing limit in discover_sessions. Since discover_sessions doesn't carry
        # the limit into load_events, we apply it here using a sentinel if needed.
        # The caller (segments.py / __main__.py) drives the limit via discover_sessions,
        # so this is a no-op unless sources is already filtered.
        return events

    def load_events_with_limit(self, limit: int) -> list[Event]:
        """Convenience: discover + limit in one call (mirrors old opencode_events(limit))."""
        db = self._db_path()
        if not db.exists():
            return []
        all_events = self.load_events([db])
        keep: list[str] = []
        seen: set[str] = set()
        for event in sorted(all_events, key=lambda e: e.ts, reverse=True):
            if event.session not in seen:
                seen.add(event.session)
                keep.append(event.session)
            if len(keep) >= limit:
                break
        keep_set = set(keep)
        return [e for e in all_events if e.session in keep_set]

    def is_agent_start(self, e: Event) -> bool:
        return e.type == "text" and "role user" in e.text.lower()

    def detect_delegation(self, e: Event) -> str | None:
        # OpenCode has no Task/delegation concept
        return None

    def is_subagent_start(self, e: Event) -> tuple[str, str] | None:
        # OpenCode has no subagent concept
        return None

    def extract_session_id(self, session: str) -> str:
        return session.split("/")[-1] if "/" in session else session
