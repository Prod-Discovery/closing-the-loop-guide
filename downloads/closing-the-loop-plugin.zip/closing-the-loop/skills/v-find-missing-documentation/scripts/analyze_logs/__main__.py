"""CLI entry point for find-missing-documentation package.

Usage (direct):
    python3 -m analyze_logs [args]

Usage (via shim):
    python3 scripts/analyze_agent_logs.py [args]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .events import Event
from .providers import PROVIDERS, all_names, get
from .providers.opencode import OpenCodeProvider
from .render import extract_segment_by_spec, render_segments, render_segments_json
from .repos import current_repo_name, normalize_repo
from .segments import build_segments, is_meta_analysis_segment


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract and format agent/subagent log segments for analysis."
    )
    # --provider is the canonical flag; --tool is a hidden backward-compat alias
    provider_choices = ["all"] + all_names()
    parser.add_argument(
        "--provider",
        choices=provider_choices,
        default="all",
        dest="provider",
        help="Provider to analyze (default: all). Choices: " + ", ".join(provider_choices),
    )
    parser.add_argument(
        "--tool",
        choices=provider_choices,
        dest="provider",
        help=argparse.SUPPRESS,  # hidden alias for --provider
    )
    parser.add_argument(
        "--latest",
        type=int,
        default=20,
        help="Maximum sessions per provider to analyze.",
    )
    parser.add_argument("--since", help="Only include events on or after YYYY-MM-DD.")
    parser.add_argument(
        "--project",
        help="Repository filter. Defaults to the current repo.",
    )
    parser.add_argument(
        "--all-repos",
        action="store_true",
        help="Analyze every repository.",
    )
    parser.add_argument("--output", help="Write report to this file.")
    parser.add_argument(
        "--text-width",
        type=int,
        default=180,
        help="Max width for event text truncation (0 for no truncation).",
    )
    parser.add_argument(
        "--extract-segment",
        help="Extract specific segment: provider:session_id:start:end",
    )
    parser.add_argument(
        "--format",
        choices=["markdown", "json"],
        default="markdown",
        dest="output_format",
        help="Output format for normal analysis mode (default: markdown).",
    )
    return parser.parse_args()


def _load_events(provider_filter: str, latest: int) -> list[Event]:
    """Load events from the selected provider(s)."""
    events: list[Event] = []
    for name, provider in PROVIDERS.items():
        if provider_filter not in ("all", name):
            continue
        if name == "opencode":
            # OpenCode needs a limit-aware loader
            oc = provider
            if hasattr(oc, "load_events_with_limit"):
                events.extend(oc.load_events_with_limit(latest))
            else:
                sources = provider.discover_sessions(latest)
                events.extend(provider.load_events(sources))
        else:
            sources = provider.discover_sessions(latest)
            events.extend(provider.load_events(sources))
    return events


def main() -> int:
    args = parse_args()

    # Handle segment extraction mode
    if args.extract_segment:
        report = extract_segment_by_spec(args.extract_segment)
        if args.output:
            Path(args.output).write_text(report, encoding="utf-8")
        else:
            print(report)
        return 0

    # Normal analysis mode
    events = _load_events(args.provider, args.latest)
    if args.since:
        events = [e for e in events if not e.ts or e.ts >= args.since]

    repo_filter = None if args.all_repos else (args.project or current_repo_name())
    segments = build_segments(events, PROVIDERS)
    if repo_filter:
        segments = [
            s for s in segments if normalize_repo(s.repo) == normalize_repo(repo_filter)
        ]
    segments = [s for s in segments if not is_meta_analysis_segment(s)]

    if args.output_format == "json":
        report = render_segments_json(segments, repo_filter)
    else:
        report = render_segments(segments, repo_filter, args.text_width)

    if args.output:
        Path(args.output).write_text(report, encoding="utf-8")
    else:
        print(report)
    return 0


if __name__ == "__main__":
    sys.exit(main())
