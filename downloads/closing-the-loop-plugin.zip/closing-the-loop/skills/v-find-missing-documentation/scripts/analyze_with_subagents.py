#!/usr/bin/env python3
"""Run log analyzer and generate subagent analysis prompts."""

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Optional


def run_analyzer(
    provider: str = "claude",
    latest: int = 20,
    project: Optional[str] = None,
    since: Optional[str] = None,
) -> dict:
    """Run the log analyzer script with --format json and return the parsed dict."""
    cmd = [
        "python3",
        str(Path(__file__).parent / "analyze_agent_logs.py"),
        "--provider", provider,
        "--format", "json",
    ]

    if latest:
        cmd.extend(["--latest", str(latest)])
    if project:
        cmd.extend([f"--project={project}"])
    if since:
        cmd.extend(["--since", since])

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error running analyzer: {result.stderr}", file=sys.stderr)
        sys.exit(1)
    return json.loads(result.stdout)


def score_segment_for_analysis(segment: dict) -> int:
    """Score how likely a segment shows struggling behavior using structured fields.

    Higher = more likely to contain documentation opportunities.
    Thresholds: HIGH >= 8, MEDIUM >= 4, LOW < 4.
    """
    score = 0

    # Search/exploration tool usage (capped at 10)
    tool_counts = segment.get("tool_counts", {})
    search_tools = {
        "Read", "Glob", "Bash", "WebSearch", "WebFetch", "Grep",
        "github-mcp-server-search_code", "github-mcp-server-get_file_contents",
    }
    search_count = sum(v for k, v in tool_counts.items() if k in search_tools)
    score += min(search_count, 10)

    # Failure/error events indicate struggle
    failure_count = segment.get("failure_event_count", 0)
    if failure_count >= 1:
        score += 3
    if failure_count >= 3:
        score += 2  # Extra weight for repeated failures

    # Tool diversity (many different tools = complex session)
    if len(tool_counts) > 5:
        score += 2

    # Longer sessions (elapsed time has minutes component)
    elapsed = segment.get("elapsed", "")
    if elapsed and "m" in elapsed:
        try:
            minutes = int(elapsed.split("m")[0])
            if minutes >= 1:
                score += 2
        except ValueError:
            pass

    # Segment size: more events shown = more investigative work
    events_shown = segment.get("events_shown", 0)
    if events_shown >= 20:
        score += 1

    return score


def create_fetch_instruction(extract_spec: str) -> str:
    """Create a fetch-and-analyze instruction for a subagent."""
    analyzer_path = Path(__file__).parent / "analyze_agent_logs.py"
    return (
        f"Run `python3 {analyzer_path} --extract-segment {extract_spec} --text-width 0`, "
        "then analyze the output for documentation opportunities. "
        "Reply in the standard format: "
        "Opportunity / Impact / Evidence / Recommendation — or \"No opportunity\" if none is evident."
    )


def main():
    parser = argparse.ArgumentParser(
        description="Analyze agent logs with subagent support for documentation opportunities."
    )
    # --provider is canonical; --tool is a hidden backward-compat alias
    provider_choices = ["claude", "copilot", "opencode", "all"]
    parser.add_argument(
        "--provider",
        default="claude",
        choices=provider_choices,
        dest="provider",
        help="Provider to analyze (default: claude).",
    )
    parser.add_argument(
        "--tool",
        choices=provider_choices,
        dest="provider",
        help=argparse.SUPPRESS,  # hidden alias for --provider
    )
    parser.add_argument("--latest", type=int, default=20, help="Analyze latest N sessions")
    parser.add_argument(
        "--since", help="Only analyze logs since this date (YYYY-MM-DD)"
    )
    parser.add_argument("--project", help="Filter by project name (bare repo name)")

    args = parser.parse_args()

    # Run the analyzer and get structured JSON
    print("Extracting log segments...", file=sys.stderr)
    analysis = run_analyzer(
        provider=args.provider,
        latest=args.latest,
        project=args.project,
        since=args.since,
    )

    segments = analysis.get("segments", [])
    print(f"Found {len(segments)} segments to analyze.", file=sys.stderr)

    if not segments:
        print("No segments found.", file=sys.stderr)
        return

    # Score segments using structured fields
    scored_segments = [(seg, score_segment_for_analysis(seg)) for seg in segments]
    scored_segments.sort(key=lambda x: x[1], reverse=True)

    # Print compact segment index (no raw event data)
    print("## Analysis Instructions\n")
    print(f"Found {len(segments)} segments. Prioritizing up to 15 for analysis.\n")
    print(
        "For each segment below, spawn a subagent with the fetch instruction shown in triple-backticks.\n"
    )
    print(
        "After all subagents respond, aggregate findings by **recommendation** (not by session), deduplicate, and sort by impact.\n"
    )

    rank = 0
    for segment, score in scored_segments[:15]:
        # Skip very small segments (fewer than 2 events shown)
        if segment.get("events_shown", 0) < 2:
            continue

        rank += 1
        label = segment.get("label", "Unknown")
        relevance = "HIGH" if score >= 8 else "MEDIUM" if score >= 4 else "LOW"
        repo = segment.get("repo", "unknown")
        extract_spec = segment.get("extract_spec", "")

        print(f"### Segment {rank} (Relevance: {relevance}, Score: {score})")
        print(f"- Repo: {repo}")
        print(f"- Header: {label}")
        if extract_spec:
            print(f"- Extract spec: `{extract_spec}`")
        print()
        if extract_spec:
            print("```")
            print(create_fetch_instruction(extract_spec))
            print("```")
        else:
            print("_(No extract spec available — segment may be malformed.)_")
        print()
        print("---\n")


if __name__ == "__main__":
    main()
