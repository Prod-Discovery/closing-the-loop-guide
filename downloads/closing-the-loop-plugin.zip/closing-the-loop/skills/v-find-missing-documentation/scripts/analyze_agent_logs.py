#!/usr/bin/env python3
"""Thin shim — preserves the `python3 scripts/analyze_agent_logs.py` invocation.

All logic lives in the analyze_logs package. This file exists solely so that
existing SKILL.md references and subagent fetch instructions keep working.
"""

import sys
from pathlib import Path

# Ensure the scripts/ directory is on sys.path so the package resolves correctly
# when this shim is invoked as a script from any working directory.
_scripts_dir = Path(__file__).resolve().parent
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))

from analyze_logs.__main__ import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
