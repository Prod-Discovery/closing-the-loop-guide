---
name: handover-retrieval
description: "Consumer reader for the governed discovery-to-delivery handover path. Detects discovery-handover tickets and generated children, reads PM + Dev sign-off, and loads the approved Engineering Brief, frozen PRD, and AGENTS block. Use for governed bare-ticket delivery or live gate inspection. Context-first tickets load Delivery Context directly instead."
trigger: [load the handover, pull the handover package, is this a handover ticket, bootstrap engineering from a ticket, check the approval gate, retrieve handover artifacts]
license: Apache-2.0
---

# Handover Retrieval (Discovery to Delivery — Consumer Side)

The handover package is produced once (by `discovery-handover-package`) and lives on the source ticket. Delivery, though, often starts somewhere else: a dev picks up a ticket key and runs an engineering entry point directly, never touching the orchestrator that assembled the package. This skill is the single step that closes that gap — it gets the **approved** package into the dev's working context, and refuses to do so until the approval gate is actually met.

This reader belongs only to the governed path. A `context-first-handover` ticket follows
`handover-shape-feature`'s direct delivery contract; it has no package or sign-off gate.

In default `delivery` mode it does four things and stops: **detect** that a ticket is a handover
ticket, **reconcile** new comments into the Brief (by invoking `handover-brief-review`), **gate-check**
PM + Dev sign-off, and **load** the approved payload. In `gate-status` mode it only detects, locates,
and inspects the gate; it never reconciles comments or loads payload. Neither mode implements, writes
a spec, or opens a PR.

> [!note] One call, owned in one place
> Engineering entry points and the bridge orchestrators should reach the handover package through *this* skill, not by each re-deriving the marker, the manifest shape, and the gate logic. The producer-side conventions (the `discovery-handover` label, the manifest, the sign-off sub-issues) all live in `discovery-create-tracker-issue` and `discovery-handover-package`; this skill is their single reader. Wiring it into the engineering-side entry points (`v-ticket-to-release`, `v-develop-feature`) is the engineering lead's call — flag it, don't assume it.

## When to Use

- Delivery starts from a **bare ticket key** and the package is not already in the local working tree.
- An engineering entry point needs the Engineering Brief + AGENTS.md context **before** it plans or writes code.
- Anything needs to answer *"is this an approved handover ticket, and may work begin?"* as a single, deterministic check.
- A pre-gate projector or session-preparation orchestrator needs the live sign-off/checklist state
  without loading artifacts for engineering.

Do **not** use it to *produce* a handover package (that is `discovery-handover-package`) or to provision an implementation backlog (that is `create-backlog-from-brief`). This skill reads, verifies, and **triggers the comment-reconcile** (`handover-brief-review` does the editing) — it never edits the Brief or moves the gate itself.

## Output Contract

A run produces one of three outcomes, never a silent half-state:

1. **Gate satisfied → context loaded.** The latest-version Engineering Brief and AGENTS.md discovery-context block are read into the session (and their paths reported), with the source ticket key, the resolved package version, and a one-line gate confirmation (both sign-off sub-issues Done — which requires their routed checklist items ticked). The caller proceeds to plan/implement from this context.
2. **Gate not satisfied → blocked, with reasons.** No artifacts are loaded for development. The run reports exactly what is missing — which sign-off sub-issue is still open (and its assignee), or which routed checklist item on it is still unticked — including any sub-issue **re-opened** because a new comment introduced a requirement-level change that must be re-ratified — so the human can resolve it on the ticket. Loading an unapproved package for implementation is the failure this skill exists to prevent.
3. **`gate-status` inspection → status returned, context not loaded.** Return the PM and Dev sign-off
   keys, assignees, statuses, readable unticked items, and `gate: open|passed`. An open gate is a normal
   result and does **not** abort the caller; the caller may continue projection/refinement work that is
   explicitly licensed before approval. No Brief, frozen PRD, or AGENTS.md block is loaded.

It also reports the **not-a-handover-ticket** case plainly: if the `discovery-handover` marker is absent, this skill makes no claim on the ticket and hands back to the caller's default behaviour (treat the description as the spec).

### Invocation mode

- **`mode: delivery`** (default): reconcile comments, enforce the gate, and load payload only on pass.
- **`mode: gate-status`**: resolve the ticket/package index and read the live gate only. Skip comment
  reconciliation and Step 4. Return status to the caller whether open or passed. This is the only
  licensed inspection path for `create-backlog-from-brief` and `prepare-amigo-session`; callers must
  not approximate gate state themselves.

## Workflow

### Step 1: Resolve the source and detect the marker

Take the ticket key (preferred) or a local `handover/` directory. Establish whether this is a handover ticket:

- **From a ticket key:** fetch the issue (Linear: get-issue; Jira: get-issue with the `cloudId`). Read its labels. The governed marker is **`discovery-handover`**, selected by `discovery-create-tracker-issue` when `handoverPath` is governed. Corroborate with an attachment whose subtitle is `discovery-handover-package`, or a local manifest (Step 2).
- If the issue carries `context-first-handover`, stop this reader and hand control back for direct
  Delivery Context loading. If it carries both path markers, report the ambiguity and stop.
- **From a local dir:** the presence of `handover/[feature]-manifest.json` is the marker.

**Generated-child walk-up (epic-shaped features).** If the ticket carries
`discovery-handover-backlog-item` / `discovery-handover-story`, or its parent carries
`discovery-handover`, treat it as a generated child of a handover Epic. Resolve the **parent** and run
every following step against it: the Brief is the Epic's description and its sign-off issues are the
gate. Classify scope from the child's label/stamp, never from its title alone:

- **Story (`discovery-handover-story` label / `Slice S-n` stamp):** record its key, keyed acceptance
  criteria, in-body §6.1 slice, `Cut from Brief v<x>` stamp, and *blocks* relations.
- **Chore (`discovery-handover-backlog-item` label / `Chore C-n` stamp):** record its key, §8 constraint,
  mitigation/prerequisite work, Brief-version stamp, and *blocks* relations. Do not demand AC or §6.1
  story scope from a chore.

For a legacy child with only a handover-labelled parent, use `Slice S-n` for a story or a matching
`manifest.backlog.chores[].key/slice` entry whose live parent is this Epic for a chore. Never classify
from a `[Story]` / `[Chore]` title. If classification remains ambiguous, report that and stop rather
than invent scope.
Two extra checks before handing back:

- **Dependency order:** if a relation that blocks this child is not Done, report it alongside the gate
  result — an approved Epic does not make an out-of-order generated item deliverable.
- **Staleness:** if the Brief's current version is newer than the child's stamp *and* the revision
  history shows a change to a Brief section the story or chore cites, report the child as stale —
  refreshing it is `create-backlog-from-brief`'s job, never this skill's.

Under **pre-gate backlog timing** (`backlogTiming: pre-gate`), generated children exist before the
Epic's gate has passed — a gate-blocked story or chore is then the expected pre-ratification state;
report it as such, not as an anomaly. The gate check itself still blocks delivery.

If neither the label nor a manifest is present, this is **not** a handover ticket. Say so and stop — return control to the caller, which should fall back to treating the ticket description as the spec. Do not guess from the description text.

### Step 2: Locate the package (local first, ticket second)

Prefer the **local working tree** — it is authoritative for the engineering session and needs no download:

1. Read `handover/[feature]-manifest.json` if present. It links the package to its ticket and indexes files and attachments: `sourceTicket`, `files` (brief, agentsContext, prd — plus bootstrap on the no-tracker path), `attachments[]` (version-stamped), `handoverMode`, and `signoffIssues` (`pm` / `dev` keys). Use it as the index for everything below.
2. If no local manifest exists, resolve from the **ticket**: the package was uploaded back to the issue as version-stamped attachments. Read the attachment list; the manifest attachment (subtitle `discovery-handover-package`) names the file set and the current version.

Resolve the **latest version** — the Brief is the ticket description as it stands now. Do not read
the payload contents yet. What makes that version *approved* is **the gate, not a stored version
number**: a post-sign-off **requirement-level** change re-opens its sub-issue (Step 2.5 /
`handover-brief-review`), so both sub-issues can be Done only against a Brief with no unratified
requirement change since sign-off. (Only non-material mechanical fixes can land after sign-off
without re-opening.)

### Step 2.5: Reconcile new comments into the Brief

In `delivery` mode, before reading the gate, check the **comments** on the ticket and the two sign-off sub-issues — skip the archived-PRD provenance comment and the live block / changes-requested comments. If any comment is **not yet reflected in the Brief**, re-invoke **handover-brief-review** to fold it in (a **targeted fold** — at most one grounding agent, never a full review pass on an unchanged Brief): a groundable change is applied to the Brief (new version), an ungroundable one is routed as a `needs-input` checklist item, and a requirement-level change applied after a side has signed **re-opens** that sub-issue. This keeps the Brief — the thing this skill loads — current with the discussion, so a requirement raised in a comment can never be silently lost.

This is **read-and-trigger only**: this skill never interprets a comment or edits the Brief itself — `handover-brief-review` owns that. It is **invocation-driven, not event-driven**: the reconcile happens here, the next time the bridge is exercised, not the instant a comment is posted. If no comment is unreflected, skip straight to the gate.

In `gate-status` mode, skip comment reconciliation entirely. Its contract is live gate inspection,
not mutation; the orchestrator that requested inspection is responsible for running the mandatory
Brief review first when its workflow requires one.

### Step 3: Check the approval gate — before loading anything for development

This is the hard gate. Read it from the **two sign-off sub-issues**, not from a file (a file can lie; the tracker state cannot). Their keys are in the manifest's `signoffIssues` (`pm`, `dev`); if there is no manifest, find them as the source ticket's children labelled `handover-signoff`.

The gate passes only when **both** sub-issues are in a Done-type state:
- **Linear:** the sub-issue's state `type === "completed"`.
- **Jira:** the sign-off issue's `fields.status.statusCategory.key === "done"` (Sub-task on a
  single-ticket-shaped feature; Task-type Epic child on an epic-shaped one).

Open questions and disambiguations are **checklist items on those same sub-issues** — routed by `discovery-handover-package` Step 4 (design/value/scope/customer/risk/legal/metric → the PM sub-issue; feasibility/data/eng → the Dev sub-issue) and `handover-brief-review` appends its judgment findings there too. The convention is that a reviewer ticks every item before moving their sub-issue to Done — but tracker checkboxes are **not workflow validators**, so verify it: **scan both sub-issue descriptions for unticked items.** Both Done *with* unticked items remaining = the gate is not clean — stop and report the specific unticked items, exactly like an open sub-issue.

**On Jira the description always arrives as markdown — and in two different shapes.** Do **not** pass `responseContentFormat: "adf"` expecting ADF: the parameter is accepted and silently ignored, so `taskList`/`taskItem` nodes never arrive (verified 2026-08-04; see `KNOWN-ISSUES.md`). Scan the text, matching **both** forms:

| Form | Example |
|------|---------|
| Real markdown checkbox | `- [ ] Acceptance criteria are testable…` |
| Escaped literal text (wiki-markup path) | `* \[ \] **Acceptance criteria** are testable…` |

Match an optional `-`/`*` bullet and optional backslashes around the brackets. **Matching only `- [ ]` will miss the second form and report a clean scan on a sign-off where nothing was ticked** — a false pass on the gate, observed on KAN-16 (Done, all boxes unticked). Linear descriptions are markdown and use the first form only.

**State the limit in the report.** Because the description is flattened to markdown, an unticked box cannot be distinguished from literal text that was never tickable in the Jira UI. Where every box reads unticked on a Done sign-off, report it as unresolved *and* name the ambiguity — do not silently pass it, and do not assert the reviewer skipped the checklist. (Legacy tickets that used an open-questions *comment* instead: confirm it is answered too.)

In `delivery` mode, if the gate fails on any count, **stop and report** which side is open (sign-off
key + assignee + status, the unticked checklist items, or the unanswered comment). Do not load
artifacts for development. The only exception is an explicit, logged user override for a dry run
that will not write code.

In `gate-status` mode, return the same specific state as structured status and hand control back even
when the gate is open. Do not proceed to Step 4. **Inspection is not loading:** reading sign-off
state for projection/refinement is not permission to read the delivery payload.

### Step 4: Load the artifacts into context

In `delivery` mode only, with the gate satisfied, read the **delivery payload** — three artifacts, at
the approved version:

- **Engineering Brief** (`files.brief`) — the arbitration layer. Read it in full; it carries the open-interpretations, **corrections to the PRD**, constraints, component import paths, and risks. **Precedence: on any conflict with the PRD, the Brief wins** — state this in the report so the implementer knows which document rules.
- **Frozen PRD** (`files.prd`) — the requirements document as frozen at handover (`[feature]-prd-v1.0.md` attachment). Never edited after the freeze; read it alongside the Brief.
- **AGENTS.md discovery-context block** (`files.agentsContext`) — the non-inferable rationale to append to the target repo's `AGENTS.md`.

**Local files:** read them from `handover/` directly — done.

**From the ticket (no local copy):** the **Engineering Brief is now the ticket description** (promoted by `discovery-handover-package` Step 7.0), so the most robust read is the description itself at the approved version — a plain get-issue, with no signed URL to expire and **no token required**. The **PRD and AGENTS.md block** are download-dependent (version-stamped attachments); download their bytes (and the Brief too, if you prefer the attachment). The download route depends on the tracker and runtime:

- **Local shell with network egress.** Fetch the raw bytes and read the actual file, not a summary of it.
  - **Linear:** re-run get-issue / get-attachment to mint a current signed URL (these expire) and fetch it.
  - **Jira:** the MCP returns attachment metadata only, so download the bytes through the REST API — get the attachment id from the manifest's `attachmentId` (or `getJiraIssue` with `fields: ["attachment"]`), then `GET https://<site>.atlassian.net/rest/api/3/attachment/content/<id>` with `-L` and basic auth (`-u "$JIRA_EMAIL:$JIRA_API_TOKEN"` or `--netrc`). Full routine: [`../discovery-handover-package/references/jira-attachment-download.md`](../discovery-handover-package/references/jira-attachment-download.md).
  - **No Jira token configured:** the Brief still loads from the description; report the PRD and AGENTS.md block as not-loaded and ask the user to supply the local files — do not fabricate them.
- **Sandboxed runtime (egress proxy).** A tracker's signed storage URL may be blocked the same way attachment *upload* is. If a direct fetch fails with a proxy/connection error, ask the user to supply the file directly. Never proceed on a file you could not actually read, and never substitute a guess for an artifact you failed to fetch.
- **If a signed URL is rejected as expired,** re-resolve it from the issue and retry — an expired token is a reason to re-fetch, not to give up.

Nothing else is loaded: a Bootstrap Prompt only exists on the no-tracker path (this load does its job here), and there is no approval artifact — the approval was already read live from the sub-issues in Step 3.

### Step 5: Report and hand back

In `delivery` mode, report the ticket key, resolved version, gate confirmation, paths/where-loaded of
the Brief, PRD, and AGENTS.md block, and the precedence rule. On generated-child walk-up, state either
**story scope = keyed criteria + §6.1 slice** or **chore scope = C-n + §8 prerequisite work**, while
**context = the Epic's payload**, plus dependency/staleness flags.
State that the AGENTS.md block should be appended before code. In `gate-status` mode, report only the
source key, resolved package/Brief version metadata, each sign-off's live state and readable unticked
items, and `gate: open|passed`; state `payload loaded: no`, then hand back.

## Tooling Note

This skill reads from an issue tracker; degrade gracefully across environments:

- **Tracker MCP server (preferred).** Linear or Atlassian (Jira) MCP in the session — read labels, attachments, sub-issue states, and comments directly.
- **Host API token.** A tracker API token in the environment — same reads over the API. For **Jira attachment download** (the AGENTS.md block), the credential comes from the Closing the Loop config when present (`~/.config/closing-the-loop/config.json` → `jira.site` + `authMethod`/`authFile`, written by `closing-the-loop-setup`); otherwise set `JIRA_EMAIL` + `JIRA_API_TOKEN` (a classic/unscoped token) or a `~/.netrc` entry. The MCP returns attachment metadata only, so the bytes come through the REST API. Without it, the Brief still loads from the description (no token needed) — only the attachment download is gated.
- **Local-only.** No tracker connection: work entirely from the local `handover/` directory and its manifest. The gate is then read from the Brief's `## Sign-off` section rather than live sub-issues, and is therefore only as trustworthy as that file — note this in the report.
- **No package at all.** Report that no handover package could be located and hand back; do not fabricate one.

## Quality Bar

A run meets the bar when:

- The handover ticket was identified by the `discovery-handover` marker, not inferred from description text.
- The approval gate was read from the two sign-off sub-issues' live state (or, local-only, from the Brief's `## Sign-off` section with that limitation stated) — and implementation was blocked whenever it was not satisfied.
- Open items were resolved as part of the sub-issues reaching Done (their routed checklist items ticked) — not bypassed.
- The Brief and AGENTS.md block actually loaded were the **approved** version, retrieved and read as real bytes — not a summary, not a newer unapproved revision.
- The loaded **payload stands alone** — the Brief does not defer any load-bearing detail (a spec, formula, enumeration, state machine, or output format) to the prototype or the brownfield reference, which this skill does not load. If it does: in `strict` mode (manifest `handoverMode`), block and re-run `handover-brief-review` to back-fill §6.1 before delivery; in `standard` mode, load but surface the open questions prominently in the report so the dev asks the PM instead of guessing.
- The outcome is unambiguous: delivery mode either loads context after a clean gate or blocks with
  the missing item; `gate-status` mode returns open/passed state without loading or failing the caller
  merely because the gate is open.

It fails the bar when an unapproved or unread package is loaded for development, when the gate is taken from a file while live sub-issues were available, when a not-a-handover ticket is treated as one, or when a download failure is hidden behind a summary.

## Anti-Patterns

**Loading before checking the gate.** The whole point is that work cannot begin on an unapproved package. Read the sign-off state first; load only on pass.

**Trusting a file over the tracker.** When sub-issues exist, their state is the gate — nothing written in a file (including the Brief's `## Sign-off` section, which must not even exist on the tracker path) is a signal. In-file sign-off is only for the no-tracker path.

**Reading a summary instead of the file.** A summariser silently drops and inverts byte-level detail (option defaults, table columns). Download and read the actual Brief; re-fetch a fresh URL if the signed one expired.

**Loading despite an open or re-opened sub-issue.** A requirement-level change after sign-off re-opens its sub-issue, so if either sub-issue is not Done, the latest Brief is not approved — do not load it. When both are Done, the latest version *is* the ratified one (only non-material mechanical fixes can land without re-opening); the gate, not a stored version number, is the approval signal.

**Absorbing handover conventions into every caller.** The marker name, manifest shape, and gate logic live here. Callers make one call; they do not re-implement the reader.

## Critical Rules

- **Gate before load.** No artifacts reach the development context until both sign-off sub-issues are Done (their routed checklist items — including open questions — ticked). A bare-key delivery path that skips this is the exact hole this skill closes.
- **Inspection never loads.** `mode: gate-status` returns the live gate state, skips comment
  reconciliation, and never enters Step 4. An open result is data for its orchestrator, not a caller
  failure or an approval override.
- **The governed marker is `discovery-handover`.** Detection keys off that label and is
  corroborated by the manifest. `context-first-handover` belongs to the direct Delivery Context
  contract.
- **A generated child loads through its Epic.** `discovery-handover-backlog-item`,
  `discovery-handover-story`, or a handover-labelled parent triggers the walk-up: gate and payload
  always come from the parent Epic. A story contributes keyed AC + §6.1 scope; a chore contributes its
  C-n + §8 prerequisite scope. An item with an unfinished blocker remains blocked after gate pass.
- **Live sub-issue state is the source of truth for the gate** (Linear `type === "completed"` / Jira `statusCategory === "done"`); the Brief's `## Sign-off` section is the fallback only when there is no tracker.
- **Load the latest version, as real bytes — the gate makes it the approved one.** Both sub-issues Done ⟹ no unratified requirement change since sign-off (a requirement-level change re-opens the gate). Retrieve and read the real bytes — re-fetch expired signed URLs, fall back on a blocked sandbox download, never proceed on an unread file.
- **Reconcile comments before the delivery gate, by delegation.** In `delivery` mode, check for
  comments not yet reflected in the Brief and re-invoke `handover-brief-review` to fold them in or
  route them. This skill **never interprets a comment or edits the Brief itself**. Skip this mutation
  in `gate-status` mode.
- **Read, verify, and trigger — never produce or implement.** Producing the package is `discovery-handover-package`; editing the Brief is `handover-brief-review`; the backlog is `create-backlog-from-brief`; implementation is the caller's. This skill detects, reconciles (by delegation), gates, and loads.
- **Engineering-side wiring is the engineering lead's call.** Composing this into `v-ticket-to-release` / `v-develop-feature` crosses into the engineering lane — propose it, don't assume it.
