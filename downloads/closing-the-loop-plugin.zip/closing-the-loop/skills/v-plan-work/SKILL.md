---
name: v-plan-work
description: Decompose work into decision-complete implementation plans that can be executed without guesswork. Use when planning a feature, scoping work, breaking a task down, designing the approach before implementation, or whenever a request touches multiple files, has dependencies between steps, or could otherwise produce sprawling unscoped diffs.
trigger: [plan this feature, break this down, scope this work, design the approach, architect this change]
license: Apache-2.0
output_contract_schema: custom
---

# Plan Work

## Objective

Create execution-ready plans that eliminate ambiguity. A good plan lets an
implementer work through each step without stopping to make design decisions,
guess at file paths, or wonder what "done" looks like. Planning is the act of
making every decision that would otherwise block execution.

## When to Use

- A task involves changes across multiple files or modules
- The work requires a specific ordering of steps (dependencies between changes)
- There are architectural choices that affect downstream work
- Risk, rollback, or migration concerns exist
- Multiple approaches exist and one must be chosen with rationale

Do not plan when the task is a single, obvious change (rename a variable, fix
a typo, update a constant). Recognize when planning is overhead and just do
the work.

## Workflow

### 1. Define Scope Boundaries

Write explicit scope and exclusions before anything else.

**Include:** what will be changed (specific files, modules, interfaces), what
behavior will be added, modified, or removed, what verification looks like.

**Exclude:** related improvements, refactoring opportunities discovered
during inspection, optimizations beyond the stated goal. If something is
tempting but out of scope, name it in exclusions — this prevents scope creep
during execution and creates a backlog of future work.

### 2. Choose the Approach

When multiple approaches exist, evaluate them explicitly: state each option
in one sentence, list its tradeoff (complexity, risk, reversibility,
performance), choose one, and state why. Do not present options without
choosing. The plan's job is to make decisions, not defer them.

### 3. Order Steps by Risk and Dependency

- **High-risk steps come first.** If something might invalidate the approach,
  discover that before building on top of it. A failed experiment in step 1
  is cheap. A failed experiment in step 8, after seven steps assumed it would
  work, is expensive.
- **Dependencies flow forward.** No step references work that hasn't been
  done yet.
- **Verification is interleaved.** Each meaningful step has a way to confirm
  it worked before moving on — early verification catches wrong assumptions
  before they compound.

### 4. Write Decision-Complete Steps

Each step must answer:

- **What** changes (specific files, functions, interfaces)
- **How** it changes (add, modify, remove — with enough detail to act without
  guessing)
- **Why** this approach (when the choice isn't obvious)
- **How to verify** it worked (a command, an observable behavior, a test)

### 5. Define Verification Strategy

End the plan with a verification section: concrete commands rather than "test
the feature", layered (unit, integration, and acceptance against the original
goal), automated where possible.

### 6. Document Risks and Mitigations

For each risk: state it in one sentence, assess likelihood and impact, and
state the mitigation and the fallback. Focus on risks that would actually
change the plan — "the API we depend on might not support batch operations"
is plan-altering; "the tests might be slow" is not.

## Output Contract

Every plan must include these sections. Use this format:

```markdown
## Scope

**Goal:** [one sentence describing the measurable outcome]

**In scope:**
- [specific change 1]
- [specific change 2]

**Out of scope:**
- [tempting but excluded item 1]

## Approach

[chosen approach with rationale — 2-4 sentences]

## Steps

1. **[Step title]**
   - Files: `path/to/file.ext`
   - Change: [what and how]
   - Verify: [command or observable behavior]

2. **[Step title]**
   ...

## Verification

- [ ] [specific verification check 1]
- [ ] [specific verification check 2]
- [ ] [acceptance criterion from the original goal]

## Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| [risk] | [level] | [level] | [action] |

## Assumptions

- [assumption 1 — something believed true but not verified]
- [assumption 2]
```

## Quality Bar

A plan meets the quality bar when:

- An implementer can execute every step without asking clarifying questions
- Every step identifies the specific files and functions involved
- The verification section contains runnable commands, not vague descriptions
- Scope boundaries are explicit — both what's included and what's excluded
- Steps are ordered so that failures are discovered early
- Risks are specific and ordered by impact, not generic or alphabetical

## Anti-Patterns

**The recursive plan.** "Step 1: Research the best approach. Step 2: Choose
an approach. Step 3: Plan the implementation." — that is not planning, it is
procrastinating. Do the research, make the choice, and write the real plan.

**The encyclopedia plan.** Excessive detail for obvious steps while leaving
complex steps vague. A boilerplate file needs a sentence; a schema migration
needs the full treatment.

**The optimistic plan.** No risks, no assumptions, no fallbacks. If your plan
has zero risks listed, you haven't thought hard enough about what could go
wrong.

## Critical Rules

1. **Never defer design decisions to the implementer.** If a step requires a
   choice (which data structure, which API, which error handling strategy),
   make that choice in the plan. The implementer should execute, not decide.

2. **Never plan on assumptions about code you haven't read.** If the plan
   involves changing a module, read that module first. Plans built on
   imagined code structures are fiction.

3. **Always include verification.** A plan without verification is a wish
   list.

4. **Keep plans proportional to the work.** A five-minute fix doesn't need a
   fifty-step plan. Match the depth of planning to the complexity and risk of
   the work.
