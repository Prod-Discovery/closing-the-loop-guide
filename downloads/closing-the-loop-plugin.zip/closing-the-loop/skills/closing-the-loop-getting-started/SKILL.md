---
name: closing-the-loop-getting-started
description: "Plugin-wide orientation for Closing the Loop. Checks which tracker/Figma connectors are visible and whether setup has run, explains the three lanes (discovery, the handover seam, engineering delivery), and hands the user the one phrase that starts their lane. Use when the user says 'what is this plugin', 'what can this do', 'help me get started', 'where do I start', 'what skills do I have', 'what's installed', or asks why a skill can't see their Jira or Linear."
trigger: [what is this plugin, where do I start, help me get started, what skills do I have, what can this do, whats installed]
license: Apache-2.0
---

# Getting Started with Closing the Loop

You've installed a plugin that covers the whole arc a feature travels — from raw customer signal, through
a validated prototype, across the PM→engineering seam, into implemented and reviewed code. It's three
lanes and one seam between them, and you almost certainly only need one lane today.

Your job in this skill: check the prerequisites are actually in place, find out which lane the user is in,
and hand them one phrase. Don't tour all 71 skills.

**How they run things** — say this once, early, because nothing else in the docs establishes it: type `/`
and pick from the menu (skills are namespaced, e.g. `/closing-the-loop:closing-the-loop-setup`), or just
describe what they want in plain English. Both work; the second is what the skills are tuned for.

## What this plugin is

Three lanes, joined by a configurable seam:

```
   [DISCOVERY ENGINE]            [HANDOVER BRIDGE]              [ENGINEERING DELIVERY]
 PM / Designer · no code   →   PM/Dev hybrid · the seam   →   Developer · full code access
 Sense & Shape (stages 0–6)    Intent ↔ reality (stage 7)    Build & deliver (plan→release)
        discovery-*                configured path                     v-*
                         \              |              /
                          └──  closing-the-loop  ──┘   (master orchestrator)
```

- **Discovery** turns customer signal into a scored opportunity, a PRD, and a working prototype.
- **The seam** turns a ticket into something a developer (or a coding agent) can actually build — grounded
  in the real codebase, not just the intent.
- **Delivery** takes it from plan to implementation to review to release.

It's a **starting point, not a prescription** — meant to be run on a real feature, stress-tested, and
adapted.

## How to Start

> **When the user is ready to act, not just orient:** hand over to `closing-the-loop-start`
> ("Start Closing the Loop") — it runs the full readiness detection, shows the journey map, and
> routes them into the loop with an explicit A/B/C choice. This skill explains; that one moves.

### Step 1: Check what's actually connected

**Do this before talking about lanes.** This plugin ships no connectors — it drives the tracker through an
MCP server the user provides — so a missing connector is the single most common reason a first run fails,
and it fails late, after they've invested a session.

Report what you can see, by name:

- **Tracker** — an Atlassian MCP server (Jira, and Confluence if they use it), or a Linear MCP server or
  `LINEAR_API_KEY` in the environment.
- **Figma** — a Figma MCP server. Only the `figma-*` and Code Connect skills need it; say so rather than
  implying it's required.
- **`gh`** — needed by the delivery lane (most `v-*` skills invoke it). Worth checking only if they're
  heading into delivery.

**If no tracker connector is connected**, say so plainly, don't pretend setup will fix it, and give the
actual command:

> I can't see a Jira or Linear connector from this session, and this plugin ships none — Atlassian, Linear,
> and Figma each maintain their own. Install the one you use:
> `/plugin install atlassian@claude-plugins-official` (or `linear@…`, or `figma@…` for the design skills).
> `claude-plugins-official` ships with Claude Code. On desktop/web use your claude.ai connector settings
> instead; in Cowork, **Customize → Connectors**.

If a connector *is* present but its tools report needing authentication, that's connected-but-unauthorized
— they need to complete its OAuth flow, not reinstall anything. And if they already have a connector for a
service, tell them **not** to add a second: duplicate servers mean duplicate tool names.

Then offer the honest alternative: **the discovery lane needs no connector at all** (stages 0–6 write
files, not tracker items), so they can start there today and connect before publishing a ticket.

### Step 2: Check whether setup has run

Read `~/.config/closing-the-loop/config.json`.

**If it's missing**, say so plainly and offer to run setup first — every tracker-touching skill reads it,
so skipping it means being asked the same questions mid-workflow:

> Nothing is configured yet. Want me to run **`closing-the-loop-setup`** now? It's one credential-safe
> pass — your tracker, where requirements live, your handover path, and your default backlog shape. No API token
> goes through the chat.

**If it exists**, report the settings back in one short line so the user knows what they're working with —
tracker, `handoverPath`, default backlog shape (`backlogMode`), and `requirementsSurface` when it differs from the tracker. Never
print anything from `~/.netrc`.

Setup isn't a hard prerequisite for discovery (stages 0–6 write to the filesystem, not a tracker), so if
the user is clearly heading into discovery, mention setup and move on rather than blocking.

### Step 3: Work out which lane they're in

Ask, or infer from what they've already told you:

| They have | Their lane | Hand them |
|---|---|---|
| Customer signal, no feature defined yet | **Discovery** | "Run the full discovery to prototype workflow" |
| A ticket that needs to become implementable | **The seam** | "Create a handover from `<KEY>`" |
| A ticket that's ready to build | **Delivery** | "Take `<KEY>` to a PR" |
| A codebase module they need to understand first | **The seam** | "Document `<module>`" (`handover-codebase-discovery`) |
| No idea, or they want the whole arc driven | **All three** | "Close the loop on `<KEY>`" |

The last row is `closing-the-loop`, the master orchestrator. It detects where the feature already is and
sequences from there — the safe answer when the lane genuinely isn't clear.

**Two things worth saying out loud, because people assume otherwise:**

- You do **not** have to start at discovery. The bridge runs without a prototype; declared feature work is
  a first-class path, not a degraded one.
- The seam is not a document-generation step you can skip. It's where intent meets the actual code.

### Step 4: Check the repo has agent context (delivery and seam lanes only)

If the target repo has no `AGENTS.md` or `CLAUDE.md`, say that running `v-setup-agent-context` once — its
First-Time Bootstrap path — is the difference between a handover grounded in the team's real conventions
and a generic one. Then continue; it's a recommendation, not a gate.

### Step 5: Hand off

Invoke the lane's entry skill, or state the phrase and stop. Do not narrate the other two lanes further —
the user can come back.

## Entry points

The ones worth knowing. The rest are discoverable by typing `/` for the slash menu, or in
`docs/skills.md`.

| Skill | Start here when |
|---|---|
| `closing-the-loop` | You want the whole arc driven end to end |
| `closing-the-loop-setup` | First run on this machine, or changing tracker/path/default backlog shape |
| `discovery-to-prototype-engine` | Customer signal, no feature yet |
| `discovery-getting-started` | You want the discovery stages explained in detail |
| `discovery-create-tracker-issue` | Discovery validated; publish it as the handoff ticket |
| `handover-shape-feature` | Context-first: make a live ticket implementable |
| `handover-workflow` | Governed: run the bridge end to end and hold at the gate |
| `prepare-amigo-session` | Governed pre-gate: walk the breakdown together before sign-off |
| `handover-deliver-epic` | Epic-shaped feature, either path: walk the projected children one at a time |
| `v-develop-feature` | A ticket is ready and you want it built |
| `v-ticket-to-release` | A ticket is ready and you want it built *and* released |
| `v-setup-agent-context` | The repo has no `AGENTS.md` / `CLAUDE.md` yet |

## Where the docs are

- **`docs/getting-started.md`** — the full walkthrough, step by step, including every prerequisite.
- **`docs/setup.md`** — the four setup questions with what each choice costs, the config schema, and
  troubleshooting.
- **`docs/glossary.md`** — `D-n`, `AC-n`, `<KEY>`, Gherkin, amigo, brownfield, the config keys. Link the
  user here rather than explaining notation inline.
- **`docs/pilot-guide.md`** — what a first real run feels like and where it's sharp.
- **`KNOWN-ISSUES.md`** — verified constraints. Check here before reporting something.

## Sending feedback

Two routes, because the two lanes have two maintainer teams. Route by what the feedback is *about*, not by
who's speaking:

- **"feedback on discovery"** → discovery stages 0–6. Anonymous: 1–5 rating plus an optional comment.
- **"feedback on the delivery skills"** → the `v-*` skills **and** the handover bridge. Free-form, with an
  optional name/email.

A bare "give feedback" belongs to neither — ask which lane first. First impressions count; two minutes of
poking around is worth reporting.

## Quality Bar

A run meets the bar when the user leaves with **one phrase to say next**, knows which connectors are
actually visible and which are missing, knows whether setup has run, and was not handed a tour of skills
irrelevant to their lane. It fails if it enumerated all 71 skills, invented a workflow that isn't in the
plugin, printed anything from `~/.netrc`, claimed a lane is ready when its connector is absent, or left the
user still asking "so what do I do?".

## Triggers

| To... | Say... |
|-------|--------|
| Get oriented | "What is this plugin?" / "Where do I start?" / "Help me get started" |
| See what's installed | "What skills do I have?" / "What's installed?" |
| Understand the discovery stages specifically | "Getting started with discovery" |
| Configure the plugin | "Set up Closing the Loop" |
| Have the whole arc driven | "Close the loop on `<KEY>`" |
