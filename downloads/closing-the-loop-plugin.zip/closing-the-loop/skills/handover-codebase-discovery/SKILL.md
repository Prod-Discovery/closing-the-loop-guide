---
name: handover-codebase-discovery
description: Discovers an existing codebase component and produces a sourced, PM/BA/tech-lead-readable reference — behaviour, public surface, conventions, hard constraints, and risks. Detects the stack first, then reads the actual code (never inferring from filenames). Use when capturing brownfield reality before building on a module, especially as the handover-bridge input that feeds the Engineering Brief's constraints, risks, and component decisions.
trigger: [discover the codebase, document a module, capture brownfield context, surface conventions, hard constraints for handover]
license: Apache-2.0
---

# Codebase Discovery (handover bridge)

The brownfield-context capture step of the discovery-to-delivery bridge. Given one component — a service, module, feature, or package — it discovers how that component actually behaves and what it constrains, then writes a sourced reference document aimed at non-engineers as much as engineers.

It is the counterpart to greenfield discovery: where the prototype documents *intended* behaviour, this skill documents *existing* behaviour. Its output feeds the handover package directly — Hard Constraints, Known Risks, and Surface Conventions become the Engineering Brief's constraints, risks, and component decisions, so engineering does not re-derive the codebase's reality by hand.

The discipline that makes it useful is the same one that makes it hard: **every claim is sourced from code that was actually read.** A reference full of plausible-sounding behaviour is worse than no reference — it gets trusted, then breaks at the framework boundary.

## When to Use

- Before building on an unfamiliar module, when you need its behaviour, conventions, and load-bearing constraints in one place.
- As the brownfield prerequisite for a handover — run it first, then the handover package reads the result (it pairs with `discovery-component-mapper`, which maps prototype UI to the surfaces this skill documents).
- To pin down the conventions a *new* surface must follow (modal, endpoint, export, job) so the next change lands consistently with what's already there.

Do **not** use it to:

- Audit a whole system's architecture — stay scoped to the one component requested.
- Document a greenfield design that has no code yet — there is nothing to source from.
- Hand over prototype code — that is intent documentation, handled elsewhere in the bridge.

## Workflow

Track progress through the steps with a TODO list.

### Step 0: Detect the ecosystem

Before locating anything, identify the project's stack so every later step uses the right conventions. Read what is actually in the repo — do not assume a layout. Look for:

- **Language / ecosystem** — from the manifest or lockfile present (e.g. a JS/TS `package.json`, a PHP `composer.json`, a Python `pyproject.toml`/`requirements.txt`, a Go `go.mod`, a Rust `Cargo.toml`, a Java/Kotlin `pom.xml`/`build.gradle`, a C# `*.csproj`, a Ruby `Gemfile`, an Elixir `mix.exs`).
- **Framework markers** — from manifest dependencies or config files.
- **Source roots** — wherever this project puts code (`src/`, `lib/`, `app/`, `internal/`, `pkg/`, or framework-specific locations).
- **Test, config, and docs conventions** — the directories and filename patterns this project actually uses.
- **Primary documentation language** — scan the README and existing docs; the output must match that language, not default to English.

Record the detected profile (language, framework, source roots, test dir, config dir, docs dir, doc language) and carry it into every later step.

### Step 1: Locate the relevant code

Search within the detected source roots — never pattern-match against hardcoded paths. Find and read whichever of these exist (skip what doesn't apply):

- **Main implementation** — the file(s) implementing the component; note approximate size in the most meaningful metric for the language (LOC, function count, public-export count).
- **Dependencies** — imported modules, injected services, base classes/interfaces, traits/mixins.
- **Composition / wiring** — how the component is assembled (DI config, factory, bootstrap, module registration, framework provider).
- **Data layer** *(if data-backed)* — domain objects, schemas, ORM models, repositories, migrations.
- **Entry points** *(if applicable)* — HTTP handlers, route definitions, RPC methods, CLI commands, queue consumers, scheduled jobs.
- **Coupled frontend** *(only if present)* — components that consume the feature.
- **Tests and configuration** — using the conventions detected in Step 0.

### Step 2: Analyze

Extract, from what you read:

- **Purpose & responsibility** — the business problem it solves; what's in and out of scope.
- **Public surface** — exported operations with signatures and contracts, in the language's own documentation idiom (don't translate it into another style).
- **Business rules** — validation, calculations, invariants.
- **State** *(if any)* — whether it keeps state between interactions; if so, the possible states, what triggers each transition, and what callers must know. Skip entirely if stateless.
- **Data flow** — entry → transformation → persistence → output.
- **Error model** — describe the model the project *actually uses*; don't force an error-code table onto a project that has none.
- **Integration direction** — for each integration, whether this component *calls* it (outbound) or *is called by* it (inbound). This split is what makes blast radius legible. Name each inbound caller with its `file:line` — an implementer needs the exact call sites, not just "the controller".
- **Behavioral modes / variants** — the distinct modes a single entry point branches into (e.g. create vs. duplicate vs. convert vs. reverse; or a `mode`/`context`/`type` parameter that changes behaviour). These are often where most of the logic lives, yet they hide behind one method name — enumerate them, don't just list the method.
- **Operational config & test doubles** — the config that governs *running* the feature, not just its data: schedules / cron cadences (quote the actual expression), feature flags, timeouts, and any mock/fake swap (e.g. a config-gated mock of an external client) plus the fixtures or test command that exercise it without the real dependency. This is what an implementer needs to run and test the change.
- **Duplicate or legacy implementations** — when two implementations of the same thing coexist (two renderers, an old and new path, a commented-out branch) and only one is wired in. State which is *live*; editing the dead one is a silent no-op and a classic time-sink.
- **Hard constraints** — load-bearing facts a developer must not work around unilaterally (a shared table, an externally versioned endpoint, a regulatory rule in the data model). Include one only if you can point at the code or config that proves it, and record what breaks if it's violated.
- **Known risks** — what someone touching this module should watch for, derived from real signals (error patterns, coverage gaps, integration complexity, stateful edges, TODOs). Don't invent them.
- **Surfaces the next feature will touch** *(conditional)* — the user- or consumer-facing shapes an upcoming change is likely to add to or extend (modal, page, endpoint, report, export, email, notification, CLI command, job). Identify these from the feature shape the caller passed in *plus* what neighbouring code already exposes. If the change adds no new surface, skip this.

### Step 3: Generate the reference

Fill the structure in [`./references/reference-template.md`](./references/reference-template.md). It carries the full section layout, the conditional-section rules, and the sourced formatting for Hard Constraints and Surface Conventions.

Four rules govern the draft:

1. **Conditional sections are omitted when they don't apply** — never padded with "N/A".
2. **Terminology and code samples match the detected ecosystem** — use the project's own vocabulary and primary language for examples.
3. **No invented content** — every path, line number, behaviour, and constraint traces to something you read; an unsourced section is left blank with a `Not covered — no evidence in code` note.
4. **Show one worked example where behaviour is non-obvious** — for any non-trivial calculation, format, or transformation, include a concrete input→output line (drawn from the code or a unit test). One real example clarifies more than a paragraph of prose.

If an approved example reference for the detected ecosystem is available, match its tone and depth — but never copy a template literally over what the code says.

### Step 4: Save

- **Default location:** the existing docs directory detected in Step 0; fall back to `docs/` only if none exists.
- **Handover context:** when run as the brownfield prerequisite for a handover, save to `handover/[component-name]-reference.md` so it lands alongside the other handover outputs.
- **Filename:** kebab-case and descriptive (e.g. `cash-discount-reference.md`).
- **Language:** match the project's existing documentation language.

### Step 5: Adversarially self-verify, then report

Before the save is final, treat the draft as a hostile reviewer would: assume every load-bearing claim is wrong until re-checked against the code. This pass is non-optional. A reference that reads authoritative but names a table, file, or test that does not exist is *worse* than no reference, because it will be trusted — the most common and most damaging failure of a brownfield handover doc is the confident, plausible, wrong claim.

Re-check, against the actual codebase (not your memory of it):

- **Every named identifier exists.** For each table, entity, class, method, constant, config key, and route the doc names, search the codebase for that exact string and confirm it resolves. A name that is plausible but unfound is corrected or removed — never kept because it "should" exist. Table names especially: confirm them where they are *bound* (the gateway/factory or the migration), not by inferring them from a convention.
- **Every `file:line` resolves.** Spot-check the load-bearing citations — the hard constraints, the main operations, the state transitions — by re-opening the cited file at the cited line and confirming it says what the doc claims. Fix drifted line numbers; drop a citation you cannot confirm.
- **Counts are exact, never approximated.** Replace any "~N" / "about N" with a figure obtained by listing and counting the actual items (tables, public methods, actions). If you genuinely cannot enumerate it, name the set you counted and how — do not round.
- **Test-coverage claims are search-confirmed in both directions.** "Tests exist" must cite the test file(s) you found; **"no tests" must be the result of a search that came up empty** — and you state the search you ran. Never assert absence by assumption.
- **Mark the unverifiable.** Any claim you could not confirm against code stays in only if labelled inferred/unconfirmed, so the reader can tell load-bearing-and-checked from inferred.

Then report: the file path, the document size, which handover sections it informs, any section left blank for lack of evidence, and **a one-line verification note** — e.g. "identifiers, citations, counts, and test-coverage claims re-checked against the codebase."

## Output Contract

**Summary.** One line: the component documented, the detected stack, the save path, and any sections left blank for lack of evidence.

**Detail.** A markdown reference file at the save path, following the bundled template — scoped to one component, with conditional sections present only when the code warranted them.

**Handover mapping.** When run for a handover, state explicitly which Engineering Brief fields the document feeds: `Hard constraints` ← Section 12, `Risks` ← Section 13, `Component decisions` ← Sections 7, 10, and 11 (when Surface Conventions is present).

**Verification.** The checks in the Quality Bar, confirmed.

## Quality Bar

A discovery run meets the bar when:

- **Sourced** — every factual claim ties back to a file that was read; no invented behaviour, no assumed constraint, no plausible-but-unread line number. Unsupported sections are blank with a "no evidence" note, not filled with guesses.
- **Verified, not just sourced** — every named identifier (table, class, method, constant, route, config key) was re-confirmed to exist by searching the code; every count is exact rather than approximated; every test-coverage claim, present *or* absent, was search-confirmed (Step 5).
- **Stack-faithful** — terminology, code samples, and the document language match the detected ecosystem; the project's own vocabulary is preserved.
- **State documented** — if the component is stateful, the State & Transitions section exists with transitions, triggers, and caller-facing guarantees. Skipping this is the most common high-impact failure.
- **Constraints sourced** — every Hard Constraint cites a file/config and, where observable, the failure it triggers.
- **Surfaces scoped** — if present, Surface Conventions lists exactly the surfaces the next feature will touch — no system-wide audit — and each cites at least one reference implementation.
- **Direction explicit** — every integration is filed outbound or inbound, never ambiguous.
- **Scannable** — the executive summary reads in under two minutes; no placeholder text remains; conditional sections that don't apply are absent, not empty.

It fails the bar when any claim is unsourced, a stateful component ships without its state section, constraints are asserted without proof, the output reads as a system-wide architecture overview instead of one scoped component, or it **names an identifier that does not exist in the code, approximates a count it could have enumerated, or asserts "no tests" without a search**.

## Anti-Patterns

**The architecture overview.** Describing the whole system when one component was requested. Stay scoped to the target.

**The code dump.** Pasting signatures without saying what they mean in business terms. The audience includes a PM — every signature needs a "why".

**The missing state section.** Skipping State & Transitions because "it's obvious from the code". It is not obvious to the agent implementing the next feature, nor to the PM writing the brief.

**The assumed constraint.** Asserting "must use existing table X" without a file that proves it. If you can't source the constraint, omit it.

**The fabricated line number.** Citing `file:42` because it sounds plausible. Either you read line 42 and it says what you claim, or you don't cite a line.

**The confident hole-filler.** Filling a section with reasonable-sounding prose the code never supported. Leave it blank with a "no evidence" note instead.

**The stack mismatch.** Writing one ecosystem's idioms for another's project, or English-only output when the project's docs are in another language.

**The framework-defaults dump.** Listing a framework's default conventions under Surface Conventions instead of what *this* codebase chose. If the entry would apply to any project using that framework, it doesn't belong here.

**The exhaustive surface enumeration.** Documenting every surface "for completeness" instead of only the ones the next feature will touch.

**The plausible-but-absent identifier.** Naming a table, class, or constant that sounds right but isn't in the code — e.g. inferring a table name from a naming convention instead of reading the gateway or migration that binds it. Search for the exact string before you commit it to the doc; a confident wrong name is the most dangerous line in a handover.

**The approximated count.** Writing "~20 tables" when enumerating them yields 15. If it is countable, count it — an approximation reads as fact and is often wrong.

**The assumed test gap.** Declaring "no tests" without running the search that would prove it. Absence of test coverage is a search result you can show, not a default you assume.
