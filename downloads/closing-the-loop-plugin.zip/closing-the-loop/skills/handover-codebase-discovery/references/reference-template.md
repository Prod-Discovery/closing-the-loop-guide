# Reference document template

Fill this template from code you actually read. Three rules:

1. **Conditional sections** (marked) are included only when relevant — omit
   them entirely rather than filling with "N/A".
2. **Terminology and code samples match the detected ecosystem.** If the
   codebase says "module", don't rebrand it "service". Render call-site
   examples in the project's primary language and idioms.
3. **No invented content.** Every path, line number, behaviour, and
   constraint must trace to code or config you read. If you can't source
   it, leave the section blank with a `Not covered — no evidence in code`
   note. An honest hole beats a confident fabrication.

---

```markdown
# [Component Name] — Reference

> **Audience:** Product Managers, Business Analysts, Technical Leads
> **Last updated:** [date]
> **Main file / entry point:** `[path]`
> **Size:** ~[LOC, or function / public-export count]

---

## 1. Executive summary

[2–4 sentences: what the component does, why it exists, who it serves.]

| Metric | Value |
|--------|-------|
| Size | ~[LOC / functions / exports] |
| Public API surface | [count] |
| External dependencies | [count] |

**Business impact:** [1–3 bullets in plain language.]

---

## 2. Core concept

[The underlying concept and approach. ASCII/Mermaid diagram if it clarifies
flow or structure.]

---

## 3. Data model *(conditional — only if the component owns or operates on persistent data)*

| Field | Type | Description |
|-------|------|-------------|
| ... | ... | ... |

**Storage:** `[table / collection / file / topic]` — purpose and relationships.

**Key relationships:** [how entities relate.]

---

## 4. Main operations

For each significant public operation:

#### [Operation name]

- **Purpose:** ...
- **Inputs:** ...
- **Output:** ...
- **Workflow:** 1. … 2. …

**Example** (project's primary language, idiomatic call site):

```[language]
[example]
```

---

## 5. Business logic

### [Rule / behaviour]

[What it is, why it exists, how it's enforced. Include concrete worked
examples for any calculation or transformation.]

---

## 6. State & transitions *(conditional — only if the component keeps state between interactions)*

**What state means here:** [what gets remembered, and why the caller cares.]

**State machine:**

```
[ASCII or Mermaid diagram of states and transitions]
```

| From → To | Trigger | Notes |
|-----------|---------|-------|
| ... | ... | ... |

**What callers need to know:** [which transitions are observable vs internal,
and what guarantees hold across calls.]

> Agents and feature developers that only see the first interaction handle
> step 1 correctly but break on step 2/3 if state isn't documented. If the
> component is stateful, this is the highest-leverage section in the doc.

---

## 7. Dependencies

- **Internal:** **[Name]** (`[path]`) — purpose / how it's used.
- **Wiring / composition:** how this component is constructed and made
  available (the mechanism the project actually uses — DI container,
  factory, module registration, bootstrap, framework provider).
- **External integrations** *(conditional):* **[Service / API]** — what's
  exchanged, auth, transport.

---

## 8. Configuration

- **Files:** `[path]` — purpose.
- **Environment variables:** `VAR_NAME` — description, default.
- **Feature flags:** `flag.name` — effect when enabled.

---

## 9. Error handling

Describe the error model the project actually uses (exceptions, `Result` /
`Option`, error returns, tagged tuples, HTTP problem-details, …).

| Trigger | Result | How it surfaces to the caller |
|---------|--------|-------------------------------|
| ... | ... | ... |

*(Include a code/constant table only if the project defines stable codes.)*

---

## 10. Integration points

Split by direction — "who calls whom?" Outbound = this component calls them;
inbound = they call this component. The split matters for blast-radius
reasoning later.

**Outbound — services/APIs this component calls:**

| Dependency | Interface | What it's used for |
|------------|-----------|--------------------|
| [Name] | [HTTP / SDK / DB / queue / library] | [Why] |

**Inbound — entry points that call this component:**

| Caller / entry point | What it calls | Why |
|----------------------|---------------|-----|
| [Caller] (`file:line`) | [method / endpoint] | [use case] |

Inbound includes HTTP routes, RPC methods, CLI commands, queue consumers,
scheduled jobs, and any internal service that depends on this one.

**Frontend** *(conditional — only if coupled UI exists):* **[Component]**
(`[path]`) — how it consumes this feature.

---

## 11. Surface conventions *(conditional — one subsection per surface the next feature will touch; omit the whole section if no surface is added or extended)*

For each surface, capture the conventions this codebase already follows so
the next feature lands consistently. Source from 1–2 reference
implementations of the same surface type elsewhere in the codebase. Do not
invent conventions; do not list framework defaults — only what this codebase
actually does.

### [Surface — e.g. modal dialog / PDF report / REST endpoint / email template / CSV export / CLI command / cron job]

- **Reference implementations:** `[path1]`, `[path2]` *(close analogues the implementer can read directly)*
- **Structural conventions:** [markup / file layout / signature / response envelope]
- **Styling / formatting conventions:** [class system, number/date helpers, header pattern, content-type — only this codebase's choices that differ from defaults]
- **Required initialisation / wiring:** [components to register, factories to bind, routes to add, asset bundle to rebuild]
- **What goes wrong if you skip a convention:** [observable failure — "radios render browser-default", "JSON missing the envelope", "cron won't pick up", "dialog crashes on open"]

> **Stage 7:** this section feeds the Engineering Brief's `Component decisions`.
> When the next feature touches a listed surface, the implementer reads the
> convention here before writing code.

---

## 12. Hard constraints

Things that **cannot be changed without coordinated effort** across the
codebase. Each constraint must be sourced — if you can't point at the code
or config that proves it, omit it. Include **what breaks if you deviate**
whenever you can observe it. A constraint without a failure signature is a
rule; one with a signature is a warning that fires at the right moment.

> **[Constraint]** *(source: `file:line` or config key)*
> *What breaks if you skip this:* [specific error / wrong output / silent failure]
> *Unsafe alternative (avoid):* [the plausible-but-wrong shortcut — only if one exists]

Example:

> **Must use the ORM's expression wrapper for raw SQL fragments in `order()` calls** *(source: `TableGateway::selectWith()` passes strings straight to `ORDER BY`)*
> *What breaks if you skip this:* the ORM backtick-quotes the string as a column name — SQL error at runtime.
> *Unsafe alternative:* passing the constant as a plain string to `$select->order($string)`.

> **Stage 7:** this section feeds the Engineering Brief's `Hard constraints`.
> A developer reading the brief should know what they must not change
> unilaterally — and what error they'll see if they try.

---

## 13. Known risks *(conditional — only if the code signals genuine risks)*

Things a developer touching this module should watch for — sourced from
error-handling patterns, test-coverage gaps, integration complexity,
stateful edge cases, or explicit TODOs/comments. Don't invent risks.

- [Risk + why it matters + mitigation if any]

> **Stage 7:** this section feeds the Engineering Brief's `Risks`.

---

## 14. Code structure

[How the implementation is organised — modules, files, classes, layers.
Tree diagram if useful.]

- **Design patterns:** **[Pattern]** — why and how.
- **Tests:** `[path]` — scenarios covered (unit / integration).

---

## 15. Glossary

- **[Term]:** [definition].

---

## References

- Main file: `[path]`
- Related docs: `[paths if any]`
```
