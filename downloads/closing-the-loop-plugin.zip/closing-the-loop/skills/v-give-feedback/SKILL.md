---
name: v-give-feedback
description: Send feedback about the ENGINEERING side — the `v-*` delivery skills and the handover bridge — to the Visma skills maintainers: tighten wording without changing meaning, let the user stay anonymous or attach name/email, preview the payload, submit only on explicit confirmation. Use for "feedback on the delivery skills", "report a problem with the skills", "suggest an improvement", "send praise". NOT the discovery lane — that is `discovery-feedback`. On a bare "give feedback", ask which lane first.
trigger: [give feedback, send feedback, feedback on the delivery skills, feedback on the engineering skills, feedback on the handover, report a problem, suggest an improvement, tell the visma team, feature request]
license: Apache-2.0
output_contract_schema: custom
---

# Give Feedback

## Objective

Turn a user's reaction to the Visma skills into a clean, consented feedback
submission. The user owns every decision: what is said, whether their identity
is attached, and whether anything is sent at all. Nothing leaves the machine
until the user has seen the exact payload and approved it. This skill is a
faithful courier — it sharpens wording for clarity but never invents,
embellishes, or softens what the user meant.

## When to Use

- A user wants to report a bug, rough edge, or confusing behaviour in a skill
- A user has an idea or feature request for the skills
- A user wants to send praise, or found a documentation gap or inaccuracy
- A user says "feedback on the delivery skills", "send this to the Visma team", or similar
- A user says a bare "give feedback" — start here, but ask which lane first (below)

Do not use this skill for capturing a reusable lesson for future sessions
(a separate concern), or for filing an issue in a tracker the user controls —
submit there directly.

### Which lane is the feedback about?

In the Closing the Loop bundle there are two feedback routes, going to two
different maintainer teams. Route by what the feedback is *about*, not by who
is speaking:

| The feedback is about… | Skill | Destination |
|---|---|---|
| The engineering delivery skills (`v-*`) or the handover bridge (`discovery-handover-package`, `handover-*`, `create-backlog-from-brief`) | **this skill** | Visma skills maintainers — free-form, optional name/email |
| The discovery lane, stages 0–6 (customer insights, competitive landscape, opportunity scoring, PRD, component library, prototype, experiment plan) | `discovery-feedback` | Discovery engine maintainers — anonymous 1–5 rating + comment |

**On a bare "give feedback" with no lane named, ask before gathering anything** —
"Is this about the engineering/handover side, or about the discovery workflow?"
— and hand off to `discovery-feedback` if they pick discovery. A misrouted
submission reaches the wrong team and is silently dropped.

(Outside the bundle — the standalone `visma-skills` library — there is no
discovery lane and this skill covers all feedback; the question is unnecessary.)

## Endpoint

Feedback is an HTTP `POST` of a JSON body to the Visma skills feedback
collector:

```
https://moonlit-rat-12.eu-west-1.convex.site/feedback
```

If the environment variable `VISMA_SKILLS_FEEDBACK_URL` is set, use its value
instead (dev/staging override). This is the same Convex deployment that
receives install/usage telemetry, but a distinct, purpose-built route — it is
the one channel that may carry the user's identity, and only when they choose.

## Payload

A single JSON object. Required: `message`, `category`, `anonymous`. The rest
are optional and `name`/`email` are sent **only** when the user is not
anonymous.

| Field | Required | Notes |
|---|---|---|
| `message` | yes | The feedback text, in the user's voice. Non-empty. |
| `category` | yes | One of `bug`, `idea`, `praise`, `docs`, `other`. |
| `anonymous` | yes | `true` or `false` — the user's choice. |
| `name` | only if not anonymous | The name the user typed. Omit when anonymous. |
| `email` | only if not anonymous | The email the user typed. Omit when anonymous. |
| `context` | optional | What they were doing, which skill, repo — only if offered. |
| `harness` | optional | The tool in use (e.g. `claude-code`, `cursor`, `copilot`). |
| `installer_version` | optional | If known from the install. |

The server stamps the receive time and, as a safety net, drops `name`/`email`
on any submission marked `anonymous: true` — but never rely on that. Send what
the user approved and nothing more.

## Workflow

### 1. Gather the feedback

Ask the user what they would like to tell the team. Capture it in their own
words. Do not interrogate — one open question is enough. If they already stated
the feedback when invoking the skill, use that; don't make them repeat it.

### 2. Classify and enrich

- Propose a `category` (`bug`, `idea`, `praise`, `docs`, `other`) and confirm it
  fits.
- Offer to tighten the wording for clarity — fix grammar, trim rambling, make a
  bug report concrete. Show the tightened version and keep the user's meaning
  and voice. If they prefer their original words, use them verbatim.
- Optionally ask one light question that would make the feedback actionable
  (for a bug: what they were doing when it happened; for an idea: the problem it
  solves). Put any answer in `context`. Never pad the message with invented
  detail.

Enrichment is clarity, never substance. If you are unsure whether a change
alters meaning, leave the original.

### 3. Choose anonymity

Ask, plainly: **send this anonymously, or attach your name and email so the
team can follow up?**

- **Anonymous** → set `anonymous: true`; do not collect or send `name`/`email`.
- **Attributed** → set `anonymous: false`; ask for name and email. Sanity-check
  the email looks like an address (`someone@domain.tld`); if it doesn't, ask
  again rather than sending junk. State that the identity is attached only
  because they chose to.

Default to anonymous if the user is unsure or doesn't answer.

### 4. Preview the exact payload

Show the user the complete JSON object that will be sent — every field, exactly
as it will go over the wire. This is a hard gate: the preview must match the
bytes you will POST. Call out explicitly whether identity is attached.

### 5. Confirm

Ask for an explicit yes. Anything short of clear approval means do not send.
If the user wants changes, return to the relevant step and re-preview. If they
decline, stop — confirm that nothing was sent.

### 6. Send and report the outcome

POST the approved JSON to the endpoint, for example:

```sh
curl -sS -X POST "$VISMA_SKILLS_FEEDBACK_URL_OR_DEFAULT" \
  -H 'content-type: application/json' \
  -d '<the exact approved JSON>'
```

- On `200` (`{"ok":true}`): tell the user the feedback was sent, and whether it
  was anonymous or attributed.
- On a `4xx` (e.g. `400 invalid payload`): the body names the offending field —
  fix it with the user, re-preview, re-confirm, and retry. Do not loop silently.
- On a network error or `5xx`: report it plainly and offer to retry. Never claim
  success you didn't observe.

## Output Contract

`output_contract_schema: custom` — this skill submits a payload rather than
producing a markdown report. A completed run reports:

- **What was sent** — the final JSON payload (or a clear statement that nothing
  was sent because the user declined).
- **Anonymity** — whether the submission was anonymous or carried name/email.
- **Outcome** — the HTTP status observed and what it means (sent / rejected /
  failed), with the next step if it wasn't accepted.

## Quality Bar

A feedback submission meets the bar when:

- The message reflects what the user actually meant — clarified, never
  fabricated or embellished.
- The category is accurate.
- The anonymity choice is the user's, explicitly made; identity is attached only
  when they opted in, and never when they chose anonymous.
- The user saw the exact payload and explicitly approved it before sending.
- The reported outcome matches the real HTTP response — no claimed success
  without a `200`.

## Anti-Patterns

**The interrogation.** Turning one piece of feedback into a questionnaire.
Gather what's needed, enrich lightly, and get out of the way.

## Critical Rules

1. **Never send without explicit confirmation of the exact payload.** The
   preview the user approves must match what is POSTed, byte for byte.
2. **Anonymity is absolute.** When the user chooses anonymous, never collect or
   send `name`/`email` — not even "just in case". Default to anonymous when
   the choice is unclear.
3. **Never fabricate or embellish.** Enrichment fixes clarity only — never
   inflate mild annoyance into a scathing report or polish a complaint into
   praise. When in doubt, keep the user's original words.
4. **Never include secrets or unrelated personal data.** Send only the feedback
   and the contact details the user knowingly provided.
5. **Report the true outcome.** Surface the HTTP status; never claim a send
   succeeded unless you saw a `200` — a timeout or `5xx` is reported as what
   it is, with an offer to retry.
6. **Respect the endpoint override.** Use `VISMA_SKILLS_FEEDBACK_URL` when set,
   otherwise the default route above.
