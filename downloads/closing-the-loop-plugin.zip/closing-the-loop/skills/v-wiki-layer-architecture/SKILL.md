---
name: v-wiki-layer-architecture
description: Generate the architecture audience layer for a wiki — system overview, components, data flows, integration points, deployment topology, and architectural seams — from an AnalysisBundle. Use when a wiki orchestrator dispatches the architecture layer, when an audience-layered design document is needed for a repo, or when a tech lead asks "how is this system put together?" before reading code.
trigger: [generate architecture wiki, write architecture layer, system design overview, architecture audience layer, port architecture wiki layer]
license: Apache-2.0
output_contract_schema: custom
---

# Wiki Layer — Architecture

## Objective

Produce the architecture-audience content for a generated wiki — the layer
that explains how the system is put together, what flows through it, where it
plugs into the outside world, and which seams matter when you change it.

The reader is a tech lead, senior engineer, architect, or new team member
getting oriented. They are *not* contributing yet (that is the engineering
layer's job) and they are *not* deciding whether to fund the work (that is
the executive layer's job). They want a faithful map of the system as it
exists, with enough detail to make integration and design decisions without
re-reading the code.

This is the layer of the wiki most likely to render diagrams. Mark
diagram-worthy material semantically; the orchestrator's `format-output`
step turns those marks into MDX `<Diagram>` components or fenced mermaid
blocks per the output format.

## When to Use

- A wiki orchestrator is dispatching audience layers and architecture is
  selected (always-emit per the design — every repo gets this layer)
- Someone needs a structured architecture description of a repo before
  diving into code (onboarding, integration scoping, design review)
- A downstream consumer wants component, data-flow, or integration-point
  data extracted from an `AnalysisBundle`

Do not use this skill when:

- The reader needs setup, contribution patterns, or gotchas — that is
  the engineering layer
- The reader needs business framing or strategic shape — that is the
  executive layer
- A free-form chat answer about one specific component is what is wanted
  — read the code directly

## Inputs

The skill is invoked with:

- `bundle` (required): an `AnalysisBundle` produced by the `v-analyze-repo`
  skill — its `repo`, `fileStructure`, `frameworks`, `dependencies`,
  `surfaces`, `signals`, and `activity` sections are the substrate
- `options` (optional):
  - `repoPath`: absolute path to the checked-out repo if cross-checking
    bundle facts is needed (e.g. opening a Dockerfile to capture the
    runtime image). The bundle is the contract; `repoPath` is only for
    spot-verification, never for re-doing the analysis pass
  - `maxComponents`: cap on enumerated components. Default: no cap;
    recommended sanity limit 12. Truncations are recorded in `warnings`
  - `maxIntegrationPoints`: cap on integration points. Default: no cap;
    recommended sanity limit 20

If `bundle` is missing or does not match the documented `AnalysisBundle`
shape, stop and report. Do not fabricate structure from a partial bundle.

## Workflow

### 1. Read the Bundle, Not the Repo

The architecture layer is a *consumer* of `v-analyze-repo`. Every fact in
the output must trace to a bundle field or to a spot-verification of a
specific file the bundle pointed to. Re-walking the tree, recounting
files, or re-running framework detection inside this skill defeats the
cost-saving rationale of the bundle. If a fact you want to assert is
not in the bundle and cannot be confirmed by opening one or two files
the bundle already references, leave it out and add a `warnings` entry
(`WARN_ARCH_INSUFFICIENT_EVIDENCE`).

### 2. Check for the Thin-Repo Signal First

Before composing sections, decide whether the bundle has enough
substance to support an architecture layer at all. A repo is **thin**
when *all* of the following hold: fewer than 3 load-bearing components
derivable from `bundle.fileStructure` and manifests, `bundle.surfaces`
empty, `bundle.signals.hasDeploymentArtifacts` false, and
`bundle.activity.commits` minimal in the configured window (e.g. <5
commits or none). Defensible default thresholds; tighten only with a
recorded reason in `warnings`.

When the thin signal fires, emit a terse layer: a one-sentence
`systemOverview.summary`, a single `WARN_ARCH_THIN_REPO`, and all other
sections recorded in `skipped` with an explicit per-section reason. Do
not emit empty component lists, fabricated diagrams, or filler prose
like "the codebase is organised into folders". This mirrors the
executive layer's `WARN_AUDIENCE_BOUNDARY_TIGHT` precedent — same
pattern (thin bundle → terse output + named warning), different
audience.

### 3. Frame the System Overview

Write a single short paragraph (2–4 sentences) that captures the system's
component view. It must answer:

- What kind of thing is this — service, library, monorepo, CLI, frontend,
  data-flow stack, infrastructure module
- Its dominant runtime shape — request/response, event-driven, batch,
  static-site, hybrid
- The primary external contract — public API, internal RPC, published
  package, deployed UI, none

Use the bundle's `frameworks`, `surfaces`, and signal booleans
(`hasFrontend`, `hasCustomerVisibleAPI`, `hasDeploymentArtifacts`,
`isPureInfra`) to pick the right framing. Do not guess the runtime shape
from the repo name.

### 4. Identify the Major Components

A component is a unit of code that has its own responsibility, a clear
boundary, and a name a reader would search for. For monorepos, components
correspond to top-level packages or apps. For single-package repos,
components correspond to top-level source directories with distinct
purposes (`server/`, `worker/`, `migrations/`, `cli/`, etc.).

For each component, capture:

- `name`: the directory or package name as it appears in the repo
- `path`: the directory path relative to the repo root
- `responsibility`: one sentence on what this component does — derived
  from its README, manifest description, entrypoint, or representative
  module names. If none is discoverable, mark `null` and add a warning
- `runtime`: the runtime it executes in (`node`, `browser`, `jvm`,
  `python`, `go`, `dotnet`, `container`, `static`, `library`,
  `unknown`) — derived from frameworks and manifest type
- `dependsOn`: a list of other component names this one calls or imports
  from, when discoverable from manifest workspace links or import paths.
  Direction matters; do not record bidirectional edges unless both
  directions actually exist

Bound the list to the load-bearing components — the ones a reader needs
to know to navigate the system. A 30-package monorepo does not need 30
entries; cluster minor utility packages and surface the cluster, not
each leaf.

### 5. Trace Data Flows

A data flow is a path data takes through the system: where it enters,
how it is transformed, where it lands, and how it exits. Pick the flows
that are load-bearing — typically 1–3 per repo:

- The primary request lifecycle for a service
- The ingestion → processing → storage path for a data-flow stack
- The build → publish lifecycle for a library
- The user-action → server-effect path for a frontend with a backend

For each flow, capture an ordered list of stages. Each stage records:

- `name`: a short label (`ingress`, `auth`, `handler`, `service`,
  `repository`, `database`, `worker`, `external API`, etc.)
- `component`: which component (from §4) owns the stage, when known
- `note`: one sentence on what happens at this stage

Mark every flow with a sibling `diagram` field whose source is a small
mermaid graph — see §9 for the exact shape. Diagrams are how this layer
earns its keep; do not skip them when the flow has more than two stages.

### 6. Capture Integration Points

An integration point is a place where the system meets something it does
not own — an external API, a database, a message broker, an identity
provider, a third-party SDK, a webhook target. For each, capture:

- `name`: the external system's name (`Stripe`, `Postgres`, `Convex`,
  `Auth0`, `S3`, `GitHub webhooks`, …)
- `direction`: `outbound` (we call them), `inbound` (they call us), or
  `bidirectional`
- `interface`: how the integration is wired (`HTTP`, `gRPC`, `webhook`,
  `SDK`, `database driver`, `queue`, `file`)
- `authModel`: a short summary (`bearer token from env`,
  `OAuth2 client credentials`, `mutual TLS`, `none`, `unknown`) — derived
  from manifest deps, surface evidence, or env-var names; use `unknown`
  rather than guessing
- `evidence`: a path to a manifest entry, surface evidence, or config
  file the reader can open to verify

Use `bundle.dependencies` and `bundle.surfaces` as the primary source.
Mark the section with a warning if the bundle's `surfaces` is empty but
the framework set strongly implies external integrations exist
(`WARN_ARCH_SURFACES_EMPTY`).

### 7. Describe Deployment Topology — When Applicable

Emit this section *only* when `bundle.signals.hasDeploymentArtifacts`
is true. When emitted, capture:

- `targets`: each runtime environment the system deploys to, derived
  from container manifests, IaC files, or workflow files
  (`Docker container`, `Kubernetes`, `serverless function`,
  `static hosting`, etc.). For each: `kind`, `evidence`, and a short
  note on the deployment trigger (e.g. tag push, manual workflow,
  merge to default branch)
- `services`: external runtime services the topology requires
  (database, cache, queue, object store) — overlap with §6 is fine, but
  here the lens is "what runs alongside us in production", not "what
  we call into"
- `diagram`: a small mermaid `graph` that shows the runtime layout —
  application nodes, shared services, traffic direction. Skip the
  diagram if there is exactly one deployment target with no shared
  services; the prose alone is clearer in that case

When the signal is false, omit the section entirely. Do not emit a
"this repo has no deployment" placeholder — the section's presence is
the signal to the reader.

### 8. Surface the Architectural Seams

This is the highest-leverage section and the easiest to skip. A seam is
a place where the system is deliberately pluggable, a place where it
deliberately is not, or a place where the contract is load-bearing for
future change. Examples:

- A registry or factory pattern that lets new providers be added without
  editing the core
- A stable interface that downstream code depends on by name
- A boundary that is currently in-process but designed to be split into
  a separate service later
- A choice that is hardcoded today and would require coordinated change
  to swap (auth provider, primary data store, deployment platform)
- A configuration surface that drives behavior across components

For each seam, capture:

- `name`: a short label
- `kind`: `extension-point`, `stable-contract`, `deferred-split`,
  `hardcoded-choice`, or `config-surface`
- `note`: 1–2 sentences on what plugs in here, or what would have to
  change to swap it, with a path the reader can open

Aim for 2–6 seams. Fewer than 2 means you have not looked hard enough;
more than 6 dilutes the signal. If the repo genuinely has none worth
calling out (rare — usually true only for trivial libraries), record
that and skip the section.

### 9. Mark Diagrams Semantically

Diagrams are emitted as structured content, not MDX. The format-output
step renders them. Use this shape wherever a diagram belongs:

```jsonc
{
  "type": "diagram",
  "format": "mermaid",
  "source": "graph TD;\n  Client --> API;\n  API --> Service;\n  Service --> DB[(Postgres)]"
}
```

Rules:

- `format` is `"mermaid"` for v1 — the only renderer the format-output
  step targets
- `source` is the diagram body, ready to drop inside a fenced mermaid
  block. Keep node labels short; long labels render unreadable
- Prefer `graph LR` for left-to-right data flows and `graph TD` for
  layered topologies. `sequenceDiagram` is allowed for request
  lifecycles when ordering matters more than topology
- Do not mark a diagram for material that is clearer in prose. A
  two-stage flow ("request hits handler, handler writes row") needs no
  diagram

The format-output step's plain-Markdown fallback wraps the same source
in a ```` ```mermaid ```` fenced block — so authoring once works for
both targets per the format prototype's contract.

### 10. Assemble the Structured Output

Emit a single JSON object matching the Output Contract. Sections that
were skipped by signal (deployment topology) are omitted entirely.
Sections that found nothing of substance are emitted as empty
collections with an explanatory `warnings` entry.

## Output Contract

The skill emits exactly one JSON object. The shape:

```jsonc
{
  "schemaVersion": "1.0",
  "audience": "architecture",
  "repo": {
    "path": "<absolute path>",
    "name": "<basename>"
  },
  "systemOverview": {
    "summary": "<2-4 sentence component view>",
    "shape": "<service|library|monorepo|cli|frontend|data-flow|infra>",
    "primaryContract": "<public-api|internal-rpc|package|ui|none>"
  },
  "components": [
    {
      "name": "<name>",
      "path": "<repo-relative path>",
      "responsibility": "<one sentence or null>",
      "runtime": "<node|browser|jvm|python|go|dotnet|container|static|library|unknown>",
      "dependsOn": ["<component name>"]
    }
  ],
  "componentDiagram": {
    "type": "diagram",
    "format": "mermaid",
    "source": "<mermaid graph of component relationships>"
  },
  "dataFlows": [
    {
      "name": "<flow name>",
      "stages": [
        { "name": "<stage>", "component": "<component name or null>", "note": "<one sentence>" }
      ],
      "diagram": {
        "type": "diagram",
        "format": "mermaid",
        "source": "<mermaid graph LR>"
      }
    }
  ],
  "integrationPoints": [
    {
      "name": "<external system>",
      "direction": "outbound|inbound|bidirectional",
      "interface": "http|grpc|webhook|sdk|database|queue|file",
      "authModel": "<short summary or 'unknown'>",
      "evidence": "<repo-relative path or manifest entry>"
    }
  ],
  "deploymentTopology": {
    "targets": [
      { "kind": "<container|k8s|serverless|static|workflow>", "trigger": "<short>", "evidence": "<path>" }
    ],
    "services": [
      { "kind": "<database|cache|queue|object-store|other>", "name": "<name>", "evidence": "<path>" }
    ],
    "diagram": {
      "type": "diagram",
      "format": "mermaid",
      "source": "<mermaid graph TD>"
    }
  },
  "seams": [
    {
      "name": "<seam name>",
      "kind": "extension-point|stable-contract|deferred-split|hardcoded-choice|config-surface",
      "note": "<1-2 sentences with a repo-relative path>"
    }
  ],
  "skipped": [
    { "section": "<section name>", "reason": "<why this section was not earned>" }
  ],
  "warnings": [
    { "code": "<WARN_CODE>", "message": "<human-readable>", "evidence": ["<path or fact>"] }
  ]
}
```

Field-level rules:

- `schemaVersion` is `"1.0"` for this skill version. Bump on contract
  changes
- `audience` is the literal `"architecture"` — this lets format-output
  route content without re-inferring the layer
- `deploymentTopology` is *omitted entirely* when
  `bundle.signals.hasDeploymentArtifacts` is false. Do not emit it as
  `null` or as an empty object — its absence carries meaning
- Every `evidence` and `path` value must reference a path that exists in
  the bundle's `fileStructure` or one of its surface entries. Never
  fabricate a path
- `diagram.source` is plain text, ready to drop inside a fenced mermaid
  block. Do not include the fence itself
- `skipped` documents sections deliberately omitted (typically when
  the thin-repo signal fired); orchestrator reads it as intentional
  silence, not failure
- `warnings` is a structured list. Stable codes, severity-ordered:
  `WARN_ARCH_THIN_REPO` (whole layer is thin — bundle too sparse to
  earn most sections; pair with populated `skipped`),
  `WARN_ARCH_INSUFFICIENT_EVIDENCE`, `WARN_ARCH_SURFACES_EMPTY`,
  `WARN_ARCH_COMPONENTS_TRUNCATED`, `WARN_ARCH_NO_DATA_FLOW_FOUND`,
  `WARN_ARCH_SEAMS_NONE`

## Quality Bar

A layer output meets the quality bar when:

- Data flows are end-to-end — they enter somewhere and they leave
  somewhere; no flow trails off in the middle
- Every diagram source parses as valid mermaid and uses short, readable
  node labels
- The component diagram and the textual component list agree — every
  edge in the diagram corresponds to a `dependsOn` entry, and vice versa
- Architectural seams identify load-bearing structure, not surface trivia
  — a seam called out is one a future change actually has to navigate
- A thin repo produces a terse layer (summary + `WARN_ARCH_THIN_REPO` +
  populated `skipped`), not a full layer of fabricated structure
- Diagrams add spatial information rather than duplicating the prose,
  and prose summarises a diagram rather than duplicating it

## Anti-Patterns

**The file-tour architecture.** Listing every top-level directory and
calling it a component map. Components have responsibilities and
boundaries; directories are a packaging mechanism. If a "component"
entry has no responsibility worth one sentence, it is not a component.

**The aspirational diagram.** Drawing the system the author wishes
existed — clean layers, well-defined seams, decoupled boundaries —
when the actual code is a 4000-line file with everything in it. The
architecture layer documents reality. If reality is messy, the
diagram and the prose say so. The seam section is where that lives.

**The unanchored diagram.** A diagram with no corresponding entries in
`components` or `dataFlows`. Diagrams must be redundant *encodings* of
structured facts, not standalone artefacts. If you cannot point to the
structured field a node represents, the diagram is fiction.

## Critical Rules

1. **The bundle is the input.** Do not re-walk the repo, re-detect
   frameworks, or re-enumerate dependencies. If the bundle is wrong,
   `v-analyze-repo` is the place to fix it — the architecture layer
   inherits from it.

2. **Every fact has evidence.** Components, integration points, and
   deployment targets all carry an `evidence` or `path` field. A reader
   must be able to open one file and verify the claim.

3. **Diagrams are structured marks.** Always emit them via the
   `diagram` shape, never as fenced text inside prose. The format-output
   step is the only place that knows whether to render `<Diagram>` or a
   fenced fallback.

4. **Stay in your lane.** Architecture ≠ engineering ≠ executive. When
   a sentence starts to describe how to contribute, fix bugs, or set
   up the project, stop — it belongs to the engineering layer. When it
   starts to describe business value or staffing, stop — it belongs
   to the executive layer.

5. **Output is structured content, never MDX.** The format-output step
   renders this layer's output to MDX. Emitting MDX directly here breaks
   the audience-skill / format-step seam and prevents independent
   improvements to either side.

7. **Bound the output.** Components, integration points, and seams are
   capped by the load-bearing rule: only what a reader needs to
   navigate the system. Truncations are recorded in `warnings`; silent
   truncation is a defect.
