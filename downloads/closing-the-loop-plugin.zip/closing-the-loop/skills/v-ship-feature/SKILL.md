---
name: v-ship-feature
description: Prescriptive, gated feature pipeline — a fixed spec → plan → tasks → implement → review → learn → commit sequence with hard gates, a scored spec gate before any planning, and a spec-vs-implementation trace at review. Use when a team wants a repeatable, gate-enforced way to ship features (rather than the adaptive v-develop-feature), when every feature must clear a measurable spec bar before work starts, or to draft spec+plan+tasks for the backlog and ship later.
trigger: [ship a feature, run the feature pipeline, gated feature workflow, spec score gate, draft a feature for the backlog, feature pipeline end to end]
license: Apache-2.0
author: PreCount team (@sjimmunck)
metadata:
  requires:
    - AGENTS.md
    - repo conventions
---

# Ship Feature

## Objective

Ship a feature through a **fixed, gated pipeline**: every phase runs in order,
every gate is checked before the next phase starts, and a failed gate loops
back rather than waving the work through. This orchestrator is deliberately
prescriptive — it trades the adaptability of v-develop-feature for
repeatability and hard quality bars, so a team gets the same shape every time.

Two distinctive gates separate this from a generic build cycle:

1. **A scored spec gate.** No planning begins until the specification clears a
   measurable bar (≥ 70/100 against the rubric below). A vague spec is the
   cheapest defect to fix and the most expensive to ship.
2. **A spec-vs-implementation trace at review.** Review does not just judge the
   diff in isolation; it walks the spec requirement by requirement and confirms
   each one is actually implemented and tested.

It composes the existing stage skills — it does not re-teach them. Invoke each
stage when its phase is reached and follow that skill's own guidance.

## When to Use

- A team wants one repeatable, gate-enforced path to ship features, with the
  same phases and the same bars every time
- Every feature must clear a measurable specification quality bar before any
  code is planned or written
- You want to **draft** a feature now (spec + plan + tasks) and hand it to the
  backlog or a tracker, then **ship** it later from that draft
- The feature is large or cross-cutting enough that a missed requirement would
  be expensive to discover late

Use a different workflow when:

- The change is a one-line fix or trivial edit — just do it directly
- You are fixing a bug — use **v-fix-bug** (diagnosis-first, failing test first)
- You want an adaptive cycle that skips stages by judgement rather than running
  a fixed gated sequence — use **v-develop-feature**
- You are preparing a release with no new feature code — use
  **v-prepare-release**

## Setup check

Before phase 1, verify `AGENTS.md` exists at the repo root and is current
(check the git log on the file). If it is missing or stale, run
**v-setup-agent-context** first — every gate below assumes the project's
conventions, type-check command, and test command are codified there.

## Modes

This orchestrator runs in one of two modes. Decide which before starting.

- **Draft mode** — run phases 1–3 (Spec → Plan → Tasks), then stop and hand the
  three artifacts to the backlog or issue tracker. No code is written. Use this
  to scope and queue work without committing implementation time now.
- **Ship mode** — run all phases. May start from scratch, or pick up a draft's
  spec + plan + tasks and resume at phase 4 (Implement). This is the default.

A draft that is later shipped must re-clear the phase-1 gate if the spec changed
since it was drafted.

## Workflow

Phases run strictly in order. Do not start a phase until the previous phase's
gate is met. A failed gate loops back to the named phase — it is not a reason
to lower the bar.

### Phase 1: Spec — invoke **v-write-spec**

Produce (or update) a specification covering five sections:

1. **Overview** — problem statement and solution summary
2. **Users & stakeholders** — who uses this, who is affected
3. **User journeys** — the happy path plus the edge cases
4. **Requirements** — UX, accessibility, contract, and operational requirements,
   each with concrete acceptance criteria
5. **Success metrics** — how we will know it works (coverage, latency,
   precision, adoption — measurable, not aspirational)

These sections extend v-write-spec's base contract — carry Users &
stakeholders, User journeys, and Success metrics as additional H2s in the
same spec document.

**Gate — scored spec (≥ 70/100):** Score the spec against the rubric below. If
a spec-scoring tool is available in the environment, use it; otherwise score
manually against the same rubric. Below 70, strengthen the weak dimensions and
re-score. Loop at most three times, then ask the user for help rather than
forcing a pass.

| Dimension | Points | Full marks when… |
|---|---:|---|
| Problem framing (Overview) | 15 | the problem and the chosen solution are both stated, not just the feature name |
| Users & stakeholders | 15 | the people who use and are affected by it are named, not implied |
| User journeys | 20 | the happy path and the realistic edge/error paths are walked step by step |
| Requirements & acceptance criteria | 30 | every requirement is testable and carries a concrete acceptance criterion |
| Success metrics | 20 | every metric is measurable with a target, not "it should feel faster" |

A spec that scores ≥ 70 but leans entirely on one dimension is not ready — no
single dimension below half its points.

### Phase 2: Plan — invoke **v-plan-work**

Turn the spec into a decision-complete implementation plan: scope boundaries,
the chosen approach with tradeoffs, steps ordered by risk, and the files and
interfaces that will change.

**Gate:** An implementer could execute every step without making a design
decision. The plan traces back to the spec — every requirement is addressed by
at least one step. No "TBD" or "decide later" remains.

For UI-facing features, invoke **v-design-frontend** here to define component
structure and states before tasks are cut.

### Phase 3: Tasks — expand the plan into an ordered task list

Break the plan into a checklist of discrete tasks, each completable in one
sitting and each independently verifiable. Order them by dependency — data and
schema first, then the service/API layer, then the interface — so that no task
depends on one listed after it.

**Gate:** Every task is actionable in one sitting and has a clear done
condition. The task order respects dependencies.

> **Draft mode stops here.** Hand off the spec, plan, and task list (e.g. as one
> tracker issue with three segments) and end the run. Resume in ship mode later.

### Phase 4: Implement — invoke **v-implement-code**

Execute the tasks in order, smallest correct diff per task, matching existing
conventions. Write tests alongside behavior changes; for test-first work
invoke **v-run-tdd**.

**Gate:** Every task is done. The project's type-check passes. Focused tests for
the changed code pass. The diff contains only what the tasks called for — no
unrelated "while I'm here" changes.

### Phase 5: Review — invoke **v-review-changes** + spec trace

Review the full changeset for correctness, security, performance, and
maintainability. Then run the **spec trace**: walk the phase-1 spec requirement
by requirement and confirm each one is implemented and covered by a test. A
requirement with no corresponding code or test is a blocking finding, even if
the diff itself is clean.

**Gate:** No blocking findings remain, and every spec requirement traces to
implementation and a test.

**Loop-back:** Implementation defects, security issues, or uncovered
requirements send the work back to **phase 4**. After fixing, re-run this phase.

For high-stakes changes — auth, payments, data migrations, public API contracts
— additionally invoke **v-scored-code-review** for a harder verdict before
committing.

### Phase 6: Learn — invoke **v-capture-learning**

Capture durable lessons: non-obvious patterns, gotchas worked around,
architectural decisions and their rationale. Default to capturing — most
features teach something.

### Phase 7: Commit — invoke **v-prepare-commit**

Prepare a clean, well-messaged commit (or sequence) containing only
feature-related changes, following the project's commit conventions.

**Gate:** The commit is clean, scoped, and explains why, not just what.

## Output Contract

### Summary

- **Feature:** [one-sentence description of what shipped]
- **Mode:** [draft — stopped after tasks | ship — full pipeline]
- **Gates cleared:** [spec score, plan trace, type-check, spec trace, commit]

### Detail

- **Spec:** [the five sections + the final spec score, e.g. "82/100"]
- **Plan:** [scope, approach, step breakdown — traced to spec requirements]
- **Tasks:** [N completed / M total, in dependency order]
- **Implementation:** [files changed, with rationale]
- **Review:** [findings addressed; spec-trace result — every requirement → code + test]
- **Learnings:** [lessons captured — or "No notable learnings"]
- **Commit:** [message(s) and structure]

For a draft run, Detail stops at Tasks and records where the artifacts were
handed off.

### Verification

| Check | How | Result |
|---|---|---|
| Spec score | rubric (≥ 70) | ✅ [score] |
| Plan trace | every requirement has a step | ✅ pass |
| Type-check | project's type-check command | ✅ pass |
| Focused tests | project's test command | ✅ pass |
| Spec trace | every requirement → code + test | ✅ pass |

### Follow-ups

- [items deliberately deferred, with rationale]
- [known limitations or technical debt taken on]
- "None" if the feature ships fully complete

## Quality Bar

A ship-feature run meets the bar when:

- The spec cleared the scored gate (≥ 70) **before** planning began — not
  back-filled afterward
- Every phase gate was checked before the next phase started
- The plan traced to the spec, and the spec trace at review confirmed every
  requirement reached implementation and a test
- Loop-backs were honored: defects and uncovered requirements were fixed at the
  source, not waved through
- The commit is clean and contains only feature-related changes

It fails the bar when:

- Planning or coding started against a spec that never cleared the gate
- A phase gate was skipped to save time
- Review judged the diff but never traced it back to the spec
- A failing gate was met by lowering the bar instead of fixing the work

## Anti-Patterns

**Back-filling the spec.** Writing code first, then a spec to match it. The spec
gate exists to shape the work, not to rubber-stamp it. Spec before plan, always.

**Gaming the score.** Padding one dimension to clear 70 while another is empty.
The per-dimension floor exists for exactly this; a lopsided spec is not ready.

**Diff-only review.** Reviewing the changeset in isolation and never checking it
against the spec. A clean diff that silently drops a requirement still fails.

**Skipping the trace.** Declaring review done without walking the spec
requirement by requirement. "It looks complete" is not the spec trace.

**Treating loop-backs as optional.** Acknowledging a finding and committing
anyway. A triggered loop-back returns to implementation — that is the point of
the gates.

## Critical Rules

1. **Spec clears the gate before planning.** Phase 2 does not start until the
   phase-1 spec scores ≥ 70. No exceptions, no back-filling.
2. **Run the phases in order; honor every gate.** This orchestrator is
   prescriptive by design. Do not reorder phases or start one before the prior
   gate is met.
3. **Invoke stage skills — don't re-implement them.** Each phase names a stage
   skill. Use its full guidance; this skill only sequences and gates.
4. **Review traces the spec.** Every requirement must reach implementation and a
   test. A clean diff that misses a requirement is a blocking finding.
5. **A failed gate loops back, never lowers the bar.** Fix the work at its
   source and re-run the gate.
6. **Draft mode stops after tasks.** Do not drift into implementation in draft
   mode; hand off the artifacts and end the run.
7. **Produce evidence, not claims.** Each phase emits artifacts and gate
   results. "I reviewed it" is not evidence; "all 12 requirements trace to code
   and tests" is.
