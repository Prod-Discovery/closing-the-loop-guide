---
name: v-prepare-release
description: Orchestrate release preparation by composing verification, documentation, and delivery stage skills into a coherent sequence. Use when packaging a body of work as a versioned release, when a sprint or milestone is complete and ready for formal delivery, when a hotfix needs to be released promptly, when bumping versions and tagging, or whenever the user says "prepare a release", "cut a release", or "ship this version".
trigger: [prepare a release, cut a release, ship this version, version bump and tag, create a release candidate]
license: Apache-2.0
---

# Prepare Release

## Objective

Prepare a release — from audit of accumulated changes through tagged,
documented, verified release commit — by invoking the right stage skills in
the right order. No new implementation occurs in this workflow; the emphasis
is on verification, documentation, and delivery readiness. A release is not
"bump the version and push." It is "verify that what accumulated since the
last release is correct, complete, documented, and ready for users."

## When to Use

- A body of work — a sprint, milestone, or feature set — is ready to be
  packaged and shipped as a versioned release
- A hotfix has been merged and needs to be released promptly
- The project's versioning scheme requires explicit release steps

Do not use this workflow for:
- New feature development — use the **v-develop-feature** workflow instead
- Bug fixes — use the **v-fix-bug** workflow instead, which starts with
  diagnosis
- Ongoing development work that is not ready for release
- Internal builds or CI artifacts that are not user-facing releases

## Context

Before starting the workflow, establish the foundation:

1. **Identify what is being released.** Review the commit log, merged
   branches, and closed issues since the last release for a rough picture
   of scope — the Phase 1 audit will make it precise.

2. **Determine the version.** Choose the next version number according to
   the project's versioning scheme; if unsure, the Phase 1 audit clarifies.

3. **Check preconditions.** All intended changes are merged to the release
   branch, no work-in-progress branches are expected to land, CI is green
   on the release branch, and release-blocking issues are resolved.

4. **Identify the release type.** This shapes the depth of each phase:
   - **Standard release:** Full audit, full test suite, complete changelog
   - **Hotfix release:** Narrow audit (only the fix), targeted test run,
     minimal changelog entry
   - **Major release:** Deep audit, extended testing including migration
     paths, comprehensive documentation updates

## Workflow

The workflow proceeds through 5 stages. Invoke each stage skill when you
reach its phase — do not re-implement what the stage skill already teaches.

### Phase 1: Audit Changes — invoke **v-review-changes**

This is not a code review of a single feature — it is an audit of the
complete changeset between the last release tag and current HEAD, reviewed
as a whole.

**Gate:** The change audit is complete. All included changes are
intentional, individually reviewed during development, and ready for
release. Any unintended inclusions are removed. No debug code, temporary
workarounds, or incomplete features remain in the changeset.

### Phase 2: Verify — run the full test suite

Run the project's full test command — the complete suite, not just tests
for recent changes — plus any integration, end-to-end, and smoke tests and
release-specific validation (build artifacts, package integrity). Any
failure stops the release, per the loop-back below. Do not invoke an
implementation or test-writing stage here: the changeset is frozen and this
phase only observes it.

**Gate:** All tests pass. No test failures are accepted in a release build —
flaky tests must be fixed or quarantined with documented justification before
proceeding. Test coverage has not regressed below the level at the last
release.

**Loop-back condition:** If tests reveal issues that need code changes, stop
the release process. The fix should go through the **v-fix-bug** workflow
separately, then restart the release process from Phase 1 after the fix is
merged. Do not make code changes inside the release workflow — this is a
verification workflow, not an implementation workflow.

### Phase 3: Configure Release CI — invoke **v-manage-ci**

Verify the release build configuration (version numbers, build flags,
artifact paths), release-specific steps (publishing, deployment, artifact
signing), secrets for release targets, that release tags trigger the
correct CI workflows, and that post-release automation is configured.

**Skip criteria:** Projects without CI, or releases that use the same CI
configuration as development builds, may skip this phase.

**Gate:** CI is configured to handle the release correctly. Build, publish,
and deploy steps are validated.

### Phase 4: Document the Release — invoke **v-update-docs**

This goes beyond code documentation — it includes user-facing release notes
and versioning:

- Write or update the changelog with all changes in this release, organized
  by category (features, fixes, breaking changes)
- Update version numbers in configuration files, package manifests, and
  documentation
- Update migration guides if the release includes breaking changes
- Review and update README if the release changes setup, usage, or
  requirements

**Gate:** The changelog accurately reflects all changes. Version numbers are
consistent across all files. Migration guides exist for any breaking changes.
No documentation references stale behavior.

### Phase 5: Release Commit — invoke **v-prepare-commit**

Stage the version bump, changelog, and release-related file changes only,
and create or prepare the release tag with the correct version.

**Gate:** The release commit is clean and well-messaged. The tag matches the
version. Only release-related changes are included — no feature code, no
bug fixes, no refactors in the release commit itself.

## Output Contract

A completed v-prepare-release workflow produces these sections under `## Output Contract`:

### Summary

- **Version:** [version number being released]
- **Type:** [major / minor / patch / hotfix]
- **Stages completed:** [list of stages invoked, with any skipped and why]

### Detail

Changes included:

- **Features:** [list or count of new features]
- **Fixes:** [list or count of bug fixes]
- **Breaking changes:** [list — or "None"]

Artifacts produced by each stage:

- **Audit:** [changes reviewed, any issues found and resolved]
- **Tests:** [suite results, coverage status]
- **CI:** [release configuration verified — or "N/A: no CI changes needed"]
- **Documentation:** [changelog updated, version bumped, migration guide if needed]
- **Commit:** [release commit message and tag]

### Verification

| Check | Command | Result |
|-------|---------|--------|
| Full test suite | [command] | ✅ pass |
| Build artifacts | [command] | ✅ pass |
| Version consistency | [specific check] | ✅ consistent |
| Changelog complete | [specific check] | ✅ complete |

### Follow-ups

- [items intentionally deferred to a later release]
- [post-release verifications still pending]
- "None" if the release is fully ready to ship

## Quality Bar

A release preparation workflow meets the quality bar when:

- All changes since the last release have been audited and are intentional
- The full test suite passes with no failures and no quarantined tests
  without documented justification
- Version numbers are consistent across all files that reference them
- The changelog accurately reflects every change in the release
- Breaking changes have migration documentation
- The release commit contains only release-related changes
- CI is configured to handle the release correctly
- No code changes were made during the release process — only documentation,
  version bumps, and configuration

## Anti-Patterns

**Changelog by commit log.** Dumping raw commit messages into the changelog
and calling it documentation. Users do not care about "refactored auth
module internals." They care about "added support for OAuth2 PKCE flow."
The changelog is a curated, user-facing document.

**Version roulette.** Bumping the major version for a patch fix, or shipping
breaking changes as a minor version. Version numbers are a contract with
users. Respect the versioning scheme.

**Fixing in the release.** Discovering a bug during the release audit and
fixing it inside the release workflow. This bypasses diagnosis, testing, and
review for the fix. Stop the release, fix the bug properly through the fix
workflow, merge it, then restart the release process.

## Critical Rules

1. **No code changes during release.** This is a verification and packaging
   workflow. If the audit or tests reveal a code problem, stop the release
   and fix it through the appropriate workflow. Then restart the release.
2. **Invoke stage skills — don't re-implement them.** This orchestrator
   sequences stages; it does not replace them.
3. **Full test suite, no exceptions.** Do not release with a partial test
   run, skipped failing tests, or ignored flaky tests.
4. **The changelog is for users.** Write it from the perspective of someone
   who uses the software, not someone who develops it. Group changes by
   impact (features, fixes, breaking), not by technical area.
5. **Respect the project's versioning scheme.** Version numbers are a
   contract with users.
6. **Audit everything since the last release.** A fresh, complete review of
   all accumulated changes as a whole — not a reliance on memory or
   individual reviews.
7. **The release commit is clean.** It contains the version bump, changelog,
   and documentation updates — nothing else.
