---
name: discovery-component-mapper
description: Maps every visible UI element in a validated prototype to its production equivalent — import paths for design-system stacks (via Figma MCP + Code Connect) or class names and markup patterns for bespoke stacks (via handover-codebase-discovery Surface Conventions). Produces handover/component-mapping.md that feeds Engineering Brief §7. Use when you have a validated prototype and need to resolve its UI to real production components before packaging the Stage 7 handover.
trigger: [component mapping, map prototype to production, code connect, surface conventions, before stage 7]
license: Apache-2.0
---

# Discovery Component Mapper

Resolves the gap between what a prototype *calls* a UI element and what the production codebase *actually uses*. Produces a stable `handover/component-mapping.md` table that `discovery-handover-package` reads directly into §7 (Component decisions).

This skill operates in three modes, auto-detected from what is available:

- **Mode 0 — Component inventory** (a `component-inventory.md` from `component-readiness-scan` exists): the prototype was built from the team's real components, so most elements resolve directly — the inventory already records each component's production import path. Cheapest and most precise; Code Connect not needed.
- **Mode A — Design system** (Figma + Code Connect): queries Figma MCP, resolves prototype component names to production import paths. Optional — requires a Figma Organization/Enterprise plan; never treat it as a prerequisite.
- **Mode B — Bespoke / legacy codebase** (no formal design system): reads `handover-codebase-discovery` Surface Conventions (§11) to extract production class names, markup patterns, and required JS initialisation.

Partial coverage is first-class: every element the skill cannot resolve is flagged explicitly so the Dev reviewer sees gaps before approval — not after implementation.

## When to Use

Run **after Stage 5 prototype is validated, before `discovery-handover-package`** (Stage 7). The output file feeds §7 of the Engineering Brief directly.

If no prototype exists, skip this skill — §7 is filled manually at Stage 7.

## Workflow

### Step 0: Detect operating mode

Check what is available, in priority order:

1. **`component-inventory.md` exists** (from `component-readiness-scan`, and the prototype was built by `prototype-from-components`) → Mode 0: resolve every real component directly from the inventory's import paths; the prototype's inline `SUBSTITUTE` flags and `fidelity-fixes.md` name the elements with no production equivalent yet — carry those into the table as explicit gaps with their fix pattern
2. **Figma MCP connected + Code Connect coverage on the relevant component set** → Mode A
3. **`handover-codebase-discovery` reference exists** in `handover/[module]-reference.md` with a populated §11 Surface Conventions section → Mode B
4. **Several available** → Run Mode 0 first, then Mode A, then Mode B for whatever remains unresolved (hybrid)
5. **None available** → Produce a skeleton table with all elements marked `❌ Unresolved`; tell the user to either run `component-readiness-scan`, connect Figma MCP, run `handover-codebase-discovery --surfaces=[types]`, or fill the table manually before Dev sign-off

Record the detected mode. Do not proceed silently on a fabricated mapping.

### Step 1: Extract UI elements from the prototype

Read the prototype file (HTML, JSX, or retrieved from the ticket attachment). On a **Jira** ticket the MCP returns attachment metadata only, so download the prototype's bytes via the REST routine in [`../discovery-handover-package/references/jira-attachment-download.md`](../discovery-handover-package/references/jira-attachment-download.md) (token-gated; otherwise use a local prototype path). Identify every element that will need a production equivalent:

- **Interactive controls**: buttons, links, form inputs, dropdowns/selects, checkboxes, radio groups, toggles, date pickers, file inputs
- **Layout / containers**: dialog/modal, drawer, sidebar, card, panel, accordion, tab group
- **Data display**: table, list, badge, status chip, avatar, chart, empty state
- **Navigation**: breadcrumb, pagination, stepper, back link
- **Feedback**: toast/banner, spinner/loading state, inline error, success state

For each element, record:
- **Prototype name** — what the prototype calls it (component name, CSS class, or descriptive label)
- **Visual role** — what it does (primary action, data input, status indicator, layout container, etc.)

Do not extract invisible implementation details (event handlers, data-fetching logic, computed values). Only the visible surface.

### Step 2 (Mode A) — Resolve via Figma MCP + Code Connect

For each prototype element:

1. Locate the matching Figma component (by component name or visual match)
2. Read the Code Connect annotation to get: production component name + import path
3. If the Figma component exists but has no Code Connect annotation → `⚠️ Partial`: record the Figma component name but flag the import path as unresolved
4. If no Figma component matches the prototype element at all → `❌ Unresolved`

### Step 2 (Mode B) — Resolve via Surface Conventions

For each prototype element:

1. Find the §11 subsection matching the element's surface type (e.g. "Modal dialog", "Form inputs", "Download form action")
2. Extract: production class names, required markup structure, required JS initialisation steps, reference file paths
3. If §11 does not have a subsection for a surface type the prototype uses → `❌ Unresolved`; suggest: "run `handover-codebase-discovery` on [target module/controller] with this surface type"

### Step 3: Write `handover/component-mapping.md`

Create or overwrite this file with the following structure:

```markdown
# Component Mapping — [Feature Name]

> Generated: [date] | Prototype: [path or ticket URL]
> Mode: [A — Figma Code Connect | B — Surface Conventions | A+B — Hybrid]
> Coverage: [N resolved / M total elements]

## Element Map

| Prototype element | Visual role | Production equivalent | Class / Import path | Source | Status |
|---|---|---|---|---|---|
| [name] | [role] | [component or pattern name] | `[import path or .css-class]` | [Figma CC / §11 ref path] | ✅ / ⚠️ / ❌ |

## Coverage summary

- ✅ Resolved: [N] — production equivalent confirmed from code or Figma
- ⚠️ Partial: [N] — component identified but import path or class unconfirmed
- ❌ Unresolved: [N] — no production match found; must be resolved before Dev approval

## Unresolved elements — action required before Engineering Brief sign-off

| Element | Why unresolved | Suggested action |
|---|---|---|
| [element] | [reason] | [specific action: "add Code Connect to Figma component X", "run handover-codebase-discovery on Y controller --surfaces=modal", "confirm class name with lead dev"] |
```

Leave no entry blank. Use `⚠️` with a note rather than omitting partial information.

### Step 4: Report

After saving the file, state:

- Operating mode and source used
- Coverage percentage (resolved / total)
- Any `❌ Unresolved` elements — these are a **soft block**: the Dev reviewer must confirm them before Engineering Brief §7 is approved
- If coverage is 100% ✅: confirm that §7 is ready to be populated from this file

## Output Contract

### Summary
Coverage percentage, mode used, and count of unresolved elements requiring Dev reviewer action.

### Detail
- `handover/component-mapping.md` at the path above
- Operating mode: which source was used (Figma node IDs / §11 reference file paths)
- List of surface types the prototype uses that were not covered (if any) — so the next `handover-codebase-discovery` run knows what to add

### Verification
- Every UI element visible to a user appears in the table — no silent omissions
- Every `❌ Unresolved` entry has a specific suggested action, not a vague "ask someone"
- Operating mode is declared and traceable to an actual source (file path or Figma component ID)
- The output file is at `handover/component-mapping.md` — not inlined in chat

### Follow-ups
- Unresolved elements must be confirmed by the Dev reviewer before §7 is signed off
- If Mode B was used and §11 Surface Conventions were incomplete: record which surfaces need coverage in the next `handover-codebase-discovery` run

## Quality Bar

Meets the bar when:
- Operating mode was auto-detected from real evidence — not assumed
- Coverage ≥ 80% ✅ before handing to Stage 7 (flag but do not block on lower coverage — flag it loudly instead)
- Every unresolved element has a specific, actionable next step
- No element was mapped by guessing — only by reading an actual source (Figma annotation, §11 entry, or reference file)

Fails the bar when:
- Elements are silently omitted as "obvious"
- `❌ Unresolved` entries have no suggested action
- Mode B was used but §11 did not exist — the mapping was invented from context rather than code
- The output is in chat only, not saved to `handover/component-mapping.md`
