---
name: v-build
description: Use for every code, test, doc, or dependency change once the scope or cause is known — 'implement', 'apply the fix', 'add tests', 'update the README or docs', 'upgrade a dependency', or fixing findings from v-challenge. Makes the smallest change, with its tests, docs, and verification evidence in the same change; covers TDD, frontend, browser end-to-end tests, and dependency upgrades. Not for unknown causes (v-investigate), PR comments or CI (v-ship), or review (v-challenge).
license: Apache-2.0
metadata:
  requires:
    - AGENTS.md
  author: "End-to-end testing guidance contributed by Mili Orucevic (@milior)"
---

# Build

**What is the smallest change that works, and what is the proof?**

## When to Use

- A scope from **v-scope** or a root cause from **v-investigate** exists
- **v-challenge** returned findings to fix

Not before the scope is clear: an unscoped change sprawls and cannot be
reviewed. The cause of a failure is unknown: invoke **v-investigate** first.

## Setup check

No `AGENTS.md`: find the commands from repo signals (step 6), then offer
**v-ship** (`references/agent-context.md`) to record them for next time.

## Workflow

### 1. Restate the scope

One sentence, from the scope, spec, or plan (the ticket or
`.visma-skills/specs/`): what changes, and what does not. Anything
discovered outside it becomes a follow-up, not an edit.

### 2. Read before editing

Read every file before changing it — the patterns around the change site,
its callers, its tests. The result should look like the same team wrote it.

### 3. Write the failing test first when behavior changes

When the project has tests, start from a test that fails for the right
reason — for a bug, the reproduction from **v-investigate** — then make it
pass. See `references/tdd.md`. When it has none, prove the change with the
acceptance command instead.

### 4. Make the minimal change

The smallest diff that meets the acceptance criteria: no speculative
parameters, abstractions, or adjacent clean-ups. Fix the cause where it
originates rather than guarding every place it surfaces. Handle errors or
propagate them; never swallow them. Regenerate generated files and synced
copies in the same change.

### 5. Change docs with behavior

If the change alters behavior, an interface, configuration, or a command
that docs describe, update those docs in the same change. See
`references/docs.md`.

### 6. Verify in layers

Find the commands in `AGENTS.md`, then in repo signals (manifests, CI
workflows, tool config), then ask the user. The installer's
`.visma-skills/config.yml` holds guesses; use one only when nothing else
names a command, and check it exists first. Fix each layer before moving on:

1. Types, lint, build
2. Focused tests for the changed code
3. The broader suite, for indirect breakage
4. Acceptance — each criterion from the scope, checked directly

Never weaken or delete a test to get a pass: either the test is wrong (fix
it and say why) or the code is.

### 7. Hand off

Then invoke **v-challenge** on the change yourself: the review is part of
the work, not an offer to make, and only the user can waive it. Load it
before starting any reviewer: it sets the depth by risk and briefs reviewers
from a fresh context. Don't commit here: committing is **v-ship**'s job, after the
review.

Called by a recipe or another skill's reference for one step: do that
step, return the result to the caller, and let it continue.

## References

| When | Read |
|---|---|
| Defining behavior test-first, or guarding a bug with a regression test | `references/tdd.md` |
| User-facing UI: pages, components, layouts, states, accessibility | `references/frontend.md` |
| Browser end-to-end tests: writing or debugging specs, page objects, isolation, result reports (a Playwright starter; adapt for other runners) | `references/e2e.md` (contributed by Mili Orucevic) |
| Upgrading dependencies, applying a CVE fix, resolving lockfile conflicts | `references/dependency-upgrades.md` |
| Updating READMEs, API docs, config docs, runbooks, examples | `references/docs.md` |

## Make it yours

Before step 1, read the team's `.visma-skills/project.md` if it exists.
Precedence: the user's instruction for this task, then that file and
`AGENTS.md` (or `CLAUDE.md`), then your own
`.visma-skills/local/preferences.md` — which never relaxes an approval gate
— then this skill. The layout is in **v-ship** (`references/project-settings.md`). This skill reads: the
command for each verification layer, coverage expectations, which test types
each kind of change needs, which files are generated or mirrored, and any
team reference files to load, each with its condition.

## Output Contract

### Summary

One line: what changed, and how many files.

### Detail

| File | Change | Why |
|---|---|---|
| `path/to/file` | what changed | which criterion or finding it serves |

### Verification

| Layer | Command | Result |
|---|---|---|
| Types / lint / build | … | pass |
| Focused tests | … | pass |
| Broader suite | … | pass |
| Criterion 1 | how it was checked | pass |

### Follow-ups

Discoveries deferred out of scope, or "None".

## Quality Bar

It fails when the evidence would still pass with the change reverted.

## Anti-Patterns

**The scope avalanche.** "Add a validation check" ends as a validation check,
a new error format, a refactored form, and a utility module. Each step felt
justified; the diff can no longer be reviewed with confidence.

## Critical Rules

1. **No secrets in the change.** Credentials, tokens, and keys never appear
   in code, configuration, fixtures, or comments — use the project's secret
   handling or placeholders.
2. **No new tooling inside a change.** A test framework, linter, build step,
   or dependency the project doesn't already use is the team's decision —
   propose it as a follow-up, even when it would help this change, unless
   the agreed scope names it.
