# Test-Driven Development

Read by **v-build** when behavior is defined test-first, or when a bug needs
a regression test.

Contents: Context · Workflow · Output Contract · Quality Bar · Anti-Patterns · Critical Rules

Skip it only for changes with no runtime behavior — documentation, comments,
formatting, configuration with no logic, static assets — and say why it does
not apply. Never skip silently.

## Context

Identify two commands before the first test. A **focused command** runs a
single test file or the subset relevant to the change (the inner loop — fast
feedback); a **broader command** runs the full suite or a wider scope (the
outer loop — regression confidence).

If the repo has no test framework — only a verifier script, an integration
check, a linter-style validator, or no formal gate — treat that as the test
gate: run it, capture its output as the focused- and broader-command
evidence, and report observed gaps as findings rather than fail-stop. Never
fail-stop on a missing test runner.

## Workflow

### 1. Red — Write a Failing Test

Write a test that describes the desired behavior and run the focused command.
The test must fail, and it must fail for the right reason — the assertion
itself fails because the behavior doesn't exist yet, not because of a syntax
error, missing import, or broken setup. Capture the output.

Prefer an existing test file for the module being changed; create a new one
only when the module has no tests or the behavior is a distinct concern. A
good test asserts on observable behavior — outputs, side effects, state
changes — tests one behavior per case, and has a descriptive name stating
what behavior is verified.

### 2. Green — Minimal Implementation

Write the smallest change to production code that makes the failing test
pass. Do not write the "full" implementation, optimize, or handle cases
beyond what the current test requires — untested behavior is unspecified
behavior. If you are tempted to implement more, write another test first.

Run the focused command; the test that was red should now pass. If it still
fails, debug the implementation — do not modify the test. Then run the
broader command: if other tests broke, the implementation introduced a side
effect — fix it before continuing.

### 3. Refactor — Improve Structure

With all tests green, improve structure, naming, and readability without
changing observable behavior. Make improvements in small, discrete changes
and run the focused tests after each — all must stay green. If you discover
needed behavior during refactoring, stop and note it: new behavior starts a
new red phase, never a refactor.

### 4. Repeat — Add Coverage Depth

Each cycle targets a different aspect of the behavior. For behavior changes,
the minimum is:

- One happy-path test
- One edge-case test
- One error-handling test

For critical or complex logic, increase coverage proportionally. If the green
phase used a shortcut (a hard-coded return value), the next red phase must
eliminate it.

### 5. Verify — Triage Broader Failures

If the broader command reveals failures, determine whether they are
pre-existing or caused by your changes — fix only regressions from your
work. Never accept a flaky test without investigation.

## Output Contract

Every TDD session must report the following. Use this format:

```markdown
## TDD Evidence

### Red Phase
- **Test file:** `path/to/test_file`
- **Tests added/modified:** [list of test names]
- **Focused command:** `[command]`
- **Result:** FAIL — [brief failure description]

### Green Phase
- **Files changed:** `path/to/implementation_file`
- **Change summary:** [what was implemented]
- **Focused command:** `[command]`
- **Result:** PASS

### Refactor Phase
- **Changes:** [structural improvements made, or "None — code was already clean"]
- **Focused command:** `[command]`
- **Result:** PASS

### Verification
- **Broader command:** `[command]`
- **Result:** PASS — [N tests passed, 0 failed]
- **Coverage gaps:** [known untested areas, or "None identified"]
```

## Quality Bar

A TDD cycle meets the quality bar when:

- Tests were written and observed failing before implementation began
- Test failures were caused by missing behavior, not broken setup
- The implementation is the minimum needed to pass the tests
- Refactoring did not change observable behavior
- At least one edge case or error path is covered for behavior changes

## Anti-Patterns

**The green-only loop.** Writing tests that pass immediately to generate
coverage statistics. If no test was observed failing first, there is no
evidence it can detect regressions.

**The permanent hack.** Hard-coding a return value to pass a single test and
never writing the test that forces the real implementation. Shortcuts in the
green phase are fine only while more tests are coming.

## Critical Rules

1. **Red before green.** Never write implementation code without a failing
   test that specifies the desired behavior. The test suite is the
   specification.

2. **Test behavior, not implementation.** Assert on return values, state
   changes, side effects, and outputs — not internal calls, private state, or
   execution paths. Good tests survive refactoring.

3. **Capture evidence at every phase.** Record the failing test, the passing
   test, and the broader verification. Reviewable evidence is the primary
   output of TDD alongside the code itself.
