# Documentation

Read by **v-build** when a change touches READMEs, API or configuration
docs, onboarding and setup guides, runbooks, or examples — or when docs have
gone stale.

Contents: Workflow · Output Contract · Quality Bar · Anti-Patterns · Critical Rules

## Workflow

### 1. Discover Existing Documentation

Before writing or changing anything, find what documentation exists: README
and contribution guides at the repository root, any dedicated documentation
directory, inline comments and docstrings in the changed code, configuration
files that carry documentation, onboarding and setup guides, decision
records, and generated docs. Do not assume you know the layout — different
projects organize documentation differently. Search before assuming, and
note the audience and conventions of what you find so updates match the
surrounding style.

### 2. Audit Documentation Scope

- **Map changed files to documentation.** For every file or module changed in
  the current work, identify which documentation references it — direct
  mentions (paths, function names) and indirect ones (described behavior,
  examples that exercise the changed code).
- **Check for stale references.** Search docs for renamed files, removed
  functions, changed defaults, or deprecated patterns — these are often
  missed because they are not in the diff.
- **Identify gaps.** New functionality with no documentation at all — a new
  option, command, or error message — is as important as inaccuracies.
- **Prioritize by impact.** User-facing docs (README, setup,
  troubleshooting) before internal ones.

### 3. Update or Create Content

When updating existing documentation, fix factual inaccuracies first — wrong
commands, incorrect paths, outdated parameter names — then remove content
about removed features or obsolete configurations rather than leaving it
alongside current content. Preserve the existing structure and style; do not
rewrite a section in a different voice unless the whole document is being
restructured.

When creating new documentation, start with the reader's most common
question, qualify any claim you have not verified in all cases, and link the
new content from discovery points (README, docs index, logical parent pages)
— an unlinked guide effectively does not exist.

### 4. Verify by Execution

Every piece of documentation must be verified, not assumed:

- **Run every command** shown in the documentation and confirm it produces
  the described output.
- **Test every example.** If docs reference specific signatures or return
  values, verify those match the current code. Stale examples are worse than
  no examples — they teach wrong things with the authority of documentation.
- **Check every link** — internal, external, and same-page anchors.
- **Walk the described path.** Read the docs as a new user following them
  step by step: does each step follow, are prerequisites stated, does the
  described result match what actually happens?

### 5. Record Known Gaps

Not all documentation can be written in one pass. Record remaining gaps
explicitly — what is missing and where it should live — and prioritize them
by user impact. Never write aspirational documentation: if a feature is not
built, do not document it as if it exists. Document the current state; future
documentation belongs with the future work.

## Output Contract

Add to the report in [SKILL.md](../SKILL.md):

- **Detail:** docs reviewed (including those left unchanged); for each doc
  updated or created, what changed or what it covers, and why
- **Verification:** commands tested, examples verified, and links checked,
  each pass/fail
- **Follow-ups:** documentation still needed, with priority and location

## Quality Bar

Documentation meets the quality bar when:

- Every command, example, and link has been verified to work
- The documentation describes the current behavior, not a previous or
  planned version
- The writing matches the surrounding documentation conventions
- New documentation is linked from discovery points
- Stale content has been removed or updated, not left alongside current
  content

## Anti-Patterns

**The orphan update.** Updating the primary README but missing documentation
in other locations (setup guides, inline comments, configuration docs, API
references) that also reference the changed behavior. Always search for all
references, not just the most obvious one.

## Critical Rules

1. **Verify everything by execution.** Every command, example, and link must
   be verified. Do not assume unchanged documentation is still correct.

2. **Discover before writing.** Always search for existing documentation
   before creating new content. Duplicates diverge and create conflicting
   sources of truth.

3. **Write for the current state.** Never document planned functionality as
   if it exists, and never leave removed functionality documented "for
   reference." Record gaps explicitly instead.

4. **Match the conventions.** Consistency across the project's documentation
   is more valuable than any individual improvement to style or organization.
