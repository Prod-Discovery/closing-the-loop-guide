---
name: figma-code-connect
description: Creates and maintains Figma Code Connect files that map Figma components to code snippets — framework-agnostic by design. Auto-detects the parser mode for the project. **First-class template-files** (`.figma.ts` with `instance.getString()`/`getEnum()`/`getInstanceSwap()` API) for React, plus brief notes for SwiftUI / Jetpack Compose. **HTML integration** (`figma.connect()` with framework-specific template strings) for HTML, Web Components, Angular, Vue, Svelte, Lit, Solid, Astro, and any other framework auto-detected from `package.json`. Same Figma MCP probing (`get_code_connect_suggestions`, `get_context_for_code_connect`) and same property-mapping helpers (`figma.string`, `figma.enum`, `figma.boolean`) across modes; only the template syntax differs. Use when the user mentions Code Connect, Figma component mapping, design-to-code translation, or asks to create / update `.figma.ts` / `.figma.tsx` files.
trigger: [code connect mapping, map figma to code, write a code connect template, create a .figma.ts file, design to code translation, figma component mapping]
license: Apache-2.0
disable-model-invocation: false
---

# Code Connect (multi-framework)

## Overview

Create a Figma Code Connect file that maps a Figma component to a code snippet, in **whichever framework the project uses**. The skill auto-detects the parser mode from `package.json` and routes the template-writing step accordingly. Everything else (URL parsing, Figma MCP probes, code-component identification, validation) is identical across frameworks.

### The two parser modes

| Mode | File pattern | Template API | Frameworks |
|---|---|---|---|
| **First-class template-files** | `.figma.ts` | `instance.getString()`, `getEnum()`, `getInstanceSwap()`, `getSlot()` — MCP-driven | React (TS/JS) |
| **`figma.connect()` parser-files** | `.figma.ts` or `.figma.tsx` | `figma.connect("url", "import.path", { props, example })` with framework template strings; helpers: `figma.string`, `figma.boolean`, `figma.enum`, `figma.instance`, `figma.children` | HTML, Web Components, **Angular**, **Vue**, **Svelte**, Lit, Solid, Astro, and other HTML-output frameworks; also React parser-style; also SwiftUI / Jetpack Compose |

Both modes are officially supported by Figma. Angular/Vue/Svelte all use the HTML integration with auto-detection from `package.json`. See [`references/api.md`](references/api.md) for the React template-file API quick reference and [`references/advanced-patterns.md`](references/advanced-patterns.md) for advanced React nesting patterns.

## Prerequisites

- **Figma MCP server connected** — verify that Figma MCP tools (e.g. `get_code_connect_suggestions`) are available. If not, guide the user to enable the Figma MCP and restart their MCP client.
- **Components must be published** to a Figma team library. Unpublished components cannot be Code Connected — surface this and stop if needed.
- **Organization or Enterprise plan required** — Code Connect is not available on Free / Professional plans.
- **URL must include `node-id`** — the Figma URL must contain the `node-id` query parameter.
- **TypeScript types (if TypeScript)** — `@figma/code-connect/figma-types` should be in `tsconfig.json`'s `compilerOptions.types` array.

## Step 0: Detect the framework + parser mode

Read the project root to decide which path to take. In order:

1. **Look at `package.json`** — check `dependencies` and `devDependencies`:
   - `react` (and not `next` only) → React, **first-class template-file mode** (Mode A)
   - `@angular/core` → Angular → **HTML integration** (Mode B)
   - `vue` → Vue → **HTML integration** (Mode B)
   - `svelte` → Svelte → **HTML integration** (Mode B)
   - `lit` → Lit (Web Components) → **HTML integration** (Mode B)
   - `solid-js` / `astro` / Stencil → **HTML integration** (Mode B)
   - Nothing JS-related (Swift / Kotlin / Compose codebase) → see [Native parsers](#native-parsers) note
2. **Look at `figma.config.json` `parser` field** — if it's already set (`react`, `html`, `vue`, `swift`, `compose`, `custom`), trust it; that overrides auto-detection
3. **Check file extensions** — `.tsx` / `.jsx` → React; `.vue` → Vue; `.svelte` → Svelte; `.ts` only → could be Angular or another HTML-based framework

Pick ONE mode for the project (Code Connect supports one parser per `figma.config.json`). Report the detected framework and mode to the user before proceeding.

## Step 1: Parse the Figma URL

Extract `fileKey` and `nodeId` from the URL:

| URL Format | fileKey | nodeId |
|---|---|---|
| `figma.com/design/:fileKey/:name?node-id=X-Y` | `:fileKey` | `X-Y` → `X:Y` |
| `figma.com/file/:fileKey/:name?node-id=X-Y` | `:fileKey` | `X-Y` → `X:Y` |
| `figma.com/design/:fileKey/branch/:branchKey/:name` | use `:branchKey` | from `node-id` param |

Always convert `nodeId` hyphens to colons: `1234-5678` → `1234:5678`.

## Step 2: Discover unmapped components

Call `mcp__*__get_code_connect_suggestions` with:
- `fileKey` — from Step 1
- `nodeId` — from Step 1 (colons format)
- `excludeMappingPrompt` — `true` (returns a lightweight list of unmapped components)

Handle the response:
- **"No published components found in this selection"** — the node has no published components. Tell the user to publish first, then stop.
- **"All component instances are already connected to code via Code Connect"** — everything is mapped already. Inform the user and stop.
- **Normal response** — extract `mainComponentNodeId` for each returned component. Use the resolved node ID (not the original from the URL) for subsequent steps. If multiple components are returned, repeat Steps 3–6 for each.

## Step 3: Fetch component properties

Call `mcp__*__get_context_for_code_connect` with:
- `fileKey` — from Step 1
- `nodeId` — the resolved `mainComponentNodeId` from Step 2
- `clientFrameworks` — match the detected framework: `["react"]`, `["html"]` (also covers Angular, Vue, Svelte, etc.), `["swift"]`, `["compose"]`
- `clientLanguages` — `["typescript"]` for most modern web stacks; `["javascript"]` if no TS; `["swift"]`, `["kotlin"]` for native

The response contains property definitions. Note each property's name and type:
- **TEXT** — text content (labels, titles, placeholders)
- **BOOLEAN** — toggles (show/hide icon, disabled)
- **VARIANT** — enum options (size, variant, state)
- **INSTANCE_SWAP** — swappable nested instances
- **SLOT** — flexible content regions (use `getSlot()` in templates, NOT `getInstanceSwap()`)

## Step 4: Identify the code component

Find which code component this Figma component maps to:

1. Read `figma.config.json` for `paths` / `importPaths` to see where components live
2. Search the codebase (`src/components/`, `components/`, `lib/ui/`, `app/components/`, framework-specific `app/` for Angular, `src/lib/` for SvelteKit, etc.) for a component matching the Figma name
3. Read candidate sources and compare their props/inputs interface against the Figma properties from Step 3
4. If multiple candidates match, pick the closest and explain reasoning
5. If no match, show the 2 closest candidates and ask the user

**Confirm with the user before Step 5.** Present the match: which code component, where it lives, why it matches.

## Step 5: Write the Code Connect file

This step branches by parser mode (from Step 0).

### Step 5A — First-class template-files (React)

File: `ComponentName.figma.ts`, placed alongside existing `.figma.ts` files (check `figma.config.json` `include` patterns).

Template structure:

```ts
// url=https://www.figma.com/file/{fileKey}/{fileName}?node-id={nodeId}
// source={path to code component}
// component={code component name}
import figma from 'figma'
const instance = figma.selectedInstance

const label = instance.getString('Label')
const variant = instance.getEnum('Variant', { 'Primary': 'primary', 'Secondary': 'secondary' })
const size = instance.getEnum('Size', { 'Small': 'sm', 'Medium': 'md', 'Large': 'lg' })
const disabled = instance.getBoolean('Disabled')
const icon = instance.getInstanceSwap('Icon')
let iconCode
if (icon && icon.type === 'INSTANCE') {
  iconCode = icon.executeTemplate().example
}

export default {
  example: figma.code`
    <Button
      variant="${variant}"
      size="${size}"
      ${disabled ? 'disabled' : ''}
      ${iconCode ? figma.code`icon={${iconCode}}` : ''}
    >${label}</Button>
  `,
  imports: ['import { Button } from "primitives"'],
  id: 'button',
  metadata: { nestable: true }
}
```

**Full API reference** (every `instance.*` method, interpolation rules, nested-component patterns, common pitfalls): [`references/api.md`](references/api.md). **Advanced patterns** (multi-level nesting, metadata prop passing): [`references/advanced-patterns.md`](references/advanced-patterns.md).

Key rules for this mode:
- Map every Figma property — never invent code props that don't exist on the component
- Exhaustive `getEnum` mappings — every VARIANT value listed, no unmapped values
- Strings wrap in quotes (`variant="${v}"`); instances/sections wrap in braces (`icon={${snippet}}`); booleans use conditionals
- Use `getInstanceSwap()` when the Figma property is INSTANCE_SWAP; `getSlot()` when it's SLOT — they're not interchangeable
- Always check `type === 'INSTANCE'` before `executeTemplate()` (the find* methods return `ErrorHandle` on failure, not null)
- Never hardcode child content — resolve dynamically via `executeTemplate()`

### Step 5B — HTML integration (Angular, Vue, Svelte, Web Components, HTML)

File: `ComponentName.figma.ts`, placed where `figma.config.json` `include` points.

Template structure (uses `figma.connect()`, not `instance.*`):

```ts
// url=https://www.figma.com/file/{fileKey}/{fileName}?node-id={nodeId}
// source={path to code component}
// component={code component name}
import figma from '@figma/code-connect/html'

figma.connect(
  'https://www.figma.com/design/{fileKey}/{fileName}?node-id={nodeId}',
  {
    props: {
      label: figma.string('Label'),
      variant: figma.enum('Variant', { 'Primary': 'primary', 'Secondary': 'secondary' }),
      size: figma.enum('Size', { 'Small': 'sm', 'Medium': 'md', 'Large': 'lg' }),
      disabled: figma.boolean('Disabled'),
      icon: figma.instance('Icon'),
    },
    example: (props) => /* framework-specific template string — see below */,
  }
)
```

**The `example` template differs per framework.** Property helpers (`figma.string`, `figma.enum`, `figma.boolean`, `figma.instance`, `figma.children`) are identical across all four.

#### Angular template

```ts
example: (props) => `
  <ds-button
    variant="${props.variant}"
    size="${props.size}"
    [disabled]="${props.disabled}"
    (click)="onClick($event)">
    ${props.icon ? `<ng-icon [icon]="${props.icon}"></ng-icon>` : ''}
    ${props.label}
  </ds-button>
`
```

Key Angular notes:
- Property binding: `[disabled]="..."` for bound expressions, `disabled="..."` for static strings
- Event binding: `(click)="..."` — emits literally as a string, since templates aren't executed by Code Connect
- Structural directives (`*ngIf`, `*ngFor`) — output verbatim; the developer / designer reading the snippet sees the syntax
- Two-way binding: `[(ngModel)]="..."` works the same

#### Vue template

```ts
example: (props) => `
  <ds-button
    variant="${props.variant}"
    size="${props.size}"
    :disabled="${props.disabled}"
    @click="onClick">
    ${props.icon ? `<ds-icon :name="${props.icon}" />` : ''}
    ${props.label}
  </ds-button>
`
```

Key Vue notes:
- `:disabled="..."` for bound props; `@click="..."` for events
- For Vue 3 composition API, the example shows what a template author would write in `<template>`
- If using `<script setup>`, the import section in the example can show the setup imports too

#### Svelte template

```ts
example: (props) => `
  <Button
    variant="${props.variant}"
    size="${props.size}"
    disabled={${props.disabled}}
    on:click={onClick}>
    ${props.icon ? `<Icon name="${props.icon}" />` : ''}
    ${props.label}
  </Button>
`
```

Key Svelte notes:
- Curly-brace prop binding: `disabled={...}`
- Event binding: `on:click={...}`
- No build-step ambiguity — the template string is what a developer writes in a `.svelte` file's markup section

#### Generic HTML / Web Components template

```ts
example: (props) => `
  <ds-button
    variant="${props.variant}"
    size="${props.size}"
    ${props.disabled ? 'disabled' : ''}>
    ${props.icon ? `<ds-icon name="${props.icon}"></ds-icon>` : ''}
    ${props.label}
  </ds-button>
`
```

#### Property-helper API (HTML integration)

| Figma type | Helper | Result type | Example |
|---|---|---|---|
| TEXT | `figma.string('Label')` | `string` | `figma.string('Title')` |
| BOOLEAN | `figma.boolean('Disabled')` or `figma.boolean('On', { true: 'yes', false: 'no' })` | `boolean` or mapped | conditional rendering |
| VARIANT | `figma.enum('Size', { 'Small': 'sm', 'Medium': 'md' })` | mapped value | enum binding |
| INSTANCE_SWAP | `figma.instance('Icon')` | a reference; the renderer resolves it | nested swap |
| SLOT | `figma.children('Content')` | child markup | freeform slot |

**Important constraint**: code in `example` is **not executed** — ternaries and conditionals emit verbatim into the snippet. Plan templates accordingly: keep logic minimal, prefer Figma-property-based interpolation over JS-level conditionals.

### Native parsers

If the codebase is **SwiftUI** or **Jetpack Compose**, Code Connect also supports first-class parsers. The shape mirrors the HTML integration — `figma.connect()` with `example` returning a string. Refer to the Figma docs (`developers.figma.com/docs/code-connect/swiftui/` and `compose/`) for parser-specific helpers (`@Binding`, modifier ordering for SwiftUI; `@Composable` annotation handling for Compose). The detection logic in Step 0 should route to these docs and let the user write the templates by hand for the first batch — automation of native parsers is out of scope for this skill.

## Step 6: Validate

Read the file back and check:

- **Property coverage** — every Figma property from Step 3 is accounted for in the template / `props` block. Flag any missing.
- **No invented props/attributes** — every code attribute the example emits must exist on the code component. Never invent a prop name to mirror a Figma property; omit instead.
- **Mode-appropriate API** — first-class template-files use `instance.*` API; HTML integration uses `figma.connect()` + property helpers. Don't mix the two.
- **Framework syntax** — Angular event bindings use parentheses, Vue uses `@`, Svelte uses `on:`. Double-check the binding syntax matches the detected framework.
- **No hardcoded children** — INSTANCE_SWAP / SLOT properties always resolve dynamically.
- **Required exports** — first-class mode needs `export default { example, id, ... }`; HTML mode needs the `figma.connect()` call at module top level.

If anything looks uncertain, point at [`references/api.md`](references/api.md) (React template-file API) or the Figma docs for the relevant framework.

## Worked example — Angular

URL: `https://www.figma.com/design/abc123/MyFile?node-id=42-100` · Project: Angular 18 + TypeScript

**Step 0**: Detect — `@angular/core` in `package.json` → HTML integration (Mode B).

**Step 1**: `fileKey=abc123`, `nodeId=42:100`.

**Step 2**: `get_code_connect_suggestions` returns one component with `mainComponentNodeId: "42:100"`.

**Step 3**: `get_context_for_code_connect` (with `clientFrameworks: ["html"]`, `clientLanguages: ["typescript"]`) returns: Label (TEXT), Variant (VARIANT: Primary/Secondary), Size (VARIANT: Small/Medium/Large), Disabled (BOOLEAN).

**Step 4**: Search codebase → `src/app/shared/button/button.component.ts` exports `DsButtonComponent`. Inputs: `variant`, `size`, `disabled`. Selector: `ds-button`.

**Step 5B**: Create `src/figma/button.figma.ts`:

```ts
// url=https://www.figma.com/design/abc123/MyFile?node-id=42-100
// source=src/app/shared/button/button.component.ts
// component=DsButtonComponent
import figma from '@figma/code-connect/html'

figma.connect(
  'https://www.figma.com/design/abc123/MyFile?node-id=42-100',
  {
    props: {
      label: figma.string('Label'),
      variant: figma.enum('Variant', { 'Primary': 'primary', 'Secondary': 'secondary' }),
      size: figma.enum('Size', { 'Small': 'sm', 'Medium': 'md', 'Large': 'lg' }),
      disabled: figma.boolean('Disabled'),
    },
    example: (props) => `
      <ds-button
        variant="${props.variant}"
        size="${props.size}"
        [disabled]="${props.disabled}">
        ${props.label}
      </ds-button>
    `,
  }
)
```

**Step 6**: Read back; every Figma property mapped; Angular property-binding syntax (`[disabled]="..."`) matches detected framework; no hardcoded children. ✓

## Worked example — React (first-class)

Same Figma URL, but project is React + TypeScript.

**Step 0**: Detect — `react` in `package.json`, no Angular → React, first-class template-file (Mode A).

**Steps 1–4**: Same as above except `clientFrameworks: ["react"]`. Code component is `src/components/Button.tsx` exporting `Button`, import path `"primitives"`.

**Step 5A**: Create `src/figma/primitives/Button.figma.ts`:

```ts
// url=https://www.figma.com/design/abc123/MyFile?node-id=42-100
// source=src/components/Button.tsx
// component=Button
import figma from 'figma'
const instance = figma.selectedInstance

const label = instance.getString('Label')
const variant = instance.getEnum('Variant', { 'Primary': 'primary', 'Secondary': 'secondary' })
const size = instance.getEnum('Size', { 'Small': 'sm', 'Medium': 'md', 'Large': 'lg' })
const disabled = instance.getBoolean('Disabled')

export default {
  example: figma.code`
    <Button variant="${variant}" size="${size}" ${disabled ? 'disabled' : ''}>
      ${label}
    </Button>
  `,
  imports: ['import { Button } from "primitives"'],
  id: 'button',
  metadata: { nestable: true }
}
```

**Step 6**: Validate per Mode A rules. ✓

See [`references/api.md`](references/api.md) for the full `instance.*` API surface; [`references/advanced-patterns.md`](references/advanced-patterns.md) for nested-component patterns.

## Common failure modes

- **Wrong mode for the framework.** Writing an `instance.getString()` template in an Angular project (or `figma.connect()` calls in a React project that uses the parser-based path the team already has). Always detect first (Step 0).
- **Mixed framework syntax.** Angular event binding is `(click)="..."`; Vue is `@click="..."`; Svelte is `on:click={...}`. Pasting the wrong one is a silent bug — Code Connect publishes the template as-is.
- **Treating the template as executable code.** It isn't. Ternaries, conditionals, and computed values output verbatim. Use Figma-property-driven interpolation, not runtime logic.
- **Inventing props.** The code component's interface (Angular `@Input`, Vue `defineProps`, Svelte `export let`, React `Props`) is authoritative. Never emit an attribute the component doesn't accept.
- **Forgetting `clientFrameworks` for HTML projects.** `clientFrameworks: ["html"]` is correct for Angular / Vue / Svelte / Web Components — the response is shared across HTML-output frameworks.
- **Hardcoding child instances.** Even in HTML mode, nested components use `figma.instance()` / `figma.children()` to resolve dynamically — never paste a fixed child markup.

## Companion skills

- `code-connect-setup` — one-time team bootstrap. Detects the framework, scaffolds `figma.config.json` with the right `parser` value, and chains this skill to map the first batch.
- `code-connect-coverage-audit` — weekly maintenance check. Walks both `.figma.ts` template-files AND `figma.connect()` parser-files; aware of all parser modes.
- `discovery-component-mapper` — downstream consumer. Mode A resolves prototype UI to code imports via these mappings; works regardless of which parser mode the team uses (Code Connect data is mode-agnostic at the Figma side).

## Notes for non-web frameworks

SwiftUI and Jetpack Compose are out of scope for closing-the-loop's typical product-flow use case (web products with PM/Designer → Engineering loops), but Code Connect supports them via dedicated parsers. If a team needs them: detect via codebase signals (Swift / Kotlin files, Xcode / Gradle config), set `parser: "swift"` or `"compose"` in `figma.config.json`, and write templates following the official docs. The Figma MCP integration works identically; only the example string differs.
